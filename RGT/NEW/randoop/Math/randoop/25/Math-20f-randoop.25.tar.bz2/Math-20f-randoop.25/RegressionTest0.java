import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math3.util.FastMath.max((-1.0d), (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(10.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double[] doubleArray5 = new double[] { (byte) 1, 32.0d, ' ', 32.0d, (short) 1 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = null;
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray7, doubleArray8 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, orderDirection6, doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (-1.0f), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(100);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix1, (int) ' ', (int) (short) -1, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 1L, (double) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((-1.0d), numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        try {
            double double20 = blockRealMatrix17.getEntry((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        float float1 = org.apache.commons.math3.util.FastMath.abs(1.0000001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-1.0d), (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 10.000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 10.000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483621820319939d + "'", double1 == 0.6483621820319939d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        int[] intArray21 = new int[] { (-1), 0, (short) 0 };
        int[] intArray22 = org.apache.commons.math3.util.MathArrays.copyOf(intArray21);
        int[] intArray26 = new int[] { (-1), 0, (short) 0 };
        int[] intArray27 = org.apache.commons.math3.util.MathArrays.copyOf(intArray26);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        try {
            blockRealMatrix17.copySubMatrix(intArray22, intArray26, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_ISACTIVECMA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        double double20 = blockRealMatrix17.getNorm();
        int[] intArray21 = new int[] {};
        int[] intArray25 = new int[] { (-1), 0, (short) 0 };
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray25);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = blockRealMatrix17.getSubMatrix(intArray21, intArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected row index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 40.000003814697266d + "'", double20 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix17, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray5 = new double[] { (short) 0, 0.6483621820319939d, 1.0000001f, 10.0f, (-57.29577951308232d) };
        double[] doubleArray7 = new double[] { 0.0d };
        double[] doubleArray11 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray11);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(doubleArray7, doubleArray11);
        try {
            double double14 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray5, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double29 = blockRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) (byte) 10, (double) '4', 0.0d, (double) '4', (double) 1L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor28 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor28.start((int) (short) 10, (int) (byte) 0, 0, (int) ' ', (int) (byte) 1, 0);
        try {
            double double40 = blockRealMatrix17.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor28, (int) '4', (int) (byte) 1, 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int[] intArray0 = new int[] {};
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2676506002282294E32d + "'", double2 == 1.2676506002282294E32d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 10.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (-1023));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.07608628613008d) + "'", double1 == (-10.07608628613008d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray28 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray24, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[] doubleArray6 = new double[] { (byte) 1, (-1.0d), (short) -1, 0, 1.2676506002282294E32d, 100 };
        double[] doubleArray7 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray6, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        try {
            double double22 = blockRealMatrix17.getEntry(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float1 = org.apache.commons.math3.util.FastMath.signum(1.0000001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (-1), (long) (-1023));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) (byte) 10, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (-1023), "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 10.0f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math3.util.FastMath.floor(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        org.apache.commons.math3.linear.RealVector realVector19 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17, realVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealVector realVector50 = null;
        try {
            blockRealMatrix48.setRowVector(1, realVector50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = blockRealMatrix66.scalarAdd((double) 100L);
        double[][] doubleArray69 = blockRealMatrix66.getData();
        try {
            blockRealMatrix45.setSubMatrix(doubleArray69, (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_STOPFITNESS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix17.add(realMatrix20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray3 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray3);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix4, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (byte) 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        try {
            double[] doubleArray20 = blockRealMatrix17.getColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.multiply(openMapRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray5 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray9 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray13 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray17 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (short) 10, doubleArray18, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 520");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = openMapRealMatrix2.createMatrix((int) (short) 1, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,023 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (-1898220449));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 698108194 + "'", int1 == 698108194);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(698108194, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = realMatrixFormat6.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor3 = null;
        try {
            double double4 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double[] doubleArray23 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray27 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray36 = new double[][] { doubleArray23, doubleArray27, doubleArray31, doubleArray35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray40 = new double[] { 0.0d };
        double[] doubleArray44 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray44);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equals(doubleArray40, doubleArray44);
        blockRealMatrix37.setRow((int) (byte) 0, doubleArray44);
        try {
            blockRealMatrix17.setColumn(100, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double6 = arrayRealVector5.getL1Norm();
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector2.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 1, (int) (short) 100);
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) nonSquareMatrixException2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x3) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0.54881346f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double[] doubleArray3 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray3);
        int[] intArray6 = new int[] { (short) 1 };
        int[] intArray13 = new int[] { 0, (byte) -1, (byte) 1, (-1023), 698108194, (short) 1 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix4, intArray6, intArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, 100, 1, (-1023), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix48.getRowMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int2 = org.apache.commons.math3.util.FastMath.max(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((-10.07608628613008d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(1.2676506002282294E32d, 100.50373127401788d, 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        try {
            arrayRealVector17.setEntry((int) (short) 100, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix17.getColumnMatrix((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 698108194);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.363884654445158d + "'", double1 == 20.363884654445158d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray45 = new double[] { 0.0d };
        double[] doubleArray49 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray49);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equals(doubleArray45, doubleArray49);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray45);
        try {
            blockRealMatrix42.setColumn((int) '#', doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long long1 = org.apache.commons.math3.util.FastMath.round(20.363884654445158d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 20L + "'", long1 == 20L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 23, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18966.804416187075d + "'", double2 == 18966.804416187075d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray3 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray3);
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) realMatrix4, "", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor43 = null;
        try {
            double double48 = blockRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor43, 0, (int) (short) 0, 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double[] doubleArray5 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray9 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray13 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray17 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix19.scalarAdd((double) 100L);
        double[][] doubleArray22 = blockRealMatrix19.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((-1898220449), (int) 'a', doubleArray22, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,898,220,449 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 100, (int) (byte) 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double6 = arrayRealVector5.getL1Norm();
        double[] doubleArray8 = new double[] { 0.0d };
        double[] doubleArray12 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (short) 10);
        boolean boolean17 = arrayRealVector5.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double21 = arrayRealVector20.getL1Norm();
        double[] doubleArray23 = new double[] { 0.0d };
        double[] doubleArray27 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray23, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (short) 10);
        boolean boolean32 = arrayRealVector20.equals((java.lang.Object) (short) 10);
        double double33 = arrayRealVector5.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double37 = arrayRealVector36.getL1Norm();
        double double38 = arrayRealVector36.getLInfNorm();
        double double39 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector36.mapToSelf(univariateFunction40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector2.add((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        try {
            org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector42.getSubVector((int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        try {
            blockRealMatrix17.addToEntry(23, 1, 2.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor3 = null;
        try {
            double double6 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor3, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector38 = null;
        try {
            arrayRealVector17.setSubVector(4, realVector38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math3.util.Precision.round((double) '4', 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3, 0, 0, (int) (short) 0, 698108194);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (698,108,194)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = blockRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor19, 0, (-127), (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        float[] floatArray6 = new float[] { (byte) 1, 100L, (short) 10, (byte) -1, (short) 10, ' ' };
        float[] floatArray8 = new float[] { 100 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray8);
        float[] floatArray13 = new float[] { 0.54881346f, (-1023), 100.0f };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(floatArray8, floatArray13);
        float[] floatArray21 = new float[] { (byte) 1, 100L, (short) 10, (byte) -1, (short) 10, ' ' };
        float[] floatArray23 = new float[] { 100 };
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(floatArray21, floatArray23);
        float[] floatArray28 = new float[] { 0.54881346f, (-1023), 100.0f };
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(floatArray23, floatArray28);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray13, floatArray23);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
//        double[] doubleArray20 = new double[] { 0.0d };
//        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
//        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
//        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
//        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
//        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
//        double double46 = blockRealMatrix45.getNorm();
//        double double47 = blockRealMatrix45.getFrobeniusNorm();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
//        org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix48.scalarMultiply(10.0d);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister51 = new org.apache.commons.math3.random.MersenneTwister();
//        int int53 = mersenneTwister51.nextInt((int) '4');
//        int[] intArray57 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray58 = org.apache.commons.math3.util.MathArrays.copyOf(intArray57);
//        mersenneTwister51.setSeed(intArray58);
//        int[] intArray60 = null;
//        try {
//            org.apache.commons.math3.linear.RealMatrix realMatrix61 = blockRealMatrix48.getSubMatrix(intArray58, intArray60);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
//        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertNotNull(doubleArray15);
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertNotNull(doubleArray20);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertNotNull(realMatrix25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray35);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertNotNull(doubleArray43);
//        org.junit.Assert.assertNotNull(doubleArray44);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
//        org.junit.Assert.assertNotNull(blockRealMatrix48);
//        org.junit.Assert.assertNotNull(realMatrix50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 36 + "'", int53 == 36);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(intArray58);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math3.util.FastMath.cos(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        float[] floatArray5 = new float[] { 20L, 10L, '4', (short) 100, 0L };
        float[] floatArray12 = new float[] { (byte) 1, 100L, (short) 10, (byte) -1, (short) 10, ' ' };
        float[] floatArray14 = new float[] { 100 };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(floatArray12, floatArray14);
        float[] floatArray19 = new float[] { 0.54881346f, (-1023), 100.0f };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(floatArray14, floatArray19);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(floatArray5, floatArray14);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 698108194);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.9810822E8f + "'", float1 == 6.9810822E8f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix19.walkInColumnOrder(realMatrixChangingVisitor20, 37, (int) (short) -1, 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (37)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (double) (-1023));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_CHECKFEASABLECOUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double2 = org.apache.commons.math3.util.FastMath.log((-0.5872139151569291d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 10, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray20);
        try {
            double double28 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray10, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        double[] doubleArray74 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray78 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray82 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray86 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray87 = new double[][] { doubleArray74, doubleArray78, doubleArray82, doubleArray86 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix88 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray87);
        double double89 = blockRealMatrix88.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix90 = blockRealMatrix66.multiply(blockRealMatrix88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 40.000003814697266d + "'", double89 == 40.000003814697266d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        try {
            double double55 = blockRealMatrix52.getEntry(1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor43 = null;
        try {
            double double48 = blockRealMatrix42.walkInRowOrder(realMatrixChangingVisitor43, (int) (short) 1, 0, 37, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 28.284272596161085d, 20.363884654445158d, Double.NaN, Double.POSITIVE_INFINITY, 2.0d, Double.NEGATIVE_INFINITY };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 9 is larger than the maximum (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        try {
            double double25 = array2DRowRealMatrix19.getEntry(698108194, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (698,108,194)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor49 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double50 = defaultRealMatrixPreservingVisitor49.end();
        double double51 = blockRealMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor49);
        try {
            blockRealMatrix17.addToEntry((int) (byte) 1, (int) (short) 10, 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str8 = realMatrixFormat7.getRowSeparator();
        java.text.NumberFormat numberFormat9 = realMatrixFormat7.getFormat();
        java.text.ParsePosition parsePosition10 = null;
        try {
            java.lang.Number number11 = org.apache.commons.math3.util.CompositeFormat.parseNumber("hi!", numberFormat9, parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        double[] doubleArray55 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray59 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray63 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray67 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray68 = new double[][] { doubleArray55, doubleArray59, doubleArray63, doubleArray67 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray68);
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = blockRealMatrix69.scalarAdd((double) 100L);
        double[][] doubleArray72 = blockRealMatrix69.getData();
        double[] doubleArray76 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray80 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray84 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray88 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray89 = new double[][] { doubleArray76, doubleArray80, doubleArray84, doubleArray88 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix90 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray89);
        double double91 = blockRealMatrix90.getNorm();
        double double92 = blockRealMatrix90.getFrobeniusNorm();
        double double93 = blockRealMatrix90.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix94 = blockRealMatrix69.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix90);
        try {
            blockRealMatrix45.setColumnMatrix((int) (short) 0, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x3 but expected 4x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 40.000003814697266d + "'", double91 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 28.284272596161085d + "'", double92 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 40.000003814697266d + "'", double93 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix94);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        double double20 = blockRealMatrix17.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = blockRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 40.000003814697266d + "'", double20 == 40.000003814697266d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.RealVector realVector44 = null;
        try {
            blockRealMatrix17.setColumnVector((int) ' ', realVector44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1));
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = null;
        double[] doubleArray6 = new double[] { 0.0d };
        double[] doubleArray10 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equals(doubleArray6, doubleArray10);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = cMAESOptimizer1.optimize((int) (short) 0, multivariateFunction3, goalType4, doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d };
        double[] doubleArray73 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray73);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray69, doubleArray73);
        blockRealMatrix66.setRow((int) (byte) 0, doubleArray73);
        double[] doubleArray77 = blockRealMatrix48.operate(doubleArray73);
        double[] doubleArray79 = new double[] { 0.0d };
        double[] doubleArray83 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix84 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray83);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equals(doubleArray79, doubleArray83);
        double double86 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray73, doubleArray83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray83, arrayRealVector87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        try {
            double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 698108194, 0.0f, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix19.createMatrix((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double[] doubleArray41 = new double[] { 0.0d };
        double[] doubleArray45 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equals(doubleArray41, doubleArray45);
        blockRealMatrix38.setRow((int) (byte) 0, doubleArray45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double double67 = blockRealMatrix66.getNorm();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix38.add(blockRealMatrix66);
        try {
            blockRealMatrix17.setRowMatrix((int) (byte) 100, blockRealMatrix69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 40.000003814697266d + "'", double67 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 28.284272596161085d + "'", double68 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        long long2 = org.apache.commons.math3.util.FastMath.min(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix24 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix25 = openMapRealMatrix21.add(openMapRealMatrix24);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = blockRealMatrix17.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(openMapRealMatrix25);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        try {
            double[] doubleArray21 = array2DRowRealMatrix19.getColumn((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor3 = null;
        try {
            double double6 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor3, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        try {
            blockRealMatrix17.setEntry((int) (byte) 0, (int) (byte) 100, (double) 0.54881346f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix6.multiply(realMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = openMapRealMatrix3.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double6 = arrayRealVector5.getL1Norm();
        double[] doubleArray8 = new double[] { 0.0d };
        double[] doubleArray12 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (short) 10);
        boolean boolean17 = arrayRealVector5.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double21 = arrayRealVector20.getL1Norm();
        double[] doubleArray23 = new double[] { 0.0d };
        double[] doubleArray27 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray23, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (short) 10);
        boolean boolean32 = arrayRealVector20.equals((java.lang.Object) (short) 10);
        double double33 = arrayRealVector5.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double37 = arrayRealVector36.getL1Norm();
        double double38 = arrayRealVector36.getLInfNorm();
        double double39 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector36.mapToSelf(univariateFunction40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector2.add((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double46 = arrayRealVector45.getL1Norm();
        double[] doubleArray48 = new double[] { 0.0d };
        double[] doubleArray52 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray48, doubleArray52);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52, (int) (short) 10);
        boolean boolean57 = arrayRealVector45.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double61 = arrayRealVector60.getL1Norm();
        double[] doubleArray63 = new double[] { 0.0d };
        double[] doubleArray67 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray67);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray67);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray67, (int) (short) 10);
        boolean boolean72 = arrayRealVector60.equals((java.lang.Object) (short) 10);
        double double73 = arrayRealVector45.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double77 = arrayRealVector76.getL1Norm();
        double double78 = arrayRealVector76.getLInfNorm();
        double double79 = arrayRealVector60.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction80 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = arrayRealVector76.mapToSelf(univariateFunction80);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = arrayRealVector81.append(arrayRealVector84);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix86 = arrayRealVector41.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector81);
        org.junit.Assert.assertNotNull(arrayRealVector85);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        try {
            blockRealMatrix17.setEntry(23, (int) (short) 10, 40.000003814697266d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = null;
        try {
            java.lang.String str9 = realMatrixFormat6.format(realMatrix8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double46 = arrayRealVector45.getL1Norm();
        double[] doubleArray48 = new double[] { 0.0d };
        double[] doubleArray52 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray48, doubleArray52);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52, (int) (short) 10);
        boolean boolean57 = arrayRealVector45.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double61 = arrayRealVector60.getL1Norm();
        double[] doubleArray63 = new double[] { 0.0d };
        double[] doubleArray67 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray67);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray67);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray67, (int) (short) 10);
        boolean boolean72 = arrayRealVector60.equals((java.lang.Object) (short) 10);
        double double73 = arrayRealVector45.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double77 = arrayRealVector76.getL1Norm();
        double double78 = arrayRealVector76.getLInfNorm();
        double double79 = arrayRealVector60.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        try {
            org.apache.commons.math3.linear.RealVector realVector80 = blockRealMatrix38.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.000001f, (java.lang.Number) (-1), true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        java.lang.String str6 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor53 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double54 = defaultRealMatrixPreservingVisitor53.end();
        double double55 = defaultRealMatrixPreservingVisitor53.end();
        double double56 = blockRealMatrix50.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor53);
        org.apache.commons.math3.exception.util.Localizable localizable57 = null;
        org.apache.commons.math3.exception.util.Localizable localizable58 = null;
        double[] doubleArray62 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray66 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray70 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray74 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray75 = new double[][] { doubleArray62, doubleArray66, doubleArray70, doubleArray74 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix76.scalarAdd((double) 100L);
        double[][] doubleArray79 = blockRealMatrix76.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray79);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable58, (java.lang.Object[]) doubleArray79);
        org.apache.commons.math3.exception.ZeroException zeroException82 = new org.apache.commons.math3.exception.ZeroException(localizable57, (java.lang.Object[]) doubleArray79);
        try {
            blockRealMatrix50.setSubMatrix(doubleArray79, 100, (-1898220449));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix17.walkInRowOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            boolean boolean4 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor28 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double33 = blockRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor28, 0, (int) (short) 100, (int) (short) 100, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 18966.804416187075d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = openMapRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor7, (-1023), 698108194, (int) '4', (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(23, 37);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) -1);
        int int2 = incrementor1.getMaximalCount();
        try {
            incrementor1.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6483621820319939d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6483621820319938d + "'", double2 == 0.6483621820319938d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1), 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 20L, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = blockRealMatrix38.scalarAdd((double) 100L);
        double[][] doubleArray41 = blockRealMatrix38.getData();
        try {
            array2DRowRealMatrix19.setSubMatrix(doubleArray41, 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str8 = realMatrixFormat7.getColumnSeparator();
        java.text.NumberFormat numberFormat9 = realMatrixFormat7.getFormat();
        java.text.ParsePosition parsePosition10 = null;
        try {
            java.lang.Number number11 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat9, parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (-1), (double) 52, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.0d + "'", double3 == 50.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray19 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray24 = new double[] { 0.0d };
        double[] doubleArray28 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray28);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equals(doubleArray24, doubleArray28);
        blockRealMatrix21.setRow((int) (byte) 0, doubleArray28);
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray47 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray48 = new double[][] { doubleArray35, doubleArray39, doubleArray43, doubleArray47 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray48);
        double double50 = blockRealMatrix49.getNorm();
        double double51 = blockRealMatrix49.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix21.add(blockRealMatrix49);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = blockRealMatrix52.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) realMatrix53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x35 but expected 3x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 40.000003814697266d + "'", double50 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 28.284272596161085d + "'", double51 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix17.scalarMultiply((double) (-1898220449));
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix17.getColumnMatrix((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1));
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker2 = cMAESOptimizer1.getConvergenceChecker();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optimization.GoalType goalType5 = null;
        double[] doubleArray6 = null;
        double[] doubleArray8 = new double[] { 0.0d };
        double[] doubleArray12 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray8);
        double[] doubleArray17 = new double[] { 0.0d };
        double[] doubleArray21 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray21);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray17);
        double double25 = org.apache.commons.math3.util.MathArrays.distance(doubleArray8, doubleArray17);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        double[] doubleArray29 = new double[] { 0.0d };
        double[] doubleArray33 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray33);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(doubleArray29, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray33, 32.0d);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = cMAESOptimizer1.optimize((int) (short) 100, multivariateFunction4, goalType5, doubleArray6, doubleArray8, doubleArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor49 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double50 = defaultRealMatrixPreservingVisitor49.end();
        double double51 = blockRealMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor49);
        double[] doubleArray54 = new double[] { 0.0d };
        double[] doubleArray58 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        boolean boolean60 = org.apache.commons.math3.util.MathArrays.equals(doubleArray54, doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray54);
        double[] doubleArray63 = new double[] { 0.0d };
        double[] doubleArray67 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray67);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray67);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray63);
        double double71 = org.apache.commons.math3.util.MathArrays.distance(doubleArray54, doubleArray63);
        try {
            blockRealMatrix17.setColumn(0, doubleArray63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 4x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 20L, 0.0d, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = blockRealMatrix48.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double53 = arrayRealVector52.getL1Norm();
        try {
            org.apache.commons.math3.linear.RealVector realVector54 = blockRealMatrix48.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        java.text.ParsePosition parsePosition9 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat6.parse("hi!", parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) 0, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = zeroException2.getContext();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = realMatrixFormat6.parse("BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        double[] doubleArray10 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray14 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray18 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray22 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray23 = new double[][] { doubleArray10, doubleArray14, doubleArray18, doubleArray22 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double[] doubleArray27 = new double[] { 0.0d };
        double[] doubleArray31 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray31);
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equals(doubleArray27, doubleArray31);
        blockRealMatrix24.setRow((int) (byte) 0, doubleArray31);
        double[] doubleArray38 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray42 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray46 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray50 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray51 = new double[][] { doubleArray38, doubleArray42, doubleArray46, doubleArray50 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        double double53 = blockRealMatrix52.getNorm();
        double double54 = blockRealMatrix52.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix24.add(blockRealMatrix52);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor56 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double57 = defaultRealMatrixPreservingVisitor56.end();
        double double58 = blockRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor56);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 40.000003814697266d + "'", double53 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 28.284272596161085d + "'", double54 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapMultiply((-57.29577951308232d));
        try {
            org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector42.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor31 = null;
        try {
            double double32 = arrayRealVector17.walkInDefaultOrder(realVectorChangingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 52, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-10.07608628613008d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix19.walkInColumnOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 28.284272596161085d + "'", double23 == 28.284272596161085d);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
//        double[] doubleArray20 = new double[] { 0.0d };
//        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
//        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
//        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
//        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
//        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
//        double double46 = blockRealMatrix45.getNorm();
//        double double47 = blockRealMatrix45.getFrobeniusNorm();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
//        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
//        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
//        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
//        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix66.scalarAdd(Double.NEGATIVE_INFINITY);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister73 = new org.apache.commons.math3.random.MersenneTwister();
//        int int75 = mersenneTwister73.nextInt((int) '4');
//        int[] intArray79 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray80 = org.apache.commons.math3.util.MathArrays.copyOf(intArray79);
//        mersenneTwister73.setSeed(intArray80);
//        int[] intArray85 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray86 = org.apache.commons.math3.util.MathArrays.copyOf(intArray85);
//        double double87 = org.apache.commons.math3.util.MathArrays.distance(intArray80, intArray85);
//        int[] intArray88 = new int[] {};
//        try {
//            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix66, intArray80, intArray88);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
//        } catch (org.apache.commons.math3.exception.NoDataException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertNotNull(doubleArray15);
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertNotNull(doubleArray20);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertNotNull(realMatrix25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray35);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertNotNull(doubleArray43);
//        org.junit.Assert.assertNotNull(doubleArray44);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
//        org.junit.Assert.assertNotNull(blockRealMatrix48);
//        org.junit.Assert.assertNotNull(doubleArray52);
//        org.junit.Assert.assertNotNull(doubleArray56);
//        org.junit.Assert.assertNotNull(doubleArray60);
//        org.junit.Assert.assertNotNull(doubleArray64);
//        org.junit.Assert.assertNotNull(doubleArray65);
//        org.junit.Assert.assertNotNull(realMatrix67);
//        org.junit.Assert.assertNotNull(realMatrix69);
//        org.junit.Assert.assertNotNull(realMatrix70);
//        org.junit.Assert.assertNotNull(blockRealMatrix72);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 21 + "'", int75 == 21);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
//        org.junit.Assert.assertNotNull(intArray88);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        try {
            org.apache.commons.math3.linear.RealVector realVector44 = blockRealMatrix17.getColumnVector(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.000001f, (java.lang.Number) (-1), true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 32.0f, 342.18125286374413d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 100L, (-1.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.99999f + "'", float2 == 99.99999f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((-127), 28.284272596161085d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble(Double.POSITIVE_INFINITY, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double2 = org.apache.commons.math3.util.FastMath.min((-10.07608628613008d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.07608628613008d) + "'", double2 == (-10.07608628613008d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor43 = null;
        try {
            double double44 = arrayRealVector42.walkInOptimizedOrder(realVectorPreservingVisitor43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        try {
            array2DRowRealMatrix19.setEntry(4, (-1023), 0.7804113358691207d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (4)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        java.lang.String str9 = realMatrixFormat6.getRowPrefix();
        double[] doubleArray13 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray17 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray21 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray25 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray26);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        blockRealMatrix27.setRow((int) (byte) 0, doubleArray34);
        double[] doubleArray41 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray45 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray49 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray53 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray54 = new double[][] { doubleArray41, doubleArray45, doubleArray49, doubleArray53 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray54);
        double double56 = blockRealMatrix55.getNorm();
        double double57 = blockRealMatrix55.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix27.add(blockRealMatrix55);
        double[] doubleArray62 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray66 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray70 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray74 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray75 = new double[][] { doubleArray62, doubleArray66, doubleArray70, doubleArray74 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray75);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = blockRealMatrix76.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = blockRealMatrix76.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = blockRealMatrix27.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix76);
        java.lang.StringBuffer stringBuffer81 = null;
        java.text.FieldPosition fieldPosition82 = null;
        try {
            java.lang.StringBuffer stringBuffer83 = realMatrixFormat6.format(realMatrix80, stringBuffer81, fieldPosition82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 40.000003814697266d + "'", double56 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 28.284272596161085d + "'", double57 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertNotNull(realMatrix80);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 10.0f);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray19 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray23 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray24 = new double[][] { doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray28 = new double[] { 0.0d };
        double[] doubleArray32 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray32);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray32);
        blockRealMatrix25.setRow((int) (byte) 0, doubleArray32);
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray47 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray51 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray52 = new double[][] { doubleArray39, doubleArray43, doubleArray47, doubleArray51 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray52);
        double double54 = blockRealMatrix53.getNorm();
        double double55 = blockRealMatrix53.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix25.add(blockRealMatrix53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix53.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix58.scalarAdd((double) '4');
        java.lang.StringBuffer stringBuffer61 = null;
        java.text.FieldPosition fieldPosition62 = null;
        try {
            java.lang.StringBuffer stringBuffer63 = realMatrixFormat6.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix58, stringBuffer61, fieldPosition62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 40.000003814697266d + "'", double54 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 28.284272596161085d + "'", double55 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.44488379011085244d + "'", double0 == 0.44488379011085244d);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 52, 10.000001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3490658503988659d + "'", double1 == 0.3490658503988659d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        java.text.ParsePosition parsePosition10 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = realMatrixFormat6.parse("", parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector30 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        try {
            blockRealMatrix17.setRow((int) 'a', doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        double double20 = blockRealMatrix17.getNorm();
        int int21 = blockRealMatrix17.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double23 = blockRealMatrix17.walkInRowOrder(realMatrixChangingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 40.000003814697266d + "'", double20 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        try {
            org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector42.getSubVector(0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        try {
            int int7 = matrixDimensionMismatchException4.getExpectedDimension(23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 23");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 23 + "'", int5 == 23);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d };
        double[] doubleArray73 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray73);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray69, doubleArray73);
        blockRealMatrix66.setRow((int) (byte) 0, doubleArray73);
        double[] doubleArray77 = blockRealMatrix48.operate(doubleArray73);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection78 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray73, orderDirection78, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int1 = org.apache.commons.math3.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        try {
            double double20 = array2DRowRealMatrix19.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (10x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        double[] doubleArray5 = new double[] { 28.284272596161085d, (byte) 1 };
        double[] doubleArray7 = new double[] { 0.0d };
        double[] doubleArray11 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray11);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(doubleArray7, doubleArray11);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) (short) 10);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray11);
        try {
            double[] doubleArray17 = openMapRealMatrix2.preMultiply(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.54881346f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        double[] doubleArray73 = new double[] { 28.284272596161085d, (byte) 1 };
        double[] doubleArray75 = new double[] { 0.0d };
        double[] doubleArray79 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray79);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equals(doubleArray75, doubleArray79);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray79, (int) (short) 10);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray73, doubleArray79);
        try {
            double[] doubleArray85 = blockRealMatrix17.preMultiply(doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0d));
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix66.scalarAdd(Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor73 = null;
        try {
            double double78 = blockRealMatrix66.walkInOptimizedOrder(realMatrixChangingVisitor73, (int) '#', (int) ' ', 0, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray1);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException7 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException7);
        zeroException2.addSuppressed((java.lang.Throwable) mathInternalError8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathInternalError8.getContext();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 1, (int) (short) 100);
        java.lang.String str3 = nonSquareMatrixException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.linear.NonSquareMatrixException: non square (1x100) matrix" + "'", str3.equals("org.apache.commons.math3.linear.NonSquareMatrixException: non square (1x100) matrix"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str10 = realMatrixFormat9.getColumnSeparator();
        java.text.NumberFormat numberFormat11 = realMatrixFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "hi!", numberFormat11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double16 = arrayRealVector15.getL1Norm();
        double[] doubleArray18 = new double[] { 0.0d };
        double[] doubleArray22 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray22);
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray22);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        boolean boolean27 = arrayRealVector15.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double31 = arrayRealVector30.getL1Norm();
        double[] doubleArray33 = new double[] { 0.0d };
        double[] doubleArray37 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray37);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray37);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) (short) 10);
        boolean boolean42 = arrayRealVector30.equals((java.lang.Object) (short) 10);
        double double43 = arrayRealVector15.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double47 = arrayRealVector46.getL1Norm();
        double double48 = arrayRealVector46.getLInfNorm();
        double double49 = arrayRealVector30.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector46.mapMultiply((double) 100.0f);
        java.lang.String str52 = realVectorFormat12.format(realVector51);
        java.lang.String str53 = realVectorFormat12.getSuffix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double60 = arrayRealVector59.getL1Norm();
        double[] doubleArray62 = new double[] { 0.0d };
        double[] doubleArray66 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray66);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) (short) 10);
        boolean boolean71 = arrayRealVector59.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double75 = arrayRealVector74.getL1Norm();
        double[] doubleArray77 = new double[] { 0.0d };
        double[] doubleArray81 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix82 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray81);
        boolean boolean83 = org.apache.commons.math3.util.MathArrays.equals(doubleArray77, doubleArray81);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray81, (int) (short) 10);
        boolean boolean86 = arrayRealVector74.equals((java.lang.Object) (short) 10);
        double double87 = arrayRealVector59.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double91 = arrayRealVector90.getL1Norm();
        double double92 = arrayRealVector90.getLInfNorm();
        double double93 = arrayRealVector74.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector90);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction94 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector90.mapToSelf(univariateFunction94);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector96 = arrayRealVector56.add((org.apache.commons.math3.linear.RealVector) arrayRealVector95);
        java.lang.StringBuffer stringBuffer97 = null;
        java.text.FieldPosition fieldPosition98 = null;
        try {
            java.lang.StringBuffer stringBuffer99 = realVectorFormat12.format((org.apache.commons.math3.linear.RealVector) arrayRealVector96, stringBuffer97, fieldPosition98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)" + "'", str52.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)" + "'", str53.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(realMatrix82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector95);
        org.junit.Assert.assertNotNull(arrayRealVector96);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        try {
            array2DRowRealMatrix19.multiplyEntry((int) (short) 10, (int) (byte) 10, (double) 0.54881346f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix50, (int) (byte) 0, 37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (37)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        java.io.ObjectOutputStream objectOutputStream23 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19, objectOutputStream23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        double[] doubleArray22 = new double[] { 0.0d };
        double[] doubleArray26 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray26);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        double[] doubleArray32 = new double[] { 0.0d };
        double[] doubleArray36 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray36);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray36);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector40.copy();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(arrayRealVector41);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = openMapRealMatrix2.add(openMapRealMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        double[] doubleArray22 = new double[] { 0.0d };
        double[] doubleArray26 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray26);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        double double31 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray20, doubleArray26, (-0.4161468365471424d));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.50373127401788d + "'", double31 == 100.50373127401788d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix19.createMatrix((int) 'a', (int) 'a');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix19.walkInRowOrder(realMatrixChangingVisitor27, 0, 0, 698108194, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (698,108,194)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 28.284272596161085d + "'", double23 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor18 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor18.start((int) (short) 10, (int) (byte) 0, 0, (int) ' ', (int) (byte) 1, 0);
        double double26 = blockRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix33 = openMapRealMatrix29.add(openMapRealMatrix32);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix17, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x3 but expected 100x35");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix33);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix38.multiply(realMatrix43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (-1L), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction31 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector2.mapToSelf(univariateFunction31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(1, 32.0d);
        int int36 = arrayRealVector35.getMaxIndex();
        try {
            double double37 = arrayRealVector32.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        try {
            arrayRealVector2.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 10.000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.162277810957525d + "'", double1 == 3.162277810957525d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.optimization.GoalType goalType1 = cMAESOptimizer0.getGoalType();
        org.junit.Assert.assertNull(goalType1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix3);
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray20 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        double[] doubleArray25 = new double[] { 0.0d };
        double[] doubleArray29 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray29);
        blockRealMatrix22.setRow((int) (byte) 0, doubleArray29);
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray40 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray44 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray48 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray49 = new double[][] { doubleArray36, doubleArray40, doubleArray44, doubleArray48 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray49);
        double double51 = blockRealMatrix50.getNorm();
        double double52 = blockRealMatrix50.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix22.add(blockRealMatrix50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix50.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix55.scalarAdd((double) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor58 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double59 = defaultRealMatrixPreservingVisitor58.end();
        double double60 = defaultRealMatrixPreservingVisitor58.end();
        double double61 = blockRealMatrix55.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        try {
            double double66 = openMapRealMatrix3.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58, 4, 698108194, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (698,108,194)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 40.000003814697266d + "'", double51 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 28.284272596161085d + "'", double52 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        org.apache.commons.math3.optimization.GoalType goalType3 = null;
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray9, 32.0d);
        double[] doubleArray15 = new double[] { 0.0d };
        double[] doubleArray19 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray19);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        double[] doubleArray26 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = cMAESOptimizer0.optimize(4, multivariateFunction2, goalType3, doubleArray9, doubleArray15, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notStrictlyPositiveException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17, (double) 32.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x3) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.000001f, (java.lang.Number) (-1), true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((-1L), (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (short) -1, 30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        try {
            incrementor0.incrementCount(23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        java.lang.String str9 = realMatrixFormat6.getRowSuffix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(10, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,023 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(1.2676506002282294E32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        double[] doubleArray46 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray50 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray54 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray58 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray59 = new double[][] { doubleArray46, doubleArray50, doubleArray54, doubleArray58 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray59);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = blockRealMatrix60.transpose();
        org.apache.commons.math3.linear.RealVector realVector63 = blockRealMatrix60.getRowVector((int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, realVector63);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realVector63);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = openMapRealMatrix6.getSubMatrix((int) (short) 1, 0, 36, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        boolean boolean37 = arrayRealVector17.isNaN();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor38 = null;
        try {
            double double41 = arrayRealVector17.walkInDefaultOrder(realVectorChangingVisitor38, 4, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (4)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        double double19 = blockRealMatrix17.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = blockRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor20, (int) '#', (int) (short) 100, (int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 40.000003814697266d + "'", double19 == 40.000003814697266d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix66.scalarAdd(Double.NEGATIVE_INFINITY);
        double[] doubleArray76 = new double[] { 28.284272596161085d, (byte) 1 };
        double[] doubleArray78 = new double[] { 0.0d };
        double[] doubleArray82 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix83 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray82);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray78, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray82, (int) (short) 10);
        boolean boolean87 = org.apache.commons.math3.util.MathArrays.equals(doubleArray76, doubleArray82);
        double[] doubleArray89 = new double[] { 0.0d };
        double[] doubleArray93 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix94 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray93);
        boolean boolean95 = org.apache.commons.math3.util.MathArrays.equals(doubleArray89, doubleArray93);
        double[] doubleArray97 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray93, 32.0d);
        double double98 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray82, doubleArray93);
        try {
            blockRealMatrix66.setColumn(698108194, doubleArray82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (698,108,194)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realMatrix83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(realMatrix94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 10101.0d + "'", double98 == 10101.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 37);
        boolean boolean3 = arrayRealVector2.isInfinite();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double5 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 35, (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.57625987E17f + "'", float2 == 1.57625987E17f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix6.add(openMapRealMatrix9);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix3.multiply(openMapRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        double[][] doubleArray21 = array2DRowRealMatrix19.getDataRef();
        int int22 = array2DRowRealMatrix19.getColumnDimension();
        try {
            array2DRowRealMatrix19.multiplyEntry(10, (-1898220449), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 10, 1.2676506002282294E32d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        int int20 = blockRealMatrix17.getRowDimension();
        double double21 = blockRealMatrix17.getFrobeniusNorm();
        double[] doubleArray26 = new double[] { 0.6483621820319939d, 1, Double.NaN, 0 };
        double[] doubleArray27 = blockRealMatrix17.preMultiply(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double35 = arrayRealVector34.getL1Norm();
        double[] doubleArray37 = new double[] { 0.0d };
        double[] doubleArray41 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray41);
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equals(doubleArray37, doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) (short) 10);
        boolean boolean46 = arrayRealVector34.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double50 = arrayRealVector49.getL1Norm();
        double[] doubleArray52 = new double[] { 0.0d };
        double[] doubleArray56 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray56);
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(doubleArray52, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56, (int) (short) 10);
        boolean boolean61 = arrayRealVector49.equals((java.lang.Object) (short) 10);
        double double62 = arrayRealVector34.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double66 = arrayRealVector65.getL1Norm();
        double double67 = arrayRealVector65.getLInfNorm();
        double double68 = arrayRealVector49.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction69 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector65.mapToSelf(univariateFunction69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector31.add((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        try {
            blockRealMatrix17.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 4x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 28.284272596161085d + "'", double21 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(arrayRealVector71);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = realMatrixFormat6.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix48.scalarMultiply(10.0d);
        org.apache.commons.math3.exception.util.Localizable localizable51 = null;
        double[] doubleArray55 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray59 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray63 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray67 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray68 = new double[][] { doubleArray55, doubleArray59, doubleArray63, doubleArray67 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray68);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException70 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable51, (java.lang.Object[]) doubleArray68);
        try {
            blockRealMatrix48.setSubMatrix(doubleArray68, (int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = defaultRealMatrixPreservingVisitor20.end();
        try {
            double double27 = array2DRowRealMatrix19.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20, (-1898220449), (int) (byte) 10, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,898,220,449)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.2676506002282294E32d, (double) 20L, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 0.6483621820319939d, 0.6483621820319938d, 342.18125286374413d, Double.NaN, (-57.29577951308232d), 0.8763541565548663d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 0, 37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 37 is larger than the maximum (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.io.ObjectInputStream objectInputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) int5, "", objectInputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 23 + "'", int5 == 23);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 10.000001f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double double43 = blockRealMatrix38.getNorm();
        try {
            blockRealMatrix38.addToEntry(0, 35, (-0.5872139151569291d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 40.000003814697266d + "'", double43 == 40.000003814697266d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        double[][] doubleArray21 = array2DRowRealMatrix19.getDataRef();
        int int22 = array2DRowRealMatrix19.getColumnDimension();
        try {
            array2DRowRealMatrix19.multiplyEntry((int) (short) 1, 18, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (18)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, 32.0d);
        int int3 = arrayRealVector2.getMaxIndex();
        try {
            double double5 = arrayRealVector2.getEntry((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 100, 0.54881346f, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        double[] doubleArray45 = new double[] { 0.0d };
        double[] doubleArray49 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray49);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equals(doubleArray45, doubleArray49);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray49, 32.0d);
        try {
            blockRealMatrix38.setColumn(698108194, doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (698,108,194)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = blockRealMatrix48.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double53 = arrayRealVector52.getL1Norm();
        double[] doubleArray55 = new double[] { 0.0d };
        double[] doubleArray59 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray59);
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equals(doubleArray55, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) (short) 10);
        boolean boolean64 = arrayRealVector52.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double68 = arrayRealVector67.getL1Norm();
        double[] doubleArray70 = new double[] { 0.0d };
        double[] doubleArray74 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equals(doubleArray70, doubleArray74);
        double[] doubleArray78 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74, (int) (short) 10);
        boolean boolean79 = arrayRealVector67.equals((java.lang.Object) (short) 10);
        double double80 = arrayRealVector52.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double84 = arrayRealVector83.getL1Norm();
        double double85 = arrayRealVector83.getLInfNorm();
        double double86 = arrayRealVector67.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector83);
        boolean boolean87 = arrayRealVector67.isNaN();
        try {
            org.apache.commons.math3.linear.RealVector realVector88 = blockRealMatrix48.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 52);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        double double20 = blockRealMatrix17.getNorm();
        int int21 = blockRealMatrix17.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = blockRealMatrix17.getRowMatrix((int) (short) 0);
        java.io.ObjectOutputStream objectOutputStream24 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17, objectOutputStream24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 40.000003814697266d + "'", double20 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 830689682, (float) '#', 32.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        double[] doubleArray22 = new double[] { 0.0d };
        double[] doubleArray26 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray26);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        double[] doubleArray32 = new double[] { 0.0d };
        double[] doubleArray36 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray36);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray36);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray30);
        double double41 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 23, (-0.4161468365471424d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11192398990716762d + "'", double2 == 0.11192398990716762d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(18, 18);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealVector realVector50 = null;
        try {
            blockRealMatrix45.setColumnVector((-1), realVector50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d };
        double[] doubleArray73 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray73);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray69, doubleArray73);
        blockRealMatrix66.setRow((int) (byte) 0, doubleArray73);
        double[] doubleArray77 = blockRealMatrix48.operate(doubleArray73);
        double[] doubleArray79 = new double[] { 0.0d };
        double[] doubleArray83 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix84 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray83);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equals(doubleArray79, doubleArray83);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83, (int) (short) 10);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equals(doubleArray73, doubleArray83);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray83);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        int[] intArray4 = new int[] { 830689682, 52, 40, 36 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
//        int int7 = mersenneTwister5.nextInt((int) '4');
//        int[] intArray11 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray12 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11);
//        mersenneTwister5.setSeed(intArray12);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
//        try {
//            double double15 = org.apache.commons.math3.util.MathArrays.distance(intArray4, intArray12);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException2 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d };
        double[] doubleArray73 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray73);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray69, doubleArray73);
        blockRealMatrix66.setRow((int) (byte) 0, doubleArray73);
        double[] doubleArray77 = blockRealMatrix48.operate(doubleArray73);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection78 = null;
        double[] doubleArray82 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray86 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray90 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray94 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray95 = new double[][] { doubleArray82, doubleArray86, doubleArray90, doubleArray94 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix96 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray95);
        org.apache.commons.math3.linear.RealMatrix realMatrix97 = blockRealMatrix96.transpose();
        double[][] doubleArray98 = blockRealMatrix96.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray77, orderDirection78, doubleArray98);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(realMatrix97);
        org.junit.Assert.assertNotNull(doubleArray98);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double46 = arrayRealVector45.getL1Norm();
        double double47 = arrayRealVector45.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double54 = arrayRealVector53.getL1Norm();
        double[] doubleArray56 = new double[] { 0.0d };
        double[] doubleArray60 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray60);
        boolean boolean62 = org.apache.commons.math3.util.MathArrays.equals(doubleArray56, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60, (int) (short) 10);
        boolean boolean65 = arrayRealVector53.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double69 = arrayRealVector68.getL1Norm();
        double[] doubleArray71 = new double[] { 0.0d };
        double[] doubleArray75 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray75);
        boolean boolean77 = org.apache.commons.math3.util.MathArrays.equals(doubleArray71, doubleArray75);
        double[] doubleArray79 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray75, (int) (short) 10);
        boolean boolean80 = arrayRealVector68.equals((java.lang.Object) (short) 10);
        double double81 = arrayRealVector53.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double85 = arrayRealVector84.getL1Norm();
        double double86 = arrayRealVector84.getLInfNorm();
        double double87 = arrayRealVector68.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector84);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction88 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector84.mapToSelf(univariateFunction88);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = arrayRealVector50.add((org.apache.commons.math3.linear.RealVector) arrayRealVector89);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector89);
        org.apache.commons.math3.linear.RealVector realVector93 = arrayRealVector91.mapDivideToSelf((double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = arrayRealVector45.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector91);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector91.copy();
        double double96 = arrayRealVector91.getL1Norm();
        double double97 = arrayRealVector42.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector91);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector89);
        org.junit.Assert.assertNotNull(arrayRealVector90);
        org.junit.Assert.assertNotNull(realVector93);
        org.junit.Assert.assertNotNull(arrayRealVector94);
        org.junit.Assert.assertNotNull(arrayRealVector95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.add(openMapRealMatrix12);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix2.add(openMapRealMatrix13);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double16 = openMapRealMatrix13.walkInOptimizedOrder(realMatrixChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat8);
        java.lang.String str10 = realVectorFormat9.getPrefix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{" + "'", str10.equals("{"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.3440585709080678E43d, 0.7804113358691207d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04551270580766942d + "'", double2 == 0.04551270580766942d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        double[] doubleArray55 = new double[] { 0.0d };
        double[] doubleArray59 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray59);
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equals(doubleArray55, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) (short) 10);
        double[] doubleArray65 = new double[] { 0.0d };
        double[] doubleArray69 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray69);
        boolean boolean71 = org.apache.commons.math3.util.MathArrays.equals(doubleArray65, doubleArray69);
        boolean boolean72 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        double[] doubleArray75 = new double[] { 0.0d };
        double[] doubleArray79 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray79);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equals(doubleArray75, doubleArray79);
        org.apache.commons.math3.linear.RealMatrix realMatrix82 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray75);
        double[] doubleArray84 = new double[] { 0.0d };
        double[] doubleArray88 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix89 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray88);
        boolean boolean90 = org.apache.commons.math3.util.MathArrays.equals(doubleArray84, doubleArray88);
        org.apache.commons.math3.linear.RealMatrix realMatrix91 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray84);
        double double92 = org.apache.commons.math3.util.MathArrays.distance(doubleArray75, doubleArray84);
        double[] doubleArray93 = array2DRowRealMatrix73.operate(doubleArray84);
        try {
            blockRealMatrix52.setColumn((int) '4', doubleArray84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(realMatrix82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(realMatrix89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(realMatrix91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = openMapRealMatrix2.createMatrix((-1898220449), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,898,220,449 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(45, 37);
        double double3 = blockRealMatrix2.getNorm();
        try {
            double double4 = blockRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (45x37) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        double[] doubleArray22 = new double[] { 0.0d };
        double[] doubleArray26 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray26);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        double[] doubleArray32 = new double[] { 0.0d };
        double[] doubleArray36 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray36);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray36);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double47 = arrayRealVector46.getL1Norm();
        double[] doubleArray49 = new double[] { 0.0d };
        double[] doubleArray53 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray53);
        boolean boolean55 = org.apache.commons.math3.util.MathArrays.equals(doubleArray49, doubleArray53);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        boolean boolean58 = arrayRealVector46.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double62 = arrayRealVector61.getL1Norm();
        double[] doubleArray64 = new double[] { 0.0d };
        double[] doubleArray68 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray68);
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray64, doubleArray68);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray68, (int) (short) 10);
        boolean boolean73 = arrayRealVector61.equals((java.lang.Object) (short) 10);
        double double74 = arrayRealVector46.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double78 = arrayRealVector77.getL1Norm();
        double double79 = arrayRealVector77.getLInfNorm();
        double double80 = arrayRealVector61.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction81 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector77.mapToSelf(univariateFunction81);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector43.add((org.apache.commons.math3.linear.RealVector) arrayRealVector82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, arrayRealVector43);
        double double85 = arrayRealVector43.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException(number0);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        int int4 = mersenneTwister2.nextInt((int) '4');
//        int[] intArray8 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
//        mersenneTwister2.setSeed(intArray9);
//        int[] intArray14 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14);
//        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray9, intArray14);
//        mersenneTwister0.setSeed(intArray14);
//        int int18 = mersenneTwister0.nextInt();
//        boolean boolean19 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07522571379268062d + "'", double1 == 0.07522571379268062d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 830689682 + "'", int18 == 830689682);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            openMapRealMatrix5.addToEntry(830689682, (int) (short) 100, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (830,689,682)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray30);
        double[] doubleArray39 = array2DRowRealMatrix19.operate(doubleArray30);
        try {
            array2DRowRealMatrix19.multiplyEntry(3, 830689682, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (830,689,682)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        int int20 = blockRealMatrix17.getRowDimension();
        double double21 = blockRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double23 = blockRealMatrix17.walkInRowOrder(realMatrixChangingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 28.284272596161085d + "'", double21 == 28.284272596161085d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix4 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix3);
        double[] doubleArray6 = new double[] { 0.0d };
        double[] doubleArray10 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equals(doubleArray6, doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 0.0d };
        double[] doubleArray19 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray19);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        double double23 = org.apache.commons.math3.util.MathArrays.distance(doubleArray6, doubleArray15);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, 0);
        double[] doubleArray27 = new double[] { 0.0d };
        double[] doubleArray31 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray31);
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equals(doubleArray27, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31, (int) (short) 10);
        double[] doubleArray37 = new double[] { 0.0d };
        double[] doubleArray41 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray41);
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equals(doubleArray37, doubleArray41);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equals(doubleArray35, doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, doubleArray35);
        try {
            org.apache.commons.math3.linear.RealVector realVector46 = openMapRealMatrix4.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        java.util.List<java.lang.Double> doubleList1 = cMAESOptimizer0.getStatisticsSigmaHistory();
        org.junit.Assert.assertNotNull(doubleList1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        long long1 = org.apache.commons.math3.util.FastMath.round(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray30);
        double[] doubleArray39 = array2DRowRealMatrix19.operate(doubleArray30);
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray47 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray51 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray55 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray56 = new double[][] { doubleArray43, doubleArray47, doubleArray51, doubleArray55 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56, true);
        int int60 = array2DRowRealMatrix59.getRowDimension();
        double[][] doubleArray61 = array2DRowRealMatrix59.getDataRef();
        int int62 = array2DRowRealMatrix59.getColumnDimension();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix19.multiply(array2DRowRealMatrix59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 3 + "'", int62 == 3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray30);
        double[] doubleArray39 = array2DRowRealMatrix19.operate(doubleArray30);
        org.apache.commons.math3.exception.util.Localizable localizable40 = null;
        org.apache.commons.math3.exception.util.Localizable localizable41 = null;
        double[] doubleArray45 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray49 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray53 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray57 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray58 = new double[][] { doubleArray45, doubleArray49, doubleArray53, doubleArray57 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = blockRealMatrix59.scalarAdd((double) 100L);
        double[][] doubleArray62 = blockRealMatrix59.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable41, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math3.exception.ZeroException zeroException65 = new org.apache.commons.math3.exception.ZeroException(localizable40, (java.lang.Object[]) doubleArray62);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray39, doubleArray62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        try {
            org.apache.commons.math3.linear.RealVector realVector44 = blockRealMatrix42.getColumnVector((-1898220449));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,898,220,449)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            openMapRealMatrix6.addToEntry(1, (-1023), 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = blockRealMatrix17.scalarMultiply((-1.0d));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 0.0f, (double) (byte) 1, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        long long1 = org.apache.commons.math3.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection19 = null;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray10, orderDirection19, true);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        double double53 = blockRealMatrix52.getFrobeniusNorm();
        boolean boolean54 = blockRealMatrix52.isSquare();
        org.apache.commons.math3.linear.RealVector realVector56 = blockRealMatrix52.getRowVector(0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix52, 10, (int) (byte) -1, 26, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 342.18125286374413d + "'", double53 == 342.18125286374413d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 100, (int) (short) -1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 30, (double) (short) -1, (double) 6.9810822E8f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(37, 10);
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = blockRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str10 = realMatrixFormat9.getColumnSeparator();
        java.text.NumberFormat numberFormat11 = realMatrixFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "hi!", numberFormat11);
        java.lang.String str13 = realVectorFormat12.getSuffix();
        java.lang.String str14 = realVectorFormat12.getSeparator();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 32.0d);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 52, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double6 = arrayRealVector5.getL1Norm();
        double[] doubleArray8 = new double[] { 0.0d };
        double[] doubleArray12 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (short) 10);
        boolean boolean17 = arrayRealVector5.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double21 = arrayRealVector20.getL1Norm();
        double[] doubleArray23 = new double[] { 0.0d };
        double[] doubleArray27 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray23, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (short) 10);
        boolean boolean32 = arrayRealVector20.equals((java.lang.Object) (short) 10);
        double double33 = arrayRealVector5.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double37 = arrayRealVector36.getL1Norm();
        double double38 = arrayRealVector36.getLInfNorm();
        double double39 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector36.mapToSelf(univariateFunction40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector2.add((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor44 = null;
        try {
            double double47 = arrayRealVector41.walkInOptimizedOrder(realVectorPreservingVisitor44, (-1898220449), 23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,898,220,449)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 37, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.808584372417849E15d + "'", double2 == 4.808584372417849E15d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        boolean boolean37 = arrayRealVector17.isNaN();
        arrayRealVector17.set(3.141592653589793d);
        double double40 = arrayRealVector17.getL1Norm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (byte) 10, number1, 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonicSequenceException5.getPrevious();
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix6, 10);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) (short) 10);
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14);
        try {
            double[] doubleArray21 = openMapRealMatrix6.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.50373127401788d + "'", double19 == 100.50373127401788d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, 32.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector2.getSubVector(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of elements should be positive (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        int int4 = mersenneTwister2.nextInt((int) '4');
//        int[] intArray8 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
//        mersenneTwister2.setSeed(intArray9);
//        int[] intArray14 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14);
//        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray9, intArray14);
//        mersenneTwister0.setSeed(intArray14);
//        double double18 = mersenneTwister0.nextDouble();
//        int[] intArray24 = new int[] { (short) -1, 3, (byte) 0, 4, (-1898220449) };
//        mersenneTwister0.setSeed(intArray24);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5604816981513565d + "'", double1 == 0.5604816981513565d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.19341001859048434d + "'", double18 == 0.19341001859048434d);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor18 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor18.start((int) (short) 10, (int) (byte) 0, 0, (int) ' ', (int) (byte) 1, 0);
        double double26 = blockRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double[] doubleArray48 = new double[] { 0.0d };
        double[] doubleArray52 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray48, doubleArray52);
        blockRealMatrix45.setRow((int) (byte) 0, doubleArray52);
        double[] doubleArray59 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray63 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray67 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray71 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray72 = new double[][] { doubleArray59, doubleArray63, doubleArray67, doubleArray71 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray72);
        double double74 = blockRealMatrix73.getNorm();
        double double75 = blockRealMatrix73.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix45.add(blockRealMatrix73);
        double[] doubleArray80 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray84 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray88 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray92 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray93 = new double[][] { doubleArray80, doubleArray84, doubleArray88, doubleArray92 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix94 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray93);
        org.apache.commons.math3.linear.RealMatrix realMatrix95 = blockRealMatrix94.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix97 = blockRealMatrix94.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix98 = blockRealMatrix45.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix94);
        try {
            blockRealMatrix17.setRowMatrix(26, realMatrix98);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (26)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 40.000003814697266d + "'", double74 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 28.284272596161085d + "'", double75 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(realMatrix95);
        org.junit.Assert.assertNotNull(realMatrix97);
        org.junit.Assert.assertNotNull(realMatrix98);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 1L, 4.808584372417849E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 26);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1489.6902673401403d + "'", double1 == 1489.6902673401403d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (-1), 0, (short) 0 };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        try {
            double double6 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 1.9155040003582885E22d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix17.getSubMatrix(100, (int) ' ', (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.04551270580766942d, (double) 52.0f, (double) 1L, 3.141592653589793d, 0.04551270580766942d, Double.POSITIVE_INFINITY, (double) 18, (double) 0L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix19.createMatrix((int) 'a', (int) 'a');
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix19.copy();
        try {
            double double28 = array2DRowRealMatrix19.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x3) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 28.284272596161085d + "'", double23 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor49 = null;
        try {
            double double50 = blockRealMatrix48.walkInOptimizedOrder(realMatrixChangingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 26, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("BlockRealMatrix{{-1.0,100.0,10.0},{0.0,10.0000009537,10.0},{0.0,10.0000009537,10.0},{0.0,10.0000009537,10.0}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray19 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = blockRealMatrix21.scalarAdd((double) 100L);
        double[][] doubleArray24 = blockRealMatrix21.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray24);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math3.exception.ZeroException zeroException27 = new org.apache.commons.math3.exception.ZeroException(localizable2, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException28 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 99.99999f, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray4 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix18.transpose();
        double[][] doubleArray20 = blockRealMatrix18.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        long long2 = org.apache.commons.math3.util.FastMath.min(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        double double53 = blockRealMatrix52.getFrobeniusNorm();
        double[] doubleArray55 = new double[] { 0.0d };
        double[] doubleArray59 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray59);
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equals(doubleArray55, doubleArray59);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray55);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix63 = blockRealMatrix52.subtract(realMatrix62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x3 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 342.18125286374413d + "'", double53 == 342.18125286374413d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(realMatrix62);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray20);
        double[] doubleArray29 = new double[] { 0.0d };
        double[] doubleArray33 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray33);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(doubleArray29, doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray29);
        double double37 = org.apache.commons.math3.util.MathArrays.distance(doubleArray20, doubleArray29);
        try {
            double[] doubleArray38 = blockRealMatrix17.operate(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, true);
        int int21 = array2DRowRealMatrix20.getRowDimension();
        double double22 = array2DRowRealMatrix20.getNorm();
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 40.000003814697266d + "'", double22 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 698108194);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 32.0d);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1229172938 + "'", int10 == 1229172938);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        double[] doubleArray22 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray26 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray30 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray34 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray22, doubleArray26, doubleArray30, doubleArray34 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray35);
        double[] doubleArray39 = new double[] { 0.0d };
        double[] doubleArray43 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray39, doubleArray43);
        blockRealMatrix36.setRow((int) (byte) 0, doubleArray43);
        double[] doubleArray50 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray54 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray58 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray62 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray63 = new double[][] { doubleArray50, doubleArray54, doubleArray58, doubleArray62 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray63);
        double double65 = blockRealMatrix64.getNorm();
        double double66 = blockRealMatrix64.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix36.add(blockRealMatrix64);
        double[] doubleArray71 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray75 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray79 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray83 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray84 = new double[][] { doubleArray71, doubleArray75, doubleArray79, doubleArray83 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix85 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray84);
        double[] doubleArray88 = new double[] { 0.0d };
        double[] doubleArray92 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix93 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray92);
        boolean boolean94 = org.apache.commons.math3.util.MathArrays.equals(doubleArray88, doubleArray92);
        blockRealMatrix85.setRow((int) (byte) 0, doubleArray92);
        double[] doubleArray96 = blockRealMatrix67.operate(doubleArray92);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 40.000003814697266d + "'", double65 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 28.284272596161085d + "'", double66 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(realMatrix93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "", "", "", "hi!");
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = null;
        try {
            java.lang.String str8 = realMatrixFormat6.format(realMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(10, 52);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(42, (-127), doubleArray4, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        int int20 = blockRealMatrix17.getRowDimension();
        double double21 = blockRealMatrix17.getFrobeniusNorm();
        double double22 = blockRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = blockRealMatrix17.transpose();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 28.284272596161085d + "'", double21 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 28.284272596161085d + "'", double22 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.57625987E17f, 32.0f, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix17.getColumnVector(0);
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray40 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray41 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray41);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = blockRealMatrix42.scalarAdd((double) 100L);
        double[][] doubleArray45 = blockRealMatrix42.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        try {
            blockRealMatrix17.copySubMatrix(10, 18, 0, (int) (byte) 100, doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix46);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int2 = org.apache.commons.math3.util.FastMath.max(52, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) '4');
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9, orderDirection10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347994d + "'", double1 == 1.7160033436347994d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(45, 37);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double7 = arrayRealVector6.getL1Norm();
        double[] doubleArray9 = new double[] { 0.0d };
        double[] doubleArray13 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, (int) (short) 10);
        boolean boolean18 = arrayRealVector6.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double22 = arrayRealVector21.getL1Norm();
        double[] doubleArray24 = new double[] { 0.0d };
        double[] doubleArray28 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray28);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equals(doubleArray24, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) (short) 10);
        boolean boolean33 = arrayRealVector21.equals((java.lang.Object) (short) 10);
        double double34 = arrayRealVector6.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        try {
            org.apache.commons.math3.linear.RealVector realVector35 = blockRealMatrix2.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 45");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (short) 100, 1.0000001f };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(number4, objArray8);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException10 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable3, objArray8);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, objArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 10.0d, objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math3.util.FastMath.asin((-10.07608628613008d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        mersenneTwister0.setSeed((long) (short) 1);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6842846779199587d + "'", double1 == 0.6842846779199587d);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(4.808584372417849E15d, (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.0d + "'", double1 == 29.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix17.getColumnMatrix(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double6 = arrayRealVector5.getL1Norm();
        double[] doubleArray8 = new double[] { 0.0d };
        double[] doubleArray12 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (short) 10);
        boolean boolean17 = arrayRealVector5.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double21 = arrayRealVector20.getL1Norm();
        double[] doubleArray23 = new double[] { 0.0d };
        double[] doubleArray27 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray23, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (short) 10);
        boolean boolean32 = arrayRealVector20.equals((java.lang.Object) (short) 10);
        double double33 = arrayRealVector5.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double37 = arrayRealVector36.getL1Norm();
        double double38 = arrayRealVector36.getLInfNorm();
        double double39 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector36.mapToSelf(univariateFunction40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector2.add((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        boolean boolean43 = arrayRealVector42.isNaN();
        double double44 = arrayRealVector42.getNorm();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarAdd((double) 100L);
        double[][] doubleArray20 = blockRealMatrix17.getData();
        double[] doubleArray24 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray28 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double39 = blockRealMatrix38.getNorm();
        double double40 = blockRealMatrix38.getFrobeniusNorm();
        double double41 = blockRealMatrix38.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix38);
        try {
            org.apache.commons.math3.linear.RealVector realVector44 = blockRealMatrix42.getRowVector((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 40.000003814697266d + "'", double39 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 28.284272596161085d + "'", double40 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 40.000003814697266d + "'", double41 == 40.000003814697266d);
        org.junit.Assert.assertNotNull(blockRealMatrix42);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math3.util.FastMath.sin((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6795226183513794d) + "'", double1 == (-0.6795226183513794d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition19 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (3x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction31 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector2.mapToSelf(univariateFunction31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double36 = arrayRealVector35.getL1Norm();
        double[] doubleArray38 = new double[] { 0.0d };
        double[] doubleArray42 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray42);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray42);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) (short) 10);
        boolean boolean47 = arrayRealVector35.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double51 = arrayRealVector50.getL1Norm();
        double[] doubleArray53 = new double[] { 0.0d };
        double[] doubleArray57 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray57);
        boolean boolean59 = org.apache.commons.math3.util.MathArrays.equals(doubleArray53, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57, (int) (short) 10);
        boolean boolean62 = arrayRealVector50.equals((java.lang.Object) (short) 10);
        double double63 = arrayRealVector35.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double67 = arrayRealVector66.getL1Norm();
        double double68 = arrayRealVector66.getLInfNorm();
        double double69 = arrayRealVector50.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector66.mapMultiply(7.105427357601002E-15d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector66);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor73 = null;
        try {
            double double76 = arrayRealVector66.walkInOptimizedOrder(realVectorChangingVisitor73, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(realVector71);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("{", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, (int) 'a', 0, 0);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        java.lang.String str6 = matrixDimensionMismatchException4.toString();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x97 but expected 0x0" + "'", str6.equals("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x97 but expected 0x0"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 698108194, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray10 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray14 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray18 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray6, doubleArray10, doubleArray14, doubleArray18 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix20.scalarAdd((double) 100L);
        double[][] doubleArray23 = blockRealMatrix20.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray23);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray23);
        java.lang.Number number27 = zeroException26.getArgument();
        java.lang.Throwable[] throwableArray28 = zeroException26.getSuppressed();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException29 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0 + "'", number27.equals(0));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(37, 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double28 = array2DRowRealMatrix19.walkInColumnOrder(realMatrixChangingVisitor23, 37, 30, 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (37)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor53 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double54 = defaultRealMatrixPreservingVisitor53.end();
        double double55 = defaultRealMatrixPreservingVisitor53.end();
        double double56 = blockRealMatrix50.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor53);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor57 = null;
        try {
            double double58 = blockRealMatrix50.walkInRowOrder(realMatrixChangingVisitor57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        java.lang.String str9 = realMatrixFormat6.getSuffix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor4 = null;
        try {
            double double7 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor4, (int) (short) -1, 830689682);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 2.0d, false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        double double4 = openMapRealMatrix3.getFrobeniusNorm();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix7.add(openMapRealMatrix10);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix7);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix3.createMatrix(52, (int) ' ');
        try {
            org.apache.commons.math3.linear.RealVector realVector17 = openMapRealMatrix3.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int2 = org.apache.commons.math3.util.FastMath.max(698108194, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 698108194 + "'", int2 == 698108194);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1));
        int int2 = cMAESOptimizer1.getMaxEvaluations();
        int int3 = cMAESOptimizer1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6842846779199587d, (-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6842846779199586d + "'", double2 == 0.6842846779199586d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix17.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = blockRealMatrix17.walkInRowOrder(realMatrixChangingVisitor19, 30, 698108194, 1229172938, (-1898220449));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d };
        double[] doubleArray73 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray73);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray69, doubleArray73);
        blockRealMatrix66.setRow((int) (byte) 0, doubleArray73);
        double[] doubleArray77 = blockRealMatrix48.operate(doubleArray73);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77, (int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 135 is larger than the maximum (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister();
//        int int4 = mersenneTwister2.nextInt((int) '4');
//        int[] intArray8 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
//        mersenneTwister2.setSeed(intArray9);
//        int[] intArray14 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14);
//        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray9, intArray14);
//        mersenneTwister0.setSeed(intArray14);
//        int int18 = mersenneTwister0.nextInt();
//        double double19 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2477040176715246d + "'", double1 == 0.2477040176715246d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 830689682 + "'", int18 == 830689682);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.1467830901935037d) + "'", double19 == (-1.1467830901935037d));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(18, 0);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
//        double[] doubleArray20 = new double[] { 0.0d };
//        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
//        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
//        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
//        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
//        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
//        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
//        double double46 = blockRealMatrix45.getNorm();
//        double double47 = blockRealMatrix45.getFrobeniusNorm();
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
//        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
//        double double53 = blockRealMatrix52.getFrobeniusNorm();
//        boolean boolean54 = blockRealMatrix52.isSquare();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister55 = new org.apache.commons.math3.random.MersenneTwister();
//        int int57 = mersenneTwister55.nextInt((int) '4');
//        int[] intArray61 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray62 = org.apache.commons.math3.util.MathArrays.copyOf(intArray61);
//        mersenneTwister55.setSeed(intArray62);
//        int[] intArray67 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray68 = org.apache.commons.math3.util.MathArrays.copyOf(intArray67);
//        double double69 = org.apache.commons.math3.util.MathArrays.distance(intArray62, intArray67);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister70 = new org.apache.commons.math3.random.MersenneTwister();
//        int int72 = mersenneTwister70.nextInt((int) '4');
//        int[] intArray76 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray77 = org.apache.commons.math3.util.MathArrays.copyOf(intArray76);
//        mersenneTwister70.setSeed(intArray77);
//        int int79 = org.apache.commons.math3.util.MathArrays.distance1(intArray62, intArray77);
//        int[] intArray83 = new int[] { (-1), 0, (short) 0 };
//        int[] intArray84 = org.apache.commons.math3.util.MathArrays.copyOf(intArray83);
//        try {
//            org.apache.commons.math3.linear.RealMatrix realMatrix85 = blockRealMatrix52.getSubMatrix(intArray77, intArray84);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertNotNull(doubleArray15);
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertNotNull(doubleArray20);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertNotNull(realMatrix25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertNotNull(doubleArray35);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertNotNull(doubleArray43);
//        org.junit.Assert.assertNotNull(doubleArray44);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
//        org.junit.Assert.assertNotNull(blockRealMatrix48);
//        org.junit.Assert.assertNotNull(blockRealMatrix50);
//        org.junit.Assert.assertNotNull(blockRealMatrix52);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 342.18125286374413d + "'", double53 == 342.18125286374413d);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 28 + "'", int57 == 28);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 34 + "'", int72 == 34);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertNotNull(intArray84);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.07522571379268062d, (java.lang.Number) 1.9155040003582885E22d, false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(45, 37);
        double double3 = blockRealMatrix2.getNorm();
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray20 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        double[] doubleArray25 = new double[] { 0.0d };
        double[] doubleArray29 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray29);
        blockRealMatrix22.setRow((int) (byte) 0, doubleArray29);
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray40 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray44 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray48 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray49 = new double[][] { doubleArray36, doubleArray40, doubleArray44, doubleArray48 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray49);
        double double51 = blockRealMatrix50.getNorm();
        double double52 = blockRealMatrix50.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix22.add(blockRealMatrix50);
        double[] doubleArray57 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray61 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray65 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray69 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray70 = new double[][] { doubleArray57, doubleArray61, doubleArray65, doubleArray69 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        double[] doubleArray74 = new double[] { 0.0d };
        double[] doubleArray78 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray78);
        boolean boolean80 = org.apache.commons.math3.util.MathArrays.equals(doubleArray74, doubleArray78);
        blockRealMatrix71.setRow((int) (byte) 0, doubleArray78);
        double[] doubleArray82 = blockRealMatrix53.operate(doubleArray78);
        double[] doubleArray84 = new double[] { 0.0d };
        double[] doubleArray88 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix89 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray88);
        boolean boolean90 = org.apache.commons.math3.util.MathArrays.equals(doubleArray84, doubleArray88);
        double double91 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray78, doubleArray88);
        try {
            blockRealMatrix2.setRow((int) '4', doubleArray78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 40.000003814697266d + "'", double51 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 28.284272596161085d + "'", double52 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(realMatrix89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor49 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double50 = defaultRealMatrixPreservingVisitor49.end();
        double double51 = blockRealMatrix17.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix17.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix52.getColumnMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.floor(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector17.mapDivide(0.0d);
        try {
            arrayRealVector17.setEntry(0, 52.00000000000001d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        double[] doubleArray22 = new double[] { 0.0d };
        double[] doubleArray26 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray26);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        double[] doubleArray32 = new double[] { 0.0d };
        double[] doubleArray36 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray36);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray36);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray30);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair42 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray30, (java.lang.Double) 1.0d);
        double[] doubleArray45 = new double[] { 28.284272596161085d, (byte) 1 };
        double[] doubleArray47 = new double[] { 0.0d };
        double[] doubleArray51 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray51);
        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray51);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray51, (int) (short) 10);
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(doubleArray45, doubleArray51);
        double[] doubleArray58 = new double[] { 0.0d };
        double[] doubleArray62 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray62);
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray62);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray62, 32.0d);
        double double67 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray51, doubleArray62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10101.0d + "'", double67 == 10101.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double2 = org.apache.commons.math3.util.Precision.round(0.0d, 45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        try {
            array2DRowRealMatrix19.multiplyEntry(830689682, (int) (byte) 100, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (830,689,682)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 28.284272596161085d + "'", double23 == 28.284272596161085d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        double[][] doubleArray21 = array2DRowRealMatrix19.getDataRef();
        int int22 = array2DRowRealMatrix19.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix19.createMatrix((int) ' ', (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,023 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix19.walkInRowOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 28.284272596161085d + "'", double23 == 28.284272596161085d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math3.util.FastMath.pow(Double.NaN, (double) 52L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        double double20 = blockRealMatrix17.getNorm();
        int int21 = blockRealMatrix17.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix24 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix24.add(openMapRealMatrix27);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix28, 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix31 = blockRealMatrix17.preMultiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 40.000003814697266d + "'", double20 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapAddToSelf(0.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector32 = blockRealMatrix17.operateTranspose(realVector31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        double double53 = blockRealMatrix52.getFrobeniusNorm();
        boolean boolean54 = blockRealMatrix52.isSquare();
        org.apache.commons.math3.linear.RealVector realVector56 = blockRealMatrix52.getRowVector(0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor57 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double58 = blockRealMatrix52.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor57);
        defaultRealMatrixPreservingVisitor57.visit((int) 'a', 40, 32.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 342.18125286374413d + "'", double53 == 342.18125286374413d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double double4 = arrayRealVector2.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double11 = arrayRealVector10.getL1Norm();
        double[] doubleArray13 = new double[] { 0.0d };
        double[] doubleArray17 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray17);
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) (short) 10);
        boolean boolean22 = arrayRealVector10.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double26 = arrayRealVector25.getL1Norm();
        double[] doubleArray28 = new double[] { 0.0d };
        double[] doubleArray32 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray32);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) (short) 10);
        boolean boolean37 = arrayRealVector25.equals((java.lang.Object) (short) 10);
        double double38 = arrayRealVector10.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double42 = arrayRealVector41.getL1Norm();
        double double43 = arrayRealVector41.getLInfNorm();
        double double44 = arrayRealVector25.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction45 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector41.mapToSelf(univariateFunction45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector7.add((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapDivideToSelf((double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector48.copy();
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapAddToSelf((double) (-127));
        double double55 = realVector54.getMinValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 99.99999f, 4, orderDirection3, false);
        boolean boolean6 = nonMonotonicSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double51 = arrayRealVector50.getL1Norm();
        double[] doubleArray53 = new double[] { 0.0d };
        double[] doubleArray57 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray57);
        boolean boolean59 = org.apache.commons.math3.util.MathArrays.equals(doubleArray53, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57, (int) (short) 10);
        boolean boolean62 = arrayRealVector50.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double66 = arrayRealVector65.getL1Norm();
        double[] doubleArray68 = new double[] { 0.0d };
        double[] doubleArray72 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray72);
        boolean boolean74 = org.apache.commons.math3.util.MathArrays.equals(doubleArray68, doubleArray72);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72, (int) (short) 10);
        boolean boolean77 = arrayRealVector65.equals((java.lang.Object) (short) 10);
        double double78 = arrayRealVector50.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double82 = arrayRealVector81.getL1Norm();
        double double83 = arrayRealVector81.getLInfNorm();
        double double84 = arrayRealVector65.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction85 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = arrayRealVector81.mapToSelf(univariateFunction85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector47.add((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector41.combine(0.0d, 0.7804113358691207d, (org.apache.commons.math3.linear.RealVector) arrayRealVector87);
        try {
            arrayRealVector88.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector86);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertNotNull(arrayRealVector88);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, 1.0d, false);
        java.lang.Double double24 = pointValuePair23.getSecond();
        java.lang.Double double25 = pointValuePair23.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25.equals(1.0d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str10 = realMatrixFormat9.getColumnSeparator();
        java.text.NumberFormat numberFormat11 = realMatrixFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "hi!", numberFormat11);
        java.text.ParsePosition parsePosition14 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = realVectorFormat12.parse("", parsePosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray30);
        double[] doubleArray39 = array2DRowRealMatrix19.operate(doubleArray30);
        double[] doubleArray41 = new double[] { 0.0d };
        double[] doubleArray45 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equals(doubleArray41, doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray41);
        double[] doubleArray50 = new double[] { 0.0d };
        double[] doubleArray54 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray54);
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(doubleArray50, doubleArray54);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray50);
        double double58 = org.apache.commons.math3.util.MathArrays.distance(doubleArray41, doubleArray50);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, 0);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair63 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray60, 1.0d, false);
        java.lang.Double double64 = pointValuePair63.getSecond();
        double[] doubleArray65 = pointValuePair63.getFirst();
        double[] doubleArray66 = pointValuePair63.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, doubleArray66);
        boolean boolean69 = arrayRealVector67.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 3, (float) 0L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray30);
        double[] doubleArray39 = array2DRowRealMatrix19.operate(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor40 = null;
        try {
            double double45 = array2DRowRealMatrix19.walkInRowOrder(realMatrixChangingVisitor40, 830689682, (int) (byte) -1, 7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (830,689,682)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor18 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor18.start((int) (short) 10, (int) (byte) 0, 0, (int) ' ', (int) (byte) 1, 0);
        double double26 = blockRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double28 = blockRealMatrix17.walkInRowOrder(realMatrixChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = array2DRowRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix19.createMatrix((int) 'a', (int) 'a');
        double[] doubleArray28 = new double[] { 0.0d };
        double[] doubleArray32 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray32);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) (short) 10);
        double[] doubleArray38 = new double[] { 0.0d };
        double[] doubleArray42 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray42);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray42);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray36, doubleArray38);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray48 = new double[] { 0.0d };
        double[] doubleArray52 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray52);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray48, doubleArray52);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray48);
        double[] doubleArray57 = new double[] { 0.0d };
        double[] doubleArray61 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray61);
        boolean boolean63 = org.apache.commons.math3.util.MathArrays.equals(doubleArray57, doubleArray61);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray57);
        double double65 = org.apache.commons.math3.util.MathArrays.distance(doubleArray48, doubleArray57);
        double[] doubleArray66 = array2DRowRealMatrix46.operate(doubleArray57);
        try {
            double[] doubleArray67 = array2DRowRealMatrix19.preMultiply(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 28.284272596161085d + "'", double23 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (byte) 100, (double) 830689682, 0.6842846779199587d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.31571532208004d + "'", double3 == 99.31571532208004d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 37);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapSubtractToSelf(20.363884654445158d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double8 = arrayRealVector7.getL1Norm();
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) (short) 10);
        boolean boolean19 = arrayRealVector7.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double23 = arrayRealVector22.getL1Norm();
        double[] doubleArray25 = new double[] { 0.0d };
        double[] doubleArray29 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray29);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) (short) 10);
        boolean boolean34 = arrayRealVector22.equals((java.lang.Object) (short) 10);
        double double35 = arrayRealVector7.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double39 = arrayRealVector38.getL1Norm();
        double double40 = arrayRealVector38.getLInfNorm();
        double double41 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        try {
            double double42 = realVector4.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 1.57625987E17f, (double) 52, (-10.07608628613008d), (double) 46, (double) 100.0f, (double) 37);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.1965513218143058E18d + "'", double6 == 8.1965513218143058E18d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "hi!", "hi!", "", "hi!");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        java.text.ParsePosition parsePosition9 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat6.parse(",", parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1.0f), 0.0d, 29.0d, (double) 45, (double) 4, 0.07522571379268062d, (double) 1.0f, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1405.3009028551708d + "'", double8 == 1405.3009028551708d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.07522571379268062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07522571379268063d + "'", double1 == 0.07522571379268063d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(46, 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction31 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector2.mapToSelf(univariateFunction31);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor33 = null;
        try {
            double double36 = arrayRealVector32.walkInOptimizedOrder(realVectorPreservingVisitor33, (-127), 40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        int int20 = blockRealMatrix17.getRowDimension();
        double double21 = blockRealMatrix17.getFrobeniusNorm();
        double[] doubleArray26 = new double[] { 0.6483621820319939d, 1, Double.NaN, 0 };
        double[] doubleArray27 = blockRealMatrix17.preMultiply(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = blockRealMatrix17.getColumnMatrix(0);
        double[] doubleArray34 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray38 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray42 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray46 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray47 = new double[][] { doubleArray34, doubleArray38, doubleArray42, doubleArray46 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray47);
        double[] doubleArray51 = new double[] { 0.0d };
        double[] doubleArray55 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray55);
        boolean boolean57 = org.apache.commons.math3.util.MathArrays.equals(doubleArray51, doubleArray55);
        blockRealMatrix48.setRow((int) (byte) 0, doubleArray55);
        try {
            blockRealMatrix17.setRow(30, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 40.000003814697266d + "'", double18 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 28.284272596161085d + "'", double19 == 28.284272596161085d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 28.284272596161085d + "'", double21 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray4 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        blockRealMatrix18.setRow((int) (byte) 0, doubleArray25);
        double[] doubleArray32 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray36 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray40 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray44 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray45 = new double[][] { doubleArray32, doubleArray36, doubleArray40, doubleArray44 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double double47 = blockRealMatrix46.getNorm();
        double double48 = blockRealMatrix46.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix18.add(blockRealMatrix46);
        double[] doubleArray53 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray57 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray61 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray65 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray66 = new double[][] { doubleArray53, doubleArray57, doubleArray61, doubleArray65 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        double[] doubleArray70 = new double[] { 0.0d };
        double[] doubleArray74 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equals(doubleArray70, doubleArray74);
        blockRealMatrix67.setRow((int) (byte) 0, doubleArray74);
        double[] doubleArray78 = blockRealMatrix49.operate(doubleArray74);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister85 = new org.apache.commons.math3.random.MersenneTwister(0);
        float float86 = mersenneTwister85.nextFloat();
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker90 = new org.apache.commons.math3.optimization.SimpleValueChecker(1.0d, 0.0d);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer91 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(0, doubleArray78, 40, 0.0d, true, 34, (int) 'a', (org.apache.commons.math3.random.RandomGenerator) mersenneTwister85, false, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker90);
        int int93 = mersenneTwister85.nextInt(7);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 40.000003814697266d + "'", double47 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 28.284272596161085d + "'", double48 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 0.54881346f + "'", float86 == 0.54881346f);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException(localizable20, objArray21);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException27 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        org.apache.commons.math3.exception.MathInternalError mathInternalError28 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException27);
        zeroException22.addSuppressed((java.lang.Throwable) mathInternalError28);
        nullArgumentException19.addSuppressed((java.lang.Throwable) mathInternalError28);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(0.07522571379268063d, (double) 0.54881346f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.13622085309577045d + "'", double2 == 0.13622085309577045d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix9.add(openMapRealMatrix12);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix2.add(openMapRealMatrix13);
        int int15 = openMapRealMatrix2.getColumnDimension();
        openMapRealMatrix2.addToEntry(36, 12, (double) '4');
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 32.0d);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        boolean boolean14 = arrayRealVector2.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double18 = arrayRealVector17.getL1Norm();
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        boolean boolean29 = arrayRealVector17.equals((java.lang.Object) (short) 10);
        double double30 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double34 = arrayRealVector33.getL1Norm();
        double double35 = arrayRealVector33.getLInfNorm();
        double double36 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction37 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector33.mapToSelf(univariateFunction37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double51 = arrayRealVector50.getL1Norm();
        double[] doubleArray53 = new double[] { 0.0d };
        double[] doubleArray57 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray57);
        boolean boolean59 = org.apache.commons.math3.util.MathArrays.equals(doubleArray53, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57, (int) (short) 10);
        boolean boolean62 = arrayRealVector50.equals((java.lang.Object) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double66 = arrayRealVector65.getL1Norm();
        double[] doubleArray68 = new double[] { 0.0d };
        double[] doubleArray72 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray72);
        boolean boolean74 = org.apache.commons.math3.util.MathArrays.equals(doubleArray68, doubleArray72);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72, (int) (short) 10);
        boolean boolean77 = arrayRealVector65.equals((java.lang.Object) (short) 10);
        double double78 = arrayRealVector50.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(0, (double) 1);
        double double82 = arrayRealVector81.getL1Norm();
        double double83 = arrayRealVector81.getLInfNorm();
        double double84 = arrayRealVector65.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction85 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = arrayRealVector81.mapToSelf(univariateFunction85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector47.add((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector41.combine(0.0d, 0.7804113358691207d, (org.apache.commons.math3.linear.RealVector) arrayRealVector87);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor89 = null;
        try {
            double double90 = arrayRealVector88.walkInOptimizedOrder(realVectorChangingVisitor89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector86);
        org.junit.Assert.assertNotNull(arrayRealVector87);
        org.junit.Assert.assertNotNull(arrayRealVector88);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        long long1 = org.apache.commons.math3.util.FastMath.round(28.284272596161085d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 28L + "'", long1 == 28L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        int int1 = cMAESOptimizer0.getEvaluations();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList2 = cMAESOptimizer0.getStatisticsMeanHistory();
        java.util.List<java.lang.Double> doubleList3 = cMAESOptimizer0.getStatisticsSigmaHistory();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(realMatrixList2);
        org.junit.Assert.assertNotNull(doubleList3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", "}", "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-1)", "BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}", "{", "");
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray8 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray12 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix18.scalarAdd((double) 100L);
        double[][] doubleArray21 = blockRealMatrix18.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, false);
        try {
            array2DRowRealMatrix25.multiplyEntry(42, 40, 0.44488379011085244d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (42)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) 100);
        boolean boolean2 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_DIAGONALONLY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-48.21273601220948d) + "'", double1 == (-48.21273601220948d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix19.walkInRowOrder(realMatrixChangingVisitor20, (int) (short) -1, (int) ' ', 1229172938, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 830689682);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (int) '#');
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = openMapRealMatrix6.getSubMatrix((-1898220449), (int) (byte) 100, 36, 46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,898,220,449)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.000001f, (java.lang.Number) 4, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 4 + "'", number5.equals(4));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor49 = null;
        try {
            double double50 = blockRealMatrix45.walkInOptimizedOrder(realMatrixChangingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, 32.0d);
        int int3 = arrayRealVector2.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector4 = null;
        try {
            double double5 = arrayRealVector2.getLInfDistance(realVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9292874901149821d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.244251137893684d + "'", double1 == 53.244251137893684d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray2 = new double[] { 28.284272596161085d, (byte) 1 };
        double[] doubleArray4 = new double[] { 0.0d };
        double[] doubleArray8 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray8);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { 0.0d };
        double[] doubleArray19 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray19);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray19);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray19, 32.0d);
        double double24 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray8, doubleArray19);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection25 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10101.0d + "'", double24 == 10101.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 28L, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2730087030867106d + "'", double2 == 0.2730087030867106d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor53 = null;
        try {
            double double58 = blockRealMatrix50.walkInRowOrder(realMatrixChangingVisitor53, (int) ' ', 830689682, 3, 45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        double[][] doubleArray21 = array2DRowRealMatrix19.getDataRef();
        int[] intArray28 = new int[] { (short) -1, 42, (-1898220449), '4', (byte) 10, 12 };
        int[] intArray32 = new int[] { 37, '#', 'a' };
        org.apache.commons.math3.exception.util.Localizable localizable33 = null;
        double[] doubleArray38 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray42 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray46 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray50 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray51 = new double[][] { doubleArray38, doubleArray42, doubleArray46, doubleArray50 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = blockRealMatrix52.scalarAdd((double) 100L);
        double[][] doubleArray55 = blockRealMatrix52.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException56 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable33, (java.lang.Number) 1229172938, (java.lang.Object[]) doubleArray55);
        try {
            array2DRowRealMatrix19.copySubMatrix(intArray28, intArray32, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) (short) 10);
        double[] doubleArray11 = new double[] { 0.0d };
        double[] doubleArray15 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equals(doubleArray11, doubleArray15);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray21 = new double[] { 0.0d };
        double[] doubleArray25 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray25);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 0.0d };
        double[] doubleArray34 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray30);
        double[] doubleArray39 = array2DRowRealMatrix19.operate(doubleArray30);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, 0, 7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 7 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(0, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        int int1 = cMAESOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = blockRealMatrix66.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix66.scalarMultiply((double) (-1898220449));
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = blockRealMatrix17.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix66.scalarAdd(Double.NEGATIVE_INFINITY);
        try {
            blockRealMatrix72.addToEntry(46, 45, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (46)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        double[] doubleArray10 = new double[] { 0.0d };
        double[] doubleArray14 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray10);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, 0);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, 1.0d, false);
        java.lang.Double double24 = pointValuePair23.getSecond();
        double[] doubleArray25 = pointValuePair23.getFirst();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 0.19341001859048434d, true);
        java.lang.Double double29 = pointValuePair28.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.19341001859048434d + "'", double29.equals(0.19341001859048434d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException10 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        org.apache.commons.math3.exception.MathInternalError mathInternalError11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException10);
        java.lang.Integer[] intArray12 = matrixDimensionMismatchException10.getWrongDimensions();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException17 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        org.apache.commons.math3.exception.MathInternalError mathInternalError18 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException17);
        java.lang.Integer[] intArray19 = matrixDimensionMismatchException17.getWrongDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable5, intArray12, intArray19);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException21 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable4, (java.lang.Object[]) intArray19);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException28 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        org.apache.commons.math3.exception.MathInternalError mathInternalError29 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException28);
        java.lang.Integer[] intArray30 = matrixDimensionMismatchException28.getWrongDimensions();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException35 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 0, 4, 23);
        org.apache.commons.math3.exception.MathInternalError mathInternalError36 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException35);
        java.lang.Integer[] intArray37 = matrixDimensionMismatchException35.getWrongDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException38 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable23, intArray30, intArray37);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException39 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable22, (java.lang.Object[]) intArray37);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException40 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable3, intArray19, intArray37);
        org.apache.commons.math3.exception.MathInternalError mathInternalError41 = new org.apache.commons.math3.exception.MathInternalError(localizable2, (java.lang.Object[]) intArray37);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException42 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, (java.lang.Object[]) intArray37);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) intArray37);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 100, 0, (double) 1.0f);
        int int4 = nonSymmetricMatrixException3.getColumn();
        int int5 = nonSymmetricMatrixException3.getColumn();
        int int6 = nonSymmetricMatrixException3.getColumn();
        java.lang.Throwable[] throwableArray7 = nonSymmetricMatrixException3.getSuppressed();
        int int8 = nonSymmetricMatrixException3.getRow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, (int) 'a', 0, 0);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix45.scalarAdd(40.000003814697266d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd((double) '4');
        double double53 = blockRealMatrix52.getFrobeniusNorm();
        boolean boolean54 = blockRealMatrix52.isSquare();
        org.apache.commons.math3.linear.RealVector realVector56 = blockRealMatrix52.getRowVector(0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor57 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double58 = blockRealMatrix52.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor57);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = null;
        try {
            blockRealMatrix52.setColumnMatrix((-1), realMatrix60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 342.18125286374413d + "'", double53 == 342.18125286374413d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double[] doubleArray3 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray7 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray15 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d };
        double[] doubleArray24 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray24);
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray24);
        blockRealMatrix17.setRow((int) (byte) 0, doubleArray24);
        double[] doubleArray31 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray35 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray39 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray43 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        double double46 = blockRealMatrix45.getNorm();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix17.add(blockRealMatrix45);
        double[] doubleArray52 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray56 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray60 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[] doubleArray64 = new double[] { 0.0d, 10.000001f, 10.0f };
        double[][] doubleArray65 = new double[][] { doubleArray52, doubleArray56, doubleArray60, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d };
        double[] doubleArray73 = new double[] { (-1.0d), (short) 100, (short) 10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray73);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray69, doubleArray73);
        blockRealMatrix66.setRow((int) (byte) 0, doubleArray73);
        double[] doubleArray77 = blockRealMatrix48.operate(doubleArray73);
        java.lang.String str78 = blockRealMatrix48.toString();
        java.lang.String str79 = blockRealMatrix48.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = blockRealMatrix48.scalarMultiply(0.44488379011085244d);
        org.apache.commons.math3.linear.RealMatrix realMatrix82 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix83 = blockRealMatrix48.multiply(realMatrix82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 40.000003814697266d + "'", double46 == 40.000003814697266d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 28.284272596161085d + "'", double47 == 28.284272596161085d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}" + "'", str78.equals("BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}"));
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}" + "'", str79.equals("BlockRealMatrix{{-1.0,110.0000009537,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0},{0.0,20.0000019073,20.0}}"));
        org.junit.Assert.assertNotNull(realMatrix81);
    }
}

