import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        try {
//            double double5 = randomDataImpl0.nextWeibull((-3.579659772485965d), (double) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.58 is smaller than, or equal to, the minimum (0): shape (-3.58)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-13.090434458502163d) + "'", double2 == (-13.090434458502163d));
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        try {
//            double double10 = randomDataImpl0.nextUniform(2.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2 is larger than, or equal to, the maximum (0): lower bound (2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 33L + "'", long7 == 33L);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(localizable19);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double8 = randomDataImpl0.nextCauchy(0.19714599852834022d, 2.2698420336529133E-14d);
//        try {
//            int int11 = randomDataImpl0.nextBinomial(10, 96.62662226727419d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 96.627 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.199276656881516d) + "'", double2 == (-6.199276656881516d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.173473482137966d + "'", double5 == 2.173473482137966d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.19714599852830256d + "'", double8 == 0.19714599852830256d);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6331529618612717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7957090937404647d + "'", double1 == 0.7957090937404647d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.633135048155878d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8734964311589889d) + "'", double1 == (-0.8734964311589889d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        java.lang.Class<?> wildcardClass13 = localizable12.getClass();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, number14, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (-1.0f));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 0.5772156649015329d);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.util.FastMath.max(0.41646964686359267d, 3.1415926535897936d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535897936d + "'", double2 == 3.1415926535897936d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.4216778387643335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4100866814812275d + "'", double1 == 0.4100866814812275d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) 1, (double) 10.0f);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        try {
            double double7 = normalDistributionImpl3.inverseCumulativeProbability(2.6453780271243006d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.645 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextGaussian(Double.POSITIVE_INFINITY, 0.24197072451914337d);
        randomDataImpl0.reSeed((long) (short) -1);
        try {
            int int10 = randomDataImpl0.nextHypergeometric((int) 'a', (int) (byte) 100, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (97): number of successes (100) must be less than or equal to population size (97)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        long long1 = org.apache.commons.math.util.FastMath.abs(94L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 94L + "'", long1 == 94L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.rint(99.26232190815468d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5285398772192723d, (-0.0012567513107897763d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.009377784314891E-6d, number12, true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (short) 100, number14, false);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100);
        java.lang.Object[] objArray22 = notStrictlyPositiveException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException16, "", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable7, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (short) 100, number29, false);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) 0.6038806745841075d, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number45 = numberIsTooSmallException44.getMin();
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException44, "hi!", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException48.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException48.getGeneralPattern();
        java.lang.Object[] objArray51 = mathException48.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable33, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1 + "'", number45.equals(1));
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, number8, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 100);
        java.lang.Object[] objArray27 = notStrictlyPositiveException26.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21, "", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable12, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "hi!", objArray27);
        java.lang.Number number31 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (short) 100 + "'", number31.equals((short) 100));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.1247788095910867d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double8 = randomDataImpl0.nextCauchy(0.19714599852834022d, 2.2698420336529133E-14d);
//        double double10 = randomDataImpl0.nextChiSquare(0.4295726740839184d);
//        try {
//            double double13 = randomDataImpl0.nextUniform(0.9595362135599295d, (-12.903236125340678d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.96 is larger than, or equal to, the maximum (-12.903): lower bound (0.96) must be strictly less than upper bound (-12.903)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9156756257068628d + "'", double2 == 1.9156756257068628d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3971484175338132d + "'", double5 == 0.3971484175338132d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.19714599852833223d + "'", double8 == 0.19714599852833223d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.052590170563866195d + "'", double10 == 0.052590170563866195d);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 99.09143343552506d, (java.lang.Number) 0.29109205601513854d, false);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.039813057856886665d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.610619909971885d + "'", double1 == 1.610619909971885d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1);
        java.lang.Throwable throwable3 = null;
        try {
            convergenceException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 32, 1.5515679276951897d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.999999999999996d + "'", double2 == 31.999999999999996d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.cosh(95.74546394552561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9085197702665885E41d + "'", double1 == 1.9085197702665885E41d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextPascal((int) (short) 100, 7.105427357601002E-15d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl5.cumulativeProbability((double) 0, (double) 'a');
//        double double10 = normalDistributionImpl5.cumulativeProbability((double) 0);
//        double[] doubleArray12 = normalDistributionImpl5.sample(100);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        java.lang.String str15 = randomDataImpl0.nextHexString((int) (short) 10);
//        randomDataImpl0.reSeed();
//        double double19 = randomDataImpl0.nextCauchy(0.0d, 76.48515225589273d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.1451706246932366d) + "'", double13 == (-0.1451706246932366d));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "d8a585b7cc" + "'", str15.equals("d8a585b7cc"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-16.00558534662548d) + "'", double19 == (-16.00558534662548d));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.ceil(101.19169134626783d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 102.0d + "'", double1 == 102.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.8002167421130939d), (-4.50000000000008d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.5 is smaller than, or equal to, the minimum (0): standard deviation (-4.5)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.48147369475998336d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5224854023283165d) + "'", double1 == (-0.5224854023283165d));
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int9 = randomDataImpl0.nextInt((int) (byte) -1, 74);
//        try {
//            int int13 = randomDataImpl0.nextHypergeometric((int) '4', (-1), (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "025c75f0b4db72988e14c0b3e2fcc50b974bd1fbb2b2e6acc75211ebc383c2fd0d1e37cdc0039ff6353af196af6e9dce4418" + "'", str6.equals("025c75f0b4db72988e14c0b3e2fcc50b974bd1fbb2b2e6acc75211ebc383c2fd0d1e37cdc0039ff6353af196af6e9dce4418"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        try {
//            long long13 = randomDataImpl0.nextLong((long) (byte) 100, 31L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (31): lower bound (100) must be strictly less than upper bound (31)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4987665905169058d) + "'", double2 == (-0.4987665905169058d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.30552580956898084d + "'", double5 == 0.30552580956898084d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 2L, 1.1686995313225756d);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1686995313225756d + "'", double3 == 1.1686995313225756d);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        randomDataImpl0.reSeed((long) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 41L + "'", long7 == 41L);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        double double10 = randomDataImpl0.nextBeta(115.63645763306418d, 98.2771875112383d);
//        long long13 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) 1, (double) 10.0f);
//        double double18 = normalDistributionImpl17.sample();
//        double double19 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5014187449662948d + "'", double10 == 0.5014187449662948d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 6L + "'", long13 == 6L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 99.56260978953088d + "'", double18 == 99.56260978953088d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.0d + "'", double19 == 101.0d);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        double double10 = randomDataImpl0.nextBeta(115.63645763306418d, 98.2771875112383d);
//        long long13 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) (short) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl0.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 38L + "'", long7 == 38L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5393747770887415d + "'", double10 == 0.5393747770887415d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9L + "'", long13 == 9L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, number9, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) (short) 100, number20, false);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 100);
        java.lang.Object[] objArray28 = notStrictlyPositiveException27.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22, "", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable13, objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable6, objArray28);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable6, objArray32);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.9124034991009714d, number35, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException42, "hi!", objArray45);
        java.lang.Object[] objArray47 = mathException46.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray47);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 243.26884900298276d, (java.lang.Number) 1.7453292519943295d, true);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 1 + "'", number43.equals(1));
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 35, (double) 28L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11210114245241813d + "'", double2 == 0.11210114245241813d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.1546021862542448d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 100, number6, false);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (short) 100, number15, false);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100);
        java.lang.Object[] objArray34 = notStrictlyPositiveException33.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable19, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException8, "hi!", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) (short) 100, number40, false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException42);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8, localizable44, objArray49);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) convergenceException50);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextPascal((int) (short) 100, 7.105427357601002E-15d);
//        double double7 = randomDataImpl0.nextGamma(99.77773697854103d, 243.26884900298276d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 22993.856197446104d + "'", double7 == 22993.856197446104d);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int9 = randomDataImpl0.nextInt((int) (byte) -1, 74);
//        int int12 = randomDataImpl0.nextBinomial(1, 0.0d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100, 0.5d);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        randomDataImpl0.reSeedSecure((long) 35);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "8fbc03f47d26dc64236c6262ac9973158945a1ee82e96eb096d719ec9c226524786781c088c2dc5ceb454847138635189837" + "'", str6.equals("8fbc03f47d26dc64236c6262ac9973158945a1ee82e96eb096d719ec9c226524786781c088c2dc5ceb454847138635189837"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 28 + "'", int9 == 28);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.5766785226370272d + "'", double17 == 3.5766785226370272d);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (short) 100, number5, false);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 0.5403023058681398d);
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.9972584133216698d, number13, true);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17);
        java.lang.Object[] objArray19 = convergenceException18.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable9, objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.1102230246251565E-16d, (-0.10556413008078144d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, (long) 46);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.380515006246586d) + "'", double1 == (-3.380515006246586d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, number7, false);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (short) 100, number16, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) 100, number23, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) (short) 100, number34, false);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException36);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 100);
        java.lang.Object[] objArray42 = notStrictlyPositiveException41.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException36, "", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable27, objArray42);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable20, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable11, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(throwable3, localizable4, objArray42);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) convergenceException47);
        int int49 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.004196829083744448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.324848565479745E-5d + "'", double1 == 7.324848565479745E-5d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6231420254876312d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-19.086314648050166d) + "'", double1 == (-19.086314648050166d));
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.getMean();
//        double double2 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        try {
//            double[] doubleArray5 = normalDistributionImpl0.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3365179487134733d + "'", double2 == 0.3365179487134733d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare(91.19769990076465d);
//        int int12 = randomDataImpl0.nextHypergeometric(2147483647, 2147483647, 0);
//        randomDataImpl0.reSeed();
//        double double16 = randomDataImpl0.nextWeibull(0.5772156649015329d, 1.3188294121079154d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "027ee330e0" + "'", str6.equals("027ee330e0"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 96.65662524281768d + "'", double8 == 96.65662524281768d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.7147110575702735d + "'", double16 == 0.7147110575702735d);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        double double7 = randomDataImpl0.nextChiSquare(0.19714599852831283d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0016237745702784368d + "'", double2 == 0.0016237745702784368d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 71 + "'", int5 == 71);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.15301274083183927d + "'", double7 == 0.15301274083183927d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35L, (float) 28L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.tan(96.40099629302728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5182956827956122d) + "'", double1 == (-1.5182956827956122d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.cos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double7 = randomDataImpl0.nextExponential(0.5913383588370286d);
//        long long10 = randomDataImpl0.nextSecureLong(41L, (long) 'a');
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0027072360243332013d) + "'", double2 == (-0.0027072360243332013d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5059378508529682d + "'", double5 == 0.5059378508529682d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.054351863245669096d + "'", double7 == 0.054351863245669096d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 82L + "'", long10 == 82L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (short) 100, number5, false);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 100);
        java.lang.Object[] objArray13 = notStrictlyPositiveException12.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7, "", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (short) 100, number33, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (short) 100, number44, false);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 100);
        java.lang.Object[] objArray52 = notStrictlyPositiveException51.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable37, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(10, "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)", objArray52);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException19, "a", objArray52);
        java.lang.Class<?> wildcardClass59 = objArray52.getClass();
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (0.399): 1 is smaller than, or equal to, the minimum (0.399)", objArray52);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double8 = randomDataImpl0.nextCauchy(0.19714599852834022d, 2.2698420336529133E-14d);
//        double double10 = randomDataImpl0.nextT(0.11236685248036105d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double14 = randomDataImpl0.nextGamma((-1.0305386432353167d), (-0.6501341356232105d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.031 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5666245019204474d + "'", double2 == 1.5666245019204474d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.9566660812064796d) + "'", double5 == (-0.9566660812064796d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1971459985282959d + "'", double8 == 0.1971459985282959d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-44.59069218017819d) + "'", double10 == (-44.59069218017819d));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.718104763569834E-134d, (-0.6981527919520386d), 0.3275850202917727d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.698 is smaller than, or equal to, the minimum (0): standard deviation (-0.698)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, 26L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 26L + "'", long2 == 26L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.605170185988092d, 0.5036524057165976d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.538279137014242E-4d + "'", double2 == 4.538279137014242E-4d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0, (double) 'a');
        double double5 = normalDistributionImpl0.cumulativeProbability((double) 0);
        double double7 = normalDistributionImpl0.cumulativeProbability(1.7453292519943295d);
        double double8 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9595362135599295d + "'", double7 == 0.9595362135599295d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.util.FastMath.min(98.2771875112383d, (-1.5700164958950522d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5700164958950522d) + "'", double2 == (-1.5700164958950522d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        try {
//            long long7 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7121957282944689d + "'", double2 == 1.7121957282944689d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 44 + "'", int5 == 44);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (short) 100, number4, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (short) 100, number13, false);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) (short) 100, number24, false);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 100);
        java.lang.Object[] objArray32 = notStrictlyPositiveException31.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException26, "", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable17, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException6, "hi!", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (short) 100, number38, false);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6, localizable42, objArray47);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (-0.06247684913107121d), (java.lang.Number) 32, false);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) (short) 100, number56, false);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException58);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException58.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable63, (java.lang.Number) (short) 100, number65, false);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67);
        org.apache.commons.math.exception.util.Localizable localizable69 = numberIsTooSmallException67.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable70, (java.lang.Number) (short) 100, number72, false);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException74);
        org.apache.commons.math.exception.util.Localizable localizable76 = numberIsTooSmallException74.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable76, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Number number83 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable81, (java.lang.Number) (short) 100, number83, false);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException85);
        org.apache.commons.math.exception.util.Localizable localizable88 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException90 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable88, (java.lang.Number) 100);
        java.lang.Object[] objArray91 = notStrictlyPositiveException90.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException85, "", objArray91);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable76, objArray91);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException(localizable69, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException(localizable60, objArray91);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable53, objArray91);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (0.399): 1 is smaller than, or equal to, the minimum (0.399)", objArray91);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-57.29577951308232d), (java.lang.Number) 0.08695332333554694d, true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.cos((-14.008000361758821d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12880770958097254d + "'", double1 == 0.12880770958097254d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.633135048155878d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        randomDataImpl0.reSeedSecure(26L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8932740142039891d + "'", double2 == 0.8932740142039891d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.3215203952789065d) + "'", double5 == (-0.3215203952789065d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (short) 100, number18, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (short) 100, number29, false);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 100);
        java.lang.Object[] objArray37 = notStrictlyPositiveException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable22, objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable15, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable6, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) (short) 100, number45, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException47.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable49, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) (short) 100, number56, false);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException63 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable61, (java.lang.Number) 100);
        java.lang.Object[] objArray64 = notStrictlyPositiveException63.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException58, "", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable49, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable68 = mathException67.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable69, (java.lang.Number) 100);
        java.lang.Object[] objArray72 = notStrictlyPositiveException71.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable68, objArray72);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 0.5403023058681398d, true);
        java.lang.Number number80 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (-0.1451706246932366d), (java.lang.Number) 0.03490658503988659d, number80);
        java.lang.Class<?> wildcardClass82 = localizable6.getClass();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(wildcardClass82);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.9595362135599295d, (java.lang.Number) 0.4881288021936899d, false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.29109205601513854d };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray22);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, number8, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 100);
        java.lang.Object[] objArray27 = notStrictlyPositiveException26.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21, "", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable12, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Class<?> wildcardClass32 = mathException31.getClass();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) (short) 100, number35, false);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 0.5403023058681398d);
        java.lang.Throwable throwable42 = null;
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (short) 100, number48, false);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException50);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException50.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable52, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) 100);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException59, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable52, objArray63);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException43, "hi!", objArray63);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable67, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number72 = numberIsTooSmallException71.getMin();
        java.lang.Object[] objArray74 = null;
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException71, "hi!", objArray74);
        java.lang.Object[] objArray76 = mathException75.getArguments();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException65, "", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31, localizable39, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)", objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(10, "ead9cbcbed204114c631895b2f94358282ce4063920035cbe75d17e9b278b42deaac3007f0f53682c91af5e111994bdc06b0", objArray76);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 1 + "'", number72.equals(1));
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 1.009377784314891E-6d, number13, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.0d, (java.lang.Number) 0.9352042265279327d, false);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1);
        int int22 = maxIterationsExceededException21.getMaxIterations();
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (short) 100, number27, false);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) (short) 100, number36, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) (short) 100, number43, false);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException45.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) (short) 100, number54, false);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 100);
        java.lang.Object[] objArray62 = notStrictlyPositiveException61.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56, "", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable47, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable40, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable31, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(throwable23, localizable24, objArray62);
        maxIterationsExceededException21.addSuppressed((java.lang.Throwable) convergenceException67);
        int int69 = maxIterationsExceededException21.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException(localizable71, (java.lang.Number) 0.5d, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) (short) -1);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.28713040364690934d, (java.lang.Number) (-1.0305386432353167d), (java.lang.Number) 1.7853314409882288d);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException79);
        java.lang.Object[] objArray82 = new java.lang.Object[] { numberIsTooSmallException19, int69, 9.33117428632563E-4d, (short) -1, convergenceException80, "6085dceb62" };
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException("7551b0013c", objArray82);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 83L, (-0.5715250677379627d), (double) 82L, 5);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.cosh(115.63645763306418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.303199278676607E49d + "'", double1 == 8.303199278676607E49d);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.getMean();
//        double double2 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double6 = normalDistributionImpl0.cumulativeProbability(112.19090887502371d, 115.63645763306418d);
//        try {
//            double double8 = normalDistributionImpl0.inverseCumulativeProbability((double) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 35 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6813849228536563d + "'", double2 == 0.6813849228536563d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.29109205601513854d, number2, true);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        double double8 = randomDataImpl0.nextGaussian(0.5693246134790239d, (double) 35);
//        long long11 = randomDataImpl0.nextLong((long) 2, (long) 100);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8279126347531564d + "'", double2 == 0.8279126347531564d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 60 + "'", int5 == 60);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-9.008286199607053d) + "'", double8 == (-9.008286199607053d));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 71L + "'", long11 == 71L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.asin(100.91758160382048d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        try {
//            int[] intArray8 = randomDataImpl0.nextPermutation(100, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9470986532070401d + "'", double2 == 0.9470986532070401d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int9 = randomDataImpl0.nextInt((int) (byte) -1, 74);
//        int int12 = randomDataImpl0.nextBinomial(1, 0.0d);
//        double double15 = randomDataImpl0.nextUniform(0.09388966880694093d, 4.590508882530958d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4453b3f7351125345ffb02a19c03744da6d5b87937dbdb87d309739c59c38a5dccdf89f52c06e6a9e0eee4ed5e817def85e5" + "'", str6.equals("4453b3f7351125345ffb02a19c03744da6d5b87937dbdb87d309739c59c38a5dccdf89f52c06e6a9e0eee4ed5e817def85e5"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 47 + "'", int9 == 47);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.821339006199184d + "'", double15 == 3.821339006199184d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0305386432353167d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.6453780271243006d, (-0.6501341356232105d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5312834618380046d + "'", double2 == 0.5312834618380046d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double8 = randomDataImpl0.nextCauchy(0.19714599852834022d, 2.2698420336529133E-14d);
//        double double10 = randomDataImpl0.nextT(0.11236685248036105d);
//        randomDataImpl0.reSeed(100L);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution13 = null;
//        try {
//            double double14 = randomDataImpl0.nextInversionDeviate(continuousDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7465359098942371d + "'", double2 == 0.7465359098942371d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.2506681121976035d) + "'", double5 == (-1.2506681121976035d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1971459985282833d + "'", double8 == 0.1971459985282833d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.17939229712989596d + "'", double10 == 0.17939229712989596d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0, (double) 'a');
        double double5 = normalDistributionImpl0.cumulativeProbability((double) 0);
        double double6 = normalDistributionImpl0.getMean();
        double[] doubleArray8 = normalDistributionImpl0.sample((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (short) 100, number13, false);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 100);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException24, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable17, objArray28);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 98.2771875112383d, false);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable17, objArray34);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.2686046189145646d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.689503868988906d + "'", double1 == 3.689503868988906d);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        randomDataImpl0.reSeed();
//        int int7 = randomDataImpl0.nextHypergeometric(60, 60, 0);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.40283451908833545d + "'", double2 == 0.40283451908833545d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextPascal((int) (short) 100, 7.105427357601002E-15d);
//        double double7 = randomDataImpl0.nextF((double) 1L, 96.99999999999999d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (0.399): 1 is smaller than, or equal to, the minimum (0.399)", "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3013623821029715d + "'", double7 == 0.3013623821029715d);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.08695332333554694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08673516427455415d + "'", double1 == 0.08673516427455415d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(throwable5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6);
        outOfRangeException3.addSuppressed((java.lang.Throwable) convergenceException6);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100, 0.5d);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double12 = randomDataImpl0.nextGamma(1205.589302129051d, 415.93241984113087d);
//        double double15 = randomDataImpl0.nextCauchy(0.12880770958097254d, 3.5766785226370272d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.7547400772077d + "'", double4 == 100.7547400772077d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 49.50000000000098d + "'", double9 == 49.50000000000098d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 501719.68531735206d + "'", double12 == 501719.68531735206d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.2842802673658078d) + "'", double15 == (-1.2842802673658078d));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1205.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.787381854311312d + "'", double1 == 7.787381854311312d);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100, 0.5d);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double12 = normalDistributionImpl8.cumulativeProbability(0.0d, (double) 87L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.53359419655142d + "'", double4 == 100.53359419655142d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-62.50000000000124d) + "'", double9 == (-62.50000000000124d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.30784979789630396d + "'", double12 == 0.30784979789630396d);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.11478481378318722d), (java.lang.Number) (-0.03981305785688667d), true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (short) 100, number10, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) 100, number23, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) (short) 100, number32, false);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException34);
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) (short) 100, number43, false);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) 100);
        java.lang.Object[] objArray51 = notStrictlyPositiveException50.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45, "", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable36, objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException25, "hi!", objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable14, objArray51);
        java.lang.Object[] objArray56 = convergenceException7.getArguments();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, number9, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) (short) 100, number20, false);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 100);
        java.lang.Object[] objArray28 = notStrictlyPositiveException27.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22, "", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable13, objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable6, objArray28);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable6, objArray32);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.9124034991009714d, number35, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException42, "hi!", objArray45);
        java.lang.Object[] objArray47 = mathException46.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray47);
        java.lang.Object[] objArray49 = mathIllegalArgumentException48.getArguments();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 1 + "'", number43.equals(1));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100);
        java.lang.Object[] objArray11 = notStrictlyPositiveException10.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Class<?> wildcardClass14 = localizable13.getClass();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number15, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (-1.0f));
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable13, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (short) 100, number37, false);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 100);
        java.lang.Object[] objArray45 = notStrictlyPositiveException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39, "", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(localizable30, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable51 = maxIterationsExceededException50.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNull(localizable51);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5036524057165976d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5541879441848107d + "'", double1 == 0.5541879441848107d);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int9 = randomDataImpl0.nextBinomial(1, 1.0E-323d);
//        double double12 = randomDataImpl0.nextWeibull((double) (byte) 100, (double) 10.0f);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "49097f434c2e1519547eef7160f329b13f65f58ec0ec48f204f33dd5c20853bad74dae251ae0583b13eeaddacd3f2779e21d" + "'", str6.equals("49097f434c2e1519547eef7160f329b13f65f58ec0ec48f204f33dd5c20853bad74dae251ae0583b13eeaddacd3f2779e21d"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.039617459311529d + "'", double12 == 10.039617459311529d);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.92931893602724d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5366007539061166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009365449924345558d + "'", double1 == 0.009365449924345558d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.6156264703860141d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        randomDataImpl0.reSeed((long) (byte) 10);
//        int int12 = randomDataImpl0.nextInt(10, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl13.getMean();
//        double double15 = normalDistributionImpl13.sample();
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double17 = normalDistributionImpl13.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 74 + "'", int12 == 74);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.35742506931883394d + "'", double15 == 0.35742506931883394d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.6501341356232105d) + "'", double16 == (-0.6501341356232105d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.013462623778017066d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5842593572720973d + "'", double1 == 1.5842593572720973d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.special.Erf.erf(0.15585191703561807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17444650256631186d + "'", double1 == 0.17444650256631186d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (short) 100, number10, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (short) 100, number21, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100);
        java.lang.Object[] objArray29 = notStrictlyPositiveException28.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23, "", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable14, objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable7, objArray29);
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable7, objArray33);
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.9124034991009714d, number36, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (short) 100, number41, false);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable45, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable45, (java.lang.Number) 9.999999999999998d);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) (short) 100, number56, false);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException58);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException58.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException66 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable60, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        java.lang.Number number67 = numberIsTooLargeException66.getMax();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException66);
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) (short) 100, number73, false);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException75);
        org.apache.commons.math.exception.util.Localizable localizable77 = numberIsTooSmallException75.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException(localizable77, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Number number84 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) (short) 100, number84, false);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException86);
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException91 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable89, (java.lang.Number) 100);
        java.lang.Object[] objArray92 = notStrictlyPositiveException91.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException86, "", objArray92);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException(localizable77, objArray92);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException("", objArray92);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68, "hi!", objArray92);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable45, objArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException98 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable7, objArray92);
        int int99 = maxIterationsExceededException98.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + (-1.0f) + "'", number67.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 100 + "'", int99 == 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1);
        java.lang.Object[] objArray3 = convergenceException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException2.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, number7, false);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (short) 100, number14, false);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) 100, number25, false);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 100);
        java.lang.Object[] objArray33 = notStrictlyPositiveException32.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException27, "", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable18, objArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable11, objArray33);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable11, objArray37);
        java.lang.String str39 = convergenceException2.getPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{0}" + "'", str39.equals("{0}"));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        randomDataImpl0.reSeed((long) (byte) 10);
//        int int12 = randomDataImpl0.nextInt(10, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl13.getMean();
//        double double15 = normalDistributionImpl13.sample();
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        long long19 = randomDataImpl0.nextLong((long) (byte) 0, (long) 5);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 40L + "'", long7 == 40L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 74 + "'", int12 == 74);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0969903231067861d + "'", double15 == 0.0969903231067861d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.6501341356232105d) + "'", double16 == (-0.6501341356232105d));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4855874989531728d + "'", double1 == 2.4855874989531728d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.2842802673658078d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9592342985552653d) + "'", double1 == (-0.9592342985552653d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1.0d) + "'", number2.equals((-1.0d)));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1);
        java.lang.Object[] objArray3 = convergenceException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException2.getSpecificPattern();
        java.lang.String str5 = convergenceException2.getPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (short) 100, number12, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable16, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) 100, number23, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 100);
        java.lang.Object[] objArray31 = notStrictlyPositiveException30.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25, "", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable16, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, "hi!", objArray31);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("e5fb611863f4668a1e9936fd930b2178adc70184402c1a92fa1a007c19c79472131e9de3df17820a5c47b51cc57d6b7d33f4", objArray31);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0398208803931389d, 0.0398208803931389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10251805412862824d + "'", double2 == 0.10251805412862824d);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        double double10 = randomDataImpl0.nextWeibull(3.623806936499755E-276d, 7.105427357601002E-15d);
//        long long12 = randomDataImpl0.nextPoisson((double) 83L);
//        try {
//            double double15 = randomDataImpl0.nextGaussian(77.95032975941305d, (-0.7073269466095004d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.707 is smaller than, or equal to, the minimum (0): standard deviation (-0.707)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31L + "'", long7 == 31L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 90L + "'", long12 == 90L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.91758160382048d, 101.93296685226451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.44674064256860674d + "'", double2 == 0.44674064256860674d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextPascal((int) (short) 100, 7.105427357601002E-15d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl5.cumulativeProbability((double) 0, (double) 'a');
//        double double10 = normalDistributionImpl5.cumulativeProbability((double) 0);
//        double[] doubleArray12 = normalDistributionImpl5.sample(100);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl0.reSeedSecure((long) 32);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.7513602501600438d) + "'", double13 == (-0.7513602501600438d));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 6L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1 == 6.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.7513602501600438d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6443711006409302d) + "'", double1 == (-0.6443711006409302d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7941917836018157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 74L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.0d + "'", double1 == 74.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.2842802673658078d), (java.lang.Number) 0.3989392509463883d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.3989392509463883d + "'", number4.equals(0.3989392509463883d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        java.lang.Object[] objArray3 = notStrictlyPositiveException2.getArguments();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 0.7779860823611199d, (java.lang.Number) 0.6118464070424346d, number8);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (short) 100, number15, false);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) 100, number22, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (short) 100, number33, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 100);
        java.lang.Object[] objArray41 = notStrictlyPositiveException40.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35, "", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable26, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable19, objArray41);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(10, "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)", objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray41);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (short) 100, number13, false);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 100);
        java.lang.Object[] objArray21 = notStrictlyPositiveException20.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15, "", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable6, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (short) 100, number33, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (short) 100, number44, false);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 100);
        java.lang.Object[] objArray52 = notStrictlyPositiveException51.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable37, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable30, objArray52);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 99.77773697854103d, (java.lang.Number) 1205.589302129051d, true);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) (short) 100, number62, false);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException64);
        org.apache.commons.math.exception.util.Localizable localizable66 = numberIsTooSmallException64.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException(localizable66, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) (short) 100, number73, false);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException75);
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable78, (java.lang.Number) 100);
        java.lang.Object[] objArray81 = notStrictlyPositiveException80.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException75, "", objArray81);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException(localizable66, objArray81);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23, localizable30, objArray81);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException88 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 100.91758160382047d, (java.lang.Number) 0.19714599852834022d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException90 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 104.36754563095616d);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray81);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(28);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(96.62662226727419d, (-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) 0.6038806745841075d, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.2456194955503825d, (java.lang.Number) 35L, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 1.009377784314891E-6d, number29, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.0d, (java.lang.Number) 0.9352042265279327d, false);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number41 = numberIsTooSmallException40.getMin();
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException40, "hi!", objArray43);
        java.lang.Object[] objArray45 = mathException44.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable23, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathIllegalArgumentException46.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1 + "'", number41.equals(1));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 31L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.2871520324188792d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.5366007539061166d, (java.lang.Number) 2.932995401022578d, (java.lang.Number) (-1.1752011936438014d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 0.28713040364690934d);
        java.lang.Class<?> wildcardClass10 = notStrictlyPositiveException9.getClass();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (short) 100, number14, false);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        java.lang.Number number25 = numberIsTooLargeException24.getMax();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) (short) 100, number31, false);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException33);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException33.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) (short) 100, number42, false);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) 100);
        java.lang.Object[] objArray50 = notStrictlyPositiveException49.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44, "", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable35, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26, "hi!", objArray50);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException9, "", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("fafe855bda", objArray50);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0f) + "'", number25.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(61.261701761001994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9421185957303497d + "'", double1 == 3.9421185957303497d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7940888107757297d, 0.5366007539061166d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5366007539061166d + "'", double2 == 0.5366007539061166d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100, 0.5d);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        try {
//            double double12 = randomDataImpl0.nextUniform(1.1684305919340625d, 0.03490658503988659d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1.168 is larger than, or equal to, the maximum (0.035): lower bound (1.168) must be strictly less than upper bound (0.035)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.33360218105157d + "'", double4 == 32.33360218105157d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-50.93343236490404d) + "'", double9 == (-50.93343236490404d));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.special.Erf.erf((-14.351783721659034d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        java.lang.Object[] objArray3 = notStrictlyPositiveException2.getArguments();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 0.7779860823611199d, (java.lang.Number) 0.6118464070424346d, number8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-6.269109644656001d));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 1);
//        randomDataImpl0.reSeed(31L);
//        long long13 = randomDataImpl0.nextPoisson(0.8813735870195429d);
//        randomDataImpl0.reSeed((long) '4');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 30.96604661043997d + "'", double4 == 30.96604661043997d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5729.5779513082325d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5704472609586753d + "'", double2 == 1.5704472609586753d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4216778387643335d, 1.5842593572720973d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.42167783876433357d + "'", double2 == 0.42167783876433357d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.FastMath.max(0.3025806528694417d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.3258259776114005d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (short) 100, number12, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (short) 100, number21, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) (short) 100, number32, false);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 100);
        java.lang.Object[] objArray40 = notStrictlyPositiveException39.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException34, "", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable25, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException14, "hi!", objArray40);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("19cf0794af", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable6, objArray40);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        double double8 = randomDataImpl0.nextGaussian(0.5693246134790239d, (double) 35);
//        double double11 = randomDataImpl0.nextGaussian(0.0d, 1.489774667644268d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5574745824944451d) + "'", double2 == (-1.5574745824944451d));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.783262205996428d + "'", double8 == 11.783262205996428d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3256924039067051d + "'", double11 == 0.3256924039067051d);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6619574321524444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.939186667985567d) + "'", double1 == (-10.939186667985567d));
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) 1, (double) 10.0f);
//        double double5 = normalDistributionImpl3.cumulativeProbability((-0.9999999999999999d));
//        double double6 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
//        double double10 = normalDistributionImpl3.cumulativeProbability(0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 98.9525882879068d + "'", double6 == 98.9525882879068d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Number number11 = outOfRangeException10.getArgument();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 1);
//        randomDataImpl0.reSeed(31L);
//        randomDataImpl0.reSeedSecure((long) 10);
//        randomDataImpl0.reSeedSecure((long) 74);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 55.37648464202509d + "'", double4 == 55.37648464202509d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 51L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-34.18589348204686d), (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8184127399016886d) + "'", double2 == (-0.8184127399016886d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6449340668481562d + "'", double1 == 1.6449340668481562d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-634.2259605531877d), (double) 74L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-634.2259605531876d) + "'", double2 == (-634.2259605531876d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.floor((-16.00558534662548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-17.0d) + "'", double1 == (-17.0d));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextPascal((int) (short) 100, 7.105427357601002E-15d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl5.cumulativeProbability((double) 0, (double) 'a');
//        double double10 = normalDistributionImpl5.cumulativeProbability((double) 0);
//        double[] doubleArray12 = normalDistributionImpl5.sample(100);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        java.lang.String str15 = randomDataImpl0.nextHexString((int) (short) 10);
//        randomDataImpl0.reSeed();
//        try {
//            double double19 = randomDataImpl0.nextF((double) 100, (-1.238629919027038d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.239 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.239)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.2977486106786282d + "'", double13 == 1.2977486106786282d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9c612b63e7" + "'", str15.equals("9c612b63e7"));
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.427597452481342E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.535270686234774E21d + "'", double1 == 2.535270686234774E21d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooLargeException12.getMax();
        java.lang.Object[] objArray15 = numberIsTooLargeException12.getArguments();
        boolean boolean16 = numberIsTooLargeException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0f) + "'", number14.equals((-1.0f)));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 1);
//        randomDataImpl0.reSeed(31L);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString(71);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 149.8344029638277d + "'", double4 == 149.8344029638277d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "b932c3178d0013e0f6726b0dde24dace776b9452fd72f2232f88b5541b79d177754b2d8" + "'", str13.equals("b932c3178d0013e0f6726b0dde24dace776b9452fd72f2232f88b5541b79d177754b2d8"));
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        double double10 = randomDataImpl0.nextUniform((double) 1, 9.999999999999998d);
//        try {
//            int int13 = randomDataImpl0.nextPascal(32, (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 44L + "'", long7 == 44L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.547649359174369d + "'", double10 == 2.547649359174369d);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.6443711006409302d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8637313535921449d) + "'", double1 == (-0.8637313535921449d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 100);
        long long5 = randomDataImpl0.nextLong((long) (short) 10, 97L);
        int int9 = randomDataImpl0.nextHypergeometric(46, 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 73L + "'", long5 == 73L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.9085197702665885E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7779860823611199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7123284421983315d + "'", double1 == 0.7123284421983315d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0, (double) 'a');
        normalDistributionImpl0.reseedRandomGenerator((-1L));
        double[] doubleArray7 = normalDistributionImpl0.sample(100);
        double double9 = normalDistributionImpl0.density((-1.45900747833139d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1376157436291832d + "'", double9 == 0.1376157436291832d);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        double double10 = randomDataImpl0.nextChiSquare(0.28551985986505746d);
//        try {
//            double double13 = randomDataImpl0.nextUniform(0.8813735870195429d, (double) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.881 is larger than, or equal to, the maximum (0): lower bound (0.881) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.752840004977593d + "'", double2 == 8.752840004977593d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.1612677327498586d + "'", double5 == 1.1612677327498586d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14774340556496585d + "'", double10 == 0.14774340556496585d);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double7 = randomDataImpl0.nextExponential(0.5913383588370286d);
//        try {
//            double double10 = randomDataImpl0.nextCauchy(1.489774667644268d, Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): scale (-∞)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.685514331174602d + "'", double2 == 7.685514331174602d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.9517832384425156d) + "'", double5 == (-0.9517832384425156d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.42415230714491753d + "'", double7 == 0.42415230714491753d);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) 0.6038806745841075d, (java.lang.Number) (-1L));
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.2456194955503825d, (java.lang.Number) 35L, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 1.009377784314891E-6d, number29, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.0d, (java.lang.Number) 0.9352042265279327d, false);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number41 = numberIsTooSmallException40.getMin();
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException40, "hi!", objArray43);
        java.lang.Object[] objArray45 = mathException44.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable23, objArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 89.52224968510244d, (java.lang.Number) 0.0038971134198105897d, true);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1 + "'", number41.equals(1));
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 97.0f, (-0.039813057856886665d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, number9, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) (short) 100, number20, false);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 100);
        java.lang.Object[] objArray28 = notStrictlyPositiveException27.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22, "", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable13, objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable6, objArray28);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 99.77773697854103d, (java.lang.Number) 1205.589302129051d, true);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (short) 100, number44, false);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46);
        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooSmallException46.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) 0.5403023058681398d);
        java.lang.Number number52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.9972584133216698d, number52, true);
        java.lang.Throwable throwable55 = null;
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(throwable55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56);
        java.lang.Object[] objArray58 = convergenceException57.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException41, localizable48, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable38, objArray58);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray58);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.special.Gamma.digamma(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5409943226533644d + "'", double1 == 3.5409943226533644d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.067052789195166E-134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 307.425685364221d + "'", double1 == 307.425685364221d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 0.28713040364690934d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.28713040364690934d + "'", number5.equals(0.28713040364690934d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.28713040364690934d + "'", number6.equals(0.28713040364690934d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.41646964686359267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007268766572387768d + "'", double1 == 0.007268766572387768d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.35183775069553463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3591418004099948d + "'", double1 == 0.3591418004099948d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.7941917836018157d);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) 100, number22, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 100);
        java.lang.Object[] objArray30 = notStrictlyPositiveException29.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24, "", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable15, objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) (short) 100, number36, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException38.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, objArray45);
        java.lang.Object[] objArray47 = numberIsTooSmallException4.getArguments();
        java.lang.Number number48 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, (float) 27L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 27.0f + "'", float2 == 27.0f);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        randomDataImpl0.reSeed();
//        double double5 = randomDataImpl0.nextT(99.0d);
//        try {
//            int int8 = randomDataImpl0.nextSecureInt(71, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71 is larger than, or equal to, the maximum (35): lower bound (71) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.34604273196212054d) + "'", double2 == (-0.34604273196212054d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.29040746022600367d) + "'", double5 == (-0.29040746022600367d));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int2 = org.apache.commons.math.util.FastMath.min(2147483647, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double2 = org.apache.commons.math.util.FastMath.pow(415.93241984113087d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian(Double.POSITIVE_INFINITY, 0.24197072451914337d);
//        double double6 = randomDataImpl0.nextExponential(4.9E-324d);
//        randomDataImpl0.reSeedSecure();
//        double double9 = randomDataImpl0.nextExponential(0.5285398772192723d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-323d + "'", double6 == 1.0E-323d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.19244734340303296d + "'", double9 == 0.19244734340303296d);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        long long1 = org.apache.commons.math.util.FastMath.round(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.600161852571429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.600161852571429d + "'", double1 == 4.600161852571429d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3256924039067051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3317439696398749d + "'", double1 == 0.3317439696398749d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (short) 100, number18, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (short) 100, number29, false);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 100);
        java.lang.Object[] objArray37 = notStrictlyPositiveException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable22, objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable15, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable6, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.421935344392128d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.6033771554807055d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.647729269736577d) + "'", double1 == (-0.647729269736577d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1686995313225756d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1686995313225756d + "'", double1 == 1.1686995313225756d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.013462623778017066d), 0.08673516427455415d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.8091018609569824d, (java.lang.Number) 2L, true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextSecureInt(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.0012567513107897763d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.001256751310789776d) + "'", double1 == (-0.001256751310789776d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.log(0.1971459985283645d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.623810715448986d) + "'", double1 == (-1.623810715448986d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, 27.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.633135048155878d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100);
        java.lang.Object[] objArray11 = notStrictlyPositiveException10.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        java.lang.Class<?> wildcardClass14 = localizable13.getClass();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number15, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (-1.0f));
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable13, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (short) 100, number37, false);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 100);
        java.lang.Object[] objArray45 = notStrictlyPositiveException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39, "", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(localizable30, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, objArray45);
        int int51 = maxIterationsExceededException50.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable52 = maxIterationsExceededException50.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(localizable52);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
        int int7 = randomDataImpl0.nextBinomial((int) (byte) 100, (double) (byte) 0);
        try {
            randomDataImpl0.setSecureAlgorithm("d8a585b7cc", "027ee330e0");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 027ee330e0");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        java.lang.String str10 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeed((long) 7);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0596994412012222d) + "'", double2 == (-1.0596994412012222d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9240007887175266d + "'", double5 == 0.9240007887175266d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.0596994412012222d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2694718195530492d) + "'", double1 == (-1.2694718195530492d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 96.62662226727419d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long1 = org.apache.commons.math.util.FastMath.round((-62.50000000000124d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-63L) + "'", long1 == (-63L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        float float2 = org.apache.commons.math.util.FastMath.max(27.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.3822519579301478d), (java.lang.Number) 2, (java.lang.Number) 0.4890976440030615d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number7 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.28551985986505746d, 3.9421185957303497d, (-0.039813057856886665d), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 3.942 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("ead9cbcbed204114c631895b2f94358282ce4063920035cbe75d17e9b278b42deaac3007f0f53682c91af5e111994bdc06b0", objArray1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7940888107757297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.700934940064219d + "'", double1 == 0.700934940064219d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.5766785226370272d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, number8, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 100);
        java.lang.Object[] objArray16 = notStrictlyPositiveException15.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10, "", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 0.9595362135599295d, (java.lang.Number) 0.4881288021936899d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (short) 100, number29, false);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        boolean boolean40 = numberIsTooLargeException39.getBoundIsAllowed();
        java.lang.Number number41 = numberIsTooLargeException39.getMax();
        java.lang.Object[] objArray42 = numberIsTooLargeException39.getArguments();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable18, objArray42);
        java.lang.Object[] objArray44 = mathException43.getArguments();
        java.lang.String str45 = mathException43.getPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (-1.0f) + "'", number41.equals((-1.0f)));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5245173051827547d, (java.lang.Number) 3L, true);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) 1, (double) 10.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator(32L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.61512014554444d + "'", double4 == 101.61512014554444d);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.013462623778017066d), (double) 26L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.277049345084916E-49d + "'", double2 == 2.277049345084916E-49d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 60);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 60.0f + "'", float1 == 60.0f);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) 1, (double) 10.0f);
//        double double5 = normalDistributionImpl3.cumulativeProbability((-0.9999999999999999d));
//        double double6 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.density((double) 35L);
//        double double9 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.1485872384348d + "'", double6 == 100.1485872384348d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 101.0332339636924d + "'", double9 == 101.0332339636924d);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 1.5607743865275137d, (java.lang.Number) 405576.74799384695d, (java.lang.Number) 0.7853981633974483d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.08695332333554694d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.5704472609586753d, (java.lang.Number) 0.0f, true);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-6.269109644656001d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 31L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.48147369475998336d), 95.74546394552561d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.005028641739593478d) + "'", double2 == (-0.005028641739593478d));
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        try {
//            double double13 = randomDataImpl0.nextF((double) 0, 3.5122385754287575d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15541889666215106d + "'", double2 == 0.15541889666215106d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8952061077387835d + "'", double5 == 0.8952061077387835d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 94L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.46838237484017126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-34.18589348204686d), (double) 97.0f, 0.0d, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException11.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(localizable13);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("6085dceb62", "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.54 is smaller than, or equal to, the minimum (0): 0.54 is smaller than, or equal to, the minimum (0)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NotStrictlyPositiveException: 0.54 is smaller than, or equal to, the minimum (0): 0.54 is smaller than, or equal to, the minimum (0)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20896069469956882d + "'", double2 == 0.20896069469956882d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5516512327661495d) + "'", double5 == (-0.5516512327661495d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (short) 100, number4, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (short) 100, number15, false);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 100);
        java.lang.Object[] objArray23 = notStrictlyPositiveException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable8, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray23);
        int int27 = maxIterationsExceededException26.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        double double8 = randomDataImpl0.nextGaussian(0.5693246134790239d, (double) 35);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double13 = randomDataImpl0.nextBeta(6.271346638066772E42d, 0.42167783876433357d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2315669190345848d + "'", double2 == 0.2315669190345848d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 81 + "'", int5 == 81);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.447415431756264d + "'", double8 == 9.447415431756264d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0625ccd4eb95f2c2af4d54a4c886bb3bbe59df658dffded44eda1ec78fdc20f6a943707a61b5c7ae7cf26e30096ecb391834" + "'", str10.equals("0625ccd4eb95f2c2af4d54a4c886bb3bbe59df658dffded44eda1ec78fdc20f6a943707a61b5c7ae7cf26e30096ecb391834"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999999981404495d + "'", double13 == 0.9999999981404495d);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        java.lang.String str10 = randomDataImpl0.nextHexString((int) (byte) 1);
//        int int13 = randomDataImpl0.nextPascal(2147483647, 0.11236685248036105d);
//        int int16 = randomDataImpl0.nextBinomial(69, 0.874591382923689d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22787995854850263d + "'", double2 == 0.22787995854850263d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2359648009269657d + "'", double5 == 1.2359648009269657d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 60 + "'", int16 == 60);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 0.3989422804014327d, false);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.3989422804014327d + "'", number13.equals(0.3989422804014327d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(8.853242435597476E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009602127145679106d + "'", double1 == 0.009602127145679106d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (short) 100, number15, false);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 100);
        java.lang.Object[] objArray23 = notStrictlyPositiveException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17, "", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) (short) 100, number36, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) (short) 100, number43, false);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException45.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) (short) 100, number54, false);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 100);
        java.lang.Object[] objArray62 = notStrictlyPositiveException61.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56, "", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable47, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable40, objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("hi!", objArray62);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(10, "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)", objArray62);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException29, "a", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable6, objArray62);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, number9, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (short) 100, number16, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (short) 100, number27, false);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 100);
        java.lang.Object[] objArray35 = notStrictlyPositiveException34.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException29, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable20, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable13, objArray35);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) (short) 100, number42, false);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 100);
        java.lang.Object[] objArray57 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException53, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable46, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("f4b469b4b8", objArray57);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable13, objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException(69);
        java.lang.Object[] objArray63 = maxIterationsExceededException62.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable13, objArray63);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray63);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 99.77773697854103d);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) -1);
        double double6 = normalDistributionImpl2.cumulativeProbability((double) 2);
        double double8 = normalDistributionImpl2.density((double) 87L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.507996083681934d + "'", double6 == 0.507996083681934d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.002733912489363339d + "'", double8 == 0.002733912489363339d);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential(1.0E-9d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1be2a769f0997f5e2a1adcd6e7ac2c74e12ab7a02d0e5c69540ffa9252ba3ba82d4a91ff330d87f4a24f1f7a4eaf23dd9f59" + "'", str6.equals("1be2a769f0997f5e2a1adcd6e7ac2c74e12ab7a02d0e5c69540ffa9252ba3ba82d4a91ff330d87f4a24f1f7a4eaf23dd9f59"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9279083704573298E-10d + "'", double8 == 1.9279083704573298E-10d);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0, (double) 'a');
//        double double6 = normalDistributionImpl0.cumulativeProbability(0.4216778387643335d, 0.9124034991009714d);
//        double double7 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.15585191703561807d + "'", double6 == 0.15585191703561807d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.49733759970826374d) + "'", double8 == (-0.49733759970826374d));
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.600161852571429d, 243.26884900298276d);
        double double4 = normalDistributionImpl2.density(1205.5893021290508d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.362584438815143E-9d + "'", double4 == 8.362584438815143E-9d);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl4.cumulativeProbability((double) 0, (double) 'a');
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            double double11 = randomDataImpl0.nextWeibull((-0.647729269736577d), 405576.74799384695d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.648 is smaller than, or equal to, the minimum (0): shape (-0.648)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.18679678270402553d) + "'", double2 == (-0.18679678270402553d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.15509939172850942d) + "'", double8 == (-0.15509939172850942d));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.031743366520231894d + "'", double1 == 0.031743366520231894d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9972584133216698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4967309460662646d + "'", double1 == 1.4967309460662646d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) (short) 100, number30, false);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100);
        java.lang.Object[] objArray38 = notStrictlyPositiveException37.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32, "", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable23, objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, "hi!", objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        java.lang.Throwable[] throwableArray46 = maxIterationsExceededException45.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException42, "d8a585b7cc", (java.lang.Object[]) throwableArray46);
        java.lang.String str48 = convergenceException47.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0f) + "'", number13.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.ConvergenceException: d8a585b7cc" + "'", str48.equals("org.apache.commons.math.ConvergenceException: d8a585b7cc"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0, (double) 'a');
        double double5 = normalDistributionImpl0.cumulativeProbability((double) 0);
        double double7 = normalDistributionImpl0.cumulativeProbability(1.7453292519943295d);
        double double9 = normalDistributionImpl0.density(0.2404605938363132d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9595362135599295d + "'", double7 == 0.9595362135599295d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3875737282642469d + "'", double9 == 0.3875737282642469d);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 1);
//        randomDataImpl0.reSeed(31L);
//        long long13 = randomDataImpl0.nextPoisson(0.8813735870195429d);
//        java.lang.String str15 = randomDataImpl0.nextHexString((int) (short) 100);
//        try {
//            int int18 = randomDataImpl0.nextSecureInt(69, 69);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 69 is larger than, or equal to, the maximum (69): lower bound (69) must be strictly less than upper bound (69)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 63.30924087877862d + "'", double4 == 63.30924087877862d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "573ab2492a84d22c536a17233fc0dfe8c89c9a3f094230a246d37e77e7894340ae429bfeda6edc6115db30b51c71e5a03d4d" + "'", str15.equals("573ab2492a84d22c536a17233fc0dfe8c89c9a3f094230a246d37e77e7894340ae429bfeda6edc6115db30b51c71e5a03d4d"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (short) 100, number4, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) 100, number22, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 100);
        java.lang.Object[] objArray30 = notStrictlyPositiveException29.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24, "", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable15, objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable8, objArray30);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("19cf0794af", objArray30);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.09388966880694093d, (-0.03191548435610338d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8984679730080225d + "'", double2 == 1.8984679730080225d);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian(Double.POSITIVE_INFINITY, 0.24197072451914337d);
//        double double6 = randomDataImpl0.nextExponential(4.9E-324d);
//        randomDataImpl0.reSeedSecure();
//        int int11 = randomDataImpl0.nextHypergeometric((int) (short) 1, (int) (short) 1, 1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 1);
//        randomDataImpl0.reSeed(31L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 63.48085337359417d + "'", double4 == 63.48085337359417d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        double double10 = randomDataImpl0.nextChiSquare(0.28551985986505746d);
//        int int13 = randomDataImpl0.nextBinomial(94, 0.15810057525282095d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0409109801197116d) + "'", double2 == (-1.0409109801197116d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6719674521642565d + "'", double5 == 0.6719674521642565d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.57154400546418E-6d + "'", double10 == 5.57154400546418E-6d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 17 + "'", int13 == 17);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        java.lang.Number number17 = numberIsTooLargeException16.getMax();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 91.19769990076465d + "'", number17.equals(91.19769990076465d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9957798004356903d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.590508882530958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.992581810648921d) + "'", double1 == (-0.992581810648921d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) (short) 100, number30, false);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100);
        java.lang.Object[] objArray38 = notStrictlyPositiveException37.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32, "", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable23, objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, "hi!", objArray38);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException42, "", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Number number53 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable51, (java.lang.Number) (short) 100, number53, false);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException55);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException55.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable57, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Number number64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable62, (java.lang.Number) (short) 100, number64, false);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException66);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable69, (java.lang.Number) 100);
        java.lang.Object[] objArray72 = notStrictlyPositiveException71.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException66, "", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable57, objArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray72);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("18f585c91d", objArray72);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("9bdd6e7bcd", objArray72);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, "9bdd6e7bcd", objArray72);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0f) + "'", number13.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.271346638066772E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) 100, number23, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) (short) 100, number30, false);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooSmallException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (short) 100, number41, false);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) 100);
        java.lang.Object[] objArray49 = notStrictlyPositiveException48.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException43, "", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable34, objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable27, objArray49);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(10, "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1): -1 is smaller than, or equal to, the minimum (-1)", objArray49);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException16, "a", objArray49);
        java.lang.String str56 = mathException55.toString();
        java.lang.Object[] objArray58 = null;
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException55, "", objArray58);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math.MathException: a" + "'", str56.equals("org.apache.commons.math.MathException: a"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.633135048155878d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        java.lang.String str13 = convergenceException11.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException11.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 27L, number2, (java.lang.Number) 0.5693246134790239d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, number7, false);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException17.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) 100, number22, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 9.999999999999998d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (short) 100, number37, false);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        java.lang.Number number48 = numberIsTooLargeException47.getMax();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException47);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) (short) 100, number54, false);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable63, (java.lang.Number) (short) 100, number65, false);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable70, (java.lang.Number) 100);
        java.lang.Object[] objArray73 = notStrictlyPositiveException72.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67, "", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable58, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("", objArray73);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, "hi!", objArray73);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable26, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable19, objArray73);
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable80, (java.lang.Number) 100);
        java.lang.Object[] objArray83 = notStrictlyPositiveException82.getArguments();
        java.lang.Number number84 = notStrictlyPositiveException82.getArgument();
        java.lang.Object[] objArray85 = notStrictlyPositiveException82.getArguments();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException(localizable19, objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable0, objArray85);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0f) + "'", number48.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 100 + "'", number84.equals(100));
        org.junit.Assert.assertNotNull(objArray85);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        randomDataImpl0.reSeed();
//        double double5 = randomDataImpl0.nextExponential((double) 31L);
//        try {
//            int[] intArray8 = randomDataImpl0.nextPermutation(36, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (36): permutation size (100) exceeds permuation domain (36)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5252981490272938d + "'", double2 == 0.5252981490272938d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 12.826361696725817d + "'", double5 == 12.826361696725817d);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare(91.19769990076465d);
//        int int12 = randomDataImpl0.nextHypergeometric(2147483647, 2147483647, 0);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "b17ce10613" + "'", str6.equals("b17ce10613"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 95.23702471570469d + "'", double8 == 95.23702471570469d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0039163223082075704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000076688000126d + "'", double1 == 1.0000076688000126d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int int9 = randomDataImpl0.nextBinomial(100, 0.0d);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(31);
//        double double14 = randomDataImpl0.nextWeibull(1.0d, (double) 1.0f);
//        randomDataImpl0.reSeedSecure((-63L));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.81088039003272d + "'", double4 == 101.81088039003272d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1b67e64245b9cd0309582b926c2aa75" + "'", str11.equals("1b67e64245b9cd0309582b926c2aa75"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2599875720235263d + "'", double14 == 0.2599875720235263d);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        long long1 = org.apache.commons.math.util.FastMath.abs(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 100, number6, false);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 100);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException17, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, "hi!", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException29, "hi!", objArray32);
        java.lang.Object[] objArray34 = mathException33.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23, "", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1 + "'", number30.equals(1));
        org.junit.Assert.assertNotNull(objArray34);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        randomDataImpl0.reSeed((long) (byte) 10);
//        int int12 = randomDataImpl0.nextInt(10, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl13.getMean();
//        double double15 = normalDistributionImpl13.sample();
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double18 = randomDataImpl0.nextExponential((double) 10.0f);
//        long long21 = randomDataImpl0.nextSecureLong(35L, (long) 81);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 27L + "'", long7 == 27L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 74 + "'", int12 == 74);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.45861282067781184d + "'", double15 == 0.45861282067781184d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.6501341356232105d) + "'", double16 == (-0.6501341356232105d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 28.268005313724696d + "'", double18 == 28.268005313724696d);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 42L + "'", long21 == 42L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 2L, 1.1686995313225756d);
        double double4 = normalDistributionImpl2.cumulativeProbability((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long8 = randomDataImpl0.nextLong(0L, (long) 1);
//        double double10 = randomDataImpl0.nextChiSquare(0.8813735870195429d);
//        long long13 = randomDataImpl0.nextLong((-63L), (long) '#');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.15932103282415974d + "'", double10 == 0.15932103282415974d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        float float2 = org.apache.commons.math.util.FastMath.max(1.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0, (double) 'a');
        double double6 = normalDistributionImpl0.cumulativeProbability(0.4216778387643335d, 0.9124034991009714d);
        double double8 = normalDistributionImpl0.density(1.2422079676186446d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.15585191703561807d + "'", double6 == 0.15585191703561807d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18443118785753917d + "'", double8 == 0.18443118785753917d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 47);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.543181589671229d + "'", double1 == 4.543181589671229d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-62.50000000000124d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        long long1 = org.apache.commons.math.util.FastMath.round(0.031743366520231894d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number8 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long8 = randomDataImpl0.nextLong(0L, (long) 1);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextChiSquare(53.13324742832959d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 55.20609880514221d + "'", double11 == 55.20609880514221d);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.03191548435610338d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (-1.0d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare(91.19769990076465d);
//        int int12 = randomDataImpl0.nextHypergeometric(2147483647, 2147483647, 0);
//        randomDataImpl0.reSeedSecure(0L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "394747bce5" + "'", str6.equals("394747bce5"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.82642350192317d + "'", double8 == 68.82642350192317d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05224159391082094d + "'", double1 == 0.05224159391082094d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) 100, number22, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 100);
        java.lang.Object[] objArray30 = notStrictlyPositiveException29.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24, "", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable15, objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "hi!", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) (short) 100, number36, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException38.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable40, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number54 = numberIsTooSmallException53.getMin();
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException53, "hi!", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getSpecificPattern();
        java.lang.String str59 = mathException57.toString();
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number62);
        java.lang.Number number64 = outOfRangeException63.getHi();
        java.lang.Throwable[] throwableArray65 = outOfRangeException63.getSuppressed();
        java.lang.Number number66 = outOfRangeException63.getLo();
        org.apache.commons.math.exception.util.Localizable localizable67 = outOfRangeException63.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Number number72 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable70, (java.lang.Number) (short) 100, number72, false);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException74);
        org.apache.commons.math.exception.util.Localizable localizable76 = numberIsTooSmallException74.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable76, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Number number83 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable81, (java.lang.Number) (short) 100, number83, false);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException85);
        org.apache.commons.math.exception.util.Localizable localizable88 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException90 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable88, (java.lang.Number) 100);
        java.lang.Object[] objArray91 = notStrictlyPositiveException90.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException85, "", objArray91);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable76, objArray91);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException("", objArray91);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException57, localizable67, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException(localizable48, objArray91);
        org.apache.commons.math.exception.util.Localizable localizable98 = convergenceException97.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable47);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 1 + "'", number54.equals(1));
        org.junit.Assert.assertNull(localizable58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str59.equals("org.apache.commons.math.MathException: hi!"));
        org.junit.Assert.assertNull(number64);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + (short) 10 + "'", number66.equals((short) 10));
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNull(localizable98);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian(Double.POSITIVE_INFINITY, 0.24197072451914337d);
//        double double6 = randomDataImpl0.nextExponential(4.9E-324d);
//        randomDataImpl0.reSeedSecure();
//        double double9 = randomDataImpl0.nextChiSquare(0.5772156649015329d);
//        java.lang.String str11 = randomDataImpl0.nextHexString(97);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.434607087093918d + "'", double9 == 3.434607087093918d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1427ba7883021f1505db17bf09c6863a203b92c34759aa71f5bbc93ccd638a7ae69250a564b5de9096ffce13448fc68ce" + "'", str11.equals("1427ba7883021f1505db17bf09c6863a203b92c34759aa71f5bbc93ccd638a7ae69250a564b5de9096ffce13448fc68ce"));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int2 = org.apache.commons.math.util.FastMath.min(2147483647, 81);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81 + "'", int2 == 81);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGamma(0.1546021862542448d, 1.3827701165792543d);
//        try {
//            double double7 = randomDataImpl1.nextGaussian(74.0d, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.008655161382224795d + "'", double4 == 0.008655161382224795d);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextExponential(1.6619574321524444d);
//        double double10 = randomDataImpl0.nextGaussian(0.0d, 3.689503868988906d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.2006015421529488d + "'", double7 == 1.2006015421529488d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-3.9687230377213214d) + "'", double10 == (-3.9687230377213214d));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.53359419655142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7546422275936857d + "'", double1 == 1.7546422275936857d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.007268766572387768d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007268766572387768d + "'", double1 == 0.007268766572387768d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.9512437185814275d, 1.505892319649711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2066722588211518d + "'", double2 == 1.2066722588211518d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.String str6 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1 out of [10, null] range" + "'", str6.equals("org.apache.commons.math.exception.OutOfRangeException: 1 out of [10, null] range"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7123284421983315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.19714599852834502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.444011259461227d + "'", double1 == 0.444011259461227d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 36L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 36.0f + "'", float1 == 36.0f);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl4.cumulativeProbability((double) 0, (double) 'a');
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long10 = randomDataImpl0.nextPoisson(41.59183349734888d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.056607315461681754d) + "'", double2 == (-0.056607315461681754d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.046929970646867755d) + "'", double8 == (-0.046929970646867755d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 46L + "'", long10 == 46L);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number7 = numberIsTooSmallException6.getMin();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException6, "hi!", objArray9);
        java.lang.Object[] objArray11 = mathException10.getArguments();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("c7466f505306ec5ee762a91e525ad5fb8ac84a1ea16ec8a16055b20d6db7971f59113648de46c6b0ebb2fb6e4f9928f0d399", objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("e7f9d1b718", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1 + "'", number7.equals(1));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable14);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) (short) -1, true);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass14 = numberIsTooLargeException12.getClass();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (short) 100, number18, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (short) 100, number25, false);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException27.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) (short) 100, number36, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 100);
        java.lang.Object[] objArray44 = notStrictlyPositiveException43.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38, "", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable29, objArray44);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable22, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) (short) 100, number51, false);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) 100);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException62, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable55, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("f4b469b4b8", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable22, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable70 = convergenceException69.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Number number74 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable72, (java.lang.Number) (short) 100, number74, false);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException76);
        org.apache.commons.math.exception.util.Localizable localizable78 = numberIsTooSmallException76.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable78, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException85 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable83, (java.lang.Number) 100);
        java.lang.Object[] objArray89 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException85, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable78, objArray89);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException("f4b469b4b8", objArray89);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, localizable70, objArray89);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray89);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9595362135599295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9400278431759497d + "'", double1 == 1.9400278431759497d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertNull(number7);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare(91.19769990076465d);
//        int int12 = randomDataImpl0.nextHypergeometric(2147483647, 2147483647, 0);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double17 = normalDistributionImpl14.cumulativeProbability((double) 0, (double) 'a');
//        double double20 = normalDistributionImpl14.cumulativeProbability(0.4216778387643335d, 0.9124034991009714d);
//        double double21 = normalDistributionImpl14.getMean();
//        double double22 = normalDistributionImpl14.getMean();
//        double double23 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl24 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double27 = normalDistributionImpl24.cumulativeProbability((double) 0, (double) 'a');
//        double double29 = normalDistributionImpl24.cumulativeProbability((double) 0);
//        double[] doubleArray31 = normalDistributionImpl24.sample(100);
//        double double32 = normalDistributionImpl24.sample();
//        double double34 = normalDistributionImpl24.cumulativeProbability(0.874591382923689d);
//        double double35 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl24);
//        double double38 = randomDataImpl0.nextWeibull(0.9595362135599295d, 9.346544339204282d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "b666f5fae1" + "'", str6.equals("b666f5fae1"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 95.50914375604107d + "'", double8 == 95.50914375604107d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.15585191703561807d + "'", double20 == 0.15585191703561807d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8110290790432885d + "'", double23 == 0.8110290790432885d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.5d + "'", double27 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.5d + "'", double29 == 0.5d);
//        org.junit.Assert.assertNotNull(doubleArray31);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.3213246409752071d + "'", double32 == 0.3213246409752071d);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.8091018609569824d + "'", double34 == 0.8091018609569824d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.5738679236035426d + "'", double35 == 0.5738679236035426d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 22.2247215174212d + "'", double38 == 22.2247215174212d);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double8 = randomDataImpl0.nextCauchy(0.19714599852834022d, 2.2698420336529133E-14d);
//        double double10 = randomDataImpl0.nextT(0.11236685248036105d);
//        randomDataImpl0.reSeed();
//        double double14 = randomDataImpl0.nextGaussian(0.054351863245669096d, 5.729577951308233E21d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7593426385350265d + "'", double2 == 0.7593426385350265d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0730116587984857d + "'", double5 == 0.0730116587984857d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.19714599852832573d + "'", double8 == 0.19714599852832573d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.720790934266001d + "'", double10 == 0.720790934266001d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.873210115965901E21d + "'", double14 == 4.873210115965901E21d);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3240888180271109d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31866795092718214d + "'", double1 == 0.31866795092718214d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 9.999999999999998d, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 5.729577951308233E21d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (short) 100, number10, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        java.lang.Number number19 = outOfRangeException18.getLo();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) 100, number22, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 100);
        java.lang.Object[] objArray30 = notStrictlyPositiveException29.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24, "", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        java.lang.Class<?> wildcardClass33 = localizable32.getClass();
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, number34, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (-1.0f));
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable32, objArray38);
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number42);
        java.lang.Number number44 = outOfRangeException43.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException43.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (short) 100, number48, false);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException50);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 100);
        java.lang.Object[] objArray56 = notStrictlyPositiveException55.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException50, "", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = convergenceException57.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable58, (java.lang.Number) (-0.10556413008078144d), (java.lang.Number) 91.19769990076465d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException66 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable58, (java.lang.Number) 0.9595362135599295d, (java.lang.Number) 0.4881288021936899d, false);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Number number69 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable67, (java.lang.Number) (short) 100, number69, false);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException71);
        org.apache.commons.math.exception.util.Localizable localizable73 = numberIsTooSmallException71.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException75 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable73, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException79 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable73, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        boolean boolean80 = numberIsTooLargeException79.getBoundIsAllowed();
        java.lang.Number number81 = numberIsTooLargeException79.getMax();
        java.lang.Object[] objArray82 = numberIsTooLargeException79.getArguments();
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException43, localizable58, objArray82);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException18, localizable32, objArray82);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable7, objArray82);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5.729577951308233E21d + "'", number5.equals(5.729577951308233E21d));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (byte) -1 + "'", number19.equals((byte) -1));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + number81 + "' != '" + (-1.0f) + "'", number81.equals((-1.0f)));
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long2 = org.apache.commons.math.util.FastMath.min(27L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.993222846126381d, (-1.0d), 1.4967309460662646d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (short) 100, number10, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 100);
        java.lang.Object[] objArray18 = notStrictlyPositiveException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12, "", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "2f97f3318af9cdf1a6fa2458f2349ef387f97cc4b63d337a8315fb4ae63a5a7f55f795bec35244f69750c7b145b3b8f19853", objArray18);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.acos(68.82642350192317d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (short) 100, number10, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) 100, number23, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) (short) 100, number32, false);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException34);
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) (short) 100, number43, false);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) 100);
        java.lang.Object[] objArray51 = notStrictlyPositiveException50.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45, "", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable36, objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException25, "hi!", objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable14, objArray51);
        java.lang.Class<?> wildcardClass56 = localizable14.getClass();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.tan((-57.87395644113832d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.991026205768291d) + "'", double1 == (-3.991026205768291d));
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        try {
//            double double9 = randomDataImpl0.nextF(8.362584438815143E-9d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "470cebb07c" + "'", str6.equals("470cebb07c"));
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextPascal((int) (short) 100, 7.105427357601002E-15d);
//        double double7 = randomDataImpl0.nextF((double) 1L, 96.99999999999999d);
//        long long10 = randomDataImpl0.nextLong((long) (byte) 10, 74L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8786290280756641d + "'", double7 == 0.8786290280756641d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 70L + "'", long10 == 70L);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.03981305785688667d), 8.27883739515648d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.039813057856886665d) + "'", double2 == (-0.039813057856886665d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.log1p(30.96604661043997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.464674296070906d + "'", double1 == 3.464674296070906d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, number8, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 0.5403023058681398d);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.9972584133216698d, number16, true);
        java.lang.Throwable throwable20 = null;
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException37, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable30, objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException21, "hi!", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number50 = numberIsTooSmallException49.getMin();
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException49, "hi!", objArray52);
        java.lang.Object[] objArray54 = mathException53.getArguments();
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43, "", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("7551b0013c", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable12, objArray54);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.559302580079866d, (java.lang.Number) (-3.991026205768291d), (java.lang.Number) 100.53359419655142d);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 1 + "'", number50.equals(1));
        org.junit.Assert.assertNotNull(objArray54);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian(Double.POSITIVE_INFINITY, 0.24197072451914337d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9866275920404853d, 10.0d, (double) 3);
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        double double12 = normalDistributionImpl10.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-5.013372407959515d) + "'", double11 == (-5.013372407959515d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-2.5450982769198127d) + "'", double12 == (-2.5450982769198127d));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 96.99999999999999d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, number8, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 0.5403023058681398d);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.9972584133216698d, number16, true);
        java.lang.Throwable throwable19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20);
        java.lang.Object[] objArray22 = convergenceException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable12, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1, "42f4766a11", objArray22);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 81, (java.lang.Number) 7.589234521208993d, (java.lang.Number) Double.POSITIVE_INFINITY);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.log1p(22993.856197446104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.04302582631003d + "'", double1 == 10.04302582631003d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.6908418981835756d), number2, false);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextCauchy((double) 97, (-3.9687230377213214d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.969 is smaller than, or equal to, the minimum (0): scale (-3.969)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "522e4a5b5ed277e2054f7fc9716295d2232631cad08bb64aba0861ae5f5219471ae33618752363af51994cdc5b10d45470e9" + "'", str6.equals("522e4a5b5ed277e2054f7fc9716295d2232631cad08bb64aba0861ae5f5219471ae33618752363af51994cdc5b10d45470e9"));
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0f, (java.lang.Number) 0.6118464070424346d, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) (short) 100, number24, false);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException26);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (short) 100, number33, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (short) 100, number44, false);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 100);
        java.lang.Object[] objArray52 = notStrictlyPositiveException51.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable37, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException26, "hi!", objArray52);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable15, objArray52);
        java.lang.Throwable throwable57 = null;
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable61, (java.lang.Number) (short) 100, number63, false);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException65);
        org.apache.commons.math.exception.util.Localizable localizable67 = numberIsTooSmallException65.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable67, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable72, (java.lang.Number) 100);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException74, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable67, objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58, "hi!", objArray78);
        java.lang.Object[] objArray81 = convergenceException58.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable15, objArray81);
        int int83 = maxIterationsExceededException82.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException91 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable87, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number92 = numberIsTooSmallException91.getMin();
        java.lang.Object[] objArray94 = null;
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException91, "hi!", objArray94);
        java.lang.Object[] objArray96 = mathException95.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException(0, "8fbc03f47d26dc64236c6262ac9973158945a1ee82e96eb096d719ec9c226524786781c088c2dc5ceb454847138635189837", objArray96);
        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException82, "7551b0013c", objArray96);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + 1 + "'", number92.equals(1));
        org.junit.Assert.assertNotNull(objArray96);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.2404605938363132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23820160133123966d + "'", double1 == 0.23820160133123966d);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        double double8 = randomDataImpl0.nextChiSquare(91.19769990076465d);
//        int int12 = randomDataImpl0.nextHypergeometric(2147483647, 2147483647, 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 99.77773697854103d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        randomDataImpl0.reSeed();
//        try {
//            double double19 = randomDataImpl0.nextT((-10.939186667985567d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -10.939 is smaller than, or equal to, the minimum (0): degrees of freedom (-10.939)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "e59e1c77bb" + "'", str6.equals("e59e1c77bb"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 88.00385906316289d + "'", double8 == 88.00385906316289d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-77.14107025523376d) + "'", double16 == (-77.14107025523376d));
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int1 = org.apache.commons.math.util.FastMath.round(6.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2L, (float) 82L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 82.0f + "'", float2 == 82.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.sin((-12.903236125340678d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3305304045759219d) + "'", double1 == (-0.3305304045759219d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        java.lang.Throwable[] throwableArray3 = maxIterationsExceededException2.getSuppressed();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("a", (java.lang.Object[]) throwableArray3);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 27L, number6, (java.lang.Number) 0.5693246134790239d);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        boolean boolean22 = numberIsTooLargeException21.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooLargeException21.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 9.999999999999998d);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) (short) 100, number41, false);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable45, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        java.lang.Number number52 = numberIsTooLargeException51.getMax();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException51);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable56, (java.lang.Number) (short) 100, number58, false);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException60);
        org.apache.commons.math.exception.util.Localizable localizable62 = numberIsTooSmallException60.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException(localizable62, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Number number69 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable67, (java.lang.Number) (short) 100, number69, false);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException71);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable74, (java.lang.Number) 100);
        java.lang.Object[] objArray77 = notStrictlyPositiveException76.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException71, "", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable62, objArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("", objArray77);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53, "hi!", objArray77);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException(localizable30, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException8, localizable23, objArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException(69);
        java.lang.Object[] objArray86 = maxIterationsExceededException85.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable23, objArray86);
        java.lang.Class<?> wildcardClass88 = objArray86.getClass();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0f) + "'", number52.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(wildcardClass88);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.cos((-17.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27516333805159693d) + "'", double1 == (-0.27516333805159693d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.039813057856886665d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(2.993222846126381d, 99.75815075903596d);
//        long long6 = randomDataImpl0.nextPoisson(0.5d);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 1);
//        randomDataImpl0.reSeed(31L);
//        try {
//            double double14 = randomDataImpl0.nextF(0.0d, 0.4342662870920704d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.81281369534177d + "'", double4 == 100.81281369534177d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, number9, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) (short) 100, number20, false);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 100);
        java.lang.Object[] objArray28 = notStrictlyPositiveException27.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22, "", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable13, objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable6, objArray28);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 99.77773697854103d, (java.lang.Number) 1205.589302129051d, true);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) (short) 100, number40, false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException42);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) 1.5607743865275137d, (java.lang.Number) 405576.74799384695d, (java.lang.Number) 0.7853981633974483d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 0.08695332333554694d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 0.28713040364690934d, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Number number61 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) (short) 100, number61, false);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException63);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException63.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException63);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException72 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable68, (java.lang.Number) (short) 100, number70, false);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException72);
        org.apache.commons.math.exception.util.Localizable localizable74 = numberIsTooSmallException72.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Number number81 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException83 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable79, (java.lang.Number) (short) 100, number81, false);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException83);
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable86, (java.lang.Number) 100);
        java.lang.Object[] objArray89 = notStrictlyPositiveException88.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException83, "", objArray89);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(localizable74, objArray89);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException63, "hi!", objArray89);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException("19cf0794af", objArray89);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56, "a", objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable44, objArray89);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray89);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.2525906253837217d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0320709855756176d + "'", double1 == 1.0320709855756176d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0534ed9674a02d3b5e739791aa63ccd5a21d098d15a52eec65abbec5667502bf73778c16265d5b80032384cf1092bec5dbfb" + "'", str3.equals("0534ed9674a02d3b5e739791aa63ccd5a21d098d15a52eec65abbec5667502bf73778c16265d5b80032384cf1092bec5dbfb"));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        double double8 = randomDataImpl0.nextGaussian(0.5693246134790239d, (double) 35);
//        try {
//            int int11 = randomDataImpl0.nextSecureInt(31, 31);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 31 is larger than, or equal to, the maximum (31): lower bound (31) must be strictly less than upper bound (31)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.957756365732586d + "'", double2 == 1.957756365732586d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 86 + "'", int5 == 86);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-28.945270355382675d) + "'", double8 == (-28.945270355382675d));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.sin((-14.351783721659034d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9770580813606029d) + "'", double1 == (-0.9770580813606029d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number7 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        java.lang.Throwable throwable5 = null;
        try {
            numberIsTooSmallException4.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int9 = randomDataImpl0.nextInt((int) (byte) -1, 74);
//        double double12 = randomDataImpl0.nextGamma(1.5842593572720973d, 7.589234521208993d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "fb5f6760ccd2a471442d4591417be4228f543efb47be2a0ba2b63f02028e6878e8a7862a69a00fac6da6268313794ccca4c5" + "'", str6.equals("fb5f6760ccd2a471442d4591417be4228f543efb47be2a0ba2b63f02028e6878e8a7862a69a00fac6da6268313794ccca4c5"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 44 + "'", int9 == 44);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4716820358058359d + "'", double12 == 0.4716820358058359d);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.543181589671229d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7125686300798901d + "'", double1 == 1.7125686300798901d);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        double double8 = randomDataImpl0.nextCauchy(0.19714599852834022d, 2.2698420336529133E-14d);
//        double double10 = randomDataImpl0.nextT(0.11236685248036105d);
//        int int13 = randomDataImpl0.nextInt(0, 44);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8597758053220397d + "'", double2 == 1.8597758053220397d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6953765158211775d + "'", double5 == 0.6953765158211775d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.19714599852867232d + "'", double8 == 0.19714599852867232d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-56.824015499371356d) + "'", double10 == (-56.824015499371356d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        double double10 = randomDataImpl0.nextChiSquare(1.2422079676186446d);
//        double double13 = randomDataImpl0.nextCauchy(0.8279126347531564d, 100.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8466139810345825d + "'", double2 == 1.8466139810345825d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3269698441324072d + "'", double5 == 0.3269698441324072d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.31444810509353366d + "'", double10 == 0.31444810509353366d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.500690156926861d + "'", double13 == 7.500690156926861d);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-19.086314648050166d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 137.5120268288505d + "'", double1 == 137.5120268288505d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 100);
        java.lang.Object[] objArray10 = notStrictlyPositiveException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        java.lang.Class<?> wildcardClass13 = localizable12.getClass();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, number14, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (-1.0f));
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable12, objArray18);
        java.lang.String str20 = mathException19.toString();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.MathException: " + "'", str20.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooLargeException12.getMax();
        java.lang.Number number15 = numberIsTooLargeException12.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (short) 100, number19, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (short) 100, number26, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (short) 100, number37, false);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 100);
        java.lang.Object[] objArray45 = notStrictlyPositiveException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException39, "", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(localizable30, objArray45);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable23, objArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, "19cf0794af", objArray45);
        boolean boolean50 = numberIsTooLargeException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0f) + "'", number14.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.0f) + "'", number15.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, number7, false);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 1L, (java.lang.Number) 0.3989422804014327d, false);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number18, (java.lang.Number) 0.28713040364690934d, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) (short) 100, number24, false);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException26);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) (short) 100, number32, false);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException34);
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) (short) 100, number45, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException47.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) (short) 100, number54, false);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable63, (java.lang.Number) (short) 100, number65, false);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable70, (java.lang.Number) 100);
        java.lang.Object[] objArray73 = notStrictlyPositiveException72.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67, "", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable58, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException47, "hi!", objArray73);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29, localizable36, objArray73);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable11, objArray73);
        java.lang.Number number79 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + (short) 10 + "'", number79.equals((short) 10));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.3989392509463883d, 89.52224968510244d, 0.6331529618612717d, 60);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.9600677293788096E-41d + "'", double4 == 3.9600677293788096E-41d);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        double double5 = randomDataImpl0.nextGaussian(0.36888939835657686d, 0.9124034991009714d);
//        int int8 = randomDataImpl0.nextZipf((int) (byte) 10, 1.5515679276951895d);
//        double double10 = randomDataImpl0.nextChiSquare(0.28551985986505746d);
//        double double13 = randomDataImpl0.nextBeta(127.35546517446726d, 0.009365449924345558d);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString(32);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9601673537581586d + "'", double2 == 0.9601673537581586d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.140607900540961d + "'", double5 == 1.140607900540961d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.007335519855030357d + "'", double10 == 0.007335519855030357d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a1f95ed8299398959600a5f90187f0a9" + "'", str15.equals("a1f95ed8299398959600a5f90187f0a9"));
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.021680619029452453d, 415.93241984113087d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 2147483647, (long) 81);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81L + "'", long2 == 81L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 41L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 41 + "'", int1 == 41);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.9972584133216698d, number10, true);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double16 = normalDistributionImpl13.cumulativeProbability((double) 0, (double) 'a');
        double double18 = normalDistributionImpl13.cumulativeProbability((double) 0);
        double[] doubleArray20 = normalDistributionImpl13.sample(100);
        java.lang.Object[] objArray21 = new java.lang.Object[] { doubleArray20 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray21);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5d + "'", double18 == 0.5d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray21);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(1.0E20d, (double) 100L);
//        randomDataImpl0.reSeed();
//        long long7 = randomDataImpl0.nextPoisson((double) 35.0f);
//        randomDataImpl0.reSeed((long) (byte) 10);
//        int int12 = randomDataImpl0.nextInt(10, (int) 'a');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl0.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 38L + "'", long7 == 38L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 74 + "'", int12 == 74);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) (short) 10, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 110.28604308874735d, number7, false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number6 = numberIsTooSmallException5.getMin();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, "hi!", objArray8);
        java.lang.Object[] objArray10 = mathException9.getArguments();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("e5fb611863f4668a1e9936fd930b2178adc70184402c1a92fa1a007c19c79472131e9de3df17820a5c47b51cc57d6b7d33f4", objArray10);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4645918875615231d + "'", double1 == 1.4645918875615231d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (short) 100, number3, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (short) 100, number12, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable16, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) 100, number23, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 100);
        java.lang.Object[] objArray31 = notStrictlyPositiveException30.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25, "", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable16, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, "hi!", objArray31);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("19cf0794af", objArray31);
        java.lang.String str36 = mathException35.getPattern();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "19cf0794af" + "'", str36.equals("19cf0794af"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.special.Gamma.digamma(98.54456501214523d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.585426454598626d + "'", double1 == 4.585426454598626d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 87, 28L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextT(1.2422079676186446d);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 100);
//        double double8 = randomDataImpl0.nextGaussian(0.5693246134790239d, (double) 35);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double12 = randomDataImpl0.nextT(0.33982877940698564d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.916085484108684d + "'", double2 == 4.916085484108684d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 94 + "'", int5 == 94);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-14.74201951089035d) + "'", double8 == (-14.74201951089035d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "f1d624d4c6deecbf6432d09f01ab9cb2bce2ef7130e1e2176306c81e4c6356eb2d8dfcf2b07c85447f012c264892fdd88a07" + "'", str10.equals("f1d624d4c6deecbf6432d09f01ab9cb2bce2ef7130e1e2176306c81e4c6356eb2d8dfcf2b07c85447f012c264892fdd88a07"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.533490675695193d + "'", double12 == 14.533490675695193d);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 6L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.19463096366643892d, 7.213622807998451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.999971146812535d + "'", double2 == 0.999971146812535d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.special.Erf.erf(22.2247215174212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8637313535921449d), number1, false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 9.999999999999998d, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 5.729577951308233E21d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (short) 100, number12, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 0.28713040364690934d);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 2.993222846126381d, (short) 0, notStrictlyPositiveException23, 0.5403023058681398d, '#', 100 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, "hi!", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 100L, (java.lang.Number) 1, true);
        java.lang.Number number36 = numberIsTooSmallException35.getMin();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35, "hi!", objArray38);
        java.lang.Object[] objArray40 = mathException39.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29, "", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable5, objArray40);
        java.lang.Number number43 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 5.729577951308233E21d + "'", number4.equals(5.729577951308233E21d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1 + "'", number36.equals(1));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + Double.POSITIVE_INFINITY + "'", number43.equals(Double.POSITIVE_INFINITY));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, number2, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (short) 100, number11, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (short) 100, number18, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (short) 100, number29, false);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 100);
        java.lang.Object[] objArray37 = notStrictlyPositiveException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException31, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable22, objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable15, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable6, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) (short) 100, number45, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException47.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable49, (java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) -1, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) (short) 100, number56, false);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException63 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable61, (java.lang.Number) 100);
        java.lang.Object[] objArray64 = notStrictlyPositiveException63.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException58, "", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable49, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable68 = mathException67.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable69, (java.lang.Number) 100);
        java.lang.Object[] objArray72 = notStrictlyPositiveException71.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable68, objArray72);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 0.5403023058681398d, true);
        java.lang.Number number80 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (-0.1451706246932366d), (java.lang.Number) 0.03490658503988659d, number80);
        java.lang.Number number82 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, number82, (java.lang.Number) 0.7147110575702735d, false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextGaussian(Double.POSITIVE_INFINITY, 0.24197072451914337d);
        randomDataImpl0.reSeed((long) (short) -1);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9866275920404853d, 10.0d, (double) 3);
        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
        try {
            int int14 = randomDataImpl0.nextPascal(7, 104.36754563095616d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 104.368 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-5.013372407959515d) + "'", double11 == (-5.013372407959515d));
    }
}

