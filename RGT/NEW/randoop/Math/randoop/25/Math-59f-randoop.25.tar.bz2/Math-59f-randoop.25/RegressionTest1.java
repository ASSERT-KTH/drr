import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        byte[] byteArray11 = null;
        try {
            mersenneTwister0.nextBytes(byteArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 10);
        int int12 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp14.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        double double33 = dfp30.toDouble();
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp30);
        double double35 = dfp30.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        int int38 = dfpField37.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getOne();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp30.nextAfter(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        int int45 = dfpField44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10K(0);
        double double51 = dfp48.toDouble();
        org.apache.commons.math.dfp.Dfp dfp52 = new org.apache.commons.math.dfp.Dfp(dfp48);
        double double53 = dfp48.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        int int56 = dfpField55.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField55.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.getOne();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.getZero();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp48.nextAfter(dfp59);
        boolean boolean61 = dfp41.unequal(dfp60);
        boolean boolean62 = dfp14.unequal(dfp41);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp6.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.power10K(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.NEGATIVE_INFINITY + "'", double33 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.NEGATIVE_INFINITY + "'", double51 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.NEGATIVE_INFINITY + "'", double53 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 16);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int1 = org.apache.commons.math.util.FastMath.abs(32768);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32768 + "'", int1 == 32768);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.tanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.util.FastMath.min(2.718281828459045d, 2.772588722239781d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.4505495340698077d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7666212411624753d) + "'", double1 == (-0.7666212411624753d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.772588722239781d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.999999999999998d + "'", double1 == 15.999999999999998d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10K(24);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.sqrt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(35.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField12.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.FastMath.min(11.105079179167618d, (-2.5045996724459267d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.5045996724459267d) + "'", double2 == (-2.5045996724459267d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.negate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((-1));
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        int int11 = mersenneTwister0.nextInt();
        int int12 = mersenneTwister0.nextInt();
        byte[] byteArray16 = new byte[] { (byte) 2, (byte) 0, (byte) 100 };
        mersenneTwister0.nextBytes(byteArray16);
        int int19 = mersenneTwister0.nextInt(1);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1350124506) + "'", int11 == (-1350124506));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1409838867 + "'", int12 == 1409838867);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.multiply((int) (short) 0);
        int int13 = dfp12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance("0.");
        int int17 = dfp16.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) 10, "hi!", dfp18, dfp28);
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.divide((int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        double double12 = dfp9.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        int int8 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.subtract(dfp12);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = org.apache.commons.math.util.FastMath.max(1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.log(0.3525134217776191d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.042666581489808d) + "'", double1 == (-1.042666581489808d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 114.59155902616465d, (java.lang.Number) 0.9866275920404853d, false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 4, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        boolean boolean23 = numberIsTooSmallException21.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10000, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.6443678373590125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long1 = org.apache.commons.math.util.FastMath.round(0.6492415549844375d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) 10, "hi!", dfp18, dfp28);
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp18.getField();
        int int31 = dfp18.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        boolean boolean6 = dfp5.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.divide(6);
        int int9 = dfp8.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 16118L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K(0);
        double double16 = dfp13.toDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp13);
        int int18 = dfp13.intValue();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp13.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp13.getField();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.newDfp(dfp22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 10);
        int int15 = dfpField11.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        boolean boolean19 = dfp9.greaterThan(dfp17);
        boolean boolean20 = dfp9.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        boolean boolean6 = dfp5.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.newInstance(dfp14);
        java.lang.String str16 = dfp15.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10." + "'", str16.equals("10."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        java.lang.Object[] objArray17 = mathRuntimeException16.getArguments();
        java.lang.String str18 = mathRuntimeException16.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str18.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1409838867);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2737097677536666d + "'", double2 == 0.2737097677536666d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6268604078470186d + "'", double1 == 3.6268604078470186d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long1 = org.apache.commons.math.util.FastMath.abs(32767L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32767L + "'", long1 == 32767L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10((int) (byte) -1);
        int int8 = dfp7.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 100L);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        mathIllegalArgumentException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 100L);
        java.lang.String str12 = notStrictlyPositiveException11.toString();
        java.lang.Number number13 = notStrictlyPositiveException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray18 = notStrictlyPositiveException17.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100L);
        java.lang.String str29 = notStrictlyPositiveException28.toString();
        java.lang.Object[] objArray30 = new java.lang.Object[] { 10.0d, 10.0f, localizable23, str29 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException17, localizable19, localizable20, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray36 = notStrictlyPositiveException35.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 100L);
        java.lang.String str47 = notStrictlyPositiveException46.toString();
        java.lang.Object[] objArray48 = new java.lang.Object[] { 10.0d, 10.0f, localizable41, str47 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException35, localizable37, localizable38, objArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray48);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 100L);
        java.lang.String str54 = notStrictlyPositiveException53.toString();
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException53.getSpecificPattern();
        java.lang.Object[] objArray56 = notStrictlyPositiveException53.getArguments();
        java.lang.Object[] objArray57 = notStrictlyPositiveException53.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable32, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 100L);
        java.lang.String str62 = notStrictlyPositiveException61.toString();
        java.lang.Number number63 = notStrictlyPositiveException61.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable64 = notStrictlyPositiveException61.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable65, (java.lang.Number) 100L);
        java.lang.String str68 = notStrictlyPositiveException67.toString();
        java.lang.Number number69 = notStrictlyPositiveException67.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable70 = notStrictlyPositiveException67.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable70, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable75, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray78 = notStrictlyPositiveException77.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException80 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable14, localizable64, (java.lang.Object[]) throwableArray78);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100L + "'", number13.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str29.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str47.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str54.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(localizable55);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str62.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 100L + "'", number63.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str68.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 100L + "'", number69.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray78);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NEGATIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103324d + "'", double2 == 11013.232920103324d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14550003380861354d) + "'", double1 == (-0.14550003380861354d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        double double10 = dfp5.toDouble();
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.07350515761485087d), 3.9993286241247037d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.07350515761485085d) + "'", double2 == (-0.07350515761485085d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        int int11 = mersenneTwister0.nextInt();
        int int12 = mersenneTwister0.nextInt();
        byte[] byteArray16 = new byte[] { (byte) 2, (byte) 0, (byte) 100 };
        mersenneTwister0.nextBytes(byteArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister18.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister21.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister24 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray29 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister24.nextBytes(byteArray29);
        mersenneTwister21.nextBytes(byteArray29);
        int int32 = mersenneTwister21.nextInt();
        int[] intArray34 = new int[] { 32767 };
        mersenneTwister21.setSeed(intArray34);
        org.apache.commons.math.random.MersenneTwister mersenneTwister36 = new org.apache.commons.math.random.MersenneTwister(intArray34);
        org.apache.commons.math.random.MersenneTwister mersenneTwister37 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister37.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister40 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray45 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister40.nextBytes(byteArray45);
        mersenneTwister37.nextBytes(byteArray45);
        int int48 = mersenneTwister37.nextInt();
        int[] intArray50 = new int[] { 32767 };
        mersenneTwister37.setSeed(intArray50);
        mersenneTwister36.setSeed(intArray50);
        org.apache.commons.math.random.MersenneTwister mersenneTwister53 = new org.apache.commons.math.random.MersenneTwister(intArray50);
        mersenneTwister18.setSeed(intArray50);
        mersenneTwister0.setSeed(intArray50);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1350124506) + "'", int11 == (-1350124506));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1409838867 + "'", int12 == 1409838867);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1350124506) + "'", int32 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1350124506) + "'", int48 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5578300447656788d) + "'", double1 == (-0.5578300447656788d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.5707963267948966d), (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.351914551873278d) + "'", double2 == (-2.351914551873278d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) (-1350124506));
        dfpField1.setIEEEFlagsBits(16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0L);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.07350515761485085d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5890943166753848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6237628778462729d + "'", double1 == 0.6237628778462729d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.newInstance(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.newInstance((byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6492415549844375d, 3.9999999999999996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16090716584968728d + "'", double2 == 0.16090716584968728d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.14550003380861354d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: 10 is smaller than, or equal to, the minimum (10)");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(0);
        double double18 = dfp15.toDouble();
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp15);
        int int20 = dfp15.intValue();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField23 = dfp15.getField();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        int int26 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getOne();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp15.nextAfter(dfp28);
        java.lang.String str30 = dfp15.toString();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp5.subtract(dfp15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0." + "'", str30.equals("0."));
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        int int4 = dfpField3.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.getE();
        double[] doubleArray8 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        dfpField3.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        double double15 = dfp12.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 1);
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp30.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.rint();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        int int47 = dfpField46.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField46.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.getOne();
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp42, dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        int int53 = dfpField52.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.power10K(0);
        double double59 = dfp56.toDouble();
        org.apache.commons.math.dfp.Dfp dfp60 = new org.apache.commons.math.dfp.Dfp(dfp56);
        double double61 = dfp56.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(1);
        int int64 = dfpField63.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField63.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.getOne();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp56.nextAfter(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp42.nextAfter(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp21.dotrap((int) (short) 100, "hi!", dfp36, dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField1.newDfp(dfp36);
        boolean boolean73 = dfp71.equals((java.lang.Object) (-0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 10);
        int int12 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp14.divide(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        double double33 = dfp30.toDouble();
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp30);
        double double35 = dfp30.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        int int38 = dfpField37.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getOne();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp30.nextAfter(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        int int45 = dfpField44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10K(0);
        double double51 = dfp48.toDouble();
        org.apache.commons.math.dfp.Dfp dfp52 = new org.apache.commons.math.dfp.Dfp(dfp48);
        double double53 = dfp48.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        int int56 = dfpField55.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField55.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.getOne();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.getZero();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp48.nextAfter(dfp59);
        boolean boolean61 = dfp41.unequal(dfp60);
        boolean boolean62 = dfp14.unequal(dfp41);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp6.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(1);
        int int66 = dfpField65.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField65.newDfp((byte) 10);
        int int69 = dfpField65.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField65.getZero();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField65.getOne();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField65.newDfp((double) 11013L);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp63.remainder(dfp73);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp73.newInstance((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.NEGATIVE_INFINITY + "'", double33 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.NEGATIVE_INFINITY + "'", double51 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.NEGATIVE_INFINITY + "'", double53 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 16 + "'", int69 == 16);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5925828509060219d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010342521839164745d + "'", double1 == 0.010342521839164745d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.floor();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((long) 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.0032883883f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0032883823257652584d + "'", double1 == 0.0032883823257652584d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        int int8 = dfp5.intValue();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(0);
        double double17 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp14);
        double double19 = dfp14.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getOne();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getZero();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp14.nextAfter(dfp25);
        boolean boolean27 = dfp5.greaterThan(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp5.getOne();
        double double29 = dfp28.toDouble();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6856496382989539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Object[] objArray5 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Object[] objArray7 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray11 = notStrictlyPositiveException10.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100L);
        java.lang.String str22 = notStrictlyPositiveException21.toString();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10.0d, 10.0f, localizable16, str22 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10, localizable12, localizable13, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 4, (java.lang.Number) 10, true);
        java.lang.Number number30 = numberIsTooSmallException29.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException29);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException29);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 4 + "'", number30.equals(4));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.ceil();
        int int9 = dfp8.getRadixDigits();
        int int10 = dfp8.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = null;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double2 = org.apache.commons.math.util.FastMath.pow(27.289917197127753d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 16118, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16118.0d + "'", double2 == 16118.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.newInstance();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister3.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister6.nextBytes(byteArray11);
        mersenneTwister3.nextBytes(byteArray11);
        int int14 = mersenneTwister3.nextInt();
        int[] intArray16 = new int[] { 32767 };
        mersenneTwister3.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister19.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray27 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister22.nextBytes(byteArray27);
        mersenneTwister19.nextBytes(byteArray27);
        int int30 = mersenneTwister19.nextInt();
        int[] intArray32 = new int[] { 32767 };
        mersenneTwister19.setSeed(intArray32);
        mersenneTwister18.setSeed(intArray32);
        org.apache.commons.math.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math.random.MersenneTwister(intArray32);
        mersenneTwister0.setSeed(intArray32);
        long long37 = mersenneTwister0.nextLong();
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1350124506) + "'", int14 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1350124506) + "'", int30 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-5638437366958947783L) + "'", long37 == (-5638437366958947783L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        long long1 = org.apache.commons.math.util.FastMath.abs(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray9 = notStrictlyPositiveException8.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 100L);
        java.lang.String str20 = notStrictlyPositiveException19.toString();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, 10.0f, localizable14, str20 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException8, localizable10, localizable11, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray27 = notStrictlyPositiveException26.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100L);
        java.lang.String str38 = notStrictlyPositiveException37.toString();
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10.0d, 10.0f, localizable32, str38 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException26, localizable28, localizable29, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 100L);
        java.lang.String str45 = notStrictlyPositiveException44.toString();
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException44.getSpecificPattern();
        java.lang.Object[] objArray47 = notStrictlyPositiveException44.getArguments();
        java.lang.Object[] objArray48 = notStrictlyPositiveException44.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable23, objArray48);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray50);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str20.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str38.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str45.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        float float2 = org.apache.commons.math.util.FastMath.min(0.15071714f, (float) 1409838867);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.15071714f + "'", float2 == 0.15071714f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        dfpField1.setIEEEFlagsBits(32760);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = null;
        dfpField1.setRoundingMode(roundingMode4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K(0);
        double double21 = dfp18.toDouble();
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp18);
        int int23 = dfp18.intValue();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp18.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.power10K(0);
        double double35 = dfp32.toDouble();
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp32);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getOne();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(1);
        int int40 = dfpField39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.floor();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(1);
        int int50 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp((byte) 1, (byte) 0);
        boolean boolean54 = dfp53.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        int int57 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField56.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp53.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp43.remainder(dfp63);
        boolean boolean65 = dfp37.unequal(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp26.multiply(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(1);
        int int69 = dfpField68.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField68.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp72.floor();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp72.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp72.rint();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp26.newInstance(dfp72);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp4.dotrap(32767, "org.apache.commons.math.exception.NumberIsTooSmallException: 4 is smaller than the minimum (10): 4 is smaller than, or equal to, the minimum (10)", dfp12, dfp72);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        int int4 = dfpField3.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 4, (java.lang.Number) 10, true);
        java.lang.Number number22 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathRuntimeException24.getGeneralPattern();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 4 + "'", number22.equals(4));
        org.junit.Assert.assertNull(localizable25);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5488135008937807d + "'", double2 == 0.5488135008937807d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp10.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        int int13 = dfp12.classify();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getOne();
        boolean boolean15 = dfp9.lessThan(dfp14);
        double double16 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp14.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.nextAfter(dfp18);
        java.lang.String str20 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K(0);
        double double29 = dfp26.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        int int34 = dfpField33.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        int int42 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.power10K(0);
        double double48 = dfp45.toDouble();
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp45);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp26.dotrap((int) (byte) 10, "hi!", dfp39, dfp49);
        int int51 = dfp50.getRadixDigits();
        int int52 = dfp50.log10K();
        java.lang.String str53 = dfp50.toString();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp50.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(1);
        int int59 = dfpField58.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.newDfp((byte) 10);
        int int62 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField58.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField65 = dfp64.getField();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        int int68 = dfpField67.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getTwo();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp64.divide(dfp72);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp64.newInstance();
        java.lang.String str75 = dfp64.toString();
        org.apache.commons.math.dfp.Dfp dfp76 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0." + "'", str20.equals("0."));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.NEGATIVE_INFINITY + "'", double48 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0." + "'", str53.equals("0."));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 16 + "'", int62 == 16);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfpField65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1." + "'", str75.equals("1."));
        org.junit.Assert.assertNotNull(dfp76);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 2.4879651793076247d, false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(35.00000000000001d);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance(4.761141324937584d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 16118.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47613905136749957d + "'", double1 == 0.47613905136749957d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int2 = org.apache.commons.math.util.FastMath.max(6, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (short) -1);
        int int7 = dfp6.log10K();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2278539698898954d + "'", double1 == 1.2278539698898954d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        double double15 = dfp12.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        int int28 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10K(0);
        double double34 = dfp31.toDouble();
        org.apache.commons.math.dfp.Dfp dfp35 = new org.apache.commons.math.dfp.Dfp(dfp31);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp12.dotrap((int) (byte) 10, "hi!", dfp25, dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp6.nextAfter(dfp25);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp6.newInstance((double) 16);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp6.newInstance((long) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.NEGATIVE_INFINITY + "'", double34 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.15071714f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1518741630980554d + "'", double1 == 0.1518741630980554d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 10);
        int int14 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getZero();
        dfpField10.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.newDfp(0.36787944117144233d);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.remainder(dfp18);
        boolean boolean20 = dfp18.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1312801002), (double) 211235929750981552L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.divide(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(0);
        double double26 = dfp23.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = new org.apache.commons.math.dfp.Dfp(dfp23);
        double double28 = dfp23.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getOne();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp23.nextAfter(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        int int38 = dfpField37.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10K(0);
        double double44 = dfp41.toDouble();
        org.apache.commons.math.dfp.Dfp dfp45 = new org.apache.commons.math.dfp.Dfp(dfp41);
        double double46 = dfp41.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(1);
        int int49 = dfpField48.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField48.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getOne();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp41.nextAfter(dfp52);
        boolean boolean54 = dfp34.unequal(dfp53);
        boolean boolean55 = dfp7.unequal(dfp34);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp34.newInstance();
        int int57 = dfp56.classify();
        org.apache.commons.math.dfp.Dfp dfp58 = new org.apache.commons.math.dfp.Dfp(dfp56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.NEGATIVE_INFINITY + "'", double26 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.NEGATIVE_INFINITY + "'", double44 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.NEGATIVE_INFINITY + "'", double46 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Object[] objArray5 = notStrictlyPositiveException2.getArguments();
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.tanh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (-0.1780070848423949d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray7 = notStrictlyPositiveException6.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getSpecificPattern();
        java.lang.String str10 = notStrictlyPositiveException6.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance("1.");
        boolean boolean12 = dfp5.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (-0.1780070848423949d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray7 = notStrictlyPositiveException6.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getSpecificPattern();
        java.lang.Number number10 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException6.getSpecificPattern();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.36787944117144233d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2.302585092994" + "'", str11.equals("2.302585092994"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 16118L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16118 + "'", int1 == 16118);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 30249);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 30249L + "'", long1 == 30249L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.302585092994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04018769118008512d + "'", double1 == 0.04018769118008512d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        double double10 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getZero();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(0);
        double double26 = dfp23.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = new org.apache.commons.math.dfp.Dfp(dfp23);
        double double28 = dfp23.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getOne();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp23.nextAfter(dfp34);
        boolean boolean36 = dfp16.unequal(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.getOne();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.NEGATIVE_INFINITY + "'", double26 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        boolean boolean11 = mersenneTwister0.nextBoolean();
        mersenneTwister0.setSeed((long) 32767);
        boolean boolean14 = mersenneTwister0.nextBoolean();
        int int16 = mersenneTwister0.nextInt(10000);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 804 + "'", int16 == 804);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.36787944117144233d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        double double11 = dfp10.toDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(0);
        double double26 = dfp23.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.ceil();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.power10K(0);
        double double37 = dfp34.toDouble();
        org.apache.commons.math.dfp.Dfp dfp38 = new org.apache.commons.math.dfp.Dfp(dfp34);
        int int39 = dfp34.intValue();
        boolean boolean40 = dfp28.lessThan(dfp34);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp17.divide(dfp28);
        try {
            org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp10, dfp12, dfp28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.302585092994d + "'", double11 == 2.302585092994d);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.NEGATIVE_INFINITY + "'", double26 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.NEGATIVE_INFINITY + "'", double37 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int[] intArray4 = new int[] { 4, 1, 4, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        double double6 = mersenneTwister5.nextGaussian();
        double double7 = mersenneTwister5.nextDouble();
        mersenneTwister5.setSeed(16);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.692220370341103d) + "'", double6 == (-0.692220370341103d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05860097449847901d + "'", double7 == 0.05860097449847901d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        java.lang.String str6 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        double double15 = dfp12.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp12);
        int int17 = dfp12.intValue();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp12.getField();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp5.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        int int28 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField27.getESplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        int int32 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        int int37 = dfpField36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10K(0);
        double double43 = dfp40.toDouble();
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp40);
        double double45 = dfp40.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        int int48 = dfpField47.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getOne();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getZero();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp40.nextAfter(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(1);
        int int55 = dfpField54.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.power10K(0);
        double double61 = dfp58.toDouble();
        org.apache.commons.math.dfp.Dfp dfp62 = new org.apache.commons.math.dfp.Dfp(dfp58);
        double double63 = dfp58.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(1);
        int int66 = dfpField65.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray67 = dfpField65.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField65.getOne();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField65.getZero();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp58.nextAfter(dfp69);
        boolean boolean71 = dfp51.unequal(dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp23.dotrap(52, "1.732050807569", dfp34, dfp51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.732050807569" + "'", str6.equals("1.732050807569"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.NEGATIVE_INFINITY + "'", double63 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
        org.junit.Assert.assertNotNull(dfpArray67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dfp72);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        int int11 = dfp10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 32768L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.01933598375618d + "'", double1 == 181.01933598375618d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        int int4 = dfpField3.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
        java.lang.String str9 = dfp8.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2.718281828459" + "'", str9.equals("2.718281828459"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        int int11 = mersenneTwister0.nextInt();
        int[] intArray13 = new int[] { 32767 };
        mersenneTwister0.setSeed(intArray13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray13);
        boolean boolean16 = mersenneTwister15.nextBoolean();
        mersenneTwister15.setSeed(32768L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1350124506) + "'", int11 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) 1);
        int int15 = dfp14.log10();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.floor();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.rint();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(1);
        int int40 = dfpField39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField39.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.getOne();
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(1);
        int int46 = dfpField45.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10K(0);
        double double52 = dfp49.toDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = new org.apache.commons.math.dfp.Dfp(dfp49);
        double double54 = dfp49.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        int int57 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField56.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getOne();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp49.nextAfter(dfp60);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp35.nextAfter(dfp61);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp14.dotrap((int) (short) 100, "hi!", dfp29, dfp61);
        int int64 = dfp29.log10K();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.NEGATIVE_INFINITY + "'", double52 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.NEGATIVE_INFINITY + "'", double54 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        double double15 = dfp12.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 1);
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp30.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.rint();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        int int47 = dfpField46.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField46.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.getOne();
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp42, dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        int int53 = dfpField52.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.power10K(0);
        double double59 = dfp56.toDouble();
        org.apache.commons.math.dfp.Dfp dfp60 = new org.apache.commons.math.dfp.Dfp(dfp56);
        double double61 = dfp56.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(1);
        int int64 = dfpField63.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField63.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.getOne();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp56.nextAfter(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp42.nextAfter(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp21.dotrap((int) (short) 100, "hi!", dfp36, dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField1.newDfp(dfp36);
        dfpField1.setIEEEFlags(17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-32767.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32767.0d) + "'", double1 == (-32767.0d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getOne();
        int int15 = dfpField13.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        int int4 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 16118);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2073111514361345d + "'", double1 == 4.2073111514361345d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(0);
        double double17 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp14);
        double double19 = dfp14.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getOne();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getZero();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp14.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.power10K(0);
        double double35 = dfp32.toDouble();
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp32);
        double double37 = dfp32.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(1);
        int int40 = dfpField39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField39.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.getOne();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp32.nextAfter(dfp43);
        boolean boolean45 = dfp25.unequal(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        int int48 = dfpField47.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getOne();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        int int56 = dfpField55.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField55.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.getOne();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp53.subtract(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp25.add(dfp53);
        boolean boolean61 = dfp7.lessThan(dfp60);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.NEGATIVE_INFINITY + "'", double37 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        dfpField1.clearIEEEFlags();
        int int11 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        int int7 = dfpField1.getRadixDigits();
        int int8 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long1 = org.apache.commons.math.util.FastMath.abs(211235929750981552L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 211235929750981552L + "'", long1 == 211235929750981552L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((int) (short) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        double double22 = dfp19.toDouble();
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getOne();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        int int37 = dfpField36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp((byte) 1, (byte) 0);
        boolean boolean41 = dfp40.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        int int44 = dfpField43.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField43.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp40.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp30.remainder(dfp50);
        boolean boolean52 = dfp24.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp13.multiply(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        int int56 = dfpField55.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp59.floor();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp59.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.rint();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp13.newInstance(dfp59);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.newInstance((long) 97);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(1);
        int int71 = dfpField70.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField70.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp74.power10K(0);
        double double77 = dfp74.toDouble();
        org.apache.commons.math.dfp.Dfp dfp78 = new org.apache.commons.math.dfp.Dfp(dfp74);
        int int79 = dfp74.intValue();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp66.add(dfp74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.NEGATIVE_INFINITY + "'", double22 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + Double.NEGATIVE_INFINITY + "'", double77 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(dfp80);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6020599913279624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.825876218113056d + "'", double1 == 1.825876218113056d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1877009.736848577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0754473602638473E8d + "'", double1 == 1.0754473602638473E8d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.log(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0963506818711306d + "'", double1 == 1.0963506818711306d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getOne();
        boolean boolean15 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((double) 17.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5585053606381855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.748057830748277d + "'", double1 == 1.748057830748277d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray9);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 100.0f, number12, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-32767));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 0L, false);
        notStrictlyPositiveException16.addSuppressed((java.lang.Throwable) numberIsTooSmallException20);
        java.lang.Throwable[] throwableArray22 = numberIsTooSmallException20.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.6045824459415916d, true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance((byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) 10, "hi!", dfp18, dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField31.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField31.getLn5Split();
        dfpField31.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp18.multiply(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.floor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        long long1 = org.apache.commons.math.util.FastMath.abs((-5638437366958947783L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5638437366958947783L + "'", long1 == 5638437366958947783L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2363421006519535d, 0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1234841237164792d + "'", double2 == 1.1234841237164792d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) 10, "hi!", dfp18, dfp28);
        int int30 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp18.newInstance(4.248291097914389d);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.newInstance((byte) 3, (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2L, 0.5585053606381855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4727426578209877d + "'", double2 == 1.4727426578209877d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        int int8 = dfp5.intValue();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(0);
        double double17 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.ceil();
        boolean boolean19 = dfp5.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp20 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = dfp5.newInstance(dfp20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister0.nextBytes(byteArray5);
        int[] intArray12 = new int[] { 10, 32768, 2, 10, (-32767) };
        mersenneTwister0.setSeed(intArray12);
        int int14 = mersenneTwister0.nextInt();
        int int16 = mersenneTwister0.nextInt(8);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-434943396) + "'", int14 == (-434943396));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags(30249);
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5572257200654551d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.745637239362754d + "'", double1 == 3.745637239362754d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 16118);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16118.0d + "'", double1 == 16118.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp5.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int1 = org.apache.commons.math.util.FastMath.round(32768.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32768 + "'", int1 == 32768);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getOne();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp23);
        int int25 = dfp23.log10K();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.power10K(0);
        double double35 = dfp32.toDouble();
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp32);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getOne();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        int int42 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.power10K(0);
        double double48 = dfp45.toDouble();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.ceil();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = dfp52.getField();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp52.getTwo();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp37.dotrap(4, "org.apache.commons.math.exception.NumberIsTooSmallException: 4 is smaller than the minimum (10): 4 is smaller than, or equal to, the minimum (10)", dfp45, dfp55);
        boolean boolean57 = dfp26.greaterThan(dfp55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.NEGATIVE_INFINITY + "'", double48 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpField53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getOne();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp23);
        int int25 = dfp23.log10K();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp23);
        int int27 = dfp23.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        double double10 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 1, (byte) 0);
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(1);
        int int30 = dfpField29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp26.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp16.remainder(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.power10K(97);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp5.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.multiply(17);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(1);
        int int46 = dfpField45.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10K(0);
        double double52 = dfp49.toDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = new org.apache.commons.math.dfp.Dfp(dfp49);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp40.multiply(dfp53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.NEGATIVE_INFINITY + "'", double52 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.divide(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        double double22 = dfp19.toDouble();
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getOne();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        int int37 = dfpField36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp((byte) 1, (byte) 0);
        boolean boolean41 = dfp40.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        int int44 = dfpField43.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField43.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp40.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp30.remainder(dfp50);
        boolean boolean52 = dfp24.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp13.multiply(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        int int56 = dfpField55.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp59.floor();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp59.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.rint();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp13.newInstance(dfp59);
        double[] doubleArray67 = dfp13.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.NEGATIVE_INFINITY + "'", double22 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.rint((-2.5045996724459267d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        double double10 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 1, (byte) 0);
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(1);
        int int30 = dfpField29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp26.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp16.remainder(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.power10K(97);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp5.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.multiply(17);
        org.apache.commons.math.dfp.Dfp dfp44 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp45 = dfp40.multiply(dfp44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017455064928217585d) + "'", double1 == (-0.017455064928217585d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(2L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray21 = notStrictlyPositiveException20.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 100L);
        java.lang.String str32 = notStrictlyPositiveException31.toString();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0d, 10.0f, localizable26, str32 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable22, localizable23, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray33);
        java.lang.Object[] objArray36 = mathIllegalArgumentException35.getArguments();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str32.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 4);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.47613905136749957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38942992998452625d + "'", double1 == 0.38942992998452625d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1312801002));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '#');
        int int12 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        double double22 = dfp19.toDouble();
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp19);
        double double24 = dfp19.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getOne();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp19.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp5.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.getLn2();
        boolean boolean41 = dfp5.equals((java.lang.Object) dfp40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.NEGATIVE_INFINITY + "'", double22 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32767);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) 10, "hi!", dfp18, dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField31.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField31.getLn5Split();
        dfpField31.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp18.multiply(dfp38);
        java.lang.Class<?> wildcardClass40 = dfp18.getClass();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp18.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(16);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        boolean boolean27 = dfp16.equals((java.lang.Object) dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance("2.302585092994");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.log(1.748057830748277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        int int11 = mersenneTwister0.nextInt();
        int[] intArray13 = new int[] { 32767 };
        mersenneTwister0.setSeed(intArray13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister16.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister19.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray27 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister22.nextBytes(byteArray27);
        mersenneTwister19.nextBytes(byteArray27);
        int int30 = mersenneTwister19.nextInt();
        int[] intArray32 = new int[] { 32767 };
        mersenneTwister19.setSeed(intArray32);
        org.apache.commons.math.random.MersenneTwister mersenneTwister34 = new org.apache.commons.math.random.MersenneTwister(intArray32);
        org.apache.commons.math.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister35.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister38 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister38.nextBytes(byteArray43);
        mersenneTwister35.nextBytes(byteArray43);
        int int46 = mersenneTwister35.nextInt();
        int[] intArray48 = new int[] { 32767 };
        mersenneTwister35.setSeed(intArray48);
        mersenneTwister34.setSeed(intArray48);
        org.apache.commons.math.random.MersenneTwister mersenneTwister51 = new org.apache.commons.math.random.MersenneTwister(intArray48);
        mersenneTwister16.setSeed(intArray48);
        mersenneTwister15.setSeed(intArray48);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1350124506) + "'", int11 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1350124506) + "'", int30 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1350124506) + "'", int46 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.newInstance(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.remainder(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp5.divide(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp5.sqrt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray21 = notStrictlyPositiveException20.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 100L);
        java.lang.String str32 = notStrictlyPositiveException31.toString();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0d, 10.0f, localizable26, str32 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable22, localizable23, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray33);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 0L, false);
        mathIllegalArgumentException35.addSuppressed((java.lang.Throwable) numberIsTooSmallException39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException43.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable52, (java.lang.Number) 100L);
        java.lang.String str55 = notStrictlyPositiveException54.toString();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10.0d, 10.0f, localizable49, str55 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException43, localizable45, localizable46, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException43.getGeneralPattern();
        numberIsTooSmallException39.addSuppressed((java.lang.Throwable) notStrictlyPositiveException43);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str32.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str55.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 4, (java.lang.Number) 10, true);
        java.lang.Number number22 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        boolean boolean24 = numberIsTooSmallException21.getBoundIsAllowed();
        java.lang.Number number25 = numberIsTooSmallException21.getArgument();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 4 + "'", number22.equals(4));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 4 + "'", number25.equals(4));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.223372E18f + "'", float1 == 9.223372E18f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.negate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 100L);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        java.lang.Number number9 = notStrictlyPositiveException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException7.getGeneralPattern();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        boolean boolean12 = notStrictlyPositiveException7.getBoundIsAllowed();
        java.lang.Number number13 = notStrictlyPositiveException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray17 = notStrictlyPositiveException16.getSuppressed();
        boolean boolean18 = notStrictlyPositiveException16.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100L);
        java.lang.String str22 = notStrictlyPositiveException21.toString();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException21.getGeneralPattern();
        notStrictlyPositiveException16.addSuppressed((java.lang.Throwable) notStrictlyPositiveException21);
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray30 = notStrictlyPositiveException29.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 100L);
        java.lang.String str41 = notStrictlyPositiveException40.toString();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0d, 10.0f, localizable35, str41 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException29, localizable31, localizable32, objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable44, (java.lang.Number) 4, (java.lang.Number) 10, true);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        int int51 = dfpField50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField50.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(1);
        int int58 = dfpField57.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray61 = dfpField57.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7, localizable26, localizable44, (java.lang.Object[]) dfpArray61);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable64, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray67 = notStrictlyPositiveException66.getSuppressed();
        boolean boolean68 = notStrictlyPositiveException66.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable69, (java.lang.Number) 100L);
        java.lang.String str72 = notStrictlyPositiveException71.toString();
        java.lang.Number number73 = notStrictlyPositiveException71.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable74 = notStrictlyPositiveException71.getGeneralPattern();
        notStrictlyPositiveException66.addSuppressed((java.lang.Throwable) notStrictlyPositiveException71);
        org.apache.commons.math.exception.util.Localizable localizable76 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.String str77 = notStrictlyPositiveException66.toString();
        java.lang.Object[] objArray78 = notStrictlyPositiveException66.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable63, objArray78);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100L + "'", number13.equals(100L));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 100L + "'", number23.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str41.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfpArray61);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str72.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 100L + "'", number73.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str77.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32767.0f);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((byte) 1, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp(dfp20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (-0.1780070848423949d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray7 = notStrictlyPositiveException6.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray12 = notStrictlyPositiveException11.getSuppressed();
        boolean boolean13 = notStrictlyPositiveException11.getBoundIsAllowed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException11);
        java.lang.Throwable[] throwableArray15 = numberIsTooSmallException3.getSuppressed();
        java.lang.String str16 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-0.178)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 10 is smaller than the minimum (-0.178)"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.1780070848423949d), 6.960605209466431E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.17800708484239489d) + "'", double2 == (-0.17800708484239489d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        java.lang.Class<?> wildcardClass8 = dfp7.getClass();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        double double19 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.rint();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.floor();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        org.apache.commons.math.dfp.Dfp dfp24 = dfp7.dotrap((int) (short) 0, "2.302585092994", dfp22, dfp23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNull(dfp24);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 100L);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        java.lang.Number number9 = notStrictlyPositiveException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException7.getGeneralPattern();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        java.lang.String str12 = notStrictlyPositiveException7.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        int int3 = mersenneTwister1.nextInt(32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.acos(97.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        mersenneTwister0.setSeed(0);
        try {
            int int6 = mersenneTwister0.nextInt((-1350124506));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1,350,124,506 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.util.FastMath.atan2(16118.0d, 1877009.736848577d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.008586851486881637d + "'", double2 == 0.008586851486881637d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        dfpField13.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.getSqr3();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(35.00000000000001d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number6 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        double double10 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 1, (byte) 0);
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(1);
        int int30 = dfpField29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp26.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp16.remainder(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.power10K(97);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp5.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.multiply(17);
        int int44 = dfp40.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 388 + "'", int44 == 388);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 8);
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8." + "'", str11.equals("8."));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(24);
        org.apache.commons.math.dfp.Dfp dfp14 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = dfp11.multiply(dfp14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray9);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 100.0f, number12, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-32767));
        java.lang.Number number17 = notStrictlyPositiveException16.getMin();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0 + "'", number17.equals(0));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlags(1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField10.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6045824459415916d, 1262023.5276316951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6045824459415917d + "'", double2 == 0.6045824459415917d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(32767);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 4);
        double double9 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 10, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(0);
        double double18 = dfp15.toDouble();
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getOne();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        int int25 = dfpField24.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(0);
        double double31 = dfp28.toDouble();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.ceil();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.DfpField dfpField36 = dfp35.getField();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.getTwo();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp20.dotrap(4, "org.apache.commons.math.exception.NumberIsTooSmallException: 4 is smaller than the minimum (10): 4 is smaller than, or equal to, the minimum (10)", dfp28, dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.newInstance((-434943396));
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((byte) 3);
        boolean boolean44 = dfp9.equals((java.lang.Object) dfp43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpField36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32767.0f);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField13.getESplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn10();
        int int20 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((long) 6);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10K(0);
        double double24 = dfp21.toDouble();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.rint();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance((byte) 1);
        int int31 = dfp30.log10();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        int int36 = dfpField35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.floor();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.rint();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        int int48 = dfpField47.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        int int56 = dfpField55.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField55.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.getOne();
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.DfpField.computeExp(dfp51, dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(1);
        int int62 = dfpField61.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField61.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp65.power10K(0);
        double double68 = dfp65.toDouble();
        org.apache.commons.math.dfp.Dfp dfp69 = new org.apache.commons.math.dfp.Dfp(dfp65);
        double double70 = dfp65.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField(1);
        int int73 = dfpField72.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField72.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField72.getOne();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField72.getZero();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp65.nextAfter(dfp76);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp51.nextAfter(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp30.dotrap((int) (short) 100, "hi!", dfp45, dfp77);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField10.newDfp(dfp45);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp8.add(dfp45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.NEGATIVE_INFINITY + "'", double68 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.NEGATIVE_INFINITY + "'", double70 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 4);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 10);
        int int21 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField17.newDfp((long) (-1350124506));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp8.dotrap((int) '#', "10.", dfp15, dfp27);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.tanh(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        int int7 = dfp6.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 211235929750981552L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1312801002));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField13.getESplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp11.newInstance(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K(0);
        double double16 = dfp13.toDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.multiply((int) (short) 0);
        boolean boolean21 = dfp18.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp7.nextAfter(dfp18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 100L);
        java.lang.String str4 = notStrictlyPositiveException3.toString();
        java.lang.Number number5 = notStrictlyPositiveException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) dfpArray10);
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 100.0f, number13, true);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        java.lang.String str19 = notStrictlyPositiveException18.toString();
        java.lang.Number number20 = notStrictlyPositiveException18.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, (java.lang.Object[]) dfpArray25);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 100.0f, number28, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) (-32767));
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 100L);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        java.lang.Number number37 = notStrictlyPositiveException35.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray42 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100L);
        java.lang.String str53 = notStrictlyPositiveException52.toString();
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10.0d, 10.0f, localizable47, str53 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException41, localizable43, localizable44, objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = notStrictlyPositiveException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray60 = notStrictlyPositiveException59.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable65, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable68, (java.lang.Number) 100L);
        java.lang.String str71 = notStrictlyPositiveException70.toString();
        java.lang.Object[] objArray72 = new java.lang.Object[] { 10.0d, 10.0f, localizable65, str71 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException59, localizable61, localizable62, objArray72);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray72);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable75, (java.lang.Number) 100L);
        java.lang.String str78 = notStrictlyPositiveException77.toString();
        org.apache.commons.math.exception.util.Localizable localizable79 = notStrictlyPositiveException77.getSpecificPattern();
        java.lang.Object[] objArray80 = notStrictlyPositiveException77.getArguments();
        java.lang.Object[] objArray81 = notStrictlyPositiveException77.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable56, objArray81);
        org.apache.commons.math.dfp.DfpField dfpField84 = new org.apache.commons.math.dfp.DfpField(1);
        int int85 = dfpField84.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField84.newDfp((byte) 10);
        int int88 = dfpField84.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField84.getZero();
        dfpField84.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField84.newDfp(0.36787944117144233d);
        dfpField84.setIEEEFlags(1409838867);
        org.apache.commons.math.dfp.Dfp[] dfpArray95 = dfpField84.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, (java.lang.Object[]) dfpArray95);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException97 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable6, localizable21, (java.lang.Object[]) dfpArray95);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException99 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.9860040539625815d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str19.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100L + "'", number20.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 100L + "'", number37.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str53.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str71.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str78.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(localizable79);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 4 + "'", int85 == 4);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 16 + "'", int88 == 16);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfpArray95);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("2.718281828459");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 11013.232920103324d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 11013.232920103324d + "'", number2.equals(11013.232920103324d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(16);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        boolean boolean29 = dfp18.equals((java.lang.Object) dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp11.subtract(dfp28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int[] intArray4 = new int[] { 4, 1, 4, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister7.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray15 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister10.nextBytes(byteArray15);
        mersenneTwister7.nextBytes(byteArray15);
        int int18 = mersenneTwister7.nextInt();
        int[] intArray20 = new int[] { 32767 };
        mersenneTwister7.setSeed(intArray20);
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        mersenneTwister6.setSeed(intArray20);
        mersenneTwister6.setSeed((long) 10000);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1350124506) + "'", int18 == (-1350124506));
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        double double15 = dfp12.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.multiply((int) (short) 0);
        int int20 = dfp19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.subtract(dfp21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int[] intArray4 = new int[] { 4, 1, 4, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        int int7 = mersenneTwister6.nextInt();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1716565916) + "'", int7 == (-1716565916));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 4, (java.lang.Number) 10, true);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        int int24 = dfpField23.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField23.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) dfpArray27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.floor();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.rint();
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp34.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) dfpArray42);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpField41);
        org.junit.Assert.assertNotNull(dfpArray42);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.sin(32767.999999999996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9278563334125679d + "'", double1 == 0.9278563334125679d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        java.lang.String str6 = dfp5.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0." + "'", str6.equals("0."));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.rint();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField21.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode23);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 24);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8844991406148166d + "'", double1 == 2.8844991406148166d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        int int9 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(2);
        int int13 = dfp12.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int2 = org.apache.commons.math.util.FastMath.max(23, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768.0f, (java.lang.Number) (-1.5574077246549023d), false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 5638437366958947783L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.1415915379310926d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = notStrictlyPositiveException2.getArguments();
        java.lang.Number number7 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        dfpField13.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        boolean boolean6 = dfp5.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.newInstance(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.multiply(24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        dfpField1.setIEEEFlagsBits(32760);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        double double10 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getZero();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10K(0);
        double double26 = dfp23.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = new org.apache.commons.math.dfp.Dfp(dfp23);
        double double28 = dfp23.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getOne();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp23.nextAfter(dfp34);
        boolean boolean36 = dfp16.unequal(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.getOne();
        double[] doubleArray38 = dfp37.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getOne();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        int int45 = dfpField44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.getOne();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp41.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.Dfp.copysign(dfp37, dfp41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.NEGATIVE_INFINITY + "'", double26 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017451520651465824d) + "'", double1 == (-0.017451520651465824d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.36787944117144233d);
        dfpField1.setIEEEFlags(1409838867);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField13.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.newDfp("1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray11 = notStrictlyPositiveException10.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100L);
        java.lang.String str22 = notStrictlyPositiveException21.toString();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10.0d, 10.0f, localizable16, str22 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10, localizable12, localizable13, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 4, (java.lang.Number) 10, true);
        java.lang.Number number30 = numberIsTooSmallException29.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException29);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException29);
        mathRuntimeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 0L, false);
        mathRuntimeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str22.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 4 + "'", number30.equals(4));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(1);
        int int3 = dfpField2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(0);
        double double9 = dfp6.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.floor();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.floor();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.getOne();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getOne();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.negate();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp13.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.rint();
        try {
            org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 10);
        int int13 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.divide(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        int int28 = dfpField27.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10K(0);
        double double34 = dfp31.toDouble();
        org.apache.commons.math.dfp.Dfp dfp35 = new org.apache.commons.math.dfp.Dfp(dfp31);
        double double36 = dfp31.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getOne();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.nextAfter(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(1);
        int int46 = dfpField45.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10K(0);
        double double52 = dfp49.toDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = new org.apache.commons.math.dfp.Dfp(dfp49);
        double double54 = dfp49.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        int int57 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField56.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getOne();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp49.nextAfter(dfp60);
        boolean boolean62 = dfp42.unequal(dfp61);
        boolean boolean63 = dfp15.unequal(dfp42);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp42.newInstance();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp64.newInstance((int) (byte) 1);
        boolean boolean67 = dfp6.unequal(dfp64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.NEGATIVE_INFINITY + "'", double34 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.NEGATIVE_INFINITY + "'", double36 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.NEGATIVE_INFINITY + "'", double52 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.NEGATIVE_INFINITY + "'", double54 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.String str6 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getPiSplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        int int11 = dfp10.intValue();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.power10((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.sqrt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.getOne();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp((byte) 1, (byte) 0);
        boolean boolean36 = dfp35.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.newInstance(0.7739865009280572d);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp15.dotrap((int) (short) 100, "", dfp29, dfp35);
        double[] doubleArray40 = dfp15.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField8.newDfp((byte) 10, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp6.nextAfter(dfp16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (-0.1780070848423949d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray7 = notStrictlyPositiveException6.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException10);
        java.lang.Throwable[] throwableArray12 = notStrictlyPositiveException10.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 11013L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.floor();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.getOne();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp((byte) 1, (byte) 0);
        boolean boolean36 = dfp35.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.newInstance(0.7739865009280572d);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp15.dotrap((int) (short) 100, "", dfp29, dfp35);
        double double40 = dfp15.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        int int6 = dfpField1.getIEEEFlags();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Object[] objArray5 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.0032883883f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5675079326161132d + "'", double1 == 1.5675079326161132d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.negate();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        double double19 = dfp16.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        int int24 = dfpField23.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10K(0);
        double double38 = dfp35.toDouble();
        org.apache.commons.math.dfp.Dfp dfp39 = new org.apache.commons.math.dfp.Dfp(dfp35);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp16.dotrap((int) (byte) 10, "hi!", dfp29, dfp39);
        int int41 = dfp40.getRadixDigits();
        int int42 = dfp40.log10K();
        java.lang.String str43 = dfp40.toString();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.newInstance((byte) 1);
        double double46 = dfp40.toDouble();
        boolean boolean47 = dfp10.greaterThan(dfp40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0." + "'", str43.equals("0."));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.NEGATIVE_INFINITY + "'", double46 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister0.nextBytes(byteArray5);
        int[] intArray12 = new int[] { 10, 32768, 2, 10, (-32767) };
        mersenneTwister0.setSeed(intArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.newInstance("1.");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 10);
        int int17 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField13.getLn2Split();
        int int21 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp5.remainder(dfp23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        int int4 = dfpField3.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(1);
        int int5 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 0L, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.831008000716577E22d + "'", number5.equals(3.831008000716577E22d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 1, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, 30249L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        long long2 = org.apache.commons.math.util.FastMath.max(30249L, (long) 32767);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32767L + "'", long2 == 32767L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-1L), (java.lang.Number) 97, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 0.15071714f);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1, (float) 2L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) 10, "hi!", dfp18, dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = null;
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        int int35 = dfpField34.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.power10K(0);
        double double41 = dfp38.toDouble();
        org.apache.commons.math.dfp.Dfp dfp42 = new org.apache.commons.math.dfp.Dfp(dfp38);
        int int43 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp38.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.dotrap((int) (byte) -1, "", dfp32, dfp45);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp45.newInstance(0.352513421777619d);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.NEGATIVE_INFINITY + "'", double41 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        dfpField13.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        int int21 = dfpField20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        double double27 = dfp24.toDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.ceil();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp24.getField();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.newInstance(dfp24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0754473602638473E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10370.377815026062d + "'", double1 == 10370.377815026062d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        dfpField1.setIEEEFlagsBits(32760);
        int int4 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.5045996724459267d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1909233824924814d) + "'", double1 == (-1.1909233824924814d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.36787944117144233d);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(0);
        double double18 = dfp15.toDouble();
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp15);
        double double20 = dfp15.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getOne();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp15.nextAfter(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(1);
        int int30 = dfpField29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 10);
        int int33 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.subtract(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp9.newInstance(dfp36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) '4');
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.008586851486881637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0661660483375144d) + "'", double1 == (-2.0661660483375144d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp24);
        boolean boolean26 = dfp25.isNaN();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.newInstance("1.732050807569");
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.add(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField31.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.subtract(dfp35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray21 = notStrictlyPositiveException20.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 100L);
        java.lang.String str32 = notStrictlyPositiveException31.toString();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0d, 10.0f, localizable26, str32 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable22, localizable23, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray33);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 0L, false);
        mathIllegalArgumentException35.addSuppressed((java.lang.Throwable) numberIsTooSmallException39);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException39.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 100L);
        java.lang.String str45 = notStrictlyPositiveException44.toString();
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException44.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (-1L), (java.lang.Number) 97, false);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 100L);
        java.lang.String str54 = notStrictlyPositiveException53.toString();
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException53.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) (-1L), (java.lang.Number) 97, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField63.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException39, localizable46, localizable55, (java.lang.Object[]) dfpArray65);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str32.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str45.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str54.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfpArray65);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        boolean boolean11 = mersenneTwister0.nextBoolean();
        int[] intArray16 = new int[] { 4, 1, 4, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister0.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray24 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        mersenneTwister19.nextBytes(byteArray24);
        mersenneTwister0.nextBytes(byteArray24);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray24);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        int int4 = dfpField3.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 2);
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2." + "'", str11.equals("2."));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        int int9 = dfp8.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray9);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 100.0f, number12, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 100L);
        java.lang.String str20 = notStrictlyPositiveException19.toString();
        java.lang.Number number21 = notStrictlyPositiveException19.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Object[] objArray23 = notStrictlyPositiveException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str20.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 100L + "'", number21.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(dfpArray27);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException7.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        java.lang.String str19 = notStrictlyPositiveException18.toString();
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 10.0f, localizable13, str19 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7, localizable9, localizable10, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 4, (java.lang.Number) 10, true);
        java.lang.Number number27 = numberIsTooSmallException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray31 = notStrictlyPositiveException30.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 100L);
        java.lang.String str42 = notStrictlyPositiveException41.toString();
        java.lang.Object[] objArray43 = new java.lang.Object[] { 10.0d, 10.0f, localizable36, str42 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException30, localizable32, localizable33, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray49 = notStrictlyPositiveException48.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable54, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) 100L);
        java.lang.String str60 = notStrictlyPositiveException59.toString();
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10.0d, 10.0f, localizable54, str60 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException48, localizable50, localizable51, objArray61);
        org.apache.commons.math.exception.util.Localizable localizable63 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable64, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray67 = notStrictlyPositiveException66.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable72, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable75, (java.lang.Number) 100L);
        java.lang.String str78 = notStrictlyPositiveException77.toString();
        java.lang.Object[] objArray79 = new java.lang.Object[] { 10.0d, 10.0f, localizable72, str78 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException80 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException66, localizable68, localizable69, objArray79);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException81 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException26, localizable45, localizable63, objArray79);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException83 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable63, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray84 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable63, objArray84);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str19.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 4 + "'", number27.equals(4));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str42.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str60.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str78.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.String str14 = notStrictlyPositiveException13.toString();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 10.0f, localizable8, str14 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 4, (java.lang.Number) 10, true);
        java.lang.Number number22 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray26 = notStrictlyPositiveException25.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 100L);
        java.lang.String str37 = notStrictlyPositiveException36.toString();
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10.0d, 10.0f, localizable31, str37 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException25, localizable27, localizable28, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException43.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable52, (java.lang.Number) 100L);
        java.lang.String str55 = notStrictlyPositiveException54.toString();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10.0d, 10.0f, localizable49, str55 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException43, localizable45, localizable46, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray62 = notStrictlyPositiveException61.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable67, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable70, (java.lang.Number) 100L);
        java.lang.String str73 = notStrictlyPositiveException72.toString();
        java.lang.Object[] objArray74 = new java.lang.Object[] { 10.0d, 10.0f, localizable67, str73 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException61, localizable63, localizable64, objArray74);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21, localizable40, localizable58, objArray74);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.466711037884725d);
        numberIsTooSmallException21.addSuppressed((java.lang.Throwable) notStrictlyPositiveException78);
        java.lang.Object[] objArray80 = numberIsTooSmallException21.getArguments();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str14.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 4 + "'", number22.equals(4));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str37.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str55.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str73.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray80);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) (short) 0, true);
        boolean boolean10 = numberIsTooSmallException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.993222846126381d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int2 = org.apache.commons.math.util.FastMath.min(32768, (int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.asin(11013.232920103323d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.16090716584968728d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.016089328111957124d + "'", double2 == 0.016089328111957124d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        int int9 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getOne();
        java.lang.Class<?> wildcardClass10 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.sqrt();
        double[] doubleArray14 = dfp9.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((long) 2);
        int int13 = dfp10.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.7666212411624753d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 0.6492415549844375d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.6492415549844375d + "'", number4.equals(0.6492415549844375d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        dfpField13.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        int int10 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp5.getField();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.nextAfter(dfp18);
        java.lang.String str20 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        int int23 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K(0);
        double double29 = dfp26.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        int int34 = dfpField33.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        int int42 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp45.power10K(0);
        double double48 = dfp45.toDouble();
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp45);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp26.dotrap((int) (byte) 10, "hi!", dfp39, dfp49);
        int int51 = dfp50.getRadixDigits();
        int int52 = dfp50.log10K();
        java.lang.String str53 = dfp50.toString();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp50.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp55);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp5.newInstance((-32767));
        int int59 = dfp5.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0." + "'", str20.equals("0."));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.NEGATIVE_INFINITY + "'", double48 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0." + "'", str53.equals("0."));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) (-1350124506));
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 10);
        int int16 = dfpField12.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField12.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.newInstance((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        int int26 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10K(0);
        double double32 = dfp29.toDouble();
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp29);
        int int34 = dfp29.intValue();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.newInstance((double) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp29.getField();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getTwo();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getOne();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        int int44 = dfpField43.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(1);
        int int52 = dfpField51.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField51.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.getOne();
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeExp(dfp47, dfp54);
        double double56 = dfp55.toDouble();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp41.divide(dfp55);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp55);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp10.divide(dfp55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.NEGATIVE_INFINITY + "'", double32 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.abs(1262024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1262024.0d + "'", double1 == 1262024.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6237628778462729d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.811686335541243d + "'", double1 == 0.811686335541243d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32767.0f);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField13.getESplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        double double8 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.newDfp((long) 32760);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp24);
        boolean boolean26 = dfp25.isNaN();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.newInstance("1.732050807569");
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.add(dfp25);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(1);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(0);
        double double15 = dfp12.toDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 1);
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp30.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.rint();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        int int47 = dfpField46.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField46.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.getOne();
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp42, dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        int int53 = dfpField52.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.power10K(0);
        double double59 = dfp56.toDouble();
        org.apache.commons.math.dfp.Dfp dfp60 = new org.apache.commons.math.dfp.Dfp(dfp56);
        double double61 = dfp56.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(1);
        int int64 = dfpField63.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField63.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.getOne();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp56.nextAfter(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp42.nextAfter(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp21.dotrap((int) (short) 100, "hi!", dfp36, dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField1.newDfp(dfp36);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.NEGATIVE_INFINITY + "'", double59 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
    }
}

