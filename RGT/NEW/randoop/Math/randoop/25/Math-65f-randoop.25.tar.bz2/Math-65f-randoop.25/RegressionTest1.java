import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double[] doubleArray5 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray5);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(bigMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable2, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable0, objArray11);
        double[] doubleArray21 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, "", objArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray21);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException28 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException29 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException28);
        java.lang.RuntimeException runtimeException30 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException29);
        org.apache.commons.math.exception.Localizable localizable31 = optimizationException29.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable33 = null;
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable35, objArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable33, objArray40);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", objArray40);
        org.apache.commons.math.optimization.OptimizationException optimizationException44 = new org.apache.commons.math.optimization.OptimizationException(localizable31, objArray40);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable47, objArray52);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException54 = new org.apache.commons.math.linear.InvalidMatrixException(localizable45, objArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException14, doubleArray21, localizable31, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException55);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(runtimeException30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable31.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        double[] doubleArray11 = new double[] { (byte) 10 };
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = blockRealMatrix13.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix9.subtract(blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix4.add(blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix16.copy();
        double[] doubleArray19 = new double[] { (byte) 10 };
        double[][] doubleArray20 = new double[][] { doubleArray19 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray20);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray24 = new double[] { (byte) 10 };
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) 10 };
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math.linear.RealMatrix realMatrix32 = blockRealMatrix31.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix27.subtract(blockRealMatrix31);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix22.add(blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix17.add(blockRealMatrix22);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl36 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable2, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable0, objArray11);
        java.lang.Object[] objArray15 = convergenceException14.getArguments();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException19);
        java.lang.RuntimeException runtimeException21 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException20);
        org.apache.commons.math.exception.Localizable localizable22 = optimizationException20.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[] doubleArray32 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray32, "", objArray34);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException36 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable25, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable23, objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(6, localizable22, objArray34);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.exception.Localizable localizable42 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable42, objArray47);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException49 = new org.apache.commons.math.linear.InvalidMatrixException(localizable40, objArray47);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException50 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", objArray47);
        org.apache.commons.math.optimization.OptimizationException optimizationException51 = new org.apache.commons.math.optimization.OptimizationException(localizable22, objArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) 'a');
        double[][] doubleArray55 = array2DRowRealMatrix54.getDataRef();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException14, (double) (short) 10, localizable22, (java.lang.Object[]) doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix64 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray63);
        org.apache.commons.math.exception.Localizable localizable67 = null;
        double[] doubleArray74 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray76 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException(doubleArray74, "", objArray76);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException78 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable67, objArray76);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException57, doubleArray63, "hi!", objArray76);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException80 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) functionEvaluationException57);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(bigMatrix64);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException(6, 0);
        org.apache.commons.math.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nonSquareMatrixException2);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        double[] doubleArray11 = new double[] { 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException15 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException15);
        java.lang.RuntimeException runtimeException17 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException16);
        org.apache.commons.math.exception.Localizable localizable18 = optimizationException16.getLocalizablePattern();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException20 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException21 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException20);
        double[] doubleArray27 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix28 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) 'a');
        double[][] doubleArray33 = array2DRowRealMatrix32.getDataRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException20, doubleArray27, "hi!", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException13, localizable18, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException40 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException41 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException40);
        double[] doubleArray47 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix48 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) 'a');
        double[][] doubleArray53 = array2DRowRealMatrix52.getDataRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException40, doubleArray47, "hi!", (java.lang.Object[]) doubleArray53);
        java.text.ParseException parseException55 = org.apache.commons.math.MathRuntimeException.createParseException(100, "hi!", (java.lang.Object[]) doubleArray53);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException56 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.optimization.OptimizationException optimizationException57 = new org.apache.commons.math.optimization.OptimizationException(localizable18, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray53);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor59 = null;
        try {
            double double60 = blockRealMatrix58.walkInOptimizedOrder(realMatrixPreservingVisitor59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(runtimeException17);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(bigMatrix28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(bigMatrix48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(parseException55);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException56);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (-1.0f));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        double[] doubleArray11 = new double[] { (byte) 10 };
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = blockRealMatrix13.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix9.subtract(blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix4.add(blockRealMatrix15);
        double[] doubleArray18 = new double[] { (byte) 10 };
        double[][] doubleArray19 = new double[][] { doubleArray18 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = blockRealMatrix20.inverse();
        double[] doubleArray23 = blockRealMatrix20.getColumn(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.multiply(blockRealMatrix20);
        double[] doubleArray26 = new double[] { (byte) 10 };
        double[][] doubleArray27 = new double[][] { doubleArray26 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = blockRealMatrix28.scalarMultiply((double) (byte) 1);
        int int31 = blockRealMatrix28.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix24.add(blockRealMatrix28);
        blockRealMatrix32.luDecompose();
        double[] doubleArray35 = new double[] { (byte) 10 };
        double[][] doubleArray36 = new double[][] { doubleArray35 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray39 = blockRealMatrix37.getColumn(0);
        double double40 = blockRealMatrix37.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix41 = blockRealMatrix32.solve((org.apache.commons.math.linear.RealMatrix) blockRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 10.0d + "'", double40 == 10.0d);
        org.junit.Assert.assertNotNull(realMatrix41);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray17 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, "", objArray19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        int int23 = array2DRowRealMatrix10.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix10.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix25 = array2DRowRealMatrix10.copy();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        double[] doubleArray11 = new double[] { 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray11);
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, localizable13, objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException15);
        double[] doubleArray17 = functionEvaluationException15.getArgument();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[] doubleArray7 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray7);
        double[] doubleArray10 = vectorialPointValuePair9.getValueRef();
        double[] doubleArray11 = vectorialPointValuePair9.getPoint();
        double[] doubleArray12 = vectorialPointValuePair9.getPointRef();
        double[] doubleArray13 = vectorialPointValuePair9.getPointRef();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker1 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker1);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer4.setCostRelativeTolerance((double) (short) 0);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer4.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker7);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer10 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker11 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer10.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker11);
        double[] doubleArray15 = new double[] { (byte) 10 };
        double[] doubleArray21 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix22 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray21);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray21);
        double[] doubleArray24 = vectorialPointValuePair23.getValueRef();
        double[] doubleArray26 = new double[] { (byte) 10 };
        double[] doubleArray32 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix33 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray32);
        double[] doubleArray35 = vectorialPointValuePair34.getValueRef();
        boolean boolean36 = simpleVectorialValueChecker11.converged((int) 'a', vectorialPointValuePair23, vectorialPointValuePair34);
        double[] doubleArray38 = new double[] { (byte) 10 };
        double[] doubleArray44 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix45 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray38, doubleArray44);
        double[] doubleArray47 = vectorialPointValuePair46.getValue();
        double[] doubleArray48 = vectorialPointValuePair46.getValueRef();
        boolean boolean49 = simpleVectorialValueChecker7.converged(0, vectorialPointValuePair34, vectorialPointValuePair46);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer50 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer50.setCostRelativeTolerance((double) (short) 0);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker53 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer50.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker53);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer56 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker57 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer56.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker57);
        double[] doubleArray61 = new double[] { (byte) 10 };
        double[] doubleArray67 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix68 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair69 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray61, doubleArray67);
        double[] doubleArray70 = vectorialPointValuePair69.getValueRef();
        double[] doubleArray72 = new double[] { (byte) 10 };
        double[] doubleArray78 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix79 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray78);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair80 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray72, doubleArray78);
        double[] doubleArray81 = vectorialPointValuePair80.getValueRef();
        boolean boolean82 = simpleVectorialValueChecker57.converged((int) 'a', vectorialPointValuePair69, vectorialPointValuePair80);
        double[] doubleArray84 = new double[] { (byte) 10 };
        double[] doubleArray90 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix91 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray90);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair92 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray84, doubleArray90);
        double[] doubleArray93 = vectorialPointValuePair92.getValue();
        double[] doubleArray94 = vectorialPointValuePair92.getValueRef();
        boolean boolean95 = simpleVectorialValueChecker53.converged(0, vectorialPointValuePair80, vectorialPointValuePair92);
        boolean boolean96 = simpleVectorialValueChecker1.converged(1000, vectorialPointValuePair34, vectorialPointValuePair80);
        double[] doubleArray97 = vectorialPointValuePair80.getValueRef();
        double[] doubleArray98 = vectorialPointValuePair80.getValue();
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(bigMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(bigMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(bigMatrix45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(bigMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(bigMatrix79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(bigMatrix91);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertNotNull(doubleArray98);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) (short) 0);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (byte) -1);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 10, (double) 52);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker7);
        levenbergMarquardtOptimizer0.setMaxIterations(0);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix8.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix4.subtract(blockRealMatrix8);
        double[] doubleArray12 = new double[] { (byte) 10 };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray13);
        double[] doubleArray17 = new double[] { (byte) 10 };
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = blockRealMatrix19.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix15.subtract(blockRealMatrix19);
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix8, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix19);
        double[] doubleArray29 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, "", objArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray35 = array2DRowRealMatrix33.getColumn(0);
        int int36 = array2DRowRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix19.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        double[] doubleArray39 = new double[] { (byte) 10 };
        double[][] doubleArray40 = new double[][] { doubleArray39 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray40);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) 10 };
        double[][] doubleArray45 = new double[][] { doubleArray44 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray49 = new double[] { (byte) 10 };
        double[][] doubleArray50 = new double[][] { doubleArray49 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray50);
        org.apache.commons.math.linear.RealMatrix realMatrix52 = blockRealMatrix51.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix47.subtract(blockRealMatrix51);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix42.add(blockRealMatrix53);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.copy();
        double[] doubleArray57 = new double[] { (byte) 10 };
        double[][] doubleArray58 = new double[][] { doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { (byte) 10 };
        double[][] doubleArray63 = new double[][] { doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        double[] doubleArray67 = new double[] { (byte) 10 };
        double[][] doubleArray68 = new double[][] { doubleArray67 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray68);
        org.apache.commons.math.linear.RealMatrix realMatrix70 = blockRealMatrix69.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix65.subtract(blockRealMatrix69);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix60.add(blockRealMatrix71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix55.add(blockRealMatrix60);
        org.apache.commons.math.linear.RealMatrix realMatrix74 = array2DRowRealMatrix33.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix60);
        double[] doubleArray76 = new double[] { (byte) 10 };
        double[][] doubleArray77 = new double[][] { doubleArray76 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix78 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray77);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix79 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray77);
        double[] doubleArray81 = new double[] { (byte) 10 };
        double[][] doubleArray82 = new double[][] { doubleArray81 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix83 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray82);
        org.apache.commons.math.linear.RealMatrix realMatrix84 = blockRealMatrix83.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix79.subtract(blockRealMatrix83);
        double[] doubleArray87 = new double[] { (byte) 10 };
        double[][] doubleArray88 = new double[][] { doubleArray87 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix89 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray88);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix90 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray88);
        double[] doubleArray92 = new double[] { (byte) 10 };
        double[][] doubleArray93 = new double[][] { doubleArray92 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix94 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray93);
        org.apache.commons.math.linear.RealMatrix realMatrix95 = blockRealMatrix94.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix96 = blockRealMatrix90.subtract(blockRealMatrix94);
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix83, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix94);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix98 = array2DRowRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix83);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(realMatrix95);
        org.junit.Assert.assertNotNull(blockRealMatrix96);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix8.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix4.subtract(blockRealMatrix8);
        double[] doubleArray12 = new double[] { (byte) 10 };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix10.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        double[] doubleArray23 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "", objArray25);
        double[] doubleArray28 = new double[] { 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException26, doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException(doubleArray28);
        double[] doubleArray31 = functionEvaluationException30.getArgument();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray31);
        double[] doubleArray33 = blockRealMatrix10.preMultiply(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor(0.0d);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker3 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer4.setParRelativeTolerance((double) 0);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker9 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 10, (double) 52);
        levenbergMarquardtOptimizer4.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker9);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker9);
        org.junit.Assert.assertNull(vectorialConvergenceChecker3);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 1000);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix2.getSubMatrix((int) (short) -1, 0, (int) '4', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 96]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException1);
        java.lang.RuntimeException runtimeException3 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException2);
        org.apache.commons.math.exception.Localizable localizable4 = optimizationException2.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable8, objArray13);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException15 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, objArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException16 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", objArray13);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException(localizable4, objArray13);
        double[] doubleArray19 = new double[] { (byte) 10 };
        double[][] doubleArray20 = new double[][] { doubleArray19 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = blockRealMatrix21.scalarMultiply((double) (byte) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = blockRealMatrix21.scalarMultiply((double) (-1));
        double[][] doubleArray26 = blockRealMatrix21.getData();
        java.lang.IllegalStateException illegalStateException27 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable4, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        double[] doubleArray30 = blockRealMatrix28.getRow(0);
        org.junit.Assert.assertNotNull(runtimeException3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException27);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 0);
        double double3 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable2, objArray7);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException9 = new org.apache.commons.math.linear.InvalidMatrixException(localizable0, objArray7);
        java.lang.Object[] objArray10 = invalidMatrixException9.getArguments();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable14, objArray19);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException21 = new org.apache.commons.math.linear.InvalidMatrixException(localizable12, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException9, "", objArray19);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException24 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException25 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException24);
        java.lang.RuntimeException runtimeException26 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException25);
        org.apache.commons.math.exception.Localizable localizable27 = optimizationException25.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable29 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable31, objArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException38 = new org.apache.commons.math.linear.InvalidMatrixException(localizable29, objArray36);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException39 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", objArray36);
        org.apache.commons.math.optimization.OptimizationException optimizationException40 = new org.apache.commons.math.optimization.OptimizationException(localizable27, objArray36);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException43 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException42);
        java.lang.RuntimeException runtimeException44 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException43);
        org.apache.commons.math.exception.Localizable localizable45 = optimizationException43.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable49, objArray54);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException56 = new org.apache.commons.math.linear.InvalidMatrixException(localizable47, objArray54);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException57 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", objArray54);
        org.apache.commons.math.optimization.OptimizationException optimizationException58 = new org.apache.commons.math.optimization.OptimizationException(localizable45, objArray54);
        java.lang.IllegalArgumentException illegalArgumentException59 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable27, objArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) 'a');
        double double66 = array2DRowRealMatrix63.getEntry((int) (byte) 1, (int) (short) 1);
        double[][] doubleArray67 = array2DRowRealMatrix63.getDataRef();
        java.io.EOFException eOFException68 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException22, localizable27, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray67);
        double double71 = blockRealMatrix70.getFrobeniusNorm();
        try {
            double double74 = blockRealMatrix70.getEntry(97, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, 2,147,483,647) in a 10x97 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(runtimeException26);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException39);
        org.junit.Assert.assertNotNull(runtimeException44);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable45.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException57);
        org.junit.Assert.assertNotNull(illegalArgumentException59);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(eOFException68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { false, (-1.0d), (byte) 1, 10.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException12 = new org.apache.commons.math.linear.InvalidMatrixException(localizable3, objArray10);
        java.lang.Object[] objArray13 = invalidMatrixException12.getArguments();
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray23 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException12, (double) (byte) 0, localizable15, objArray28);
        java.lang.NullPointerException nullPointerException30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("Array2DRowRealMatrix{{100.0},{97.0},{1.0},{10.0},{-1.0},{100.0}}", objArray28);
        java.lang.IllegalArgumentException illegalArgumentException32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("a {0}x{1} matrix was provided instead of a square matrix", objArray28);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(nullPointerException30);
        org.junit.Assert.assertNotNull(illegalArgumentException32);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException2 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException3 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException2);
        java.lang.RuntimeException runtimeException4 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) optimizationException3);
        org.apache.commons.math.exception.Localizable localizable5 = optimizationException3.getLocalizablePattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        java.util.ConcurrentModificationException concurrentModificationException7 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable5, objArray6);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException8 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray6);
        java.io.IOException iOException9 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) arrayIndexOutOfBoundsException8);
        org.junit.Assert.assertNotNull(runtimeException4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(concurrentModificationException7);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException8);
        org.junit.Assert.assertNotNull(iOException9);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray1 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray13 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, "", objArray15);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable6, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable4, objArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException19 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray15);
        try {
            org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray1, "BlockRealMatrix{{10.0}}", objArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        double[] doubleArray11 = new double[] { 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException9, doubleArray11);
        java.lang.Object[] objArray13 = functionEvaluationException12.getArguments();
        java.io.IOException iOException14 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException12);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(iOException14);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(1, (int) '4');
        double[] doubleArray9 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray11);
        double[] doubleArray14 = new double[] { 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException12, doubleArray14);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix2.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { (byte) 10 };
        double[] doubleArray25 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix26 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray25);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair27 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray25);
        double[] doubleArray28 = vectorialPointValuePair27.getValueRef();
        double[] doubleArray29 = vectorialPointValuePair27.getPoint();
        double[] doubleArray30 = vectorialPointValuePair27.getPointRef();
        double[] doubleArray31 = vectorialPointValuePair27.getPointRef();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray31, true);
        org.apache.commons.math.linear.BigMatrix bigMatrix34 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(bigMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(bigMatrix34);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        java.lang.Object[] objArray1 = null;
        java.lang.NullPointerException nullPointerException2 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray1);
        org.junit.Assert.assertNotNull(nullPointerException2);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray17 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, "", objArray19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        int int23 = array2DRowRealMatrix10.getColumnDimension();
        int int24 = array2DRowRealMatrix10.getRowDimension();
        double[] doubleArray31 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31, "", objArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray42 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, "", objArray44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.RealMatrix realMatrix47 = array2DRowRealMatrix35.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        java.lang.String str48 = array2DRowRealMatrix46.toString();
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix10.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        int int50 = array2DRowRealMatrix46.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Array2DRowRealMatrix{{100.0},{97.0},{1.0},{10.0},{-1.0},{100.0}}" + "'", str48.equals("Array2DRowRealMatrix{{100.0},{97.0},{1.0},{10.0},{-1.0},{100.0}}"));
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, 1000);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException4 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1);
        org.apache.commons.math.optimization.OptimizationException optimizationException5 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException4);
        double[] doubleArray11 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix12 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) 'a');
        double[][] doubleArray17 = array2DRowRealMatrix16.getDataRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException4, doubleArray11, "hi!", (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        try {
            double[] doubleArray20 = array2DRowRealMatrix2.preMultiply(doubleArray11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(bigMatrix12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn(0);
        double[][] doubleArray13 = array2DRowRealMatrix10.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix10.createMatrix(36, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) 'a');
        double[][] doubleArray3 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray3);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix4.transpose();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = blockRealMatrix4.walkInOptimizedOrder(realMatrixChangingVisitor6, 1000, 52, 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1,000 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        double[] doubleArray6 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray17 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, "", objArray19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[] doubleArray24 = new double[] { (byte) 10 };
        double[] doubleArray30 = new double[] { ' ', 1.0f, 100.0d, 100.0d, (-1.0f) };
        org.apache.commons.math.linear.BigMatrix bigMatrix31 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray30);
        double[] doubleArray33 = vectorialPointValuePair32.getValueRef();
        boolean boolean34 = array2DRowRealMatrix10.equals((java.lang.Object) doubleArray33);
        boolean boolean36 = array2DRowRealMatrix10.equals((java.lang.Object) 1.0f);
        double[] doubleArray43 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, "", objArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(bigMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        double[] doubleArray1 = new double[] { (byte) 10 };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10 };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = blockRealMatrix8.inverse();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix4.subtract(blockRealMatrix8);
        double[] doubleArray12 = new double[] { (byte) 10 };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix10.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        double[] doubleArray23 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "", objArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray34 = new double[] { 100.0f, 'a', 1, 10L, (-1L), 100.0d };
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray34, "", objArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealMatrix realMatrix39 = array2DRowRealMatrix27.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix38);
        int int40 = array2DRowRealMatrix27.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix27.createMatrix(1, 36);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix16.multiply(realMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = blockRealMatrix44.scalarMultiply((double) 0L);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(realMatrix46);
    }
}

