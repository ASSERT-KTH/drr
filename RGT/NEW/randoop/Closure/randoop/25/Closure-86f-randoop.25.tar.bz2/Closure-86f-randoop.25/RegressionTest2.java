import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        defaultCodingConvention1.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        java.lang.String str8 = defaultCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship13 = defaultCodingConvention1.getClassesDefinedByCall(node12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        boolean[] booleanArray29 = scriptOrFnNode27.getParamAndVarConst();
        java.lang.String[] strArray30 = scriptOrFnNode27.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray30);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean38 = node33.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode37);
        boolean[] booleanArray39 = scriptOrFnNode37.getParamAndVarConst();
        java.lang.String[] strArray40 = scriptOrFnNode37.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode48 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean49 = node44.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode48);
        boolean[] booleanArray50 = scriptOrFnNode48.getParamAndVarConst();
        java.lang.String[] strArray51 = scriptOrFnNode48.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make(diagnosticType42, strArray51);
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType21, strArray51);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean59 = scriptOrFnNode57.hasParamOrVar("STRING EOL");
        java.lang.String[] strArray60 = scriptOrFnNode57.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("", node12, checkLevel16, diagnosticType21, strArray60);
        java.lang.String str62 = jSError61.description;
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(subclassRelationship13);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Exceeded max number of optimization iterations: {0}" + "'", str62.equals("Exceeded max number of optimization iterations: {0}"));
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
//        com.google.javascript.rhino.jstype.JSType jSType9 = null;
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
//        boolean boolean12 = jSType11.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
//        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
//        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
//        int int25 = scriptOrFnNode22.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
//        boolean boolean27 = functionType26.isNativeObjectType();
//        boolean boolean28 = functionType26.isBooleanValueType();
//        java.lang.String str29 = functionType26.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(jSType5);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(objectType13);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(booleanArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): function (this:me, {727754009}): me" + "'", str29.equals("function (): function (this:me, {727754009}): me"));
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int0 = com.google.javascript.rhino.Token.BREAK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 116 + "'", int0 == 116);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        boolean boolean4 = jSDocInfo0.isExport();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(jSTypeExpression5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        java.lang.String str8 = compilerOptions0.nameReferenceGraphPath;
        boolean boolean9 = compilerOptions0.specializeInitialModule;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean3 = jSDocInfoBuilder1.recordBlockDescription(": ");
        boolean boolean5 = jSDocInfoBuilder1.recordFileOverview("<No stack trace available>");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder7 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression9 = null;
        boolean boolean10 = jSDocInfoBuilder7.recordParameter("STRING EOL", jSTypeExpression9);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder12 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean13 = jSDocInfoBuilder12.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression14 = null;
        boolean boolean15 = jSDocInfoBuilder12.recordType(jSTypeExpression14);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression16 = null;
        boolean boolean17 = jSDocInfoBuilder12.recordThisType(jSTypeExpression16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean27 = scriptOrFnNode24.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression29 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode24, ": ");
        boolean boolean30 = jSDocInfoBuilder12.recordParameter("<No stack trace available>", jSTypeExpression29);
        boolean boolean31 = jSDocInfoBuilder7.recordThisType(jSTypeExpression29);
        boolean boolean32 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression29);
        boolean boolean33 = jSDocInfoBuilder1.recordDeprecated();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        compilerOptions0.allowLegacyJsMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy32 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy32.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.Region region8 = compilerInput3.getRegion(140);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(region8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.exportSymbol");
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isNoCompile();
        int int4 = jSDocInfo0.getImplementedInterfaceCount();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test012");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context1.setLocale(locale3);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        boolean boolean7 = context1.isGeneratingDebug();
//        try {
//            context1.setLanguageVersion(142);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 142");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getParameterNames();
        boolean boolean4 = jSDocInfo0.containsDeclaration();
        boolean boolean6 = jSDocInfo0.hasParameterType("JSDocInfo");
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        boolean[] booleanArray8 = scriptOrFnNode6.getParamAndVarConst();
        java.lang.String[] strArray9 = scriptOrFnNode6.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst14 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(sourceAst14, "", true);
        com.google.javascript.jscomp.JSModule jSModule18 = compilerInput17.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = null;
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter19, logger20);
        compilerInput17.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel25, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode34);
        boolean[] booleanArray36 = scriptOrFnNode34.getParamAndVarConst();
        java.lang.String[] strArray37 = scriptOrFnNode34.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray37);
        loggerErrorManager21.report(checkLevel25, jSError38);
        compilerOptions11.reportMissingOverride = checkLevel25;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile43);
        com.google.javascript.jscomp.SourceAst sourceAst45 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(sourceAst45, "", true);
        com.google.javascript.jscomp.JSModule jSModule49 = compilerInput48.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter50 = null;
        java.util.logging.Logger logger51 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager52 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter50, logger51);
        compilerInput48.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager52);
        com.google.javascript.jscomp.Compiler compiler54 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager52);
        compilerInput44.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler54);
        java.lang.String str56 = compiler54.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray57 = compiler54.getWarnings();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt58 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter59 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler54, sourceExcerpt58);
        java.lang.String str60 = jSError10.format(checkLevel25, (com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter59);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNull(jSModule18);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSSourceFile43);
        org.junit.Assert.assertNull(jSModule49);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray57);
        org.junit.Assert.assertNull(str60);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
//        com.google.javascript.rhino.jstype.JSType jSType7 = null;
//        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
//        com.google.javascript.rhino.jstype.JSType jSType13 = null;
//        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
//        boolean boolean16 = jSType15.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
//        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
//        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
//        int int29 = scriptOrFnNode26.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
//        com.google.javascript.rhino.jstype.JSType jSType34 = null;
//        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
//        com.google.javascript.rhino.jstype.JSType jSType40 = null;
//        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
//        boolean boolean43 = jSType42.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
//        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
//        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
//        int int56 = scriptOrFnNode53.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
//        java.lang.String str58 = functionType57.getReferenceName();
//        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
//        com.google.javascript.rhino.jstype.JSType jSType62 = null;
//        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
//        com.google.javascript.rhino.jstype.JSType jSType68 = null;
//        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
//        boolean boolean71 = jSType70.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
//        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
//        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
//        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
//        int int84 = scriptOrFnNode81.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
//        boolean boolean86 = functionType85.isNativeObjectType();
//        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
//        java.lang.String str88 = functionType85.toDebugHashCodeString();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(jSType9);
//        org.junit.Assert.assertNotNull(jSType15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(objectType17);
//        org.junit.Assert.assertNotNull(jSType20);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(booleanArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(functionType30);
//        org.junit.Assert.assertNotNull(jSType36);
//        org.junit.Assert.assertNotNull(jSType42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(objectType44);
//        org.junit.Assert.assertNotNull(jSType47);
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(booleanArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(functionType57);
//        org.junit.Assert.assertNull(str58);
//        org.junit.Assert.assertNotNull(jSType64);
//        org.junit.Assert.assertNotNull(jSType70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertNotNull(objectType72);
//        org.junit.Assert.assertNotNull(jSType75);
//        org.junit.Assert.assertNotNull(node77);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(booleanArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//        org.junit.Assert.assertNotNull(functionType85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "function (): function (this:me, {1819233191}): me" + "'", str88.equals("function (): function (this:me, {1819233191}): me"));
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesGlobalState();
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.addAuthor("STRING EOL\n");
        boolean boolean9 = jSDocInfoBuilder1.hasParameter("STRING EOL");
        boolean boolean11 = jSDocInfoBuilder1.addReference("<No stack trace available>");
        boolean boolean12 = jSDocInfoBuilder1.recordNoAlias();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        boolean boolean29 = functionType26.isEmptyType();
        boolean boolean30 = functionType26.isNumber();
        java.lang.String str31 = functionType26.toString();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): None" + "'", str31.equals("function (): None"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(68);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean[] booleanArray27 = scriptOrFnNode25.getParamAndVarConst();
        int int28 = scriptOrFnNode25.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry5.createFunctionType(jSType19, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean boolean30 = functionType29.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        googleCodingConvention0.applySubclassRelationship(functionType29, functionType31, subclassType32);
        java.util.Set<java.lang.String> strSet34 = functionType29.getPropertyNames();
        boolean boolean36 = functionType29.hasOwnProperty("function (): function (this:me, {727754009}): me");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strSet34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("Unknown class name", checkLevel1, "window");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType3);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
//        boolean boolean5 = diagnosticGroup3.matches(diagnosticType4);
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup3;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        boolean boolean8 = diagnosticGroup3.matches(diagnosticType7);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = null;
//        boolean boolean11 = diagnosticGroup9.matches(diagnosticType10);
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup9;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        boolean boolean14 = diagnosticGroup9.matches(diagnosticType13);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = null;
//        boolean boolean19 = diagnosticGroup17.matches(diagnosticType18);
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup17;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        boolean boolean22 = diagnosticGroup17.matches(diagnosticType21);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray25 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType7, diagnosticType13, diagnosticType15, diagnosticType21, diagnosticType23, diagnosticType24 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray25);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray25);
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup27;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup27;
//        context1.seal((java.lang.Object) diagnosticGroup27);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(diagnosticGroup3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(diagnosticType7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(diagnosticType13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(diagnosticType15);
//        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticGroup17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(diagnosticType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(diagnosticType23);
//        org.junit.Assert.assertNotNull(diagnosticType24);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray25);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.optimizeParameters = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.checkCaja = false;
        boolean boolean9 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test026");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
//        com.google.javascript.rhino.jstype.JSType jSType9 = null;
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
//        boolean boolean12 = jSType11.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
//        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
//        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
//        int int25 = scriptOrFnNode22.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
//        java.lang.String str27 = functionType26.getReferenceName();
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
//        boolean boolean34 = jSType33.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSType33.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
//        com.google.javascript.rhino.jstype.JSType jSType38 = objectType35.resolve(errorReporter36, jSTypeStaticScope37);
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType35);
//        com.google.javascript.rhino.jstype.JSType jSType40 = objectType39.getParameterType();
//        com.google.javascript.rhino.jstype.JSType jSType41 = functionType26.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType39);
//        boolean boolean42 = functionType26.isNullType();
//        java.lang.String str43 = functionType26.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(jSType5);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(objectType13);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(booleanArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNotNull(jSType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(objectType35);
//        org.junit.Assert.assertNotNull(jSType38);
//        org.junit.Assert.assertNotNull(objectType39);
//        org.junit.Assert.assertNull(jSType40);
//        org.junit.Assert.assertNotNull(jSType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "function (): function (this:me, {1774214466}): me" + "'", str43.equals("function (): function (this:me, {1774214466}): me"));
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("STRING EOL", jSTypeExpression3);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder6 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean7 = jSDocInfoBuilder6.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder6.recordType(jSTypeExpression8);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder6.recordThisType(jSTypeExpression10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean19 = node14.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode18);
        boolean boolean21 = scriptOrFnNode18.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode18, ": ");
        boolean boolean24 = jSDocInfoBuilder6.recordParameter("<No stack trace available>", jSTypeExpression23);
        boolean boolean25 = jSDocInfoBuilder1.recordThisType(jSTypeExpression23);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope26 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder29 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry28);
        try {
            com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeExpression23.evaluate(jSTypeStaticScope26, jSTypeRegistry28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: TYPEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 109");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(0, "hi!");
        boolean boolean3 = node2.wasEmptyNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.rhino.Context.checkOptimizationLevel((int) (byte) 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        java.lang.String str2 = defaultCodingConvention0.identifyTypeDefAssign(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node6);
        node6.setCharno(23);
        node6.setQuotedString();
        java.lang.String str12 = node6.getQualifiedName();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray13 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput3 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList14 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList14, compilerInputArray13);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies16 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList14);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList17 = compilerInputSortedDependencies16.getSortedList();
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList18 = compilerInputSortedDependencies16.getSortedList();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(compilerInputArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(compilerInputList17);
        org.junit.Assert.assertNotNull(compilerInputList18);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("window", "lsh", 89);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Result result15 = compiler13.getResult();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getErrors();
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.inlineConstantVars = true;
        compilerOptions17.strictMessageReplacement = false;
        compiler13.initOptions(compilerOptions17);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        node2.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node2.setJSType(jSType6);
        node2.setCharno(11);
        int int10 = node2.getType();
        com.google.javascript.rhino.Node node11 = node2.cloneNode();
        java.lang.Object obj12 = null;
        java.lang.Object obj13 = null;
        java.lang.Object obj14 = null;
        try {
            java.lang.String str15 = com.google.javascript.rhino.ScriptRuntime.getMessage4("JSDocInfo", (java.lang.Object) node11, obj12, obj13, obj14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSDocInfo");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordType(jSTypeExpression3);
        java.lang.String[] strArray13 = new java.lang.String[] { "", "Not declared as a constructor", "hi!", "EOL", "<No stack trace available>", "", "EOL", "STRING EOL" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        boolean boolean16 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet14);
        boolean boolean17 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        boolean boolean18 = jSDocInfoBuilder1.recordOverride();
        boolean boolean19 = jSDocInfoBuilder1.shouldParseDocumentation();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder21 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean22 = jSDocInfoBuilder21.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = null;
        boolean boolean24 = jSDocInfoBuilder21.recordType(jSTypeExpression23);
        java.lang.String[] strArray33 = new java.lang.String[] { "", "Not declared as a constructor", "hi!", "EOL", "<No stack trace available>", "", "EOL", "STRING EOL" };
        java.util.LinkedHashSet<java.lang.String> strSet34 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet34, strArray33);
        boolean boolean36 = jSDocInfoBuilder21.recordModifies((java.util.Set<java.lang.String>) strSet34);
        boolean boolean37 = jSDocInfoBuilder1.recordSuppressions((java.util.Set<java.lang.String>) strSet34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDescription();
        jSDocInfo0.setLicense("JSDocInfo");
        boolean boolean8 = jSDocInfo0.hasParameterType(": ");
        java.lang.String str10 = jSDocInfo0.getDescriptionForParameter("lsh");
        java.lang.String str11 = jSDocInfo0.getLendsName();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 120, 64, 35);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) '#');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean10 = defaultCodingConvention8.isExported("<No stack trace available>");
        boolean boolean12 = defaultCodingConvention8.isConstantKey("Not declared as a constructor");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType14 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        defaultCodingConvention13.applyDelegateRelationship(objectType14, objectType15, objectType16, functionType17, functionType18);
        java.lang.String str20 = defaultCodingConvention13.getExportPropertyFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship25 = defaultCodingConvention13.getClassesDefinedByCall(node24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        node27.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node27.setJSType(jSType31);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = defaultCodingConvention13.getClassesDefinedByCall(node27);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = defaultCodingConvention8.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node5, node7, node27 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(18, nodeArray35);
        try {
            com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray35, 107, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(subclassRelationship25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(subclassRelationship33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(nodeArray35);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = null;
        java.lang.String str7 = defaultCodingConvention5.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder12 = node11.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship13 = defaultCodingConvention5.getClassesDefinedByCall(node11);
        java.lang.String str14 = node11.getString();
        java.lang.String str15 = googleCodingConvention0.extractClassNameIfProvide(node4, node11);
        boolean boolean17 = googleCodingConvention0.isValidEnumKey("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention18 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean21 = googleCodingConvention18.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOL");
        node24.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        node24.setJSType(jSType28);
        java.lang.String str33 = node24.toString(true, false, true);
        java.lang.String str34 = node24.toStringTree();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(12, node24, node38, 131, (int) (short) -1);
        boolean boolean42 = googleCodingConvention18.isOptionalParameter(node38);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean49 = scriptOrFnNode47.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean52 = node51.isVarArgs();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("EOL");
        node58.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node62 = node58.getLastChild();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode47, node51, node56, node58);
        com.google.javascript.rhino.Node node64 = scriptOrFnNode47.cloneNode();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("EOL");
        node66.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        node66.setJSType(jSType70);
        node66.setCharno(11);
        boolean boolean74 = node66.hasOneChild();
        node66.setCharno(4);
        java.lang.String str77 = googleCodingConvention18.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode47, node66);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship78 = googleCodingConvention0.getClassesDefinedByCall(node66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder12);
        org.junit.Assert.assertNull(subclassRelationship13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EOL" + "'", str14.equals("EOL"));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "STRING EOL" + "'", str33.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "STRING EOL\n" + "'", str34.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(str77);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = defaultCodingConvention0.isExported("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean15 = defaultCodingConvention13.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean22 = node17.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.lang.String str23 = defaultCodingConvention13.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean boolean25 = defaultCodingConvention13.isConstant(": ");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean28 = node27.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node27.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = scriptOrFnNode33.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node36 = node27.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode33);
        java.lang.String str37 = defaultCodingConvention13.getSingletonGetterClassName(node27);
        com.google.javascript.rhino.jstype.JSType jSType38 = node27.getJSType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError45 = nodeTraversal11.makeError(node27, diagnosticType39, strArray44);
        int int46 = nodeTraversal11.getLineNumber();
        com.google.javascript.rhino.Node node47 = nodeTraversal11.getCurrentNode();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNull(node47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, ": ", false);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput9, "hi!", false);
        com.google.javascript.jscomp.JSModule jSModule13 = compilerInput9.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(jSModule13);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDescription();
        jSDocInfo0.setLicense("JSDocInfo");
        boolean boolean8 = jSDocInfo0.hasParameterType(": ");
        boolean boolean9 = jSDocInfo0.hasThisType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_MOD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 97 + "'", int0 == 97);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "language version", 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getTemplateTypeName();
        java.lang.String str28 = functionType26.toString();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "function (): None" + "'", str28.equals("function (): None"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        java.lang.String str7 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "", 38, 120);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention12 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType14 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        defaultCodingConvention12.applyDelegateRelationship(objectType13, objectType14, objectType15, functionType16, functionType17);
        java.lang.String str19 = defaultCodingConvention12.getExportPropertyFunction();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship24 = defaultCodingConvention12.getClassesDefinedByCall(node23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        node26.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node26.setJSType(jSType30);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship32 = defaultCodingConvention12.getClassesDefinedByCall(node26);
        java.util.List<java.lang.String> strList33 = defaultCodingConvention0.identifyTypeDeclarationCall(node26);
        java.lang.Appendable appendable34 = null;
        try {
            node26.appendStringTree(appendable34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(subclassRelationship24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(subclassRelationship32);
        org.junit.Assert.assertNull(strList33);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING EOL");
        java.lang.String str6 = scriptOrFnNode3.getSourceName();
        boolean boolean7 = scriptOrFnNode3.hasChildren();
        com.google.javascript.rhino.jstype.JSType jSType8 = scriptOrFnNode3.getJSType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jSType8);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test052");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
//        boolean[] booleanArray11 = scriptOrFnNode9.getParamAndVarConst();
//        java.lang.String[] strArray12 = scriptOrFnNode9.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
//        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
//        java.lang.String str15 = jSError13.toString();
//        com.google.javascript.jscomp.CheckLevel checkLevel16 = jSError13.level;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = null;
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
//        com.google.javascript.jscomp.SourceAst sourceAst23 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(sourceAst23, "", true);
//        com.google.javascript.jscomp.JSModule jSModule27 = compilerInput26.getModule();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter28 = null;
//        java.util.logging.Logger logger29 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager30 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter28, logger29);
//        compilerInput26.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager30);
//        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager30);
//        com.google.javascript.jscomp.CheckLevel checkLevel34 = com.google.javascript.jscomp.CheckLevel.OFF;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel34, "STRING EOL");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean44 = node39.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode43);
//        boolean[] booleanArray45 = scriptOrFnNode43.getParamAndVarConst();
//        java.lang.String[] strArray46 = scriptOrFnNode43.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType37, strArray46);
//        loggerErrorManager30.report(checkLevel34, jSError47);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel50 = diagnosticType49.defaultLevel;
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode54 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        java.lang.String[] strArray55 = scriptOrFnNode54.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make(": ", node22, checkLevel34, diagnosticType49, strArray55);
//        try {
//            com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("function (): None", 151, 300, checkLevel16, diagnosticType17, strArray55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertNotNull(node5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(booleanArray11);
//        org.junit.Assert.assertNotNull(strArray12);
//        org.junit.Assert.assertNotNull(jSError13);
//        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str15.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
//        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNull(jSModule27);
//        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType36);
//        org.junit.Assert.assertNotNull(diagnosticType37);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(booleanArray45);
//        org.junit.Assert.assertNotNull(strArray46);
//        org.junit.Assert.assertNotNull(jSError47);
//        org.junit.Assert.assertNotNull(diagnosticType49);
//        org.junit.Assert.assertTrue("'" + checkLevel50 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel50.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(strArray55);
//        org.junit.Assert.assertNotNull(jSError56);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.defineElement("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        boolean boolean23 = enumType20.canBeCalled();
        boolean boolean24 = enumType20.isEnumType();
        boolean boolean25 = enumType20.isEnumType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
//        boolean[] booleanArray8 = scriptOrFnNode6.getParamAndVarConst();
//        java.lang.String[] strArray9 = scriptOrFnNode6.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray9);
//        com.google.javascript.jscomp.CheckLevel checkLevel11 = jSError10.level;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = null;
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder13 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry12);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder15 = functionBuilder13.setIsConstructor(false);
//        boolean boolean16 = jSError10.equals((java.lang.Object) functionBuilder13);
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = null;
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder18 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry17);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder19 = functionBuilder13.withParams(functionParamBuilder18);
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
//        jSTypeRegistry22.resetForTypeCheck();
//        boolean boolean25 = jSTypeRegistry22.isForwardDeclaredType("hi!");
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder26 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry22);
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
//        boolean boolean34 = jSType33.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSType33.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
//        com.google.javascript.rhino.jstype.JSType jSType38 = objectType35.resolve(errorReporter36, jSTypeStaticScope37);
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = objectType35.toObjectType();
//        com.google.javascript.rhino.jstype.EnumType enumType40 = jSTypeRegistry22.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType39);
//        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry22.createNamedType("@IMPLEMENTATION.VERSION@", "goog.exportProperty", 0, 31);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder46 = functionBuilder13.withReturnType(jSType45);
//        try {
//            com.google.javascript.rhino.jstype.FunctionType functionType47 = functionBuilder13.build();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticType0);
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(booleanArray8);
//        org.junit.Assert.assertNotNull(strArray9);
//        org.junit.Assert.assertNotNull(jSError10);
//        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(functionBuilder15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(functionBuilder19);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(jSType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(objectType35);
//        org.junit.Assert.assertNotNull(jSType38);
//        org.junit.Assert.assertNotNull(objectType39);
//        org.junit.Assert.assertNotNull(enumType40);
//        org.junit.Assert.assertNotNull(jSType45);
//        org.junit.Assert.assertNotNull(functionBuilder46);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = compilerOptions0.messageBundle;
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.setSummaryDetailLevel(56);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(messageBundle7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        compilerOptions0.skipAllCompilerPasses();
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config4 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "function (): function (this:me, {1774214466}): me", config4, errorReporter5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = diagnosticType1.defaultLevel;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        diagnosticType1.level = checkLevel14;
        boolean boolean30 = diagnosticGroup0.matches(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        context1.removeThreadLocal((java.lang.Object) 56);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType5, diagnosticType6, diagnosticType7, diagnosticType8 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean18 = node13.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode17);
//        boolean[] booleanArray19 = scriptOrFnNode17.getParamAndVarConst();
//        java.lang.String[] strArray20 = scriptOrFnNode17.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray20);
//        boolean boolean22 = diagnosticGroup10.matches(jSError21);
//        context1.seal((java.lang.Object) boolean22);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(diagnosticType5);
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertNotNull(diagnosticType7);
//        org.junit.Assert.assertNotNull(diagnosticType8);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
//        org.junit.Assert.assertNotNull(diagnosticType11);
//        org.junit.Assert.assertNotNull(node13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(booleanArray19);
//        org.junit.Assert.assertNotNull(strArray20);
//        org.junit.Assert.assertNotNull(jSError21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        boolean[] booleanArray8 = scriptOrFnNode6.getParamAndVarConst();
        java.lang.String[] strArray9 = scriptOrFnNode6.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray9);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = jSError10.level;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder13 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry12);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder15 = functionBuilder13.setIsConstructor(false);
        boolean boolean16 = jSError10.equals((java.lang.Object) functionBuilder13);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder18 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry17);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder19 = functionBuilder13.withParams(functionParamBuilder18);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder21 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        node30.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        node30.setJSType(jSType34);
        node30.setCharno(11);
        boolean boolean38 = node23.checkTreeTypeAwareEqualsSilent(node30);
        com.google.javascript.rhino.Node node39 = functionParamBuilder21.newParameterFromNode(node30);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention40 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node41 = null;
        java.lang.String str42 = defaultCodingConvention40.identifyTypeDefAssign(node41);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder47 = node46.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship48 = defaultCodingConvention40.getClassesDefinedByCall(node46);
        java.lang.String str49 = node46.getString();
        com.google.javascript.rhino.Node node50 = node39.copyInformationFrom(node46);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder51 = functionBuilder19.withSourceNode(node50);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(functionBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionBuilder19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder47);
        org.junit.Assert.assertNull(subclassRelationship48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "EOL" + "'", str49.equals("EOL"));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(functionBuilder51);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getAllDependencies();
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = null;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.instrumentationTemplate = "@IMPLEMENTATION.VERSION@";
        boolean boolean5 = compilerOptions0.inlineLocalVariables;
        boolean boolean6 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable5 = jSTypeRegistry2.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        jSTypeRegistry9.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry13.getGreatestSubtypeWithProperty(jSType14, "");
        boolean boolean17 = jSType16.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSType16.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
        com.google.javascript.rhino.jstype.JSType jSType21 = objectType18.resolve(errorReporter19, jSTypeStaticScope20);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry9.createDefaultObjectUnion(jSType21);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSTypeRegistry26.getNativeObjectType(jSTypeNative27);
        jSTypeRegistry9.registerPropertyOnType("@IMPLEMENTATION.VERSION@", (com.google.javascript.rhino.jstype.JSType) objectType28);
        try {
            jSTypeRegistry2.overwriteDeclaredType("", (com.google.javascript.rhino.jstype.JSType) objectType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeIterable5);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType28);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean23 = defaultCodingConvention21.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean30 = node25.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode29);
        java.lang.String str31 = defaultCodingConvention21.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("EOL");
        node33.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        node33.setJSType(jSType37);
        node33.setCharno(11);
        boolean boolean41 = node33.hasOneChild();
        node33.setCharno(4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = defaultCodingConvention21.getClassesDefinedByCall(node33);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry2.createFromTypeNodes(node33, "error reporter", jSTypeStaticScope46, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNotNull(jSType48);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        java.lang.String str88 = functionType57.getTemplateTypeName();
        com.google.javascript.rhino.jstype.JSType jSType89 = null;
        try {
            com.google.javascript.rhino.jstype.JSType.TypePair typePair90 = functionType57.getTypesUnderShallowEquality(jSType89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNull(str88);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        node2.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node2.setJSType(jSType6);
        node2.setCharno(11);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(114, node2);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
        scriptOrFnNode17.setCompilerData((java.lang.Object) jSTypeNative19);
        scriptOrFnNode17.setBaseLineno(104);
        int int23 = scriptOrFnNode17.getParamAndVarCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDescription();
        jSDocInfo0.setLicense("JSDocInfo");
        boolean boolean7 = jSDocInfo0.shouldPreserveTry();
        boolean boolean8 = jSDocInfo0.isExterns();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("STRING EOL", jSTypeExpression3);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder6 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean7 = jSDocInfoBuilder6.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder6.recordType(jSTypeExpression8);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder6.recordThisType(jSTypeExpression10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean19 = node14.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode18);
        boolean boolean21 = scriptOrFnNode18.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode18, ": ");
        boolean boolean24 = jSDocInfoBuilder6.recordParameter("<No stack trace available>", jSTypeExpression23);
        boolean boolean25 = jSDocInfoBuilder1.recordThisType(jSTypeExpression23);
        boolean boolean26 = jSTypeExpression23.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("div", "error reporter", "@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean10 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = scriptOrFnNode4.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean9 = node8.isVarArgs();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        node15.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node19 = node15.getLastChild();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode4, node8, node13, node15);
        node13.setVarArgs(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node19);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) '4', "<No stack trace available>", 108, 98);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags5 = null;
        try {
            node4.setSideEffectFlags(sideEffectFlags5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.getGreatestSubtypeWithProperty(jSType61, "");
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        boolean boolean70 = jSType69.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSType69.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = objectType71.resolve(errorReporter72, jSTypeStaticScope73);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean81 = node76.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode80);
        boolean[] booleanArray82 = scriptOrFnNode80.getParamAndVarConst();
        int int83 = scriptOrFnNode80.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry60.createFunctionType(jSType74, (com.google.javascript.rhino.Node) scriptOrFnNode80);
        java.lang.String str85 = functionType84.getReferenceName();
        boolean boolean86 = functionType84.hasReferenceName();
        boolean boolean87 = functionType84.isEmptyType();
        boolean boolean88 = functionType56.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType84);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable89 = functionType56.getParameters();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(booleanArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(nodeIterable89);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test076");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context1.setLocale(locale3);
//        boolean boolean5 = context1.isGeneratingSource();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_DIV;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 96 + "'", int0 == 96);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        compiler13.report(jSError27);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        jSSourceFile31.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        com.google.javascript.jscomp.JSModule jSModule35 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        com.google.javascript.jscomp.JSModule[] jSModuleArray36 = new com.google.javascript.jscomp.JSModule[] { jSModule35 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean38 = compilerOptions37.checkEs5Strict;
        java.lang.String str39 = compilerOptions37.syntheticBlockStartMarker;
        boolean boolean40 = compilerOptions37.checkSuspiciousCode;
        compiler13.init(jSSourceFileArray33, jSModuleArray36, compilerOptions37);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertNotNull(jSModuleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean5 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression3, "hi!");
        boolean boolean6 = jSDocInfoBuilder1.recordInterface();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder8 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean9 = jSDocInfoBuilder8.recordJavaDispatch();
        boolean boolean11 = jSDocInfoBuilder8.addReference("hi!");
        boolean boolean12 = jSDocInfoBuilder8.recordNoShadow();
        boolean boolean14 = jSDocInfoBuilder8.addAuthor("STRING EOL\n");
        boolean boolean16 = jSDocInfoBuilder8.hasParameter("STRING EOL");
        jSDocInfoBuilder8.markName("hi!", (int) '#', 91);
        boolean boolean22 = jSDocInfoBuilder8.recordTemplateTypeName("error reporter");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder24 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean25 = jSDocInfoBuilder24.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet26 = null;
        boolean boolean27 = jSDocInfoBuilder24.recordModifies(strSet26);
        boolean boolean28 = jSDocInfoBuilder24.isPopulatedWithFileOverview();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean36 = node31.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode35);
        boolean boolean38 = scriptOrFnNode35.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression40 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode35, ": ");
        boolean boolean41 = jSDocInfoBuilder24.recordParameter("Unknown class name", jSTypeExpression40);
        boolean boolean42 = jSDocInfoBuilder8.recordBaseType(jSTypeExpression40);
        boolean boolean43 = jSDocInfoBuilder1.recordEnumParameterType(jSTypeExpression40);
        boolean boolean45 = jSDocInfoBuilder1.recordReturnDescription("STRING EOL\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.getGreatestSubtypeWithProperty(jSType61, "");
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        boolean boolean70 = jSType69.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSType69.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = objectType71.resolve(errorReporter72, jSTypeStaticScope73);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean81 = node76.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode80);
        boolean[] booleanArray82 = scriptOrFnNode80.getParamAndVarConst();
        int int83 = scriptOrFnNode80.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry60.createFunctionType(jSType74, (com.google.javascript.rhino.Node) scriptOrFnNode80);
        java.lang.String str85 = functionType84.getReferenceName();
        boolean boolean86 = functionType84.hasReferenceName();
        boolean boolean87 = functionType84.isEmptyType();
        boolean boolean88 = functionType56.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType84);
        boolean boolean90 = functionType56.hasOwnProperty("Not declared as a constructor");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(booleanArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        boolean boolean13 = compilerInput3.isExtern();
        com.google.javascript.jscomp.JSModule jSModule15 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] { jSModule15, jSModule17, jSModule19 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph21 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray20);
        com.google.javascript.jscomp.JSModule jSModule23 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule26 = jSModuleGraph21.getDeepestCommonDependencyInclusive(jSModule23, jSModule25);
        compilerInput3.setModule(jSModule26);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertNull(jSModule26);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.jstype.ObjectType objectType6 = jSTypeRegistry2.createAnonymousObjectType();
        boolean boolean7 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(objectType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        boolean boolean10 = jSType9.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSType9.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = objectType11.resolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry2.createDefaultObjectUnion(jSType14);
        jSTypeRegistry2.identifyNonNullableName("error reporter");
        java.util.Map<java.lang.String, com.google.javascript.rhino.jstype.JSType> strMap18 = null;
        try {
            com.google.javascript.rhino.jstype.RecordType recordType19 = jSTypeRegistry2.createRecordType(strMap18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = null;
        compilerOptions0.sourceMapFormat = format1;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = compilerOptions0.propertyRenaming;
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int0 = com.google.javascript.rhino.Token.CONST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 149 + "'", int0 == 149);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int0 = com.google.javascript.rhino.Token.LT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.hasProperty("Not declared as a constructor");
        boolean boolean23 = enumType20.isDateType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean5 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression3, "hi!");
        boolean boolean6 = jSDocInfoBuilder1.recordInterface();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression7 = null;
        boolean boolean8 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression7);
        boolean boolean10 = jSDocInfoBuilder1.recordDescription("JSDocInfo");
        boolean boolean11 = jSDocInfoBuilder1.recordJavaDispatch();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Not declared as a constructor" + "'", str3.equals("Not declared as a constructor"));
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, (long) 123);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.withReturnType(jSType4);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = functionBuilder1.withName(": ");
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder9 = functionBuilder7.withInferredReturnType(jSType8);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder7);
        org.junit.Assert.assertNotNull(functionBuilder9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.hasProperty("Not declared as a constructor");
        boolean boolean24 = enumType20.defineElement("lsh");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = null;
        java.lang.String str7 = defaultCodingConvention5.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder12 = node11.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship13 = defaultCodingConvention5.getClassesDefinedByCall(node11);
        java.lang.String str14 = node11.getString();
        java.lang.String str15 = googleCodingConvention0.extractClassNameIfProvide(node4, node11);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        java.lang.String[] strArray20 = scriptOrFnNode19.getParamAndVarNames();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) 120, 64, 35);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '#');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean30 = defaultCodingConvention28.isExported("<No stack trace available>");
        boolean boolean32 = defaultCodingConvention28.isConstantKey("Not declared as a constructor");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType36 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType37 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType38 = null;
        defaultCodingConvention33.applyDelegateRelationship(objectType34, objectType35, objectType36, functionType37, functionType38);
        java.lang.String str40 = defaultCodingConvention33.getExportPropertyFunction();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship45 = defaultCodingConvention33.getClassesDefinedByCall(node44);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("EOL");
        node47.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        node47.setJSType(jSType51);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship53 = defaultCodingConvention33.getClassesDefinedByCall(node47);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship54 = defaultCodingConvention28.getDelegateRelationship(node47);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node25, node27, node47 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(18, nodeArray55);
        node56.setWasEmptyNode(false);
        java.lang.String str59 = googleCodingConvention0.extractClassNameIfProvide((com.google.javascript.rhino.Node) scriptOrFnNode19, node56);
        boolean boolean61 = googleCodingConvention0.isSuperClassReference("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder12);
        org.junit.Assert.assertNull(subclassRelationship13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EOL" + "'", str14.equals("EOL"));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(subclassRelationship45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(subclassRelationship53);
        org.junit.Assert.assertNull(delegateRelationship54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        node6.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node6.setJSType(jSType10);
        java.lang.String str15 = node6.toString(true, false, true);
        java.lang.String str16 = node6.toStringTree();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(12, node6, node20, 131, (int) (short) -1);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node20);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = scriptOrFnNode29.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean34 = node33.isVarArgs();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("EOL");
        node40.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node44 = node40.getLastChild();
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode29, node33, node38, node40);
        com.google.javascript.rhino.Node node46 = scriptOrFnNode29.cloneNode();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        node48.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        node48.setJSType(jSType52);
        node48.setCharno(11);
        boolean boolean56 = node48.hasOneChild();
        node48.setCharno(4);
        java.lang.String str59 = googleCodingConvention0.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode29, node48);
        boolean boolean61 = googleCodingConvention0.isPrivate("<No stack trace available>");
        java.lang.String str62 = googleCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING EOL" + "'", str15.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING EOL\n" + "'", str16.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "goog.global" + "'", str62.equals("goog.global"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("STRING EOL\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        jSDocInfo0.setDeprecated(true);
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = null;
        compilerOptions0.sourceMapFormat = format1;
        boolean boolean3 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = null;
        try {
            com.google.javascript.rhino.Node node2 = compiler0.parse(jSSourceFile1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable5 = jSTypeRegistry2.getTypesWithProperty("");
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.getType("");
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNotNull(jSTypeIterable5);
        org.junit.Assert.assertNull(jSType7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.instrumentForCoverage;
        boolean boolean7 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.debugFunctionSideEffectsPath = "";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean[] booleanArray27 = scriptOrFnNode25.getParamAndVarConst();
        int int28 = scriptOrFnNode25.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry5.createFunctionType(jSType19, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean boolean30 = functionType29.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        googleCodingConvention0.applySubclassRelationship(functionType29, functionType31, subclassType32);
        boolean boolean34 = functionType29.isNativeObjectType();
        java.lang.String str35 = functionType29.getNormalizedReferenceName();
        boolean boolean36 = functionType29.isNoType();
        boolean boolean37 = functionType29.matchesStringContext();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition1.setItem("<No stack trace available>");
        marker0.annotation = stringPosition1;
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition5 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        java.lang.String str6 = stringPosition5.getItem();
        marker0.name = stringPosition5;
        com.google.javascript.rhino.JSDocInfo.Marker marker8 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition9 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition9.setItem("<No stack trace available>");
        marker8.annotation = stringPosition9;
        int int13 = stringPosition9.getPositionOnStartLine();
        int int14 = stringPosition9.getStartLine();
        marker0.description = stringPosition9;
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, ": ", false);
        java.lang.String str11 = compilerInput9.getLine(25);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.instrumentForCoverage;
        com.google.javascript.jscomp.SourceAst sourceAst7 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "", true);
        com.google.javascript.jscomp.JSModule jSModule11 = compilerInput10.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = null;
        java.util.logging.Logger logger13 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager14 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter12, logger13);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = loggerErrorManager14.getErrors();
        int int16 = loggerErrorManager14.getErrorCount();
        compilerInput10.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager14);
        int int18 = loggerErrorManager14.getWarningCount();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        jSTypeRegistry21.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        boolean boolean29 = jSType28.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = objectType30.resolve(errorReporter31, jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry21.createDefaultObjectUnion(jSType33);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.OFF;
        boolean boolean36 = jSType34.equals((java.lang.Object) checkLevel35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean47 = node42.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode46);
        boolean[] booleanArray48 = scriptOrFnNode46.getParamAndVarConst();
        java.lang.String[] strArray49 = scriptOrFnNode46.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean57 = node52.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode56);
        boolean[] booleanArray58 = scriptOrFnNode56.getParamAndVarConst();
        java.lang.String[] strArray59 = scriptOrFnNode56.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray59);
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode67 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean68 = node63.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode67);
        boolean[] booleanArray69 = scriptOrFnNode67.getParamAndVarConst();
        java.lang.String[] strArray70 = scriptOrFnNode67.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType40, strArray70);
        loggerErrorManager14.report(checkLevel35, jSError72);
        compilerOptions0.checkUnreachableCode = checkLevel35;
        boolean boolean75 = compilerOptions0.exportTestFunctions;
        compilerOptions0.collapseProperties = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule11);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(booleanArray69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        int int8 = scriptOrFnNode6.getRegexpCount();
        java.lang.String str9 = scriptOrFnNode6.getSourceName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        defaultCodingConvention10.applyDelegateRelationship(objectType11, objectType12, objectType13, functionType14, functionType15);
        java.lang.String str17 = defaultCodingConvention10.getExportPropertyFunction();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention10.getClassesDefinedByCall(node21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOL");
        node24.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        node24.setJSType(jSType28);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship30 = defaultCodingConvention10.getClassesDefinedByCall(node24);
        node24.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] { scriptOrFnNode6, node24 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(82, nodeArray33, 304, 3);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(subclassRelationship30);
        org.junit.Assert.assertNotNull(nodeArray33);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry5.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) objectType16);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry1.createFunctionType(jSType20, false, jSTypeArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(jSType20);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int0 = com.google.javascript.rhino.Token.SHNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        java.lang.String str3 = jSSourceFile2.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.Scope scope12 = nodeTraversal11.getScope();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        node15.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node15.setJSType(jSType19);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean23 = defaultCodingConvention21.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean30 = node25.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode29);
        java.lang.String str31 = defaultCodingConvention21.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean38 = node33.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("EOL");
        node40.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        node40.setJSType(jSType44);
        node40.setCharno(11);
        boolean boolean48 = node33.checkTreeTypeAwareEqualsSilent(node40);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode54 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean55 = node50.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode54);
        boolean[] booleanArray56 = scriptOrFnNode54.getParamAndVarConst();
        int int57 = scriptOrFnNode54.getSideEffectFlags();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((-1), node15, (com.google.javascript.rhino.Node) scriptOrFnNode29, node40, (com.google.javascript.rhino.Node) scriptOrFnNode54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode65 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean66 = node61.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode65);
        boolean[] booleanArray67 = scriptOrFnNode65.getParamAndVarConst();
        java.lang.String[] strArray68 = scriptOrFnNode65.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError69 = com.google.javascript.jscomp.JSError.make(diagnosticType59, strArray68);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = jSError69.level;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup71 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticType diagnosticType72 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel73 = diagnosticType72.defaultLevel;
        boolean boolean74 = diagnosticGroup71.matches(diagnosticType72);
        com.google.javascript.jscomp.DiagnosticType diagnosticType75 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        java.lang.String[] strArray84 = scriptOrFnNode81.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError85 = com.google.javascript.jscomp.JSError.make(diagnosticType75, strArray84);
        com.google.javascript.jscomp.JSError jSError86 = nodeTraversal11.makeError((com.google.javascript.rhino.Node) scriptOrFnNode54, checkLevel70, diagnosticType72, strArray84);
        java.lang.String str87 = jSError86.sourceName;
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(scope12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(booleanArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(booleanArray67);
        org.junit.Assert.assertNotNull(strArray68);
        org.junit.Assert.assertNotNull(jSError69);
        org.junit.Assert.assertTrue("'" + checkLevel70 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel70.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup71);
        org.junit.Assert.assertNotNull(diagnosticType72);
        org.junit.Assert.assertTrue("'" + checkLevel73 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel73.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(diagnosticType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertNotNull(jSError85);
        org.junit.Assert.assertNotNull(jSError86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "" + "'", str87.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.instrumentationTemplate = "<No stack trace available>";
        boolean boolean4 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.unaliasableGlobals = "com.google.javascript.rhino.EcmaError: : ";
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Result result15 = compiler13.getResult();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getErrors();
        com.google.javascript.jscomp.Result result17 = compiler13.getResult();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(result17);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.inlineFunctions = true;
        com.google.javascript.jscomp.SourceMap.Format format6 = compilerOptions0.sourceMapFormat;
        compilerOptions0.collapseAnonymousFunctions = false;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(format6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(codingConvention8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.inlineFunctions = true;
        com.google.javascript.jscomp.SourceMap.Format format6 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setSummaryDetailLevel((int) (byte) -1);
        compilerOptions0.setColorizeErrorOutput(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(format6);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry26.getGreatestSubtypeWithProperty(jSType27, "");
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        boolean boolean36 = jSType35.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSType35.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType37.resolve(errorReporter38, jSTypeStaticScope39);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean47 = node42.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode46);
        boolean[] booleanArray48 = scriptOrFnNode46.getParamAndVarConst();
        int int49 = scriptOrFnNode46.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry26.createFunctionType(jSType40, (com.google.javascript.rhino.Node) scriptOrFnNode46);
        java.lang.String str51 = functionType50.getReferenceName();
        boolean boolean52 = functionType50.hasReferenceName();
        java.util.Set<java.lang.String> strSet53 = functionType50.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.ObjectType objectType54 = functionType50.getImplicitPrototype();
        com.google.javascript.rhino.jstype.ObjectType objectType55 = jSTypeRegistry2.createObjectType("STRING EOL", node23, (com.google.javascript.rhino.jstype.ObjectType) functionType50);
        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        boolean boolean62 = jSType61.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType63 = jSType61.toObjectType();
        boolean boolean64 = objectType63.isInterface();
        boolean boolean65 = objectType63.matchesUint32Context();
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, false);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry68.getGreatestSubtypeWithProperty(jSType69, "");
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, false);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        boolean boolean78 = jSType77.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSType77.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope81 = null;
        com.google.javascript.rhino.jstype.JSType jSType82 = objectType79.resolve(errorReporter80, jSTypeStaticScope81);
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry68.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) objectType79);
        boolean boolean84 = objectType63.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) objectType79);
        boolean boolean85 = functionType50.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) objectType79);
        boolean boolean86 = functionType50.isArrayType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(strSet53);
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNotNull(objectType55);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(objectType63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        com.google.javascript.jscomp.SourceAst sourceAst6 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(sourceAst6, "", true);
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput9.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = null;
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter11, logger12);
        compilerInput9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Scope scope16 = compiler15.getTopScope();
        int int17 = compiler15.getWarningCount();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, sourceExcerpt19);
        lightweightMessageFormatter20.setColorize(false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNull(scope16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        java.lang.String str8 = compilerOptions0.nameReferenceGraphPath;
        boolean boolean9 = compilerOptions0.labelRenaming;
        boolean boolean10 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType30.isRecordType();
        boolean boolean89 = functionType30.hasCachedValues();
        com.google.javascript.rhino.jstype.ObjectType objectType90 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType30);
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet91 = objectType90.getPossibleToBooleanOutcomes();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(objectType90);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet91 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet91.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        boolean boolean30 = compilerOptions0.lineBreak;
        boolean boolean31 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean32 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        node1.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node1.setJSType(jSType5);
        node1.setCharno(11);
        node1.putIntProp(2, 4095);
        com.google.javascript.rhino.Node node12 = node1.cloneNode();
        try {
            com.google.javascript.rhino.Node node14 = node1.getAncestor((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("EOL");
        node9.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node9.setJSType(jSType13);
        node9.setCharno(11);
        boolean boolean17 = node2.checkTreeTypeAwareEqualsSilent(node9);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(118, node9, 110, 40);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = scriptOrFnNode24.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode24.setSourceName("EOL");
        int int30 = scriptOrFnNode24.addVar("STRING EOL");
        node20.addChildToBack((com.google.javascript.rhino.Node) scriptOrFnNode24);
        try {
            double double32 = scriptOrFnNode24.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: TYPEOF [source name: EOL] [encoded source length: 0] [base line: -1] [end line: -1] 109 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isNoCompile();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getParameterType("error reporter");
        boolean boolean6 = jSDocInfo0.isDefine();
        java.util.Set<java.lang.String> strSet7 = jSDocInfo0.getModifies();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSTypeExpression5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = functionType26.isNativeObjectType();
        boolean boolean28 = functionType26.isBooleanValueType();
        boolean boolean29 = functionType26.isConstructor();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        java.lang.String[] strArray5 = scriptOrFnNode4.getParamAndVarNames();
        int int6 = scriptOrFnNode4.getParamCount();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] { scriptOrFnNode4 };
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(1, nodeArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(nodeArray7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("goog.exportProperty", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        compilerOptions0.setDefineToDoubleLiteral("div", (double) 20);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.instrumentForCoverage;
        com.google.javascript.jscomp.SourceAst sourceAst7 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "", true);
        com.google.javascript.jscomp.JSModule jSModule11 = compilerInput10.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = null;
        java.util.logging.Logger logger13 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager14 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter12, logger13);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = loggerErrorManager14.getErrors();
        int int16 = loggerErrorManager14.getErrorCount();
        compilerInput10.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager14);
        int int18 = loggerErrorManager14.getWarningCount();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        jSTypeRegistry21.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        boolean boolean29 = jSType28.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = objectType30.resolve(errorReporter31, jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry21.createDefaultObjectUnion(jSType33);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.OFF;
        boolean boolean36 = jSType34.equals((java.lang.Object) checkLevel35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean47 = node42.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode46);
        boolean[] booleanArray48 = scriptOrFnNode46.getParamAndVarConst();
        java.lang.String[] strArray49 = scriptOrFnNode46.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean57 = node52.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode56);
        boolean[] booleanArray58 = scriptOrFnNode56.getParamAndVarConst();
        java.lang.String[] strArray59 = scriptOrFnNode56.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray59);
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode67 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean68 = node63.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode67);
        boolean[] booleanArray69 = scriptOrFnNode67.getParamAndVarConst();
        java.lang.String[] strArray70 = scriptOrFnNode67.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType40, strArray70);
        loggerErrorManager14.report(checkLevel35, jSError72);
        compilerOptions0.checkUnreachableCode = checkLevel35;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy75 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy75;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule11);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(booleanArray69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.hasOwnProperty("Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getWarnings();
        int int17 = compiler13.getWarningCount();
        com.google.javascript.jscomp.SourceAst sourceAst18 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(sourceAst18, "", true);
        com.google.javascript.jscomp.JSModule jSModule22 = compilerInput21.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        com.google.javascript.jscomp.JSError[] jSErrorArray26 = loggerErrorManager25.getErrors();
        int int27 = loggerErrorManager25.getErrorCount();
        compilerInput21.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        compiler13.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        loggerErrorManager25.generateReport();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(jSModule22);
        org.junit.Assert.assertNotNull(jSErrorArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.optimizeParameters = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel13);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard15 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel13);
        compilerOptions0.checkFunctions = checkLevel13;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule5.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] { jSModule5, jSModule9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11);
        com.google.javascript.jscomp.JSModule jSModule15 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] { jSModule15, jSModule17, jSModule19 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph21 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray20);
        com.google.javascript.jscomp.JSModule jSModule23 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule26 = jSModuleGraph21.getDeepestCommonDependencyInclusive(jSModule23, jSModule25);
        java.util.List<java.lang.String> strList27 = jSModule25.getProvides();
        com.google.javascript.jscomp.JSModule jSModule29 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        boolean boolean30 = jSModuleGraph3.dependsOn(jSModule25, jSModule29);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        com.google.javascript.jscomp.Region region36 = compilerInput34.getRegion((int) (short) 100);
        java.lang.String str37 = compilerInput34.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput34, ": ", false);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput40, "hi!", false);
        jSModule29.remove(compilerInput43);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(jSModule13);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertNull(jSModule26);
        org.junit.Assert.assertNotNull(strList27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNull(region36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        java.lang.String str12 = nodeTraversal11.getSourceName();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        node6.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node6.setJSType(jSType10);
        java.lang.String str15 = node6.toString(true, false, true);
        java.lang.String str16 = node6.toStringTree();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(12, node6, node20, 131, (int) (short) -1);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node20);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = scriptOrFnNode29.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean34 = node33.isVarArgs();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("EOL");
        node40.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node44 = node40.getLastChild();
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode29, node33, node38, node40);
        com.google.javascript.rhino.Node node46 = scriptOrFnNode29.cloneNode();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        node48.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        node48.setJSType(jSType52);
        node48.setCharno(11);
        boolean boolean56 = node48.hasOneChild();
        node48.setCharno(4);
        java.lang.String str59 = googleCodingConvention0.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode29, node48);
        com.google.javascript.rhino.Node node60 = scriptOrFnNode29.detachFromParent();
        java.util.Set<java.lang.String> strSet61 = node60.getDirectives();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING EOL" + "'", str15.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING EOL\n" + "'", str16.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(strSet61);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        boolean boolean29 = functionType26.isEmptyType();
        boolean boolean31 = functionType26.isPropertyInExterns("goog.exportSymbol");
        boolean boolean32 = functionType26.hasCachedValues();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("div");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(div)" + "'", str1.equals("(div)"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean[] booleanArray7 = scriptOrFnNode5.getParamAndVarConst();
        java.lang.Object obj8 = scriptOrFnNode5.getCompilerData();
        boolean[] booleanArray9 = scriptOrFnNode5.getParamAndVarConst();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(booleanArray9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.optimizeParameters = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
//        com.google.javascript.rhino.jstype.JSType jSType9 = null;
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
//        boolean boolean12 = jSType11.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
//        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
//        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
//        int int25 = scriptOrFnNode22.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder27 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
//        com.google.javascript.rhino.jstype.JSType jSType37 = null;
//        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.getGreatestSubtypeWithProperty(jSType37, "");
//        boolean boolean40 = jSType39.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType41 = jSType39.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
//        com.google.javascript.rhino.jstype.JSType jSType44 = objectType41.resolve(errorReporter42, jSTypeStaticScope43);
//        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode50 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean51 = node46.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode50);
//        boolean[] booleanArray52 = scriptOrFnNode50.getParamAndVarConst();
//        int int53 = scriptOrFnNode50.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry30.createFunctionType(jSType44, (com.google.javascript.rhino.Node) scriptOrFnNode50);
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = null;
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder56 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry55);
//        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode62 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean63 = node58.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode62);
//        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("EOL");
//        node65.putBooleanProp((int) '4', false);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        node65.setJSType(jSType69);
//        node65.setCharno(11);
//        boolean boolean73 = node58.checkTreeTypeAwareEqualsSilent(node65);
//        com.google.javascript.rhino.Node node74 = functionParamBuilder56.newParameterFromNode(node65);
//        com.google.javascript.rhino.jstype.JSType jSType75 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType75 };
//        boolean boolean77 = functionParamBuilder56.addRequiredParams(jSTypeArray76);
//        try {
//            com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry2.createFunctionType(jSType44, jSTypeArray76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSType5);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(objectType13);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(booleanArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertNotNull(jSType33);
//        org.junit.Assert.assertNotNull(jSType39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(objectType41);
//        org.junit.Assert.assertNotNull(jSType44);
//        org.junit.Assert.assertNotNull(node46);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(booleanArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(functionType54);
//        org.junit.Assert.assertNotNull(node58);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(node65);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//        org.junit.Assert.assertNotNull(node74);
//        org.junit.Assert.assertNotNull(jSTypeArray76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = functionType26.getImplicitPrototype();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable31 = functionType26.getImplementedInterfaces();
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType32 = functionType26.getInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeIterable31);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray4 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType1, diagnosticType2, diagnosticType3 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray4);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean[] booleanArray14 = scriptOrFnNode12.getParamAndVarConst();
        java.lang.String[] strArray15 = scriptOrFnNode12.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray15);
        boolean boolean17 = diagnosticGroup5.matches(jSError16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = jSError16.getType();
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.level;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticTypeArray4);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        com.google.javascript.jscomp.Compiler compiler13 = nodeTraversal11.getCompiler();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(compiler13);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.inlineFunctions = true;
        com.google.javascript.jscomp.SourceMap.Format format6 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setSummaryDetailLevel((int) (byte) -1);
        java.lang.String str9 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(format6);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        int int29 = functionType26.getMaxArguments();
        boolean boolean30 = functionType26.isEnumElementType();
        boolean boolean31 = functionType26.isUnknownType();
        com.google.javascript.rhino.Node node32 = functionType26.getSource();
        com.google.javascript.rhino.jstype.FunctionType functionType33 = functionType26.getConstructor();
        boolean boolean34 = functionType26.isNativeObjectType();
        boolean boolean35 = functionType26.isDateType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        java.lang.String str8 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.optimizeReturns = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSType jSType21 = enumType20.unboxesTo();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = enumType20.getOwnPropertyJSDocInfo("div");
        boolean boolean24 = enumType20.matchesStringContext();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = scriptOrFnNode4.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode4.setSourceName("EOL");
        int int10 = scriptOrFnNode4.addVar("STRING EOL");
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(129, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean18 = node13.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node13.addChildAfter(node20, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean37 = node32.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode36);
        boolean boolean39 = scriptOrFnNode36.hasParamOrVar("");
        scriptOrFnNode29.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode36);
        scriptOrFnNode36.addParam("Unknown class name");
        scriptOrFnNode36.setLineno(0);
        com.google.javascript.rhino.Node node45 = scriptOrFnNode4.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode36);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable46 = node45.children();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeIterable46);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.hasOwnProperty("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry31.getGreatestSubtypeWithProperty(jSType32, "");
        boolean boolean35 = jSType34.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType34.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope38 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = objectType36.resolve(errorReporter37, jSTypeStaticScope38);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry25.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope41 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry25.getForgivingType(jSTypeStaticScope41, "window", "lsh", 0, 105);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, false);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry50.getGreatestSubtypeWithProperty(jSType51, "");
        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54, false);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType jSType59 = jSTypeRegistry56.getGreatestSubtypeWithProperty(jSType57, "");
        boolean boolean60 = jSType59.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSType59.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType61.resolve(errorReporter62, jSTypeStaticScope63);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode70 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean71 = node66.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode70);
        boolean[] booleanArray72 = scriptOrFnNode70.getParamAndVarConst();
        int int73 = scriptOrFnNode70.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry50.createFunctionType(jSType64, (com.google.javascript.rhino.Node) scriptOrFnNode70);
        java.lang.String str75 = functionType74.getReferenceName();
        boolean boolean76 = functionType74.hasReferenceName();
        boolean boolean77 = functionType74.isEmptyType();
        boolean boolean78 = functionType74.isNumber();
        com.google.javascript.rhino.jstype.EnumType enumType79 = jSTypeRegistry25.createEnumType("Not declared as a constructor", (com.google.javascript.rhino.jstype.JSType) functionType74);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue80 = enumType20.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType74);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(booleanArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(enumType79);
        org.junit.Assert.assertNotNull(ternaryValue80);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable5 = jSTypeRegistry2.getTypesWithProperty("");
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.getType("");
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        jSTypeRegistry10.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        boolean boolean18 = jSType17.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSType17.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope21 = null;
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType19.resolve(errorReporter20, jSTypeStaticScope21);
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry10.createDefaultObjectUnion(jSType22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.OFF;
        boolean boolean25 = jSType23.equals((java.lang.Object) checkLevel24);
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry2.createOptionalType(jSType23);
        org.junit.Assert.assertNotNull(jSTypeIterable5);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(jSType26);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.generateExports = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "JSDocInfo", 4095, 118);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        int int3 = jSModule1.getDepth();
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = jSModule1.getInputs();
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(compilerInputList4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearSideEffectFlags();
        boolean boolean2 = sideEffectFlags0.areAllFlagsSet();
        int int3 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setAllFlags();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.recordMeaning("EOL");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility5 = com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE;
        boolean boolean6 = jSDocInfoBuilder1.recordVisibility(visibility5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + visibility5 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE + "'", visibility5.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = compilerOptions0.messageBundle;
        compilerOptions0.coalesceVariableNames = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention13 = compilerOptions10.getCodingConvention();
        byte[] byteArray15 = new byte[] { (byte) 10 };
        compilerOptions10.inputVariableMapSerialized = byteArray15;
        compilerOptions0.inputPropertyMapSerialized = byteArray15;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(messageBundle7);
        org.junit.Assert.assertNull(codingConvention13);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder3 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean4 = jSDocInfoBuilder3.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = null;
        boolean boolean7 = jSDocInfoBuilder3.recordThrowDescription(jSTypeExpression5, "hi!");
        boolean boolean8 = jSDocInfoBuilder3.recordInterface();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean15 = node10.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode14);
        boolean boolean17 = scriptOrFnNode14.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression19 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode14, ": ");
        boolean boolean20 = jSTypeExpression19.isOptionalArg();
        boolean boolean21 = jSDocInfoBuilder3.recordDefineType(jSTypeExpression19);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression22 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression19);
        boolean boolean24 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression22, "Not declared as a constructor");
        boolean boolean25 = jSDocInfoBuilder1.isDescriptionRecorded();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = defaultCodingConvention0.isPrivate("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSType jSType21 = enumType20.unboxesTo();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = enumType20.getOwnPropertyJSDocInfo("div");
        java.lang.String str24 = enumType20.getDisplayName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at " + "'", str24.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearSideEffectFlags();
        boolean boolean2 = sideEffectFlags0.areAllFlagsSet();
        int int3 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setThrows();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        boolean boolean5 = googleCodingConvention0.isPrivate("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.recordImplicitCast();
        boolean boolean6 = jSDocInfoBuilder1.recordDeprecated();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        boolean boolean10 = jSDocInfoBuilder1.addReference("function (): function (this:me, {1819233191}): me");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        com.google.javascript.rhino.Node node88 = functionType85.getSource();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNull(node88);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 0);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder6 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder6.recordParameter("STRING EOL", jSTypeExpression8);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder11 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean12 = jSDocInfoBuilder11.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression13 = null;
        boolean boolean14 = jSDocInfoBuilder11.recordType(jSTypeExpression13);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression15 = null;
        boolean boolean16 = jSDocInfoBuilder11.recordThisType(jSTypeExpression15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean boolean26 = scriptOrFnNode23.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression28 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode23, ": ");
        boolean boolean29 = jSDocInfoBuilder11.recordParameter("<No stack trace available>", jSTypeExpression28);
        boolean boolean30 = jSDocInfoBuilder6.recordThisType(jSTypeExpression28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) 0);
        java.lang.String[] strArray39 = new java.lang.String[] { "<No stack trace available>", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "<No stack trace available>", "window", "", "STRING EOL\n" };
        java.util.LinkedHashSet<java.lang.String> strSet40 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet40, strArray39);
        node32.setDirectives((java.util.Set<java.lang.String>) strSet40);
        boolean boolean43 = jSDocInfoBuilder6.recordSuppressions((java.util.Set<java.lang.String>) strSet40);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet40);
        boolean boolean45 = jSDocInfoBuilder1.recordSuppressions((java.util.Set<java.lang.String>) strSet40);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType21, "com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNotNull(jSType23);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = functionType26.isNativeObjectType();
        com.google.javascript.rhino.Node node28 = functionType26.getParametersNode();
        boolean boolean29 = functionType26.isReturnTypeInferred();
        boolean boolean30 = functionType26.matchesObjectContext();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        byte[] byteArray5 = new byte[] { (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray5;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.instrumentForCoverageOnly = true;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean21 = enumType20.hasCachedValues();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test176");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 13);
//        java.lang.String str4 = context1.getImplementationVersion();
//        int int5 = context1.getLanguageVersion();
//        try {
//            context1.setCompileFunctionsWithDynamicScope(true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        compilerOptions0.setLooseTypes(true);
        boolean boolean8 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType57.matchesObjectContext();
        boolean boolean90 = functionType57.isPropertyInExterns("STRING EOL");
        java.lang.String str91 = functionType57.getDisplayName();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(str91);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.instrumentForCoverage;
        com.google.javascript.jscomp.SourceAst sourceAst7 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "", true);
        com.google.javascript.jscomp.JSModule jSModule11 = compilerInput10.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = null;
        java.util.logging.Logger logger13 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager14 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter12, logger13);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = loggerErrorManager14.getErrors();
        int int16 = loggerErrorManager14.getErrorCount();
        compilerInput10.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager14);
        int int18 = loggerErrorManager14.getWarningCount();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        jSTypeRegistry21.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        boolean boolean29 = jSType28.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = objectType30.resolve(errorReporter31, jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry21.createDefaultObjectUnion(jSType33);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.OFF;
        boolean boolean36 = jSType34.equals((java.lang.Object) checkLevel35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean47 = node42.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode46);
        boolean[] booleanArray48 = scriptOrFnNode46.getParamAndVarConst();
        java.lang.String[] strArray49 = scriptOrFnNode46.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean57 = node52.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode56);
        boolean[] booleanArray58 = scriptOrFnNode56.getParamAndVarConst();
        java.lang.String[] strArray59 = scriptOrFnNode56.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray59);
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode67 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean68 = node63.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode67);
        boolean[] booleanArray69 = scriptOrFnNode67.getParamAndVarConst();
        java.lang.String[] strArray70 = scriptOrFnNode67.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType40, strArray70);
        loggerErrorManager14.report(checkLevel35, jSError72);
        compilerOptions0.checkUnreachableCode = checkLevel35;
        boolean boolean75 = compilerOptions0.exportTestFunctions;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean78 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule11);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(booleanArray69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.withReturnType(jSType4);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = functionBuilder1.forConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.getGreatestSubtypeWithProperty(jSType10, "");
        boolean boolean13 = jSType12.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType14 = jSType12.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = objectType14.resolve(errorReporter15, jSTypeStaticScope16);
        com.google.javascript.rhino.jstype.ObjectType objectType18 = objectType14.toObjectType();
        boolean boolean19 = objectType14.isInstanceType();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder20 = functionBuilder6.withReturnType((com.google.javascript.rhino.jstype.JSType) objectType14);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder22 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean29 = node24.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("EOL");
        node31.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        node31.setJSType(jSType35);
        node31.setCharno(11);
        boolean boolean39 = node24.checkTreeTypeAwareEqualsSilent(node31);
        com.google.javascript.rhino.Node node40 = functionParamBuilder22.newParameterFromNode(node31);
        boolean boolean41 = functionParamBuilder22.hasVarArgs();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder42 = functionBuilder6.withParams(functionParamBuilder22);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder6);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objectType14);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionBuilder20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionBuilder42);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap30 = compilerOptions0.customPasses;
        boolean boolean31 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceAst sourceAst10 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst10, "", true);
        com.google.javascript.jscomp.JSModule jSModule14 = compilerInput13.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = null;
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter15, logger16);
        compilerInput13.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        com.google.javascript.jscomp.Scope scope20 = compiler19.getTopScope();
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler19, true);
        com.google.javascript.jscomp.SourceAst sourceAst23 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(sourceAst23, "", true);
        com.google.javascript.jscomp.JSModule jSModule27 = compilerInput26.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter28 = null;
        java.util.logging.Logger logger29 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager30 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter28, logger29);
        compilerInput26.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager30);
        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager30);
        com.google.javascript.jscomp.NodeTraversal.Callback callback33 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal34 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler32, callback33);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt35 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter36 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler32, sourceExcerpt35);
        compiler32.reportCodeChange();
        com.google.javascript.jscomp.MessageFormatter messageFormatter39 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler32, false);
        com.google.javascript.jscomp.SourceMap sourceMap40 = compiler32.getSourceMap();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler32);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNull(jSModule14);
        org.junit.Assert.assertNull(scope20);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNull(jSModule27);
        org.junit.Assert.assertNotNull(messageFormatter39);
        org.junit.Assert.assertNull(sourceMap40);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility4 = jSDocInfo0.getVisibility();
        java.lang.String str5 = jSDocInfo0.getTemplateTypeName();
        boolean boolean6 = jSDocInfo0.hasReturnType();
        int int7 = jSDocInfo0.getImplementedInterfaceCount();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = jSDocInfo0.getTypedefType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertNull(visibility4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(jSTypeExpression8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule3, jSModule5 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        try {
            java.lang.String str13 = jSModule9.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertNull(jSModule12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = null;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.inlineFunctions = false;
        java.lang.String str5 = compilerOptions0.nameReferenceGraphPath;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.checkShadowVars = checkLevel6;
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup3;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str2 = jSSourceFile1.getName();
        java.lang.String str3 = jSSourceFile1.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, true);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, false);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Not declared as a constructor" + "'", str2.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Not declared as a constructor" + "'", str3.equals("Not declared as a constructor"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = marker0.annotation;
        com.google.javascript.rhino.JSDocInfo.Marker marker2 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition3 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition3.setItem("<No stack trace available>");
        marker2.annotation = stringPosition3;
        marker0.annotation = stringPosition3;
        stringPosition3.setItem("EOL");
        org.junit.Assert.assertNull(stringPosition1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getParameterNames();
        boolean boolean4 = jSDocInfo0.shouldPreserveTry();
        boolean boolean5 = jSDocInfo0.hasFileOverview();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOL");
        node3.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node3.setJSType(jSType7);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean11 = defaultCodingConvention9.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean18 = node13.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode17);
        java.lang.String str19 = defaultCodingConvention9.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("EOL");
        node28.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        node28.setJSType(jSType32);
        node28.setCharno(11);
        boolean boolean36 = node21.checkTreeTypeAwareEqualsSilent(node28);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean43 = node38.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode42);
        boolean[] booleanArray44 = scriptOrFnNode42.getParamAndVarConst();
        int int45 = scriptOrFnNode42.getSideEffectFlags();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((-1), node3, (com.google.javascript.rhino.Node) scriptOrFnNode17, node28, (com.google.javascript.rhino.Node) scriptOrFnNode42);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder48 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean49 = jSDocInfoBuilder48.recordDeprecated();
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression51 = jSDocInfo50.getEnumParameterType();
        java.util.Set<java.lang.String> strSet52 = jSDocInfo50.getSuppressions();
        boolean boolean53 = jSDocInfoBuilder48.recordModifies(strSet52);
        node28.setDirectives(strSet52);
        compilerOptions0.stripTypes = strSet52;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(jSTypeExpression51);
        org.junit.Assert.assertNotNull(strSet52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray4 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType1, diagnosticType2, diagnosticType3 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray4);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean[] booleanArray14 = scriptOrFnNode12.getParamAndVarConst();
        java.lang.String[] strArray15 = scriptOrFnNode12.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray15);
        boolean boolean17 = diagnosticGroup5.matches(jSError16);
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup5;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticTypeArray4);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        boolean boolean12 = nodeTraversal11.hasScope();
        int int13 = nodeTraversal11.getLineNumber();
        com.google.javascript.rhino.Node node14 = nodeTraversal11.getCurrentNode();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        boolean boolean30 = compilerOptions0.tightenTypes;
        boolean boolean31 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str3.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.getGreatestSubtypeWithProperty(jSType61, "");
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        boolean boolean70 = jSType69.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSType69.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = objectType71.resolve(errorReporter72, jSTypeStaticScope73);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean81 = node76.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode80);
        boolean[] booleanArray82 = scriptOrFnNode80.getParamAndVarConst();
        int int83 = scriptOrFnNode80.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry60.createFunctionType(jSType74, (com.google.javascript.rhino.Node) scriptOrFnNode80);
        java.lang.String str85 = functionType84.getReferenceName();
        boolean boolean86 = functionType84.hasReferenceName();
        boolean boolean87 = functionType84.isEmptyType();
        boolean boolean88 = functionType56.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType84);
        int int89 = functionType84.getMinArguments();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(booleanArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }
}

