import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        java.lang.String str7 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "", 38, 120);
        boolean boolean13 = defaultCodingConvention0.isExported("dot");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        compiler9.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str17 = jSSourceFile16.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile16 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
        try {
            compiler9.init(jSSourceFileArray18, jSModuleArray19, compilerOptions20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Not declared as a constructor" + "'", str17.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSSourceFileArray18);
        org.junit.Assert.assertNotNull(jSModuleArray19);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int int0 = com.google.javascript.rhino.Token.FUNCTION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 105 + "'", int0 == 105);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        try {
            compiler9.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean[] booleanArray11 = scriptOrFnNode9.getParamAndVarConst();
        java.lang.String[] strArray12 = scriptOrFnNode9.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean[] booleanArray21 = scriptOrFnNode19.getParamAndVarConst();
        java.lang.String[] strArray22 = scriptOrFnNode19.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        boolean[] booleanArray32 = scriptOrFnNode30.getParamAndVarConst();
        java.lang.String[] strArray33 = scriptOrFnNode30.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray33);
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType3, strArray33);
        java.lang.String str36 = jSError35.toString();
        com.google.javascript.jscomp.SourceAst sourceAst37 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(sourceAst37, "", true);
        com.google.javascript.jscomp.JSModule jSModule41 = compilerInput40.getModule();
        boolean boolean42 = jSError35.equals((java.lang.Object) jSModule41);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7" + "'", str36.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7"));
        org.junit.Assert.assertNull(jSModule41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.isAllType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_URSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 92 + "'", int0 == 92);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection3 = jSDocInfo0.getMarkers();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(markerCollection3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        try {
            compiler13.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        node2.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node2.setJSType(jSType6);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean10 = defaultCodingConvention8.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean17 = node12.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode16);
        java.lang.String str18 = defaultCodingConvention8.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        node27.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node27.setJSType(jSType31);
        node27.setCharno(11);
        boolean boolean35 = node20.checkTreeTypeAwareEqualsSilent(node27);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode41 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean42 = node37.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode41);
        boolean[] booleanArray43 = scriptOrFnNode41.getParamAndVarConst();
        int int44 = scriptOrFnNode41.getSideEffectFlags();
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((-1), node2, (com.google.javascript.rhino.Node) scriptOrFnNode16, node27, (com.google.javascript.rhino.Node) scriptOrFnNode41);
        com.google.javascript.rhino.FunctionNode functionNode46 = null;
        try {
            int int47 = scriptOrFnNode16.addFunction(functionNode46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        boolean boolean12 = nodeTraversal11.hasScope();
        java.lang.String str13 = nodeTraversal11.getSourceName();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int0 = com.google.javascript.rhino.Token.IFEQ;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        com.google.javascript.jscomp.JSError[] jSErrorArray13 = loggerErrorManager9.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray14 = loggerErrorManager9.getWarnings();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray13);
        org.junit.Assert.assertNotNull(jSErrorArray14);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = node4.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode8);
        java.lang.String str10 = defaultCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode8);
        boolean boolean12 = defaultCodingConvention0.isConstant(": ");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean15 = node14.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node14.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean22 = scriptOrFnNode20.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node23 = node14.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode20);
        java.lang.String str24 = defaultCodingConvention0.getSingletonGetterClassName(node14);
        com.google.javascript.rhino.Node node25 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship26 = defaultCodingConvention0.getClassesDefinedByCall(node25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(subclassRelationship26);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.getColumnNumber();
        java.lang.String str4 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        java.lang.String str6 = ecmaError2.getSourceName();
        int int7 = ecmaError2.lineNumber();
        java.lang.String str8 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        java.lang.String str2 = defaultCodingConvention0.identifyTypeDefAssign(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node6);
        java.lang.String str9 = node6.getString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = null;
        java.lang.String str12 = defaultCodingConvention10.identifyTypeDefAssign(node11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node16.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = defaultCodingConvention10.getClassesDefinedByCall(node16);
        java.lang.String str19 = node16.getString();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean33 = node28.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode32);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node21.addChildAfter(node28, (com.google.javascript.rhino.Node) scriptOrFnNode37);
        try {
            node6.replaceChild(node16, node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "EOL" + "'", str9.equals("EOL"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EOL" + "'", str19.equals("EOL"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        int int10 = loggerErrorManager7.getErrorCount();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordType(jSTypeExpression3);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThisType(jSTypeExpression5);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression7 = null;
        boolean boolean8 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean16 = node11.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode15);
        boolean boolean18 = scriptOrFnNode15.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression20 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode15, ": ");
        boolean boolean21 = jSDocInfoBuilder1.recordParameter(": ", jSTypeExpression20);
        boolean boolean22 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder24 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean25 = jSDocInfoBuilder24.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression26 = null;
        boolean boolean27 = jSDocInfoBuilder24.recordType(jSTypeExpression26);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression28 = null;
        boolean boolean29 = jSDocInfoBuilder24.recordThisType(jSTypeExpression28);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression30 = null;
        boolean boolean31 = jSDocInfoBuilder24.recordBaseType(jSTypeExpression30);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode38 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean39 = node34.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode38);
        boolean boolean41 = scriptOrFnNode38.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression43 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode38, ": ");
        boolean boolean44 = jSDocInfoBuilder24.recordParameter(": ", jSTypeExpression43);
        boolean boolean45 = jSDocInfoBuilder1.recordType(jSTypeExpression43);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput18 = compiler13.getInput("EOL");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int0 = com.google.javascript.rhino.Token.ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int0 = com.google.javascript.rhino.Token.URSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(64);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a constructor", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        try {
            com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("dot", "STRING EOL\n", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.JSModule[] jSModuleArray21 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = null;
        try {
            com.google.javascript.jscomp.Result result23 = compiler13.compile(jSSourceFile19, jSModuleArray21, compilerOptions22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray21);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean15 = scriptOrFnNode12.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode12, ": ");
        boolean boolean18 = jSDocInfoBuilder1.recordParameter("Unknown class name", jSTypeExpression17);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder20 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean21 = jSDocInfoBuilder20.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression22 = null;
        boolean boolean23 = jSDocInfoBuilder20.recordType(jSTypeExpression22);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression24 = null;
        boolean boolean25 = jSDocInfoBuilder20.recordThisType(jSTypeExpression24);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression26 = null;
        boolean boolean27 = jSDocInfoBuilder20.recordBaseType(jSTypeExpression26);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode34);
        boolean boolean37 = scriptOrFnNode34.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression39 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode34, ": ");
        boolean boolean40 = jSDocInfoBuilder20.recordParameter(": ", jSTypeExpression39);
        boolean boolean42 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression39, "");
        boolean boolean44 = jSDocInfoBuilder1.recordBlockDescription("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        lightweightMessageFormatter13.setColorize(true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18);
        com.google.javascript.jscomp.SourceAst sourceAst20 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(sourceAst20, "", true);
        com.google.javascript.jscomp.JSModule jSModule24 = compilerInput23.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter25 = null;
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter25, logger26);
        compilerInput23.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        compilerInput19.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
        java.lang.String str31 = compiler29.getAstDotGraph();
        compiler29.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean40 = node35.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode39);
        boolean[] booleanArray41 = scriptOrFnNode39.getParamAndVarConst();
        java.lang.String[] strArray42 = scriptOrFnNode39.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray42);
        compiler29.report(jSError43);
        try {
            java.lang.String str45 = lightweightMessageFormatter13.formatWarning(jSError43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(jSModule24);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str3 = jSDocInfo0.getDescriptionForParameter("Not declared as a constructor");
        java.lang.String str4 = jSDocInfo0.toString();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSDocInfo" + "'", str4.equals("JSDocInfo"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean27 = scriptOrFnNode24.hasParamOrVar("");
        scriptOrFnNode17.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode24);
        scriptOrFnNode24.addParam("Unknown class name");
        scriptOrFnNode24.setLineno(0);
        com.google.javascript.rhino.Context context33 = null;
        com.google.javascript.rhino.Context context34 = com.google.javascript.rhino.Context.enter(context33);
        try {
            scriptOrFnNode24.setCompilerData((java.lang.Object) context33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(context34);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Scope scope10 = compiler9.getTopScope();
        int int11 = compiler9.getWarningCount();
        int int12 = compiler9.getWarningCount();
        try {
            java.lang.String[] strArray13 = compiler9.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(scope10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            java.lang.String str5 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("STRING EOL\n", "dot", "window");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property STRING EOL\n");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative27);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.UnionType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int0 = com.google.javascript.rhino.Token.NOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        ecmaError2.initColumnNumber(114);
        java.lang.String str6 = ecmaError2.getScriptStackTrace();
        ecmaError2.initLineSource("STRING EOL\n");
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, (long) (short) 1);
        try {
            context1.unseal((java.lang.Object) 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.addAuthor("STRING EOL\n");
        boolean boolean9 = jSDocInfoBuilder1.hasParameter("STRING EOL");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder11 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean12 = jSDocInfoBuilder11.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression13 = null;
        boolean boolean14 = jSDocInfoBuilder11.recordType(jSTypeExpression13);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression15 = null;
        boolean boolean16 = jSDocInfoBuilder11.recordThisType(jSTypeExpression15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean boolean26 = scriptOrFnNode23.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression28 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode23, ": ");
        boolean boolean29 = jSDocInfoBuilder11.recordParameter("<No stack trace available>", jSTypeExpression28);
        boolean boolean30 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression28);
        boolean boolean32 = jSDocInfoBuilder1.addReference("EOL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a constructor");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        try {
            compiler13.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = marker0.annotation;
        com.google.javascript.rhino.JSDocInfo.Marker marker2 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition3 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition3.setItem("<No stack trace available>");
        marker2.annotation = stringPosition3;
        marker0.annotation = stringPosition3;
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition8 = marker0.description;
        org.junit.Assert.assertNull(stringPosition1);
        org.junit.Assert.assertNull(stringPosition8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean15 = scriptOrFnNode12.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode12, ": ");
        boolean boolean18 = jSDocInfoBuilder1.recordParameter("Unknown class name", jSTypeExpression17);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder20 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean21 = jSDocInfoBuilder20.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression22 = null;
        boolean boolean23 = jSDocInfoBuilder20.recordType(jSTypeExpression22);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression24 = null;
        boolean boolean25 = jSDocInfoBuilder20.recordThisType(jSTypeExpression24);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression26 = null;
        boolean boolean27 = jSDocInfoBuilder20.recordBaseType(jSTypeExpression26);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode34);
        boolean boolean37 = scriptOrFnNode34.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression39 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode34, ": ");
        boolean boolean40 = jSDocInfoBuilder20.recordParameter(": ", jSTypeExpression39);
        boolean boolean42 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression39, "");
        boolean boolean43 = jSTypeExpression39.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        java.lang.String str7 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship12 = defaultCodingConvention0.getClassesDefinedByCall(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean19 = node14.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode18);
        boolean[] booleanArray20 = scriptOrFnNode18.getParamAndVarConst();
        int int21 = scriptOrFnNode18.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = scriptOrFnNode18.getParent();
        try {
            boolean boolean23 = defaultCodingConvention0.isVarArgsParameter(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(subclassRelationship12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(node22);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray1);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray7 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType3, diagnosticType4, diagnosticType5, diagnosticType6 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray7);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean16 = node11.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode15);
//        boolean[] booleanArray17 = scriptOrFnNode15.getParamAndVarConst();
//        java.lang.String[] strArray18 = scriptOrFnNode15.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray18);
//        boolean boolean20 = diagnosticGroup8.matches(jSError19);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup22;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray25 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup2, diagnosticGroup8, diagnosticGroup21, diagnosticGroup22, diagnosticGroup24 };
//        try {
//            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray1);
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertNotNull(diagnosticType4);
//        org.junit.Assert.assertNotNull(diagnosticType5);
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray7);
//        org.junit.Assert.assertNotNull(diagnosticType9);
//        org.junit.Assert.assertNotNull(node11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(booleanArray17);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertNotNull(jSError19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(diagnosticGroup21);
//        org.junit.Assert.assertNotNull(diagnosticGroup22);
//        org.junit.Assert.assertNotNull(diagnosticGroup24);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray25);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean5 = diagnosticGroup0.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDescription();
        boolean boolean5 = jSDocInfo0.hasThisType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.isConstructorRecorded();
        boolean boolean7 = jSDocInfoBuilder1.recordLends(": ");
        boolean boolean8 = jSDocInfoBuilder1.recordExport();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("STRING EOL", "hi!", 61, "window", 31);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = evaluatorException5.getScriptStackTrace(filenameFilter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry2.createNamedType("hi!", "EOL", 151, 105);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordType(jSTypeExpression3);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThisType(jSTypeExpression5);
        boolean boolean8 = jSDocInfoBuilder1.recordLends("window");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean3 = jSDocInfoBuilder1.recordBlockDescription(": ");
        boolean boolean5 = jSDocInfoBuilder1.recordFileOverview("<No stack trace available>");
        boolean boolean6 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        compiler9.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str17 = jSSourceFile16.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "dot");
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = null;
        try {
            com.google.javascript.jscomp.Result result22 = compiler9.compile(jSSourceFile16, jSSourceFile20, compilerOptions21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Not declared as a constructor" + "'", str17.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSSourceFile20);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal.EdgeCallback<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable> ancestorIterableEdgeCallback0 = null;
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable> ancestorIterableFixedPointGraphTraversal1 = new com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable>(ancestorIterableEdgeCallback0);
        com.google.javascript.jscomp.graph.DiGraph<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable> ancestorIterableDiGraph2 = null;
        try {
            ancestorIterableFixedPointGraphTraversal1.computeFixedPoint(ancestorIterableDiGraph2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        int int12 = compiler9.getErrorCount();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt13 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter14 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt13);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention15 = compiler9.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int0 = com.google.javascript.rhino.Token.RETURN_RESULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 62 + "'", int0 == 62);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean15 = defaultCodingConvention13.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean22 = node17.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.lang.String str23 = defaultCodingConvention13.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean boolean25 = defaultCodingConvention13.isConstant(": ");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean28 = node27.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node27.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = scriptOrFnNode33.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node36 = node27.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode33);
        java.lang.String str37 = defaultCodingConvention13.getSingletonGetterClassName(node27);
        com.google.javascript.rhino.jstype.JSType jSType38 = node27.getJSType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError45 = nodeTraversal11.makeError(node27, diagnosticType39, strArray44);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention46 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode59 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean60 = node55.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode59);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode64 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node48.addChildAfter(node55, (com.google.javascript.rhino.Node) scriptOrFnNode64);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship66 = defaultCodingConvention46.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode64);
        java.lang.Object obj67 = null;
        java.lang.RuntimeException runtimeException68 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) node27, (java.lang.Object) delegateRelationship66, obj67);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(delegateRelationship66);
        org.junit.Assert.assertNotNull(runtimeException68);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str3 = jSDocInfo0.getDescriptionForParameter("Not declared as a constructor");
        boolean boolean4 = jSDocInfo0.isConstant();
        java.lang.String str5 = jSDocInfo0.getDescription();
        boolean boolean6 = jSDocInfo0.isInterface();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean7 = jSDocInfoBuilder1.recordParameterDescription("EOL", ": ");
        jSDocInfoBuilder1.markText("Not declared as a constructor", 109, 60, 123, 100);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder15 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean16 = jSDocInfoBuilder15.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = null;
        boolean boolean18 = jSDocInfoBuilder15.recordType(jSTypeExpression17);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression19 = null;
        boolean boolean20 = jSDocInfoBuilder15.recordThisType(jSTypeExpression19);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        boolean boolean30 = scriptOrFnNode27.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression32 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode27, ": ");
        boolean boolean33 = jSDocInfoBuilder15.recordParameter("<No stack trace available>", jSTypeExpression32);
        boolean boolean34 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression32);
        boolean boolean35 = jSTypeExpression32.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry3.getGreatestSubtypeWithProperty(jSType4, "");
        boolean boolean7 = jSType6.matchesNumberContext();
        boolean boolean8 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType6);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean15 = defaultCodingConvention13.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean22 = node17.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.lang.String str23 = defaultCodingConvention13.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean boolean25 = defaultCodingConvention13.isConstant(": ");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean28 = node27.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node27.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = scriptOrFnNode33.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node36 = node27.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode33);
        java.lang.String str37 = defaultCodingConvention13.getSingletonGetterClassName(node27);
        com.google.javascript.rhino.jstype.JSType jSType38 = node27.getJSType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError45 = nodeTraversal11.makeError(node27, diagnosticType39, strArray44);
        java.util.List<com.google.javascript.rhino.Node> nodeList46 = null;
        try {
            nodeTraversal11.traverseRoots(nodeList46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.withReturnType(jSType4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder8 = functionBuilder1.withReturnType(jSType6, true);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder10 = functionBuilder1.withName("STRING EOL\n");
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder8);
        org.junit.Assert.assertNotNull(functionBuilder10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING EOL");
        int int6 = scriptOrFnNode3.getLineno();
        com.google.javascript.rhino.Node node7 = scriptOrFnNode3.getParent();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 109 + "'", int6 == 109);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList6);
        try {
            com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph1.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.SourceAst sourceAst1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceAst1, "", true);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = null;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter6, logger7);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel12, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean22 = node17.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean[] booleanArray23 = scriptOrFnNode21.getParamAndVarConst();
        java.lang.String[] strArray24 = scriptOrFnNode21.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray24);
        loggerErrorManager8.report(checkLevel12, jSError25);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.make("EOL", checkLevel12, "");
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(diagnosticType28);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(109, 92, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        int int6 = ecmaError2.getLineNumber();
        java.lang.String str7 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ": " + "'", str7.equals(": "));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        com.google.javascript.jscomp.PassConfig passConfig14 = null;
        try {
            compiler9.setPassConfig(passConfig14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "", 22);
        int int5 = tokenStream4.getTokenno();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean8 = node3.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("EOL");
        node10.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node10.setJSType(jSType14);
        node10.setCharno(11);
        boolean boolean18 = node3.checkTreeTypeAwareEqualsSilent(node10);
        com.google.javascript.rhino.Node node19 = functionParamBuilder1.newParameterFromNode(node10);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] { jSType20 };
        boolean boolean22 = functionParamBuilder1.addRequiredParams(jSTypeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        boolean boolean29 = jSType28.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        boolean boolean31 = objectType30.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSTypeRegistry34.getNativeObjectType(jSTypeNative35);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43, false);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry45.getGreatestSubtypeWithProperty(jSType46, "");
        boolean boolean49 = jSType48.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType50 = jSType48.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        com.google.javascript.rhino.jstype.JSType jSType53 = objectType50.resolve(errorReporter51, jSTypeStaticScope52);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode59 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean60 = node55.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode59);
        boolean[] booleanArray61 = scriptOrFnNode59.getParamAndVarConst();
        int int62 = scriptOrFnNode59.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry39.createFunctionType(jSType53, (com.google.javascript.rhino.Node) scriptOrFnNode59);
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        boolean boolean70 = jSType69.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSType69.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = objectType71.resolve(errorReporter72, jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.ObjectType objectType75 = objectType71.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { objectType30, objectType36, jSType53, objectType71 };
        try {
            boolean boolean77 = functionParamBuilder1.addOptionalParams(jSTypeArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(booleanArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(functionType63);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        jSDocInfoBuilder1.markName("dot", 100, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int0 = com.google.javascript.rhino.Token.NULL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_BITAND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 89 + "'", int0 == 89);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int0 = com.google.javascript.rhino.Token.RC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 82 + "'", int0 == 82);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType30.isRecordType();
        boolean boolean89 = functionType30.isResolved();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean5 = diagnosticGroup0.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = null;
        boolean boolean8 = diagnosticGroup6.matches(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean11 = diagnosticGroup6.matches(diagnosticType10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = null;
        boolean boolean16 = diagnosticGroup14.matches(diagnosticType15);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean19 = diagnosticGroup14.matches(diagnosticType18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray22 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType4, diagnosticType10, diagnosticType12, diagnosticType18, diagnosticType20, diagnosticType21 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray22);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(diagnosticTypeArray22);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        try {
            java.lang.String str16 = compiler9.getSourceLine("STRING EOL\n", (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int0 = com.google.javascript.rhino.Token.GE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray13 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput3 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList14 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList14, compilerInputArray13);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies16 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList14);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.Region region22 = compilerInput20.getRegion((int) (short) 100);
        java.lang.String str23 = compilerInput20.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter24 = null;
        java.util.logging.Logger logger25 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager26 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter24, logger25);
        com.google.javascript.jscomp.JSError[] jSErrorArray27 = loggerErrorManager26.getErrors();
        int int28 = loggerErrorManager26.getErrorCount();
        compilerInput20.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager26);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray30 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput20 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList31 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList31, compilerInputArray30);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies33 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList31);
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList34 = compilerInputSortedDependencies16.getSortedDependenciesOf((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(compilerInputArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(region22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(compilerInputArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition1.setItem("<No stack trace available>");
        marker0.annotation = stringPosition1;
        java.lang.String str5 = stringPosition1.getItem();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter12 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9);
        try {
            compiler9.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile4 = null;
        try {
            jsAst3.setSourceFile(sourceFile4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        try {
            context1.setLanguageVersion(97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("window", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str2 = jSDocInfo0.getBlockDescription();
        boolean boolean3 = jSDocInfo0.shouldPreserveTry();
        java.util.Set<java.lang.String> strSet4 = jSDocInfo0.getSuppressions();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            com.google.javascript.rhino.Context.reportWarning("Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        node6.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node6.setJSType(jSType10);
        java.lang.String str15 = node6.toString(true, false, true);
        java.lang.String str16 = node6.toStringTree();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(12, node6, node20, 131, (int) (short) -1);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        boolean boolean33 = scriptOrFnNode30.hasParamOrVar("");
        int int34 = scriptOrFnNode30.getChildCount();
        try {
            boolean boolean35 = googleCodingConvention0.isPropertyTestFunction((com.google.javascript.rhino.Node) scriptOrFnNode30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING EOL" + "'", str15.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING EOL\n" + "'", str16.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        try {
//            com.google.javascript.rhino.Context.reportError("", "", 60, "", 28);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (#60)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.JSDocInfo jSDocInfo1 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = jSDocInfo1.getEnumParameterType();
        boolean boolean3 = jSDocInfo1.isNoAlias();
        boolean boolean5 = jSDocInfo1.hasParameterType("window");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        node8.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node8.setJSType(jSType12);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention14 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean16 = defaultCodingConvention14.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str24 = defaultCodingConvention14.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode22);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("EOL");
        node33.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        node33.setJSType(jSType37);
        node33.setCharno(11);
        boolean boolean41 = node26.checkTreeTypeAwareEqualsSilent(node33);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean48 = node43.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode47);
        boolean[] booleanArray49 = scriptOrFnNode47.getParamAndVarConst();
        int int50 = scriptOrFnNode47.getSideEffectFlags();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((-1), node8, (com.google.javascript.rhino.Node) scriptOrFnNode22, node33, (com.google.javascript.rhino.Node) scriptOrFnNode47);
        try {
            java.lang.String str52 = com.google.javascript.rhino.ScriptRuntime.getMessage2("Not declared as a constructor", (java.lang.Object) "window", (java.lang.Object) node51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a constructor");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(jSTypeExpression2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean14 = node9.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode13);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node2.addChildAfter(node9, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship20 = defaultCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode18);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention21 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean24 = googleCodingConvention21.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        node27.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node27.setJSType(jSType31);
        java.lang.String str36 = node27.toString(true, false, true);
        java.lang.String str37 = node27.toStringTree();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(12, node27, node41, 131, (int) (short) -1);
        boolean boolean45 = googleCodingConvention21.isOptionalParameter(node41);
        boolean boolean46 = defaultCodingConvention0.isPropertyTestFunction(node41);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING EOL" + "'", str36.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "STRING EOL\n" + "'", str37.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        boolean boolean4 = jSDocInfo0.hasParameterType("window");
        java.lang.String str5 = jSDocInfo0.getTemplateTypeName();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList6 = jSDocInfo0.getImplementedInterfaces();
        int int7 = jSDocInfo0.getParameterCount();
        boolean boolean8 = jSDocInfo0.isExterns();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(jSTypeExpressionList6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        boolean boolean4 = jSTypeRegistry2.isForwardDeclaredType("goog.exportProperty");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean16 = node11.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode15);
        boolean[] booleanArray17 = scriptOrFnNode15.getParamAndVarConst();
        int int18 = scriptOrFnNode15.getSideEffectFlags();
        com.google.javascript.rhino.Node node19 = scriptOrFnNode15.getFirstChild();
        scriptOrFnNode15.setBaseLineno(60);
        int int22 = scriptOrFnNode15.getEncodedSourceEnd();
        java.lang.String str23 = scriptOrFnNode9.checkTreeEquals((com.google.javascript.rhino.Node) scriptOrFnNode15);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry2.createInterfaceType("Not declared as a constructor", (com.google.javascript.rhino.Node) scriptOrFnNode9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.withReturnType(jSType4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder8 = functionBuilder1.withReturnType(jSType6, true);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder9 = functionBuilder8.forConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.jstype.ObjectType objectType21 = objectType17.toObjectType();
        boolean boolean23 = objectType17.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder25 = functionBuilder9.withReturnType((com.google.javascript.rhino.jstype.JSType) objectType17, false);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder8);
        org.junit.Assert.assertNotNull(functionBuilder9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionBuilder25);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("EOL", "Unknown class name", 43, "<No stack trace available>", 304);
        try {
            evaluatorException5.initColumnNumber(133);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 120, 64, 35);
        int int5 = node3.getIntProp(150);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(18);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "lsh" + "'", str1.equals("lsh"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getWarnings();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput18 = compiler13.getInput("STRING EOL\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.Token token0 = new com.google.javascript.rhino.Token();
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "STRING EOL\n", 120);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = null;
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        boolean boolean4 = jSTypeRegistry2.isForwardDeclaredType("goog.exportProperty");
        jSTypeRegistry2.setTemplateTypeName("");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Result result15 = compiler13.getResult();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getErrors();
        com.google.javascript.jscomp.JSModule jSModule17 = null;
        try {
            java.lang.String str18 = compiler13.toSource(jSModule17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(24);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "div" + "'", str1.equals("div"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = functionType26.getImplicitPrototype();
        boolean boolean31 = objectType30.isConstructor();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        boolean boolean29 = functionType26.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        jSTypeRegistry2.resetForTypeCheck();
//        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
//        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
//        com.google.javascript.rhino.jstype.JSType jSType11 = null;
//        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
//        boolean boolean14 = jSType13.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
//        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
//        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
//        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
//        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry2.createNamedType("@IMPLEMENTATION.VERSION@", "goog.exportProperty", 0, 31);
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
//        com.google.javascript.rhino.jstype.JSType jSType29 = null;
//        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry28.getGreatestSubtypeWithProperty(jSType29, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
//        com.google.javascript.rhino.jstype.JSType jSType35 = null;
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry34.getGreatestSubtypeWithProperty(jSType35, "");
//        boolean boolean38 = jSType37.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope41 = null;
//        com.google.javascript.rhino.jstype.JSType jSType42 = objectType39.resolve(errorReporter40, jSTypeStaticScope41);
//        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode48 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean49 = node44.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode48);
//        boolean[] booleanArray50 = scriptOrFnNode48.getParamAndVarConst();
//        int int51 = scriptOrFnNode48.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry28.createFunctionType(jSType42, (com.google.javascript.rhino.Node) scriptOrFnNode48);
//        java.lang.String str53 = functionType52.getReferenceName();
//        boolean boolean54 = functionType52.hasReferenceName();
//        java.util.Set<java.lang.String> strSet55 = functionType52.getOwnPropertyNames();
//        com.google.javascript.rhino.jstype.ObjectType objectType56 = functionType52.getImplicitPrototype();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = null;
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder58 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry57);
//        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode64 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean65 = node60.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode64);
//        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("EOL");
//        node67.putBooleanProp((int) '4', false);
//        com.google.javascript.rhino.jstype.JSType jSType71 = null;
//        node67.setJSType(jSType71);
//        node67.setCharno(11);
//        boolean boolean75 = node60.checkTreeTypeAwareEqualsSilent(node67);
//        com.google.javascript.rhino.Node node76 = functionParamBuilder58.newParameterFromNode(node67);
//        com.google.javascript.rhino.jstype.JSType jSType77 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray78 = new com.google.javascript.rhino.jstype.JSType[] { jSType77 };
//        boolean boolean79 = functionParamBuilder58.addRequiredParams(jSTypeArray78);
//        try {
//            com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry2.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType52, jSTypeArray78);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(jSType13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(objectType15);
//        org.junit.Assert.assertNotNull(jSType18);
//        org.junit.Assert.assertNotNull(objectType19);
//        org.junit.Assert.assertNotNull(enumType20);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertNotNull(jSType31);
//        org.junit.Assert.assertNotNull(jSType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(objectType39);
//        org.junit.Assert.assertNotNull(jSType42);
//        org.junit.Assert.assertNotNull(node44);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(booleanArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(functionType52);
//        org.junit.Assert.assertNull(str53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(strSet55);
//        org.junit.Assert.assertNotNull(objectType56);
//        org.junit.Assert.assertNotNull(node60);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(node67);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertNotNull(node76);
//        org.junit.Assert.assertNotNull(jSTypeArray78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal.EdgeCallback<java.lang.reflect.GenericDeclaration, com.google.javascript.jscomp.SourceExcerptProvider> genericDeclarationEdgeCallback0 = null;
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal<java.lang.reflect.GenericDeclaration, com.google.javascript.jscomp.SourceExcerptProvider> genericDeclarationFixedPointGraphTraversal1 = new com.google.javascript.jscomp.graph.FixedPointGraphTraversal<java.lang.reflect.GenericDeclaration, com.google.javascript.jscomp.SourceExcerptProvider>(genericDeclarationEdgeCallback0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int0 = com.google.javascript.rhino.Token.GETVAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        int int7 = scriptOrFnNode5.getRegexpCount();
        java.lang.String str8 = scriptOrFnNode5.getSourceName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        int int19 = scriptOrFnNode17.getRegexpCount();
        java.lang.String[] strArray20 = scriptOrFnNode17.getParamAndVarNames();
        boolean boolean21 = scriptOrFnNode17.isLocalResultCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        java.lang.String[] strArray4 = scriptOrFnNode3.getParamAndVarNames();
        int int5 = scriptOrFnNode3.getParamCount();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int0 = com.google.javascript.rhino.Token.ANNOTATION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 300 + "'", int0 == 300);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDescription();
        jSDocInfo0.setLicense("JSDocInfo");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility7 = jSDocInfo0.getVisibility();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(visibility7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        com.google.javascript.jscomp.CodingConvention codingConvention17 = compiler13.getCodingConvention();
        try {
            compiler13.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(codingConvention17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        boolean[] booleanArray8 = scriptOrFnNode6.getParamAndVarConst();
        java.lang.String[] strArray9 = scriptOrFnNode6.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean17 = node12.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode16);
        boolean[] booleanArray18 = scriptOrFnNode16.getParamAndVarConst();
        java.lang.String[] strArray19 = scriptOrFnNode16.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray19);
        java.lang.String str21 = jSError20.toString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        boolean boolean30 = scriptOrFnNode27.hasParamOrVar("");
        com.google.javascript.rhino.Node node31 = scriptOrFnNode27.getLastSibling();
        boolean boolean32 = jSError20.equals((java.lang.Object) scriptOrFnNode27);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str21.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        try {
//            com.google.javascript.rhino.Context.reportError("goog.exportProperty");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportProperty");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("EOL", "lsh", "STRING EOL", "Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property EOL");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode1 = new com.google.javascript.rhino.ScriptOrFnNode(17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("");
        org.junit.Assert.assertNull(jSType3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        jSTypeRegistry8.resetForTypeCheck();
        boolean boolean11 = jSTypeRegistry8.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder12 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry8);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry16.getGreatestSubtypeWithProperty(jSType17, "");
        boolean boolean20 = jSType19.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSType19.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
        com.google.javascript.rhino.jstype.JSType jSType24 = objectType21.resolve(errorReporter22, jSTypeStaticScope23);
        com.google.javascript.rhino.jstype.ObjectType objectType25 = objectType21.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType26 = jSTypeRegistry8.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType25);
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry8.createNamedType("@IMPLEMENTATION.VERSION@", "goog.exportProperty", 0, 31);
        try {
            jSTypeRegistry2.overwriteDeclaredType("error reporter", jSType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertNotNull(enumType26);
        org.junit.Assert.assertNotNull(jSType31);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        boolean boolean16 = compiler13.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("STRING EOL\n", generator18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str22 = jSSourceFile21.getName();
        java.lang.String str23 = jSSourceFile21.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str26 = jSSourceFile25.getName();
        java.lang.String str27 = jSSourceFile25.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile21, jSSourceFile25, jSSourceFile30 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList34 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList34, jSSourceFileArray33);
        com.google.javascript.jscomp.JSModule[] jSModuleArray36 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList37 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList37, jSModuleArray36);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph39 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList37);
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = null;
        try {
            com.google.javascript.jscomp.Result result41 = compiler13.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList34, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList37, compilerOptions40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Not declared as a constructor" + "'", str22.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Not declared as a constructor" + "'", str23.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Not declared as a constructor" + "'", str26.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Not declared as a constructor" + "'", str27.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(jSModuleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig1 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordConstancy();
        jSDocInfoBuilder1.markName("", 109, 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int0 = com.google.javascript.rhino.Token.SET_REF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 66 + "'", int0 == 66);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        try {
            compiler9.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = marker0.name;
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition2 = null;
        marker0.type = typePosition2;
        org.junit.Assert.assertNull(stringPosition1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        boolean boolean34 = jSType33.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSType33.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType35.resolve(errorReporter36, jSTypeStaticScope37);
        com.google.javascript.rhino.jstype.ObjectType objectType39 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType35);
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType39.getParameterType();
        com.google.javascript.rhino.jstype.JSType jSType41 = functionType26.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType39);
        boolean boolean42 = objectType39.isEnumType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean3 = jSDocInfoBuilder1.recordBlockDescription(": ");
        boolean boolean5 = jSDocInfoBuilder1.recordFileOverview("<No stack trace available>");
        boolean boolean6 = jSDocInfoBuilder1.isInterfaceRecorded();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder8 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean9 = jSDocInfoBuilder8.recordJavaDispatch();
        boolean boolean11 = jSDocInfoBuilder8.addReference("hi!");
        boolean boolean14 = jSDocInfoBuilder8.recordParameterDescription("EOL", ": ");
        jSDocInfoBuilder8.markText("Not declared as a constructor", 109, 60, 123, 100);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder22 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean23 = jSDocInfoBuilder22.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression24 = null;
        boolean boolean25 = jSDocInfoBuilder22.recordType(jSTypeExpression24);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression26 = null;
        boolean boolean27 = jSDocInfoBuilder22.recordThisType(jSTypeExpression26);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode34);
        boolean boolean37 = scriptOrFnNode34.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression39 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode34, ": ");
        boolean boolean40 = jSDocInfoBuilder22.recordParameter("<No stack trace available>", jSTypeExpression39);
        boolean boolean41 = jSDocInfoBuilder8.recordBaseType(jSTypeExpression39);
        boolean boolean43 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression39, "dot");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder45 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean46 = jSDocInfoBuilder45.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression47 = null;
        boolean boolean48 = jSDocInfoBuilder45.recordType(jSTypeExpression47);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression49 = null;
        boolean boolean50 = jSDocInfoBuilder45.recordThisType(jSTypeExpression49);
        boolean boolean51 = jSDocInfoBuilder45.isPopulated();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder53 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean54 = jSDocInfoBuilder53.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression55 = null;
        boolean boolean56 = jSDocInfoBuilder53.recordType(jSTypeExpression55);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression57 = null;
        boolean boolean58 = jSDocInfoBuilder53.recordThisType(jSTypeExpression57);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode65 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean66 = node61.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode65);
        boolean boolean68 = scriptOrFnNode65.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression70 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode65, ": ");
        boolean boolean71 = jSDocInfoBuilder53.recordParameter("<No stack trace available>", jSTypeExpression70);
        boolean boolean72 = jSDocInfoBuilder45.recordTypedef(jSTypeExpression70);
        boolean boolean73 = jSTypeExpression70.isVarArgs();
        boolean boolean74 = jSDocInfoBuilder1.recordImplementedInterface(jSTypeExpression70);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        context1.removeThreadLocal((java.lang.Object) 56);
//        java.util.Locale locale5 = null;
//        java.util.Locale locale6 = context1.setLocale(locale5);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(locale6);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        java.util.Map<java.lang.String, com.google.javascript.rhino.jstype.JSType> strMap21 = null;
        try {
            com.google.javascript.rhino.jstype.RecordType recordType22 = jSTypeRegistry2.createRecordType(strMap21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str2 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(jSTypeExpression3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        boolean boolean10 = jSType9.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSType9.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = objectType11.resolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry2.createDefaultObjectUnion(jSType14);
        jSTypeRegistry2.clearTemplateTypeName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder18 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        node27.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node27.setJSType(jSType31);
        node27.setCharno(11);
        boolean boolean35 = node20.checkTreeTypeAwareEqualsSilent(node27);
        com.google.javascript.rhino.Node node36 = functionParamBuilder18.newParameterFromNode(node27);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] { jSType37 };
        boolean boolean39 = functionParamBuilder18.addRequiredParams(jSTypeArray38);
        try {
            com.google.javascript.rhino.Node node40 = jSTypeRegistry2.createOptionalParameters(jSTypeArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder2.setIsConstructor(false);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder2.forConstructor();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = functionBuilder5.withName("goog.exportProperty");
        java.lang.Object obj8 = null;
        com.google.javascript.jscomp.SourceAst sourceAst9 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceAst9, "", true);
        com.google.javascript.jscomp.JSModule jSModule13 = compilerInput12.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = null;
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter14, logger15);
        compilerInput12.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback19);
        boolean boolean21 = nodeTraversal20.hasScope();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode34);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node23.addChildAfter(node30, (com.google.javascript.rhino.Node) scriptOrFnNode39);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder41 = node30.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node42 = node30.cloneNode();
        try {
            java.lang.String str43 = com.google.javascript.rhino.ScriptRuntime.getMessage4("", (java.lang.Object) "goog.exportProperty", obj8, (java.lang.Object) nodeTraversal20, (java.lang.Object) node30);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder7);
        org.junit.Assert.assertNull(jSModule13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder41);
        org.junit.Assert.assertNotNull(node42);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        java.lang.String str2 = defaultCodingConvention0.identifyTypeDefAssign(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = node4.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode8);
        java.util.List<java.lang.String> strList10 = defaultCodingConvention0.identifyTypeDeclarationCall(node4);
        boolean boolean12 = defaultCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(strList10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Result result15 = compiler13.getResult();
        boolean boolean16 = compiler13.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = null;
        try {
            com.google.javascript.jscomp.Result result20 = compiler13.compile(jSSourceFileArray17, jSModuleArray18, compilerOptions19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertNotNull(jSModuleArray18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isNoShadow();
        boolean boolean2 = jSDocInfo0.isDeprecated();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int0 = com.google.javascript.rhino.Token.EQ;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        try {
//            com.google.javascript.rhino.Context.reportError(": ");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: : ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("STRING EOL", jSTypeExpression3);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder6 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean7 = jSDocInfoBuilder6.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder6.recordType(jSTypeExpression8);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder6.recordThisType(jSTypeExpression10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean19 = node14.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode18);
        boolean boolean21 = scriptOrFnNode18.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode18, ": ");
        boolean boolean24 = jSDocInfoBuilder6.recordParameter("<No stack trace available>", jSTypeExpression23);
        boolean boolean25 = jSDocInfoBuilder1.recordThisType(jSTypeExpression23);
        boolean boolean27 = jSDocInfoBuilder1.recordBlockDescription("div");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int0 = com.google.javascript.rhino.Token.LABEL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 126 + "'", int0 == 126);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("Unknown class name", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        node2.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node2.setJSType(jSType6);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean10 = defaultCodingConvention8.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean17 = node12.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode16);
        java.lang.String str18 = defaultCodingConvention8.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        node27.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node27.setJSType(jSType31);
        node27.setCharno(11);
        boolean boolean35 = node20.checkTreeTypeAwareEqualsSilent(node27);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode41 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean42 = node37.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode41);
        boolean[] booleanArray43 = scriptOrFnNode41.getParamAndVarConst();
        int int44 = scriptOrFnNode41.getSideEffectFlags();
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((-1), node2, (com.google.javascript.rhino.Node) scriptOrFnNode16, node27, (com.google.javascript.rhino.Node) scriptOrFnNode41);
        try {
            com.google.javascript.rhino.Node node46 = com.google.javascript.jscomp.NodeUtil.newExpr(node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = node4.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode8);
        java.lang.String str10 = defaultCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode8);
        boolean boolean12 = defaultCodingConvention0.isConstant(": ");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean15 = node14.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node14.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean22 = scriptOrFnNode20.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node23 = node14.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode20);
        java.lang.String str24 = defaultCodingConvention0.getSingletonGetterClassName(node14);
        com.google.javascript.rhino.jstype.JSType jSType25 = node14.getJSType();
        java.util.Set<java.lang.String> strSet26 = node14.getDirectives();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNull(strSet26);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        boolean boolean10 = jSType9.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSType9.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = objectType11.resolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry2.createDefaultObjectUnion(jSType14);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry18.getGreatestSubtypeWithProperty(jSType19, "");
        boolean boolean22 = jSType21.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSType21.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope25 = null;
        com.google.javascript.rhino.jstype.JSType jSType26 = objectType23.resolve(errorReporter24, jSTypeStaticScope25);
        com.google.javascript.rhino.jstype.ObjectType objectType27 = objectType23.toObjectType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = jSType14.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) objectType23);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry31.getGreatestSubtypeWithProperty(jSType32, "");
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry37.getGreatestSubtypeWithProperty(jSType38, "");
        boolean boolean41 = jSType40.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = jSType40.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        com.google.javascript.rhino.jstype.JSType jSType45 = objectType42.resolve(errorReporter43, jSTypeStaticScope44);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode51 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean52 = node47.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode51);
        boolean[] booleanArray53 = scriptOrFnNode51.getParamAndVarConst();
        int int54 = scriptOrFnNode51.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry31.createFunctionType(jSType45, (com.google.javascript.rhino.Node) scriptOrFnNode51);
        java.lang.String str56 = functionType55.getReferenceName();
        boolean boolean57 = functionType55.hasReferenceName();
        boolean boolean58 = functionType55.isEmptyType();
        boolean boolean59 = functionType55.isEnumType();
        boolean boolean60 = objectType23.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType55);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(objectType42);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean[] booleanArray11 = scriptOrFnNode9.getParamAndVarConst();
        java.lang.String[] strArray12 = scriptOrFnNode9.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        java.lang.String str15 = jSError13.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean[] booleanArray26 = scriptOrFnNode24.getParamAndVarConst();
        java.lang.String[] strArray27 = scriptOrFnNode24.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType18, strArray27);
        try {
            com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 151, 48, checkLevel16, diagnosticType17, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str15.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            com.google.javascript.rhino.Context.reportWarning("JSDocInfo", "", 97, "lsh", 88);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean5 = diagnosticGroup0.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = null;
        boolean boolean8 = diagnosticGroup6.matches(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean11 = diagnosticGroup6.matches(diagnosticType10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = null;
        boolean boolean16 = diagnosticGroup14.matches(diagnosticType15);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean19 = diagnosticGroup14.matches(diagnosticType18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray22 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType4, diagnosticType10, diagnosticType12, diagnosticType18, diagnosticType20, diagnosticType21 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray22);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup23;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean32 = node27.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode31);
        boolean[] booleanArray33 = scriptOrFnNode31.getParamAndVarConst();
        java.lang.String[] strArray34 = scriptOrFnNode31.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(diagnosticType25, strArray34);
        com.google.javascript.jscomp.CheckLevel checkLevel36 = jSError35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = jSError35.level;
        boolean boolean38 = diagnosticGroup23.matches(jSError35);
        java.lang.Class<?> wildcardClass39 = jSError35.getClass();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(diagnosticTypeArray22);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean boolean8 = scriptOrFnNode5.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, ": ");
        boolean boolean11 = jSTypeExpression10.isOptionalArg();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str15 = ecmaError14.getScriptStackTrace();
        boolean boolean16 = jSTypeExpression10.equals((java.lang.Object) str15);
        boolean boolean17 = jSTypeExpression10.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "<No stack trace available>" + "'", str15.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        int int6 = ecmaError2.getLineNumber();
        int int7 = ecmaError2.getColumnNumber();
        java.lang.String str8 = ecmaError2.details();
        java.lang.String str9 = ecmaError2.sourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ": " + "'", str8.equals(": "));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSDocInfo", true);
        com.google.javascript.jscomp.SourceFile sourceFile18 = compilerInput3.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(sourceFile18);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        boolean boolean29 = functionType26.isEmptyType();
        boolean boolean30 = functionType26.isInstanceType();
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        try {
            boolean boolean32 = functionType26.differsFrom(jSType31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isNoShadow();
        java.lang.String str2 = jSDocInfo0.getTemplateTypeName();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(jSTypeExpression3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate30 = null;
        try {
            boolean boolean31 = functionType26.setValidator(jSTypePredicate30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str2 = jSDocInfo0.getBlockDescription();
        boolean boolean3 = jSDocInfo0.shouldPreserveTry();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getBaseType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSTypeExpression4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        int int7 = scriptOrFnNode5.getRegexpCount();
        int int8 = scriptOrFnNode5.getParamCount();
        int int9 = scriptOrFnNode5.getParamCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int0 = com.google.javascript.rhino.Token.LC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 81 + "'", int0 == 81);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule5.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] { jSModule5, jSModule9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11);
        com.google.javascript.jscomp.JSModule[] jSModuleArray14 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray14);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(jSModule13);
        org.junit.Assert.assertNotNull(jSModuleArray14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, ": ", false);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput9, "hi!", false);
        java.lang.String str13 = compilerInput9.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal.EdgeCallback<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable> ancestorIterableEdgeCallback1 = null;
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable> ancestorIterableFixedPointGraphTraversal2 = new com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.rhino.Node.AncestorIterable, java.lang.Throwable>(ancestorIterableEdgeCallback1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean6 = googleCodingConvention3.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("EOL");
        node9.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node9.setJSType(jSType13);
        java.lang.String str18 = node9.toString(true, false, true);
        java.lang.String str19 = node9.toStringTree();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(12, node9, node23, 131, (int) (short) -1);
        boolean boolean27 = googleCodingConvention3.isOptionalParameter(node23);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags28 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags28.clearSideEffectFlags();
        boolean boolean30 = sideEffectFlags28.areAllFlagsSet();
        sideEffectFlags28.setMutatesThis();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder33 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean34 = jSDocInfoBuilder33.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet35 = null;
        boolean boolean36 = jSDocInfoBuilder33.recordModifies(strSet35);
        boolean boolean37 = jSDocInfoBuilder33.isPopulatedWithFileOverview();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode44 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean45 = node40.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode44);
        boolean boolean47 = scriptOrFnNode44.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression49 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode44, ": ");
        boolean boolean50 = jSDocInfoBuilder33.recordParameter("Unknown class name", jSTypeExpression49);
        try {
            java.lang.String str51 = com.google.javascript.rhino.ScriptRuntime.getMessage4("@IMPLEMENTATION.VERSION@", (java.lang.Object) ancestorIterableEdgeCallback1, (java.lang.Object) googleCodingConvention3, (java.lang.Object) sideEffectFlags28, (java.lang.Object) "Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property @IMPLEMENTATION.VERSION@");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING EOL" + "'", str18.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING EOL\n" + "'", str19.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Scope scope10 = compiler9.getTopScope();
        int int11 = compiler9.getWarningCount();
        int int12 = compiler9.getWarningCount();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState13 = compiler9.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = null;
        try {
            com.google.javascript.rhino.Node node15 = compiler9.parse(jSSourceFile14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(scope10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intermediateState13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getWarnings();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt17 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, sourceExcerpt17);
        lightweightMessageFormatter18.setColorize(false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope7 = null;
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope7, "STRING EOL", "Not declared as a constructor", 122, 107);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType12);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType57.matchesObjectContext();
        boolean boolean89 = functionType57.canBeCalled();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceAst sourceAst1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceAst1, "", true);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = null;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter6, logger7);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Scope scope11 = compiler10.getTopScope();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt14 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter15 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, sourceExcerpt14);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNull(scope11);
        org.junit.Assert.assertNotNull(messageFormatter13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        node1.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node1.setJSType(jSType5);
        node1.setCharno(11);
        node1.putIntProp(2, 4095);
        node1.setType(4);
        boolean boolean14 = node1.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        int int13 = nodeTraversal11.getLineNumber();
        boolean boolean14 = nodeTraversal11.hasScope();
        int int15 = nodeTraversal11.getLineNumber();
        com.google.javascript.rhino.Node node16 = nodeTraversal11.getCurrentNode();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(node16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Scope scope10 = compiler9.getTopScope();
        int int11 = compiler9.getWarningCount();
        int int12 = compiler9.getWarningCount();
        com.google.javascript.jscomp.Scope scope13 = compiler9.getTopScope();
        try {
            compiler9.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(scope10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(scope13);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean32 = node27.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode31);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node20.addChildAfter(node27, (com.google.javascript.rhino.Node) scriptOrFnNode36);
        java.lang.String str38 = node20.toString();
        node8.addChildrenToFront(node20);
        try {
            double double40 = node8.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING EOL is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "STRING EOL" + "'", str38.equals("STRING EOL"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule5.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] { jSModule5, jSModule9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11);
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(jSModule13);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.recordImplicitCast();
        boolean boolean6 = jSDocInfoBuilder1.recordDeprecated();
        boolean boolean8 = jSDocInfoBuilder1.recordDescription("div");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeThreadLocal((java.lang.Object) 56);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context1.addPropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING EOL");
        java.lang.String str6 = scriptOrFnNode3.getSourceName();
        scriptOrFnNode3.setIsSyntheticBlock(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node8.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node20 = node8.cloneNode();
        boolean boolean21 = node8.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.addAuthor("STRING EOL\n");
        boolean boolean9 = jSDocInfoBuilder1.hasParameter("STRING EOL");
        jSDocInfoBuilder1.markName("hi!", (int) '#', 91);
        boolean boolean15 = jSDocInfoBuilder1.recordFileOverview("STRING EOL\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean[] booleanArray7 = scriptOrFnNode5.getParamAndVarConst();
        java.lang.String[] strArray8 = scriptOrFnNode5.getParamAndVarNames();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = scriptOrFnNode5.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder9.append("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        boolean boolean34 = jSType33.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSType33.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType35.resolve(errorReporter36, jSTypeStaticScope37);
        com.google.javascript.rhino.jstype.ObjectType objectType39 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType35);
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType39.getParameterType();
        com.google.javascript.rhino.jstype.JSType jSType41 = functionType26.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType39);
        boolean boolean42 = functionType26.isNullType();
        boolean boolean43 = functionType26.isInstanceType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceAst sourceAst1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceAst1, "", true);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = null;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter6, logger7);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Scope scope11 = compiler10.getTopScope();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        com.google.javascript.jscomp.SourceAst sourceAst14 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(sourceAst14, "", true);
        com.google.javascript.jscomp.JSModule jSModule18 = compilerInput17.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = null;
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter19, logger20);
        compilerInput17.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler23, callback24);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt26 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter27 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler23, sourceExcerpt26);
        compiler23.reportCodeChange();
        com.google.javascript.jscomp.MessageFormatter messageFormatter30 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler23, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray31 = compiler23.getMessages();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNull(scope11);
        org.junit.Assert.assertNotNull(messageFormatter13);
        org.junit.Assert.assertNull(jSModule18);
        org.junit.Assert.assertNotNull(messageFormatter30);
        org.junit.Assert.assertNotNull(jSErrorArray31);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING EOL");
        scriptOrFnNode3.setBaseLineno(27);
        com.google.javascript.rhino.Node node8 = scriptOrFnNode3.getLastSibling();
        java.lang.Appendable appendable9 = null;
        try {
            node8.appendStringTree(appendable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(19, "dot");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean boolean12 = scriptOrFnNode9.hasParamOrVar("");
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast13 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal3, (com.google.javascript.rhino.Node) scriptOrFnNode9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean boolean22 = scriptOrFnNode19.hasParamOrVar("");
        boolean boolean23 = scriptOrFnNode9.hasChild((com.google.javascript.rhino.Node) scriptOrFnNode19);
        int int24 = scriptOrFnNode9.getEncodedSourceStart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(objectLiteralCast13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean boolean8 = scriptOrFnNode5.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, ": ");
        boolean boolean11 = jSTypeExpression10.isVarArgs();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression12 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression10);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getParameterNames();
        boolean boolean4 = jSDocInfo0.containsDeclaration();
        java.lang.String str5 = jSDocInfo0.getLendsName();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode1 = new com.google.javascript.rhino.ScriptOrFnNode(1);
        int int3 = scriptOrFnNode1.getParamOrVarIndex("");
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable4 = scriptOrFnNode1.getAncestors();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(ancestorIterable4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeThreadLocal((java.lang.Object) 56);
        context1.removeActivationName("error reporter");
        boolean boolean7 = context1.isGeneratingSource();
        java.lang.String str8 = context1.getImplementationVersion();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str8.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordType(jSTypeExpression3);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThisType(jSTypeExpression5);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression7 = null;
        boolean boolean8 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean16 = node11.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode15);
        boolean boolean18 = scriptOrFnNode15.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression20 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode15, ": ");
        boolean boolean21 = jSDocInfoBuilder1.recordParameter(": ", jSTypeExpression20);
        boolean boolean22 = jSDocInfoBuilder1.isConstructorRecorded();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("STRING EOL");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean14 = node9.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode13);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node2.addChildAfter(node9, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship20 = defaultCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode18);
        scriptOrFnNode18.setOptionalArg(false);
        java.lang.String str23 = scriptOrFnNode18.getSourceName();
        try {
            java.lang.String str25 = scriptOrFnNode18.getParamOrVarName(300);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: 300 ∉ [0, 0)");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship20);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getLendsName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        com.google.javascript.jscomp.JSError[] jSErrorArray13 = loggerErrorManager9.getErrors();
        int int14 = loggerErrorManager9.getErrorCount();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("EOL");
        node9.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node9.setJSType(jSType13);
        node9.setCharno(11);
        boolean boolean17 = node2.checkTreeTypeAwareEqualsSilent(node9);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(118, node9, 110, 40);
        boolean boolean21 = node20.isOptionalArg();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        boolean boolean3 = jSDocInfo0.hasBaseType();
        java.lang.String str4 = jSDocInfo0.getSourceName();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 101");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = scriptOrFnNode4.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean9 = node8.isVarArgs();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        node15.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node19 = node15.getLastChild();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode4, node8, node13, node15);
        java.lang.String str21 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) node20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "INSTANCEOF" + "'", str21.equals("INSTANCEOF"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = objectType7.resolve(errorReporter8, jSTypeStaticScope9);
        com.google.javascript.rhino.jstype.ObjectType objectType11 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType7);
        boolean boolean12 = objectType7.matchesInt32Context();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = objectType7.getOwnPropertyJSDocInfo("dot");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(jSDocInfo14);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean boolean12 = scriptOrFnNode9.hasParamOrVar("");
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast13 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal3, (com.google.javascript.rhino.Node) scriptOrFnNode9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean boolean22 = scriptOrFnNode19.hasParamOrVar("");
        boolean boolean23 = scriptOrFnNode9.hasChild((com.google.javascript.rhino.Node) scriptOrFnNode19);
        scriptOrFnNode9.removeParamOrVar("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(objectLiteralCast13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int0 = com.google.javascript.rhino.Token.RETHROW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("goog.exportProperty", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder2 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean3 = jSDocInfoBuilder2.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet4 = null;
        boolean boolean5 = jSDocInfoBuilder2.recordModifies(strSet4);
        boolean boolean6 = jSDocInfoBuilder2.isPopulated();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean14 = scriptOrFnNode12.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean17 = node16.isVarArgs();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        node23.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node27 = node23.getLastChild();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode12, node16, node21, node23);
        boolean boolean29 = node21.hasChildren();
        try {
            java.lang.String str30 = com.google.javascript.rhino.ScriptRuntime.getMessage3("Unknown class name", (java.lang.Object) boolean6, (java.lang.Object) 30, (java.lang.Object) node21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Unknown class name");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        java.lang.String str2 = defaultCodingConvention0.identifyTypeDefAssign(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node6);
        node6.setCharno(23);
        boolean boolean11 = node6.hasChildren();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        try {
            node3.setSideEffectFlags(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str2 = jSSourceFile1.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, true);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Not declared as a constructor" + "'", str2.equals("Not declared as a constructor"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode1 = new com.google.javascript.rhino.ScriptOrFnNode((int) '#');
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeThreadLocal((java.lang.Object) 56);
        context1.removeActivationName("error reporter");
        boolean boolean7 = context1.isGeneratingSource();
        context1.addActivationName("Unknown class name");
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule3, jSModule5 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        com.google.javascript.jscomp.SourceAst sourceAst13 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(sourceAst13, "", true);
        com.google.javascript.jscomp.JSModule jSModule17 = compilerInput16.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = null;
        java.util.logging.Logger logger19 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager20 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter18, logger19);
        compilerInput16.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager20);
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager20);
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler22, callback23);
        try {
            jSModule12.sortInputsByDeps(compiler22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertNull(jSModule17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 112, 137, 122);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        boolean boolean29 = functionType26.isEmptyType();
        boolean boolean30 = functionType26.isInstanceType();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList31 = functionType26.getSubTypes();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType32 = functionType26.getSuperClassConstructor();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(functionTypeList31);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        int int13 = nodeTraversal11.getLineNumber();
        boolean boolean14 = nodeTraversal11.hasScope();
        com.google.javascript.rhino.Node node15 = nodeTraversal11.getCurrentNode();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int int0 = com.google.javascript.rhino.Token.SETELEM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean[] booleanArray7 = scriptOrFnNode5.getParamAndVarConst();
        int int8 = scriptOrFnNode5.getSideEffectFlags();
        int int9 = scriptOrFnNode5.getRegexpCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(14, 0, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        int int6 = ecmaError2.getLineNumber();
        com.google.javascript.rhino.EcmaError ecmaError9 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str10 = ecmaError9.getScriptStackTrace();
        java.lang.String str11 = ecmaError9.details();
        java.lang.String str12 = ecmaError9.getScriptStackTrace();
        int int13 = ecmaError9.getLineNumber();
        ecmaError2.addSuppressed((java.lang.Throwable) ecmaError9);
        ecmaError2.initColumnNumber(5);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(ecmaError9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "<No stack trace available>" + "'", str10.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ": " + "'", str11.equals(": "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "<No stack trace available>" + "'", str12.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean[] booleanArray27 = scriptOrFnNode25.getParamAndVarConst();
        int int28 = scriptOrFnNode25.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry5.createFunctionType(jSType19, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean boolean30 = functionType29.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        googleCodingConvention0.applySubclassRelationship(functionType29, functionType31, subclassType32);
        java.util.Set<java.lang.String> strSet34 = functionType29.getPropertyNames();
        try {
            com.google.javascript.rhino.jstype.JSType jSType36 = functionType29.getTopMostDefiningType("window");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strSet34);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean2 = node1.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node1.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = scriptOrFnNode7.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node10 = node1.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode7);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean17 = scriptOrFnNode15.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode15.setSourceName("EOL");
        int int21 = scriptOrFnNode15.addVar("STRING EOL");
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(129, (com.google.javascript.rhino.Node) scriptOrFnNode15);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean29 = node24.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean36 = node31.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode35);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode40 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node24.addChildAfter(node31, (com.google.javascript.rhino.Node) scriptOrFnNode40);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean48 = node43.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode47);
        boolean boolean50 = scriptOrFnNode47.hasParamOrVar("");
        scriptOrFnNode40.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode47);
        scriptOrFnNode47.addParam("Unknown class name");
        scriptOrFnNode47.setLineno(0);
        com.google.javascript.rhino.Node node56 = scriptOrFnNode15.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode47);
        boolean boolean57 = node56.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean60 = node59.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder61 = node59.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode65 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean67 = scriptOrFnNode65.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node68 = node59.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode65);
        boolean boolean69 = node68.isNoSideEffectsCall();
        try {
            node1.addChildAfter(node56, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder61);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility4 = jSDocInfo0.getVisibility();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility5 = null;
        jSDocInfo0.setVisibility(visibility5);
        boolean boolean8 = jSDocInfo0.hasParameterType("lsh");
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertNull(visibility4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.getColumnNumber();
        java.lang.String str4 = ecmaError2.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        try {
            java.util.Collection<java.lang.String> strCollection9 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule3, jSModule5 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        java.lang.String str13 = jSModule9.toString();
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING EOL" + "'", str13.equals("STRING EOL"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        boolean boolean3 = jSDocInfo0.hasBaseType();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility4 = jSDocInfo0.getVisibility();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(visibility4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        boolean boolean34 = jSType33.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSType33.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType35.resolve(errorReporter36, jSTypeStaticScope37);
        com.google.javascript.rhino.jstype.ObjectType objectType39 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType35);
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType39.getParameterType();
        com.google.javascript.rhino.jstype.JSType jSType41 = functionType26.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType39);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = objectType39.getOwnPropertyJSDocInfo("");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNull(jSDocInfo43);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        int int12 = compiler9.getErrorCount();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt13 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter14 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt13);
        com.google.javascript.jscomp.SourceAst sourceAst15 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(sourceAst15, "", true);
        com.google.javascript.jscomp.JSModule jSModule19 = compilerInput18.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter20 = null;
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter20, logger21);
        compilerInput18.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager22);
        compiler9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager22);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker25 = null;
        compiler9.tracker = performanceTracker25;
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(jSModule19);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        boolean boolean58 = functionType26.isFunctionType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler13.getErrorManager();
        int int18 = compiler13.getWarningCount();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.addAuthor("STRING EOL\n");
        boolean boolean9 = jSDocInfoBuilder1.hasParameter("STRING EOL");
        jSDocInfoBuilder1.markName("hi!", (int) '#', 91);
        boolean boolean14 = jSDocInfoBuilder1.recordInterface();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        java.lang.String str11 = defaultCodingConvention1.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean boolean13 = defaultCodingConvention1.isConstant(": ");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean16 = node15.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node15.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = scriptOrFnNode21.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node24 = node15.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.lang.String str25 = defaultCodingConvention1.getSingletonGetterClassName(node15);
        com.google.javascript.rhino.jstype.JSType jSType26 = node15.getJSType();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(53, node15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(jSType26);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getLanguageVersion();
        boolean boolean3 = context1.hasCompileFunctionsWithDynamicScope();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule3, jSModule5 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        try {
            jSModule12.clearAsts();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertNull(jSModule12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean[] booleanArray27 = scriptOrFnNode25.getParamAndVarConst();
        int int28 = scriptOrFnNode25.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry5.createFunctionType(jSType19, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean boolean30 = functionType29.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        googleCodingConvention0.applySubclassRelationship(functionType29, functionType31, subclassType32);
        java.util.Set<java.lang.String> strSet34 = functionType29.getPropertyNames();
        boolean boolean35 = functionType29.isEnumType();
        com.google.javascript.rhino.jstype.JSType jSType37 = functionType29.getPropertyType("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strSet34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jSType37);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean3 = jSDocInfoBuilder1.recordOverride();
        boolean boolean4 = jSDocInfoBuilder1.recordPreserveTry();
        boolean boolean5 = jSDocInfoBuilder1.recordInterface();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        node8.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node8.setJSType(jSType12);
        java.lang.String str17 = node8.toString(true, false, true);
        java.lang.String str18 = node8.toStringTree();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(12, node8, node22, 131, (int) (short) -1);
        jSDocInfoBuilder1.markTypeNode(node22, 93, 108, (int) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING EOL" + "'", str17.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING EOL\n" + "'", str18.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Result result15 = compiler13.getResult();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getErrors();
        boolean boolean17 = compiler13.isTypeCheckingEnabled();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        java.lang.String str2 = defaultCodingConvention0.identifyTypeDefAssign(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = node4.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode8);
        java.util.List<java.lang.String> strList10 = defaultCodingConvention0.identifyTypeDeclarationCall(node4);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean17 = node12.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node12.addChildAfter(node19, (com.google.javascript.rhino.Node) scriptOrFnNode28);
        int int30 = scriptOrFnNode28.getRegexpCount();
        scriptOrFnNode28.addParam("");
        java.util.List<java.lang.String> strList33 = defaultCodingConvention0.identifyTypeDeclarationCall((com.google.javascript.rhino.Node) scriptOrFnNode28);
        java.lang.String str34 = defaultCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(strList10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(strList33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "window" + "'", str34.equals("window"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int0 = com.google.javascript.rhino.Token.SETVAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(93);
        com.google.javascript.rhino.Node node3 = node1.getAncestor(104);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput17 = compiler13.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.defineElement("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.jstype.JSType jSType23 = enumType20.getIndexType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(jSType23);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearSideEffectFlags();
        boolean boolean2 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setMutatesArguments();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = functionType26.getImplicitPrototype();
        boolean boolean31 = objectType30.isNumberObjectType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType30.isResolved();
        com.google.javascript.rhino.jstype.JSType jSType89 = null;
        try {
            com.google.javascript.rhino.jstype.JSType.TypePair typePair90 = functionType30.getTypesUnderEquality(jSType89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = node4.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode8);
        java.lang.String str10 = defaultCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode8);
        int int12 = scriptOrFnNode8.addVar("error reporter");
        int int13 = scriptOrFnNode8.getRegexpCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean27 = scriptOrFnNode24.hasParamOrVar("");
        scriptOrFnNode17.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.Node node29 = scriptOrFnNode24.getParent();
        com.google.javascript.rhino.Node node31 = node29.getAncestor(133);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node31);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        java.lang.String str6 = ecmaError2.getSourceName();
        int int7 = ecmaError2.lineNumber();
        java.lang.String str8 = ecmaError2.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<No stack trace available>" + "'", str8.equals("<No stack trace available>"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean[] booleanArray11 = scriptOrFnNode9.getParamAndVarConst();
        java.lang.String[] strArray12 = scriptOrFnNode9.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean[] booleanArray21 = scriptOrFnNode19.getParamAndVarConst();
        java.lang.String[] strArray22 = scriptOrFnNode19.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        boolean[] booleanArray32 = scriptOrFnNode30.getParamAndVarConst();
        java.lang.String[] strArray33 = scriptOrFnNode30.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray33);
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType3, strArray33);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup36 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = diagnosticType37.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup36, checkLevel38);
        diagnosticType3.level = checkLevel38;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = null;
        diagnosticType3.level = checkLevel41;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean3 = node2.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node2.getJsDocBuilderForNode();
        java.lang.Object obj5 = null;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 75, (java.lang.Object) node2, obj5);
        java.lang.Throwable[] throwableArray7 = runtimeException6.getSuppressed();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean8 = node3.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean15 = node10.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode14);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node3.addChildAfter(node10, (com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean boolean22 = scriptOrFnNode19.addConst("Unknown class name");
        try {
            boolean boolean23 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: TYPEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 109 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean14 = node9.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode13);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node2.addChildAfter(node9, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        com.google.javascript.rhino.Node node20 = node9.getFirstChild();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder22 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean29 = node24.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("EOL");
        node31.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        node31.setJSType(jSType35);
        node31.setCharno(11);
        boolean boolean39 = node24.checkTreeTypeAwareEqualsSilent(node31);
        com.google.javascript.rhino.Node node40 = functionParamBuilder22.newParameterFromNode(node31);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType41 };
        boolean boolean43 = functionParamBuilder22.addRequiredParams(jSTypeArray42);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention44 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean46 = defaultCodingConvention44.isValidEnumKey("EOL");
        com.google.javascript.rhino.Node node50 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention44, "hi!", 120, (-1));
        com.google.javascript.rhino.Node node51 = functionParamBuilder22.newParameterFromNode(node50);
        try {
            java.lang.String str52 = com.google.javascript.rhino.ScriptRuntime.getMessage2("EOL", (java.lang.Object) node20, (java.lang.Object) functionParamBuilder22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property EOL");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule1.setDepth((int) (short) 10);
        java.util.List<java.lang.String> strList4 = jSModule1.getRequires();
        org.junit.Assert.assertNotNull(strList4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int0 = com.google.javascript.rhino.Token.MUL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        ecmaError2.initLineSource("");
        java.lang.String str8 = ecmaError2.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Scope scope10 = compiler9.getTopScope();
        int int11 = compiler9.getWarningCount();
        com.google.javascript.jscomp.Result result12 = compiler9.getResult();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(scope10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(result12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.getColumnNumber();
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = ecmaError2.getScriptStackTrace(filenameFilter4);
        java.lang.Throwable[] throwableArray6 = ecmaError2.getSuppressed();
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
        java.lang.Object obj10 = null;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) diagnosticGroupArray7, obj10);
        ecmaError2.addSuppressed((java.lang.Throwable) runtimeException11);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
        org.junit.Assert.assertNotNull(runtimeException11);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node8.getJsDocBuilderForNode();
        fileLevelJsDocBuilder19.append("");
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder19);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str3 = jSDocInfo0.getDescriptionForParameter("Not declared as a constructor");
        boolean boolean4 = jSDocInfo0.isConstant();
        java.lang.String str5 = jSDocInfo0.getDescription();
        int int6 = jSDocInfo0.getParameterCount();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean8 = node3.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("EOL");
        node10.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node10.setJSType(jSType14);
        node10.setCharno(11);
        boolean boolean18 = node3.checkTreeTypeAwareEqualsSilent(node10);
        com.google.javascript.rhino.Node node19 = functionParamBuilder1.newParameterFromNode(node10);
        node19.detachChildren();
        int int21 = node19.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDeprecationReason();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getEnumParameterType();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.SourceAst sourceAst10 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst10, "", true);
        com.google.javascript.jscomp.JSModule jSModule14 = compilerInput13.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = null;
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter15, logger16);
        compilerInput13.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler19);
        java.lang.String str21 = compiler19.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray22 = compiler19.getWarnings();
        int int23 = compiler19.getWarningCount();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = null;
        boolean boolean29 = diagnosticGroup27.matches(diagnosticType28);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup27;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean32 = diagnosticGroup27.matches(diagnosticType31);
        java.lang.String[] strArray33 = null;
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("STRING EOL", (int) (byte) 100, 42, diagnosticType31, strArray33);
        java.lang.RuntimeException runtimeException35 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) jSDocInfo0, (java.lang.Object) compiler19, (java.lang.Object) (byte) 100);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str38 = jSSourceFile37.getName();
        java.lang.String str39 = jSSourceFile37.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        jSSourceFile43.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile43 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = null;
        try {
            com.google.javascript.jscomp.Result result47 = compiler19.compile(jSSourceFile37, jSSourceFileArray45, compilerOptions46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(jSTypeExpression5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(jSModule14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(runtimeException35);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Not declared as a constructor" + "'", str38.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Not declared as a constructor" + "'", str39.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSSourceFile43);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getErrors();
        int int9 = loggerErrorManager7.getErrorCount();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.SourceAst sourceAst11 = compilerInput3.getSourceAst();
        try {
            java.lang.String str12 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(sourceAst11);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        node2.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node2.setJSType(jSType6);
        java.lang.String str11 = node2.toString(true, false, true);
        java.lang.String str12 = node2.toStringTree();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(12, node2, node16, 131, (int) (short) -1);
        java.lang.Class<?> wildcardClass20 = node16.getClass();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING EOL" + "'", str11.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "STRING EOL\n" + "'", str12.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean boolean12 = scriptOrFnNode9.hasParamOrVar("");
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast13 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal3, (com.google.javascript.rhino.Node) scriptOrFnNode9);
        com.google.javascript.rhino.Node node14 = scriptOrFnNode9.getFirstChild();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(objectLiteralCast13);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearAllFlags();
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a constructor", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(36);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        java.lang.String str7 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "", 38, 120);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry20.getGreatestSubtypeWithProperty(jSType21, "");
        boolean boolean24 = jSType23.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType25 = jSType23.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope27 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = objectType25.resolve(errorReporter26, jSTypeStaticScope27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean35 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode34);
        boolean[] booleanArray36 = scriptOrFnNode34.getParamAndVarConst();
        int int37 = scriptOrFnNode34.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry14.createFunctionType(jSType28, (com.google.javascript.rhino.Node) scriptOrFnNode34);
        java.lang.String str39 = functionType38.getReferenceName();
        boolean boolean40 = functionType38.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry43.getGreatestSubtypeWithProperty(jSType44, "");
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        boolean boolean53 = jSType52.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType54 = jSType52.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope56 = null;
        com.google.javascript.rhino.jstype.JSType jSType57 = objectType54.resolve(errorReporter55, jSTypeStaticScope56);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode63 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean64 = node59.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode63);
        boolean[] booleanArray65 = scriptOrFnNode63.getParamAndVarConst();
        int int66 = scriptOrFnNode63.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry43.createFunctionType(jSType57, (com.google.javascript.rhino.Node) scriptOrFnNode63);
        java.lang.String str68 = functionType67.getReferenceName();
        boolean boolean69 = functionType67.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, false);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry72.getGreatestSubtypeWithProperty(jSType73, "");
        boolean boolean76 = jSType75.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = jSType75.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope79 = null;
        com.google.javascript.rhino.jstype.JSType jSType80 = objectType77.resolve(errorReporter78, jSTypeStaticScope79);
        com.google.javascript.rhino.jstype.ObjectType objectType81 = objectType77.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter82 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter82, false);
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType jSType87 = jSTypeRegistry84.getGreatestSubtypeWithProperty(jSType85, "");
        boolean boolean88 = jSType87.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType89 = jSType87.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter90 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope91 = null;
        com.google.javascript.rhino.jstype.JSType jSType92 = objectType89.resolve(errorReporter90, jSTypeStaticScope91);
        boolean boolean93 = objectType81.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) objectType89);
        defaultCodingConvention0.applySingletonGetter(functionType38, functionType67, objectType89);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType95 = null;
        boolean boolean96 = functionType67.setPrototype(functionPrototypeType95);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(booleanArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(objectType89);
        org.junit.Assert.assertNotNull(jSType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        jSTypeRegistry3.resetForTypeCheck();
        boolean boolean6 = jSTypeRegistry3.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder7 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry3);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.jstype.ObjectType objectType20 = objectType16.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType21 = jSTypeRegistry3.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType20);
        com.google.javascript.rhino.jstype.JSType jSType22 = enumType21.unboxesTo();
        com.google.javascript.rhino.jstype.SimpleSlot simpleSlot24 = new com.google.javascript.rhino.jstype.SimpleSlot("window", jSType22, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(enumType21);
        org.junit.Assert.assertNull(jSType22);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = null;
        java.lang.String str7 = defaultCodingConvention5.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder12 = node11.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship13 = defaultCodingConvention5.getClassesDefinedByCall(node11);
        java.lang.String str14 = node11.getString();
        java.lang.String str15 = googleCodingConvention0.extractClassNameIfProvide(node4, node11);
        boolean boolean17 = googleCodingConvention0.isValidEnumKey("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        com.google.javascript.jscomp.SourceAst sourceAst18 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(sourceAst18, "", true);
        com.google.javascript.jscomp.JSModule jSModule22 = compilerInput21.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        compilerInput21.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        com.google.javascript.jscomp.NodeTraversal.Callback callback28 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal29 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler27, callback28);
        com.google.javascript.rhino.Node node30 = nodeTraversal29.getCurrentNode();
        int int31 = nodeTraversal29.getLineNumber();
        boolean boolean32 = nodeTraversal29.hasScope();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode38 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean39 = node34.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode38);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode45 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean46 = node41.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode45);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode50 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node34.addChildAfter(node41, (com.google.javascript.rhino.Node) scriptOrFnNode50);
        boolean boolean53 = scriptOrFnNode50.addConst("Unknown class name");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention54 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType55 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType58 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType59 = null;
        defaultCodingConvention54.applyDelegateRelationship(objectType55, objectType56, objectType57, functionType58, functionType59);
        java.lang.String str61 = defaultCodingConvention54.getExportPropertyFunction();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship66 = defaultCodingConvention54.getClassesDefinedByCall(node65);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("EOL");
        node68.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        node68.setJSType(jSType72);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship74 = defaultCodingConvention54.getClassesDefinedByCall(node68);
        boolean boolean75 = scriptOrFnNode50.isEquivalentTo(node68);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast76 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal29, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder12);
        org.junit.Assert.assertNull(subclassRelationship13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EOL" + "'", str14.equals("EOL"));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSModule22);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(subclassRelationship66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(subclassRelationship74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        boolean boolean59 = functionType26.isPropertyInExterns("");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isHidden();
        java.lang.String str4 = jSDocInfo0.getDeprecationReason();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getEnumParameterType();
        boolean boolean6 = jSDocInfo0.isConstructor();
        java.lang.String str7 = jSDocInfo0.getDeprecationReason();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = jSDocInfo0.getType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(jSTypeExpression5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(jSTypeExpression8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_MUL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 95 + "'", int0 == 95);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = objectType7.resolve(errorReporter8, jSTypeStaticScope9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        jSTypeRegistry13.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.getGreatestSubtypeWithProperty(jSType18, "");
        boolean boolean21 = jSType20.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSType20.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope24 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = objectType22.resolve(errorReporter23, jSTypeStaticScope24);
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry13.createDefaultObjectUnion(jSType25);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair27 = jSType10.getTypesUnderInequality(jSType26);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.getGreatestSubtypeWithProperty(jSType37, "");
        boolean boolean40 = jSType39.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType41 = jSType39.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        com.google.javascript.rhino.jstype.JSType jSType44 = objectType41.resolve(errorReporter42, jSTypeStaticScope43);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode50 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean51 = node46.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode50);
        boolean[] booleanArray52 = scriptOrFnNode50.getParamAndVarConst();
        int int53 = scriptOrFnNode50.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry30.createFunctionType(jSType44, (com.google.javascript.rhino.Node) scriptOrFnNode50);
        java.lang.String str55 = functionType54.getReferenceName();
        boolean boolean56 = functionType54.hasReferenceName();
        boolean boolean57 = functionType54.isEmptyType();
        boolean boolean58 = functionType54.isEnumType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair59 = jSType26.getTypesUnderEquality((com.google.javascript.rhino.jstype.JSType) functionType54);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(typePair27);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(objectType41);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(booleanArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(typePair59);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType30.isRecordType();
        boolean boolean89 = functionType30.hasCachedValues();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable90 = functionType30.getAllImplementedInterfaces();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable90);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode3.setSourceName("EOL");
        int int9 = scriptOrFnNode3.addVar("STRING EOL");
        com.google.javascript.rhino.Node node10 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention11 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean18 = node13.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node13.addChildAfter(node20, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship31 = defaultCodingConvention11.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode29);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean38 = scriptOrFnNode36.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode36.setSourceName("EOL");
        int int42 = scriptOrFnNode36.addVar("STRING EOL");
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(129, (com.google.javascript.rhino.Node) scriptOrFnNode36);
        boolean boolean44 = defaultCodingConvention11.isPropertyTestFunction(node43);
        try {
            scriptOrFnNode3.addChildBefore(node10, node43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(delegateRelationship31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile4 = jsAst3.getSourceFile();
        com.google.javascript.jscomp.SourceAst sourceAst5 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceAst5, "", true);
        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput8.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = null;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter10, logger11);
        compilerInput8.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.Scope scope15 = compiler14.getTopScope();
        int int16 = compiler14.getWarningCount();
        int int17 = compiler14.getWarningCount();
        try {
            com.google.javascript.rhino.Node node18 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = jSType16.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder3 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean4 = jSDocInfoBuilder3.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = null;
        boolean boolean7 = jSDocInfoBuilder3.recordThrowDescription(jSTypeExpression5, "hi!");
        boolean boolean8 = jSDocInfoBuilder3.recordInterface();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean15 = node10.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode14);
        boolean boolean17 = scriptOrFnNode14.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression19 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode14, ": ");
        boolean boolean20 = jSTypeExpression19.isOptionalArg();
        boolean boolean21 = jSDocInfoBuilder3.recordDefineType(jSTypeExpression19);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression22 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression19);
        boolean boolean24 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression22, "Not declared as a constructor");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope25 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        try {
            com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeExpression22.evaluate(jSTypeStaticScope25, jSTypeRegistry28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: TYPEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 109");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean11 = node6.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean18 = node13.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node6.addChildAfter(node13, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship24 = defaultCodingConvention4.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode22);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = scriptOrFnNode29.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode29.setSourceName("EOL");
        int int35 = scriptOrFnNode29.addVar("STRING EOL");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(129, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean37 = defaultCodingConvention4.isPropertyTestFunction(node36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, false);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry40.getGreatestSubtypeWithProperty(jSType41, "");
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType jSType49 = jSTypeRegistry46.getGreatestSubtypeWithProperty(jSType47, "");
        boolean boolean50 = jSType49.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSType49.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope53 = null;
        com.google.javascript.rhino.jstype.JSType jSType54 = objectType51.resolve(errorReporter52, jSTypeStaticScope53);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode60 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean61 = node56.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode60);
        boolean[] booleanArray62 = scriptOrFnNode60.getParamAndVarConst();
        int int63 = scriptOrFnNode60.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry40.createFunctionType(jSType54, (com.google.javascript.rhino.Node) scriptOrFnNode60);
        java.lang.String str65 = functionType64.getReferenceName();
        boolean boolean66 = functionType64.hasReferenceName();
        int int67 = functionType64.getMaxArguments();
        boolean boolean68 = functionType64.isEnumElementType();
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7", node36, (com.google.javascript.rhino.jstype.ObjectType) functionType64);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(delegateRelationship24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(booleanArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(objectType69);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = objectType7.resolve(errorReporter8, jSTypeStaticScope9);
        com.google.javascript.rhino.jstype.ObjectType objectType11 = objectType7.toObjectType();
        boolean boolean12 = objectType11.isNumberValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry15.getGreatestSubtypeWithProperty(jSType16, "");
        try {
            com.google.javascript.rhino.jstype.JSType jSType19 = objectType11.getGreatestSubtype(jSType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType18);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean5 = diagnosticGroup0.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeThreadLocal((java.lang.Object) 56);
        context1.removeActivationName("error reporter");
        boolean boolean7 = context1.isGeneratingSource();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter9 = context1.setErrorReporter(errorReporter8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean2 = node1.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node1.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = scriptOrFnNode7.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node10 = node1.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode7);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention11 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = null;
        java.lang.String str13 = defaultCodingConvention11.identifyTypeDefAssign(node12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        java.util.List<java.lang.String> strList21 = defaultCodingConvention11.identifyTypeDeclarationCall(node15);
        com.google.javascript.rhino.Node node22 = node10.copyInformationFrom(node15);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention23 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean25 = defaultCodingConvention23.isExported("<No stack trace available>");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = null;
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean33 = node28.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode32);
        boolean boolean35 = scriptOrFnNode32.hasParamOrVar("");
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast36 = defaultCodingConvention23.getObjectLiteralCast(nodeTraversal26, (com.google.javascript.rhino.Node) scriptOrFnNode32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean43 = node38.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode42);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode49 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean50 = node45.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode49);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode54 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node38.addChildAfter(node45, (com.google.javascript.rhino.Node) scriptOrFnNode54);
        java.lang.String str56 = node38.toString();
        boolean boolean57 = defaultCodingConvention23.isPropertyTestFunction(node38);
        try {
            node15.removeChild(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(strList21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(objectLiteralCast36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "STRING EOL" + "'", str56.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
//        boolean[] booleanArray8 = scriptOrFnNode6.getParamAndVarConst();
//        java.lang.String[] strArray9 = scriptOrFnNode6.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray9);
//        com.google.javascript.jscomp.CheckLevel checkLevel11 = jSError10.level;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = null;
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder13 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry12);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder15 = functionBuilder13.setIsConstructor(false);
//        boolean boolean16 = jSError10.equals((java.lang.Object) functionBuilder13);
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = null;
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder18 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry17);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder19 = functionBuilder13.withParams(functionParamBuilder18);
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
//        jSTypeRegistry22.resetForTypeCheck();
//        boolean boolean25 = jSTypeRegistry22.isForwardDeclaredType("hi!");
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder26 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry22);
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
//        boolean boolean34 = jSType33.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSType33.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
//        com.google.javascript.rhino.jstype.JSType jSType38 = objectType35.resolve(errorReporter36, jSTypeStaticScope37);
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = objectType35.toObjectType();
//        com.google.javascript.rhino.jstype.EnumType enumType40 = jSTypeRegistry22.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType39);
//        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry22.createNamedType("@IMPLEMENTATION.VERSION@", "goog.exportProperty", 0, 31);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder46 = functionBuilder13.withReturnType(jSType45);
//        boolean boolean47 = jSType45.isNoObjectType();
//        boolean boolean48 = jSType45.isUnionType();
//        org.junit.Assert.assertNotNull(diagnosticType0);
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(booleanArray8);
//        org.junit.Assert.assertNotNull(strArray9);
//        org.junit.Assert.assertNotNull(jSError10);
//        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(functionBuilder15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(functionBuilder19);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(jSType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(objectType35);
//        org.junit.Assert.assertNotNull(jSType38);
//        org.junit.Assert.assertNotNull(objectType39);
//        org.junit.Assert.assertNotNull(enumType40);
//        org.junit.Assert.assertNotNull(jSType45);
//        org.junit.Assert.assertNotNull(functionBuilder46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition0.setItem("<No stack trace available>");
        java.lang.String str3 = stringPosition0.getItem();
        java.lang.String str4 = stringPosition0.getItem();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node3 = null;
        java.lang.String str4 = defaultCodingConvention2.identifyTypeDefAssign(node3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node8.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship10 = defaultCodingConvention2.getClassesDefinedByCall(node8);
        node8.setCharno(23);
        node8.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        int int21 = scriptOrFnNode19.getParamCount();
        java.lang.String str22 = googleCodingConvention0.extractClassNameIfRequire(node8, (com.google.javascript.rhino.Node) scriptOrFnNode19);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder9);
        org.junit.Assert.assertNull(subclassRelationship10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        node1.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node1.setJSType(jSType5);
        node1.setCharno(11);
        node1.putIntProp(2, 4095);
        node1.setType(4);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node15.addChildAfter(node22, (com.google.javascript.rhino.Node) scriptOrFnNode31);
        int int33 = scriptOrFnNode31.getRegexpCount();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression35 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode31, "");
        com.google.javascript.rhino.Node node36 = node1.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode31);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean[] booleanArray27 = scriptOrFnNode25.getParamAndVarConst();
        int int28 = scriptOrFnNode25.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry5.createFunctionType(jSType19, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean boolean30 = functionType29.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        googleCodingConvention0.applySubclassRelationship(functionType29, functionType31, subclassType32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean40 = node35.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode39);
        boolean boolean41 = googleCodingConvention0.isOptionalParameter(node35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        boolean boolean4 = jSTypeRegistry2.isForwardDeclaredType("goog.exportProperty");
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable6 = jSTypeRegistry2.getTypesWithProperty("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeIterable6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int0 = com.google.javascript.rhino.Token.DEL_REF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 67 + "'", int0 == 67);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int0 = com.google.javascript.rhino.Token.TARGET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 127 + "'", int0 == 127);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        jsAst3.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile5 = null;
        try {
            jsAst3.setSourceFile(sourceFile5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        int int29 = functionType26.getMaxArguments();
        boolean boolean30 = functionType26.isEnumElementType();
        java.lang.String str31 = functionType26.getTemplateTypeName();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry7.getGreatestSubtypeWithProperty(jSType8, "");
        boolean boolean11 = jSType10.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = jSType10.toObjectType();
        boolean boolean13 = objectType12.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry16.getGreatestSubtypeWithProperty(jSType17, "");
        boolean boolean20 = jSType19.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSType19.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
        com.google.javascript.rhino.jstype.JSType jSType24 = objectType21.resolve(errorReporter22, jSTypeStaticScope23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        jSTypeRegistry27.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry31.getGreatestSubtypeWithProperty(jSType32, "");
        boolean boolean35 = jSType34.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType34.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope38 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = objectType36.resolve(errorReporter37, jSTypeStaticScope38);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry27.createDefaultObjectUnion(jSType39);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair41 = jSType24.getTypesUnderInequality(jSType40);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair42 = objectType12.getTypesUnderShallowEquality(jSType40);
        boolean boolean43 = objectType12.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair44 = objectType4.getTypesUnderEquality((com.google.javascript.rhino.jstype.JSType) objectType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objectType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(typePair41);
        org.junit.Assert.assertNotNull(typePair42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(typePair44);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.addAuthor("STRING EOL\n");
        boolean boolean9 = jSDocInfoBuilder1.hasParameter("STRING EOL");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder12 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression14 = null;
        boolean boolean15 = jSDocInfoBuilder12.recordParameter("STRING EOL", jSTypeExpression14);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder17 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean18 = jSDocInfoBuilder17.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression19 = null;
        boolean boolean20 = jSDocInfoBuilder17.recordType(jSTypeExpression19);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression21 = null;
        boolean boolean22 = jSDocInfoBuilder17.recordThisType(jSTypeExpression21);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean30 = node25.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean32 = scriptOrFnNode29.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression34 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode29, ": ");
        boolean boolean35 = jSDocInfoBuilder17.recordParameter("<No stack trace available>", jSTypeExpression34);
        boolean boolean36 = jSDocInfoBuilder12.recordThisType(jSTypeExpression34);
        boolean boolean37 = jSDocInfoBuilder1.recordParameter("", jSTypeExpression34);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope38 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        jSTypeRegistry41.resetForTypeCheck();
        try {
            com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeExpression34.evaluate(jSTypeStaticScope38, jSTypeRegistry41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: TYPEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 109");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule1.setDepth((int) (short) 10);
        java.util.List<java.lang.String> strList4 = jSModule1.getRequires();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule6.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule10.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule14 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule14.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] { jSModule18, jSModule20, jSModule22 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph24 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray23);
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule29 = jSModuleGraph24.getDeepestCommonDependencyInclusive(jSModule26, jSModule28);
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule33 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule35 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray36 = new com.google.javascript.jscomp.JSModule[] { jSModule31, jSModule33, jSModule35 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph37 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray36);
        com.google.javascript.jscomp.JSModule jSModule39 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule41 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule42 = jSModuleGraph37.getDeepestCommonDependencyInclusive(jSModule39, jSModule41);
        java.lang.String str43 = jSModule39.toString();
        com.google.javascript.jscomp.JSModule[] jSModuleArray44 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule6, jSModule10, jSModule14, jSModule28, jSModule39 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList45 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList45, jSModuleArray44);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.JSModule> jSModuleSortedDependencies47 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.JSModule>((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList45);
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertNull(jSModule29);
        org.junit.Assert.assertNotNull(jSModuleArray36);
        org.junit.Assert.assertNull(jSModule42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "STRING EOL" + "'", str43.equals("STRING EOL"));
        org.junit.Assert.assertNotNull(jSModuleArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        boolean boolean4 = jSDocInfo0.hasParameterType("window");
        java.lang.String str5 = jSDocInfo0.getTemplateTypeName();
        boolean boolean6 = jSDocInfo0.isConstant();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        boolean boolean8 = objectType7.isInterface();
        boolean boolean9 = objectType7.matchesUint32Context();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression12 = jSDocInfo11.getEnumParameterType();
        java.lang.String str14 = jSDocInfo11.getDescriptionForParameter("Not declared as a constructor");
        boolean boolean15 = jSDocInfo11.isConstant();
        java.lang.String str16 = jSDocInfo11.getDescription();
        objectType7.setPropertyJSDocInfo("hi!", jSDocInfo11, false);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(jSTypeExpression12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean89 = functionType57.hasProperty("");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        org.junit.Assert.assertNotNull(jSType5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int0 = com.google.javascript.rhino.Token.WHILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 113 + "'", int0 == 113);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("JSDocInfo", 18, 0);
        boolean boolean4 = functionNode3.requiresActivation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = marker0.annotation;
        com.google.javascript.rhino.JSDocInfo.Marker marker2 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition3 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition3.setItem("<No stack trace available>");
        marker2.annotation = stringPosition3;
        marker0.annotation = stringPosition3;
        int int8 = stringPosition3.getStartLine();
        org.junit.Assert.assertNull(stringPosition1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        java.lang.String str4 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str4.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("STRING EOL", jSTypeExpression3);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder6 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean7 = jSDocInfoBuilder6.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder6.recordType(jSTypeExpression8);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder6.recordThisType(jSTypeExpression10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean19 = node14.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode18);
        boolean boolean21 = scriptOrFnNode18.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode18, ": ");
        boolean boolean24 = jSDocInfoBuilder6.recordParameter("<No stack trace available>", jSTypeExpression23);
        boolean boolean25 = jSDocInfoBuilder1.recordThisType(jSTypeExpression23);
        boolean boolean27 = jSDocInfoBuilder1.recordFileOverview("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getTypedefType();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList2 = jSDocInfo0.getThrownTypes();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(jSTypeExpressionList2);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context1.setLocale(locale3);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        boolean boolean7 = context1.hasCompileFunctionsWithDynamicScope();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
        com.google.javascript.jscomp.SourceAst sourceAst6 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(sourceAst6, "", true);
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput9.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = null;
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter11, logger12);
        compilerInput9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Scope scope16 = compiler15.getTopScope();
        int int17 = compiler15.getWarningCount();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
        try {
            compiler15.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNull(scope16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = null;
        java.lang.String str7 = defaultCodingConvention5.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder12 = node11.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship13 = defaultCodingConvention5.getClassesDefinedByCall(node11);
        java.lang.String str14 = node11.getString();
        java.lang.String str15 = googleCodingConvention0.extractClassNameIfProvide(node4, node11);
        boolean boolean18 = googleCodingConvention0.isExported("goog.exportProperty", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection19 = googleCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder12);
        org.junit.Assert.assertNull(subclassRelationship13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EOL" + "'", str14.equals("EOL"));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection19);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        boolean boolean58 = functionType26.isEmptyType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = functionType26.isTemplateType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        int int12 = compiler9.getErrorCount();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt13 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter14 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt13);
        com.google.javascript.jscomp.SourceAst sourceAst15 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(sourceAst15, "", true);
        com.google.javascript.jscomp.JSModule jSModule19 = compilerInput18.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter20 = null;
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter20, logger21);
        compilerInput18.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager22);
        compiler9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager22);
        try {
            java.lang.String str27 = compiler9.getSourceLine("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7", 110);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(jSModule19);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        java.lang.String str6 = ecmaError2.getSourceName();
        java.io.FilenameFilter filenameFilter7 = null;
        java.lang.String str8 = ecmaError2.getScriptStackTrace(filenameFilter7);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<No stack trace available>" + "'", str8.equals("<No stack trace available>"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        java.lang.String str31 = functionType30.getReferenceName();
        boolean boolean32 = functionType30.hasReferenceName();
        boolean boolean33 = functionType30.isEmptyType();
        boolean boolean34 = functionType30.isEnumType();
        try {
            jSTypeRegistry2.overwriteDeclaredType("", (com.google.javascript.rhino.jstype.JSType) functionType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.putThreadLocal((java.lang.Object) "lsh", (java.lang.Object) 48);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.toString();
        boolean boolean2 = jSDocInfo0.hasThisType();
        boolean boolean3 = jSDocInfo0.hasThisType();
        boolean boolean4 = jSDocInfo0.isJavaDispatch();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSDocInfo" + "'", str1.equals("JSDocInfo"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getParameterNames();
        boolean boolean4 = jSDocInfo0.containsDeclaration();
        java.lang.String str5 = jSDocInfo0.getVersion();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        jsAst3.clearAst();
        jsAst3.clearAst();
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        node6.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node6.setJSType(jSType10);
        java.lang.String str15 = node6.toString(true, false, true);
        java.lang.String str16 = node6.toStringTree();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(12, node6, node20, 131, (int) (short) -1);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node20);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = scriptOrFnNode29.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 1);
        boolean boolean34 = node33.isVarArgs();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("EOL");
        node40.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.Node node44 = node40.getLastChild();
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4', (com.google.javascript.rhino.Node) scriptOrFnNode29, node33, node38, node40);
        com.google.javascript.rhino.Node node46 = scriptOrFnNode29.cloneNode();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        node48.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        node48.setJSType(jSType52);
        node48.setCharno(11);
        boolean boolean56 = node48.hasOneChild();
        node48.setCharno(4);
        java.lang.String str59 = googleCodingConvention0.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode29, node48);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode65 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean66 = node61.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode65);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode72 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean73 = node68.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode72);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode77 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node61.addChildAfter(node68, (com.google.javascript.rhino.Node) scriptOrFnNode77);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode84 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean85 = node80.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode84);
        boolean boolean87 = scriptOrFnNode84.hasParamOrVar("");
        scriptOrFnNode77.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode84);
        try {
            boolean boolean89 = googleCodingConvention0.isPropertyTestFunction((com.google.javascript.rhino.Node) scriptOrFnNode84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING EOL" + "'", str15.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING EOL\n" + "'", str16.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean8 = node3.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("EOL");
        node10.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node10.setJSType(jSType14);
        node10.setCharno(11);
        boolean boolean18 = node3.checkTreeTypeAwareEqualsSilent(node10);
        com.google.javascript.rhino.Node node19 = functionParamBuilder1.newParameterFromNode(node10);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention20 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node21 = null;
        java.lang.String str22 = defaultCodingConvention20.identifyTypeDefAssign(node21);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node26.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship28 = defaultCodingConvention20.getClassesDefinedByCall(node26);
        java.lang.String str29 = node26.getString();
        com.google.javascript.rhino.Node node30 = node19.copyInformationFrom(node26);
        boolean boolean31 = node30.isVarArgs();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression33 = new com.google.javascript.rhino.JSTypeExpression(node30, "Not declared as a constructor");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder27);
        org.junit.Assert.assertNull(subclassRelationship28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EOL" + "'", str29.equals("EOL"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int0 = com.google.javascript.rhino.Token.XMLATTR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 143 + "'", int0 == 143);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        compiler13.reportCodeChange();
        com.google.javascript.jscomp.SourceAst sourceAst17 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceAst17, "", true);
        com.google.javascript.jscomp.JSModule jSModule21 = compilerInput20.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = null;
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter22, logger23);
        compilerInput20.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        com.google.javascript.jscomp.Scope scope27 = compiler26.getTopScope();
        int int28 = compiler26.getWarningCount();
        int int29 = compiler26.getWarningCount();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState30 = compiler26.getState();
        compiler13.setState(intermediateState30);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(jSModule21);
        org.junit.Assert.assertNull(scope27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intermediateState30);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str2 = jSDocInfo0.getBlockDescription();
        boolean boolean3 = jSDocInfo0.shouldPreserveTry();
        java.lang.String str4 = jSDocInfo0.getTemplateTypeName();
        java.lang.String str5 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression6 = jSDocInfo0.getEnumParameterType();
        java.lang.String str7 = jSDocInfo0.getDescription();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(jSTypeExpression6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Result result15 = compiler13.getResult();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler13.getErrors();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str19 = jSSourceFile18.getName();
        java.lang.String str20 = jSSourceFile18.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18, true);
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList24 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList24, jSModuleArray23);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph26 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList24);
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        jSModule28.setDepth((int) (short) 10);
        com.google.javascript.jscomp.JSModule jSModule32 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray33 = new com.google.javascript.jscomp.JSModule[] { jSModule28, jSModule32 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList34 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList34, jSModuleArray33);
        com.google.javascript.jscomp.JSModule jSModule36 = jSModuleGraph26.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList34);
        com.google.javascript.jscomp.JSModule[] jSModuleArray37 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList34);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        try {
            com.google.javascript.jscomp.Result result39 = compiler13.compile(jSSourceFile18, jSModuleArray37, compilerOptions38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Not declared as a constructor" + "'", str19.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Not declared as a constructor" + "'", str20.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(jSModuleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(jSModule36);
        org.junit.Assert.assertNotNull(jSModuleArray37);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.lang.String str15 = compiler13.getAstDotGraph();
        int int16 = compiler13.getErrorCount();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        int int6 = ecmaError2.getLineNumber();
        int int7 = ecmaError2.getColumnNumber();
        int int8 = ecmaError2.getColumnNumber();
        ecmaError2.initColumnNumber(73);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        scriptOrFnNode3.addParam("Not declared as a constructor");
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordType(jSTypeExpression3);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordReturnType(jSTypeExpression5);
        boolean boolean7 = jSDocInfoBuilder1.isDescriptionRecorded();
        boolean boolean9 = jSDocInfoBuilder1.recordDescription("<No stack trace available>");
        boolean boolean10 = jSDocInfoBuilder1.recordDeprecated();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.lang.String str3 = jSDocInfo0.getVersion();
        boolean boolean4 = jSDocInfo0.isDefine();
        java.lang.String str5 = jSDocInfo0.getVersion();
        boolean boolean6 = jSDocInfo0.isExterns();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isNoCompile();
        java.util.Collection<java.lang.String> strCollection4 = jSDocInfo0.getReferences();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(strCollection4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean5 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression3, "hi!");
        boolean boolean6 = jSDocInfoBuilder1.recordInterface();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean15 = scriptOrFnNode12.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode12, ": ");
        boolean boolean18 = jSTypeExpression17.isOptionalArg();
        boolean boolean19 = jSDocInfoBuilder1.recordDefineType(jSTypeExpression17);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression20 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression17);
        boolean boolean21 = jSTypeExpression20.isVarArgs();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context1.setLocale(locale3);
//        context1.setLanguageVersion(0);
//        try {
//            context1.setLanguageVersion((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 35");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(locale4);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative2, jSTypeNative3, jSTypeNative4, jSTypeNative5, jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry1.createUnionType(jSTypeNativeArray7);
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean7 = jSDocInfoBuilder1.recordParameterDescription("EOL", ": ");
        jSDocInfoBuilder1.markText("Not declared as a constructor", 109, 60, 123, 100);
        boolean boolean15 = jSDocInfoBuilder1.recordDescription("STRING EOL\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.lang.String str3 = jSDocInfo0.getVersion();
        boolean boolean5 = jSDocInfo0.hasParameterType("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule3, jSModule5 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("STRING EOL");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        java.util.List<java.lang.String> strList13 = jSModule11.getProvides();
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList14 = jSModule11.getInputs();
        jSModule11.setDepth(147);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertNotNull(strList13);
        org.junit.Assert.assertNotNull(compilerInputList14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        jSModuleGraph1.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = null;
        java.lang.String str3 = defaultCodingConvention1.identifyTypeDefAssign(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node7.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship9 = defaultCodingConvention1.getClassesDefinedByCall(node7);
        node7.setQuotedString();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean17 = node12.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode16);
        boolean boolean19 = scriptOrFnNode16.hasParamOrVar("");
        com.google.javascript.rhino.Node node20 = scriptOrFnNode16.removeFirstChild();
        int int23 = scriptOrFnNode16.addRegexp("STRING EOL", "");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean30 = scriptOrFnNode28.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode28.setSourceName("EOL");
        int int34 = scriptOrFnNode28.addVar("STRING EOL");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(129, (com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(141, node7, (com.google.javascript.rhino.Node) scriptOrFnNode16, node35);
        java.lang.String str38 = scriptOrFnNode16.getRegexpString(0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertNull(subclassRelationship9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "STRING EOL" + "'", str38.equals("STRING EOL"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerInput3);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(runtimeException5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordDeprecated();
        boolean boolean4 = jSDocInfoBuilder1.addAuthor("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int0 = com.google.javascript.rhino.Token.LE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.toString();
        java.lang.String str2 = jSDocInfo0.getFileOverview();
        boolean boolean3 = jSDocInfo0.hasReturnType();
        boolean boolean4 = jSDocInfo0.hasTypedefType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSDocInfo" + "'", str1.equals("JSDocInfo"));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.withReturnType(jSType4);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = functionBuilder5.forConstructor();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder8 = functionBuilder6.setIsConstructor(false);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder6);
        org.junit.Assert.assertNotNull(functionBuilder8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(28);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 13);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        boolean boolean6 = googleCodingConvention4.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
//        com.google.javascript.rhino.jstype.JSType jSType10 = null;
//        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.getGreatestSubtypeWithProperty(jSType10, "");
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry15.getGreatestSubtypeWithProperty(jSType16, "");
//        boolean boolean19 = jSType18.matchesNumberContext();
//        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType18.toObjectType();
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope22 = null;
//        com.google.javascript.rhino.jstype.JSType jSType23 = objectType20.resolve(errorReporter21, jSTypeStaticScope22);
//        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean30 = node25.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode29);
//        boolean[] booleanArray31 = scriptOrFnNode29.getParamAndVarConst();
//        int int32 = scriptOrFnNode29.getSideEffectFlags();
//        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry9.createFunctionType(jSType23, (com.google.javascript.rhino.Node) scriptOrFnNode29);
//        boolean boolean34 = functionType33.isNativeObjectType();
//        com.google.javascript.rhino.jstype.FunctionType functionType35 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType36 = null;
//        googleCodingConvention4.applySubclassRelationship(functionType33, functionType35, subclassType36);
//        java.lang.Object obj38 = context1.getThreadLocal((java.lang.Object) subclassType36);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(jSType12);
//        org.junit.Assert.assertNotNull(jSType18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(objectType20);
//        org.junit.Assert.assertNotNull(jSType23);
//        org.junit.Assert.assertNotNull(node25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(booleanArray31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(functionType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNull(obj38);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int0 = com.google.javascript.rhino.Token.RB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 80 + "'", int0 == 80);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.SourceAst sourceAst2 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceAst2, "", true);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput5.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = loggerErrorManager9.getErrors();
        int int11 = loggerErrorManager9.getErrorCount();
        compilerInput5.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        int int13 = loggerErrorManager9.getWarningCount();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        jSTypeRegistry16.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry20.getGreatestSubtypeWithProperty(jSType21, "");
        boolean boolean24 = jSType23.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType25 = jSType23.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope27 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = objectType25.resolve(errorReporter26, jSTypeStaticScope27);
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry16.createDefaultObjectUnion(jSType28);
        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.OFF;
        boolean boolean31 = jSType29.equals((java.lang.Object) checkLevel30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode41 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean42 = node37.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode41);
        boolean[] booleanArray43 = scriptOrFnNode41.getParamAndVarConst();
        java.lang.String[] strArray44 = scriptOrFnNode41.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray44);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode51 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean52 = node47.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode51);
        boolean[] booleanArray53 = scriptOrFnNode51.getParamAndVarConst();
        java.lang.String[] strArray54 = scriptOrFnNode51.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode62 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean63 = node58.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode62);
        boolean[] booleanArray64 = scriptOrFnNode62.getParamAndVarConst();
        java.lang.String[] strArray65 = scriptOrFnNode62.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError66 = com.google.javascript.jscomp.JSError.make(diagnosticType56, strArray65);
        com.google.javascript.jscomp.JSError jSError67 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType35, strArray65);
        loggerErrorManager9.report(checkLevel30, jSError67);
        com.google.javascript.jscomp.CheckLevel checkLevel69 = composeWarningsGuard1.level(jSError67);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(booleanArray64);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(jSError66);
        org.junit.Assert.assertNotNull(jSError67);
        org.junit.Assert.assertNull(checkLevel69);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 52, 137, 62);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("<No stack trace available>");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean10 = node5.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode9);
        boolean boolean12 = scriptOrFnNode9.hasParamOrVar("");
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast13 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal3, (com.google.javascript.rhino.Node) scriptOrFnNode9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean boolean22 = scriptOrFnNode19.hasParamOrVar("");
        boolean boolean23 = scriptOrFnNode9.hasChild((com.google.javascript.rhino.Node) scriptOrFnNode19);
        int int25 = scriptOrFnNode19.addVar("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(objectLiteralCast13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType57);
        java.lang.Object obj89 = null;
        boolean boolean90 = objectType88.equals(obj89);
        boolean boolean91 = objectType88.isEnumElementType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node1.addChildAfter(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        int int19 = scriptOrFnNode17.getRegexpCount();
        java.lang.String[] strArray20 = scriptOrFnNode17.getParamAndVarNames();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("EOL");
        node30.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        node30.setJSType(jSType34);
        node30.setCharno(11);
        boolean boolean38 = node23.checkTreeTypeAwareEqualsSilent(node30);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(118, node30, 110, 40);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean48 = node43.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode47);
        boolean[] booleanArray49 = scriptOrFnNode47.getParamAndVarConst();
        boolean boolean50 = node30.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode47);
        boolean boolean51 = scriptOrFnNode17.checkTreeTypeAwareEqualsSilent(node30);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        node1.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node1.setJSType(jSType5);
        node1.setCharno(11);
        int int9 = node1.getType();
        com.google.javascript.rhino.Node node10 = node1.cloneNode();
        java.lang.String str11 = node10.toStringTree();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING EOL\n" + "'", str11.equals("STRING EOL\n"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry2.createNamedType("@IMPLEMENTATION.VERSION@", "goog.exportProperty", 0, 31);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder26 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNotNull(jSType25);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceAst sourceAst1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceAst1, "", true);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = null;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter6, logger7);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Scope scope11 = compiler10.getTopScope();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        try {
            compiler10.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNull(scope11);
        org.junit.Assert.assertNotNull(messageFormatter13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        boolean boolean12 = nodeTraversal11.hasScope();
        int int13 = nodeTraversal11.getLineNumber();
        int int14 = nodeTraversal11.getLineNumber();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.isConstructorRecorded();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode11 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean12 = node7.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode11);
        boolean boolean14 = scriptOrFnNode11.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression16 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode11, ": ");
        boolean boolean17 = jSTypeExpression16.isVarArgs();
        boolean boolean18 = jSDocInfoBuilder1.recordThisType(jSTypeExpression16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = scriptOrFnNode4.hasParamOrVar("Not declared as a constructor");
        scriptOrFnNode4.setSourceName("EOL");
        int int10 = scriptOrFnNode4.addVar("STRING EOL");
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(129, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean18 = node13.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean25 = node20.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node13.addChildAfter(node20, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean37 = node32.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode36);
        boolean boolean39 = scriptOrFnNode36.hasParamOrVar("");
        scriptOrFnNode29.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode36);
        scriptOrFnNode36.addParam("Unknown class name");
        scriptOrFnNode36.setLineno(0);
        com.google.javascript.rhino.Node node45 = scriptOrFnNode4.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode36);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression47 = new com.google.javascript.rhino.JSTypeExpression(node45, "JSDocInfo");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = null;
        compilerOptions0.sourceMapFormat = format1;
        boolean boolean3 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        java.util.Set<java.lang.String> strSet29 = functionType26.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.getGreatestSubtypeWithProperty(jSType39, "");
        boolean boolean42 = jSType41.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSType41.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType43.resolve(errorReporter44, jSTypeStaticScope45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode52 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean53 = node48.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode52);
        boolean[] booleanArray54 = scriptOrFnNode52.getParamAndVarConst();
        int int55 = scriptOrFnNode52.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry32.createFunctionType(jSType46, (com.google.javascript.rhino.Node) scriptOrFnNode52);
        functionType26.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.getGreatestSubtypeWithProperty(jSType61, "");
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        boolean boolean70 = jSType69.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSType69.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = objectType71.resolve(errorReporter72, jSTypeStaticScope73);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean81 = node76.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode80);
        boolean[] booleanArray82 = scriptOrFnNode80.getParamAndVarConst();
        int int83 = scriptOrFnNode80.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry60.createFunctionType(jSType74, (com.google.javascript.rhino.Node) scriptOrFnNode80);
        java.lang.String str85 = functionType84.getReferenceName();
        boolean boolean86 = functionType84.hasReferenceName();
        boolean boolean87 = functionType84.isEmptyType();
        boolean boolean88 = functionType56.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType84);
        java.lang.String str89 = functionType84.getReferenceName();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(booleanArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNull(str89);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        java.lang.String str7 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship12 = defaultCodingConvention0.getClassesDefinedByCall(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("EOL");
        node14.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        node14.setJSType(jSType18);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship20 = defaultCodingConvention0.getClassesDefinedByCall(node14);
        com.google.javascript.rhino.Node node21 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention22 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node23 = null;
        java.lang.String str24 = defaultCodingConvention22.identifyTypeDefAssign(node23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        java.util.List<java.lang.String> strList32 = defaultCodingConvention22.identifyTypeDeclarationCall(node26);
        try {
            node14.replaceChildAfter(node21, node26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(subclassRelationship12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(subclassRelationship20);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(strList32);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 142, 0);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node3.getJSDocInfo();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSDocInfo4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility4 = jSDocInfo0.getVisibility();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility5 = null;
        jSDocInfo0.setVisibility(visibility5);
        boolean boolean7 = jSDocInfo0.hasTypedefType();
        boolean boolean8 = jSDocInfo0.isConstructor();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertNull(visibility4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.defineElement("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        boolean boolean24 = enumType20.isPropertyTypeDeclared("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry28.getNativeObjectType(jSTypeNative29);
        boolean boolean32 = enumType20.defineDeclaredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) objectType30, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("window", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "", 0, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7", (int) '4');
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(100, "goog.exportSymbol");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.getColumnNumber();
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = ecmaError2.getScriptStackTrace(filenameFilter4);
        java.lang.Throwable[] throwableArray6 = ecmaError2.getSuppressed();
        ecmaError2.initSourceName("STRING EOL");
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, nodeArray1, 121, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = functionType26.isNativeObjectType();
        com.google.javascript.rhino.jstype.ObjectType objectType28 = functionType26.toObjectType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(objectType28);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.recordDescription("Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.util.Collection<java.lang.String> strCollection15 = compilerInput3.getProvides();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(strCollection15);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSType jSType21 = enumType20.unboxesTo();
        boolean boolean22 = enumType20.isNativeObjectType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
//        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = null;
//        java.util.logging.Logger logger10 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter9, logger10);
//        compilerInput7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
//        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
//        java.lang.String str15 = compiler13.getAstDotGraph();
//        compiler13.reportCodeChange();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
//        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
//        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
//        compiler13.report(jSError27);
//        int int29 = jSError27.lineNumber;
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(jSModule8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticType17);
//        org.junit.Assert.assertNotNull(node19);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(booleanArray25);
//        org.junit.Assert.assertNotNull(strArray26);
//        org.junit.Assert.assertNotNull(jSError27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        boolean boolean16 = jSType15.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSType15.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = objectType17.resolve(errorReporter18, jSTypeStaticScope19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean[] booleanArray28 = scriptOrFnNode26.getParamAndVarConst();
        int int29 = scriptOrFnNode26.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry6.createFunctionType(jSType20, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.getGreatestSubtypeWithProperty(jSType40, "");
        boolean boolean43 = jSType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = objectType44.resolve(errorReporter45, jSTypeStaticScope46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean54 = node49.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode53);
        boolean[] booleanArray55 = scriptOrFnNode53.getParamAndVarConst();
        int int56 = scriptOrFnNode53.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry33.createFunctionType(jSType47, (com.google.javascript.rhino.Node) scriptOrFnNode53);
        java.lang.String str58 = functionType57.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        boolean boolean71 = jSType70.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType70.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = objectType72.resolve(errorReporter73, jSTypeStaticScope74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean82 = node77.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean[] booleanArray83 = scriptOrFnNode81.getParamAndVarConst();
        int int84 = scriptOrFnNode81.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry61.createFunctionType(jSType75, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean86 = functionType85.isNativeObjectType();
        googleCodingConvention0.applySingletonGetter(functionType30, functionType57, (com.google.javascript.rhino.jstype.ObjectType) functionType85);
        boolean boolean88 = functionType30.isRecordType();
        boolean boolean89 = functionType30.hasCachedValues();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList90 = functionType30.getSubTypes();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(booleanArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNull(functionTypeList90);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        int int29 = functionType26.getMaxArguments();
        boolean boolean30 = functionType26.isBooleanValueType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = objectType7.resolve(errorReporter8, jSTypeStaticScope9);
        com.google.javascript.rhino.jstype.ObjectType objectType11 = objectType7.toObjectType();
        boolean boolean12 = objectType11.isNativeObjectType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("dot");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int0 = com.google.javascript.rhino.Token.REGEXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry2.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope18, "window", "lsh", 0, 105);
        boolean boolean25 = jSTypeRegistry2.hasNamespace("error reporter");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("JSDocInfo", 18, 0);
        java.lang.String str4 = functionNode3.getFunctionName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSDocInfo" + "'", str4.equals("JSDocInfo"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getTypedefType();
        java.util.Collection<java.lang.String> strCollection2 = jSDocInfo0.getReferences();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(strCollection2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        boolean boolean22 = enumType20.hasOwnProperty("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7");
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        boolean boolean29 = jSType28.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = objectType30.resolve(errorReporter31, jSTypeStaticScope32);
        com.google.javascript.rhino.JSDocInfo jSDocInfo35 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression36 = jSDocInfo35.getEnumParameterType();
        java.lang.String str38 = jSDocInfo35.getDescriptionForParameter("Not declared as a constructor");
        objectType30.setPropertyJSDocInfo("@IMPLEMENTATION.VERSION@", jSDocInfo35, true);
        boolean boolean41 = enumType20.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) objectType30);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNull(jSTypeExpression36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getParameterNames();
        boolean boolean4 = jSDocInfo0.isConstructor();
        jSDocInfo0.setDeprecated(false);
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean[] booleanArray7 = scriptOrFnNode5.getParamAndVarConst();
        int int8 = scriptOrFnNode5.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = scriptOrFnNode5.getFirstChild();
        scriptOrFnNode5.setBaseLineno(60);
        try {
            scriptOrFnNode5.setDouble((double) 65);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: TYPEOF [source name: null] [encoded source length: 0] [base line: 60] [end line: -1] 109 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str2 = jSSourceFile1.getName();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Not declared as a constructor" + "'", str2.equals("Not declared as a constructor"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getErrorMessage();
        ecmaError2.initColumnNumber(50);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        int int7 = scriptOrFnNode5.getRegexpCount();
        int int8 = scriptOrFnNode5.getParamCount();
        java.lang.Object obj10 = scriptOrFnNode5.getProp(123);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.rhino.Node node12 = nodeTraversal11.getCurrentNode();
        int int13 = nodeTraversal11.getLineNumber();
        java.lang.String str14 = nodeTraversal11.getSourceName();
        com.google.javascript.jscomp.Compiler compiler15 = nodeTraversal11.getCompiler();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(compiler15);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("hi!");
        boolean boolean5 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean7 = jSDocInfoBuilder1.addAuthor("STRING EOL\n");
        boolean boolean9 = jSDocInfoBuilder1.recordTemplateTypeName("STRING EOL\n");
        boolean boolean10 = jSDocInfoBuilder1.isInterfaceRecorded();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression11 = null;
        boolean boolean12 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Scope scope10 = compiler9.getTopScope();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.lang.String str14 = jSSourceFile13.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        jSSourceFile19.clearCachedSource();
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("STRING EOL\n", generator22);
        com.google.javascript.jscomp.SourceFile.Generator generator25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator25);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile19, jSSourceFile23, jSSourceFile26 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = null;
        try {
            com.google.javascript.jscomp.Result result29 = compiler9.compile(jSSourceFileArray11, jSSourceFileArray27, compilerOptions28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(scope10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Not declared as a constructor" + "'", str14.equals("Not declared as a constructor"));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFileArray27);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceAst sourceAst1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceAst1, "", true);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = null;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter6, logger7);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Scope scope11 = compiler10.getTopScope();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        com.google.javascript.jscomp.SourceAst sourceAst14 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(sourceAst14, "", true);
        com.google.javascript.jscomp.JSModule jSModule18 = compilerInput17.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = null;
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter19, logger20);
        compilerInput17.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler23, callback24);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt26 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter27 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler23, sourceExcerpt26);
        compiler23.reportCodeChange();
        com.google.javascript.jscomp.MessageFormatter messageFormatter30 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler23, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray31 = compiler23.getErrors();
        try {
            compiler23.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNull(scope11);
        org.junit.Assert.assertNotNull(messageFormatter13);
        org.junit.Assert.assertNull(jSModule18);
        org.junit.Assert.assertNotNull(messageFormatter30);
        org.junit.Assert.assertNotNull(jSErrorArray31);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        boolean boolean15 = jSType14.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType14.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType16.resolve(errorReporter17, jSTypeStaticScope18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean26 = node21.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean[] booleanArray27 = scriptOrFnNode25.getParamAndVarConst();
        int int28 = scriptOrFnNode25.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry5.createFunctionType(jSType19, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        boolean boolean30 = functionType29.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        googleCodingConvention0.applySubclassRelationship(functionType29, functionType31, subclassType32);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry37.getGreatestSubtypeWithProperty(jSType38, "");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry43.getGreatestSubtypeWithProperty(jSType44, "");
        boolean boolean47 = jSType46.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSType46.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope50 = null;
        com.google.javascript.rhino.jstype.JSType jSType51 = objectType48.resolve(errorReporter49, jSTypeStaticScope50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean58 = node53.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode57);
        boolean[] booleanArray59 = scriptOrFnNode57.getParamAndVarConst();
        int int60 = scriptOrFnNode57.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry37.createFunctionType(jSType51, (com.google.javascript.rhino.Node) scriptOrFnNode57);
        java.lang.String str62 = functionType61.getReferenceName();
        boolean boolean63 = functionType61.hasReferenceName();
        boolean boolean64 = functionType61.isEmptyType();
        boolean boolean65 = functionType61.isNumber();
        boolean boolean67 = functionType29.defineInferredProperty("", (com.google.javascript.rhino.jstype.JSType) functionType61, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(booleanArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        int int6 = ecmaError2.getLineNumber();
        int int7 = ecmaError2.getColumnNumber();
        java.lang.String str8 = ecmaError2.lineSource();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        jSTypeRegistry2.setTemplateTypeName("goog.exportProperty");
        boolean boolean8 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.getGreatestSubtypeWithProperty(jSType12, "");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.getGreatestSubtypeWithProperty(jSType18, "");
        boolean boolean21 = jSType20.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSType20.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope24 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = objectType22.resolve(errorReporter23, jSTypeStaticScope24);
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry11.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) objectType22);
        boolean boolean28 = jSTypeRegistry2.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) objectType22, "Not declared as a constructor");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = objectType7.resolve(errorReporter8, jSTypeStaticScope9);
        com.google.javascript.rhino.jstype.ObjectType objectType11 = objectType7.toObjectType();
        boolean boolean13 = objectType7.hasOwnProperty("goog.exportProperty");
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean boolean8 = scriptOrFnNode5.hasParamOrVar("");
        int int9 = scriptOrFnNode5.getChildCount();
        int int10 = scriptOrFnNode5.getEncodedSourceEnd();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = null;
        try {
            boolean boolean7 = diagnosticGroupWarningsGuard5.enables(diagnosticGroup6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertNotNull(format1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isConstant();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSTypeExpression4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("STRING EOL", false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        node6.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node6.setJSType(jSType10);
        java.lang.String str15 = node6.toString(true, false, true);
        java.lang.String str16 = node6.toStringTree();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(12, node6, node20, 131, (int) (short) -1);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node20);
        boolean boolean26 = googleCodingConvention0.isPrivate(": ");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("EOL");
        node28.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        node28.setJSType(jSType32);
        java.lang.String str37 = node28.toString(true, false, true);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable38 = node28.siblings();
        boolean boolean39 = googleCodingConvention0.isVarArgsParameter(node28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING EOL" + "'", str15.equals("STRING EOL"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING EOL\n" + "'", str16.equals("STRING EOL\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "STRING EOL" + "'", str37.equals("STRING EOL"));
        org.junit.Assert.assertNotNull(nodeIterable38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        boolean boolean5 = jSDocInfoBuilder1.isConstructorRecorded();
        jSDocInfoBuilder1.markAnnotation("STRING EOL", (int) (short) 0, 117);
        boolean boolean10 = jSDocInfoBuilder1.isJavaDispatch();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str3 = jSDocInfo0.getDescriptionForParameter("Not declared as a constructor");
        boolean boolean4 = jSDocInfo0.isConstant();
        java.util.Set<java.lang.String> strSet5 = jSDocInfo0.getModifies();
        int int6 = jSDocInfo0.getImplementedInterfaceCount();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordType(jSTypeExpression3);
        java.lang.String[] strArray13 = new java.lang.String[] { "", "Not declared as a constructor", "hi!", "EOL", "<No stack trace available>", "", "EOL", "STRING EOL" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        boolean boolean16 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet14);
        boolean boolean17 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        boolean boolean18 = jSDocInfoBuilder1.recordOverride();
        boolean boolean19 = jSDocInfoBuilder1.shouldParseDocumentation();
        boolean boolean20 = jSDocInfoBuilder1.recordNoCompile();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.optimizeParameters = false;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertNull(codingConvention3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = functionType26.isOrdinaryFunction();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean5 = jSTypeRegistry2.isForwardDeclaredType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        boolean boolean14 = jSType13.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType13.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType15.resolve(errorReporter16, jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = objectType15.toObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry2.createEnumType("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) objectType19);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry26.getGreatestSubtypeWithProperty(jSType27, "");
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        boolean boolean36 = jSType35.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSType35.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType37.resolve(errorReporter38, jSTypeStaticScope39);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean47 = node42.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode46);
        boolean[] booleanArray48 = scriptOrFnNode46.getParamAndVarConst();
        int int49 = scriptOrFnNode46.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry26.createFunctionType(jSType40, (com.google.javascript.rhino.Node) scriptOrFnNode46);
        java.lang.String str51 = functionType50.getReferenceName();
        boolean boolean52 = functionType50.hasReferenceName();
        java.util.Set<java.lang.String> strSet53 = functionType50.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.ObjectType objectType54 = functionType50.getImplicitPrototype();
        com.google.javascript.rhino.jstype.ObjectType objectType55 = jSTypeRegistry2.createObjectType("STRING EOL", node23, (com.google.javascript.rhino.jstype.ObjectType) functionType50);
        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        boolean boolean62 = jSType61.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType63 = jSType61.toObjectType();
        boolean boolean64 = objectType63.isInterface();
        boolean boolean65 = objectType63.isTemplateType();
        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry2.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) objectType63);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(enumType20);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(strSet53);
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNotNull(objectType55);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(objectType63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(jSType66);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordJavaDispatch();
        boolean boolean4 = jSDocInfoBuilder1.addReference("Not declared as a constructor");
        boolean boolean5 = jSDocInfoBuilder1.recordExport();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean boolean27 = functionType26.isNativeObjectType();
        com.google.javascript.rhino.Node node28 = functionType26.getParametersNode();
        boolean boolean29 = functionType26.hasInstanceType();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.siblings();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean13 = node8.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean[] booleanArray14 = scriptOrFnNode12.getParamAndVarConst();
        int int15 = scriptOrFnNode12.getSideEffectFlags();
        com.google.javascript.rhino.Node node16 = scriptOrFnNode12.getFirstChild();
        scriptOrFnNode12.setBaseLineno(60);
        int int19 = scriptOrFnNode12.getEncodedSourceEnd();
        java.lang.String str20 = scriptOrFnNode6.checkTreeEquals((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean boolean29 = scriptOrFnNode26.hasParamOrVar("");
        int int30 = scriptOrFnNode26.getChildCount();
        try {
            node1.replaceChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeIterable2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        boolean boolean4 = diagnosticGroup2.matches(diagnosticType3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup2;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel6);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard1, diagnosticGroupWarningsGuard7 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        boolean boolean6 = jSType5.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType5.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = objectType7.resolve(errorReporter8, jSTypeStaticScope9);
        com.google.javascript.rhino.jstype.ObjectType objectType11 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType7);
        boolean boolean12 = objectType7.matchesInt32Context();
        boolean boolean13 = objectType7.isResolved();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry29.getGreatestSubtypeWithProperty(jSType30, "");
        boolean boolean33 = jSType32.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSType32.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = objectType34.resolve(errorReporter35, jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.ObjectType objectType38 = objectType34.toObjectType();
        boolean boolean39 = objectType38.isNumberValueType();
        boolean boolean40 = functionType26.isSubtype((com.google.javascript.rhino.jstype.JSType) objectType38);
        java.lang.Class<?> wildcardClass41 = objectType38.getClass();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.getGreatestSubtypeWithProperty(jSType3, "");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        boolean boolean12 = jSType11.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType11.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType13.resolve(errorReporter14, jSTypeStaticScope15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean23 = node18.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode22);
        boolean[] booleanArray24 = scriptOrFnNode22.getParamAndVarConst();
        int int25 = scriptOrFnNode22.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry2.createFunctionType(jSType16, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        java.lang.String str27 = functionType26.getReferenceName();
        boolean boolean28 = functionType26.hasReferenceName();
        boolean boolean29 = functionType26.isEmptyType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = functionType26.getImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        boolean boolean4 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry7.getGreatestSubtypeWithProperty(jSType8, "");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry13.getGreatestSubtypeWithProperty(jSType14, "");
        boolean boolean17 = jSType16.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSType16.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
        com.google.javascript.rhino.jstype.JSType jSType21 = objectType18.resolve(errorReporter19, jSTypeStaticScope20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean28 = node23.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode27);
        boolean[] booleanArray29 = scriptOrFnNode27.getParamAndVarConst();
        int int30 = scriptOrFnNode27.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry7.createFunctionType(jSType21, (com.google.javascript.rhino.Node) scriptOrFnNode27);
        java.lang.String str32 = functionType31.getReferenceName();
        boolean boolean33 = functionType31.hasReferenceName();
        int int34 = functionType31.getMaxArguments();
        boolean boolean35 = functionType31.isEnumElementType();
        boolean boolean36 = functionType31.isUnknownType();
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry2.createNullableType((com.google.javascript.rhino.jstype.JSType) functionType31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(jSType37);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setDefineToDoubleLiteral("Unknown class name", 0.0d);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getType();
        java.lang.String str4 = jSDocInfo0.getLendsName();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean[] booleanArray7 = scriptOrFnNode5.getParamAndVarConst();
        int int8 = scriptOrFnNode5.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = scriptOrFnNode5.getFirstChild();
        scriptOrFnNode5.setBaseLineno((int) (byte) 10);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        boolean boolean4 = jSDocInfo0.hasParameterType("window");
        java.util.Set<java.lang.String> strSet5 = jSDocInfo0.getParameterNames();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        node1.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node1.setJSType(jSType5);
        node1.setCharno(11);
        node1.putIntProp(2, 4095);
        node1.setType(4);
        try {
            com.google.javascript.rhino.Node node14 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning(": ", "lsh");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility4 = jSDocInfo0.getVisibility();
        java.lang.String str5 = jSDocInfo0.getTemplateTypeName();
        boolean boolean6 = jSDocInfo0.hasReturnType();
        boolean boolean7 = jSDocInfo0.hasBaseType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertNull(visibility4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        defaultCodingConvention4.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.lang.String str11 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship16 = defaultCodingConvention4.getClassesDefinedByCall(node15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard20 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        boolean[] booleanArray32 = scriptOrFnNode30.getParamAndVarConst();
        java.lang.String[] strArray33 = scriptOrFnNode30.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode40 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean41 = node36.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode40);
        boolean[] booleanArray42 = scriptOrFnNode40.getParamAndVarConst();
        java.lang.String[] strArray43 = scriptOrFnNode40.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError44 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray43);
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode51 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean52 = node47.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode51);
        boolean[] booleanArray53 = scriptOrFnNode51.getParamAndVarConst();
        java.lang.String[] strArray54 = scriptOrFnNode51.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make(diagnosticType45, strArray54);
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType24, strArray54);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode60 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean62 = scriptOrFnNode60.hasParamOrVar("STRING EOL");
        java.lang.String[] strArray63 = scriptOrFnNode60.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("", node15, checkLevel19, diagnosticType24, strArray63);
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray75 = new java.lang.String[] { "JSDocInfo", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL", "EOL", "hi!", "hi!" };
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("", 28, 23, diagnosticType68, strArray75);
        com.google.javascript.jscomp.JSError jSError77 = com.google.javascript.jscomp.JSError.make("window", 0, 28, diagnosticType24, strArray75);
        int int78 = jSError77.lineNumber;
        int int79 = jSError77.lineNumber;
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(subclassRelationship16);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jSError44);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(diagnosticType68);
        org.junit.Assert.assertNotNull(strArray75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertNotNull(jSError77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("EOL", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        boolean boolean3 = jSDocInfo0.hasBaseType();
        boolean boolean4 = jSDocInfo0.hasEnumParameterType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, sourceExcerpt12);
        lightweightMessageFormatter13.setColorize(true);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention20 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType25 = null;
        defaultCodingConvention20.applyDelegateRelationship(objectType21, objectType22, objectType23, functionType24, functionType25);
        java.lang.String str27 = defaultCodingConvention20.getExportPropertyFunction();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(": ", (-1), 129);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship32 = defaultCodingConvention20.getClassesDefinedByCall(node31);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup33 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = diagnosticType34.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup33, checkLevel35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean47 = node42.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode46);
        boolean[] booleanArray48 = scriptOrFnNode46.getParamAndVarConst();
        java.lang.String[] strArray49 = scriptOrFnNode46.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean57 = node52.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode56);
        boolean[] booleanArray58 = scriptOrFnNode56.getParamAndVarConst();
        java.lang.String[] strArray59 = scriptOrFnNode56.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray59);
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode67 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean68 = node63.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode67);
        boolean[] booleanArray69 = scriptOrFnNode67.getParamAndVarConst();
        java.lang.String[] strArray70 = scriptOrFnNode67.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("hi!", 0, 7, diagnosticType40, strArray70);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode76 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean78 = scriptOrFnNode76.hasParamOrVar("STRING EOL");
        java.lang.String[] strArray79 = scriptOrFnNode76.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError80 = com.google.javascript.jscomp.JSError.make("", node31, checkLevel35, diagnosticType40, strArray79);
        com.google.javascript.jscomp.DiagnosticType diagnosticType84 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray91 = new java.lang.String[] { "JSDocInfo", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL", "EOL", "hi!", "hi!" };
        com.google.javascript.jscomp.JSError jSError92 = com.google.javascript.jscomp.JSError.make("", 28, 23, diagnosticType84, strArray91);
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("window", 0, 28, diagnosticType40, strArray91);
        try {
            java.lang.String str94 = lightweightMessageFormatter13.formatError(jSError93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(subclassRelationship32);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(booleanArray69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strArray79);
        org.junit.Assert.assertNotNull(jSError80);
        org.junit.Assert.assertNotNull(diagnosticType84);
        org.junit.Assert.assertNotNull(strArray91);
        org.junit.Assert.assertNotNull(jSError92);
        org.junit.Assert.assertNotNull(jSError93);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        jsAst3.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromFile("");
        try {
            jsAst3.setSourceFile(sourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel2, "");
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.instrumentationTemplate = "STRING EOL";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "STRING EOL");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceAst sourceAst5 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceAst5, "", true);
        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput8.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = null;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter10, logger11);
        compilerInput8.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.Scope scope15 = compiler14.getTopScope();
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14, true);
        try {
            com.google.javascript.rhino.Node node18 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection3 = googleCodingConvention0.getAssertionFunctions();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean7 = googleCodingConvention4.isExported("STRING EOL", false);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry16.getGreatestSubtypeWithProperty(jSType17, "");
        boolean boolean20 = jSType19.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSType19.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
        com.google.javascript.rhino.jstype.JSType jSType24 = objectType21.resolve(errorReporter22, jSTypeStaticScope23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean31 = node26.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode30);
        boolean[] booleanArray32 = scriptOrFnNode30.getParamAndVarConst();
        int int33 = scriptOrFnNode30.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry10.createFunctionType(jSType24, (com.google.javascript.rhino.Node) scriptOrFnNode30);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry37.getGreatestSubtypeWithProperty(jSType38, "");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry43.getGreatestSubtypeWithProperty(jSType44, "");
        boolean boolean47 = jSType46.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSType46.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope50 = null;
        com.google.javascript.rhino.jstype.JSType jSType51 = objectType48.resolve(errorReporter49, jSTypeStaticScope50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean58 = node53.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode57);
        boolean[] booleanArray59 = scriptOrFnNode57.getParamAndVarConst();
        int int60 = scriptOrFnNode57.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry37.createFunctionType(jSType51, (com.google.javascript.rhino.Node) scriptOrFnNode57);
        java.lang.String str62 = functionType61.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, false);
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry65.getGreatestSubtypeWithProperty(jSType66, "");
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69, false);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry71.getGreatestSubtypeWithProperty(jSType72, "");
        boolean boolean75 = jSType74.matchesNumberContext();
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSType74.toObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        com.google.javascript.rhino.jstype.JSType jSType79 = objectType76.resolve(errorReporter77, jSTypeStaticScope78);
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode85 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean86 = node81.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode85);
        boolean[] booleanArray87 = scriptOrFnNode85.getParamAndVarConst();
        int int88 = scriptOrFnNode85.getSideEffectFlags();
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry65.createFunctionType(jSType79, (com.google.javascript.rhino.Node) scriptOrFnNode85);
        boolean boolean90 = functionType89.isNativeObjectType();
        googleCodingConvention4.applySingletonGetter(functionType34, functionType61, (com.google.javascript.rhino.jstype.ObjectType) functionType89);
        boolean boolean92 = functionType34.isRecordType();
        boolean boolean93 = functionType34.hasCachedValues();
        com.google.javascript.rhino.jstype.FunctionType functionType94 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType95 = null;
        googleCodingConvention0.applySubclassRelationship(functionType34, functionType94, subclassType95);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(booleanArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(booleanArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        java.lang.String str6 = ecmaError2.getSourceName();
        java.lang.String str7 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ": " + "'", str7.equals(": "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        node1.putBooleanProp((int) '4', false);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node1.setJSType(jSType5);
        node1.setCharno(11);
        node1.putIntProp(2, 4095);
        node1.setType(4);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean20 = node15.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean27 = node22.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode26);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        node15.addChildAfter(node22, (com.google.javascript.rhino.Node) scriptOrFnNode31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode38 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean39 = node34.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode38);
        boolean boolean41 = scriptOrFnNode38.hasParamOrVar("");
        scriptOrFnNode31.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode38);
        scriptOrFnNode38.addParam("Unknown class name");
        scriptOrFnNode38.setLineno(0);
        boolean boolean47 = node1.hasChild((com.google.javascript.rhino.Node) scriptOrFnNode38);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder1.forConstructor();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean11 = node6.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode10);
        boolean[] booleanArray12 = scriptOrFnNode10.getParamAndVarConst();
        int int13 = scriptOrFnNode10.getSideEffectFlags();
        com.google.javascript.rhino.Node node14 = scriptOrFnNode10.getFirstChild();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder15 = functionBuilder1.withParamsNode((com.google.javascript.rhino.Node) scriptOrFnNode10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean21 = scriptOrFnNode19.hasParamOrVar("STRING EOL");
        int int22 = scriptOrFnNode19.getLineno();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder23 = functionBuilder1.withSourceNode((com.google.javascript.rhino.Node) scriptOrFnNode19);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(functionBuilder15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 109 + "'", int22 == 109);
        org.junit.Assert.assertNotNull(functionBuilder23);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL", 37, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(100, node4, 150, 17);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        boolean boolean30 = compilerOptions0.ideMode;
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean6 = node1.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean boolean8 = scriptOrFnNode5.hasParamOrVar("");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, ": ");
        scriptOrFnNode5.setVarArgs(false);
        int int13 = scriptOrFnNode5.getRegexpCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = null;
        boolean boolean9 = diagnosticGroup7.matches(diagnosticType8);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        boolean boolean12 = diagnosticGroup7.matches(diagnosticType11);
        java.lang.String[] strArray13 = null;
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("STRING EOL", (int) (byte) 100, 42, diagnosticType11, strArray13);
        java.lang.String[] strArray18 = new java.lang.String[] { "<No stack trace available>", "window", "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 146, 102, checkLevel3, diagnosticType11, strArray18);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean7 = node2.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode6);
        boolean boolean9 = scriptOrFnNode6.hasParamOrVar("");
        com.google.javascript.rhino.Node node10 = scriptOrFnNode6.removeFirstChild();
        int int13 = scriptOrFnNode6.addRegexp("STRING EOL", "");
        try {
            java.lang.String str14 = com.google.javascript.rhino.ScriptRuntime.getMessage1("<No stack trace available>", (java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <No stack trace available>");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy3 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean4 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy3 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy3.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("INSTANCEOF", "<No stack trace available>", ": ", 34, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at hi! line 0 : 7", 28);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test491");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("EOL");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
//        boolean boolean9 = node4.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode8);
//        boolean[] booleanArray10 = scriptOrFnNode8.getParamAndVarConst();
//        java.lang.String[] strArray11 = scriptOrFnNode8.getParamAndVarNames();
//        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray11);
//        com.google.javascript.jscomp.CheckLevel checkLevel13 = jSError12.level;
//        java.lang.String str14 = jSError12.toString();
//        com.google.javascript.jscomp.CheckLevel checkLevel15 = jSError12.level;
//        compilerOptions0.checkMissingReturn = checkLevel15;
//        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType2);
//        org.junit.Assert.assertNotNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(booleanArray10);
//        org.junit.Assert.assertNotNull(strArray11);
//        org.junit.Assert.assertNotNull(jSError12);
//        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str14.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
//        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "<No stack trace available>");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str5 = jSSourceFile2.getCode();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.toString();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str5.equals("com.google.javascript.rhino.EcmaError: : "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter12 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9);
        try {
            boolean boolean13 = compiler9.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = jSDocInfo0.getEnumParameterType();
        java.lang.String str3 = jSDocInfo0.getDescriptionForParameter("Not declared as a constructor");
        boolean boolean4 = jSDocInfo0.isConstant();
        boolean boolean5 = jSDocInfo0.hasReturnType();
        org.junit.Assert.assertNull(jSTypeExpression1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_PARAMETER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0);
        boolean boolean2 = node1.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node1.getJsDocBuilderForNode();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean9 = scriptOrFnNode7.hasParamOrVar("Not declared as a constructor");
        com.google.javascript.rhino.Node node10 = node1.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode7);
        boolean boolean11 = node10.isNoSideEffectsCall();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable12 = node10.siblings();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(nodeIterable12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.toString();
        java.lang.String str2 = jSDocInfo0.getFileOverview();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getThisType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSDocInfo" + "'", str1.equals("JSDocInfo"));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(jSTypeExpression3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel14, "STRING EOL");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("EOL");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(32, 109, 6);
        boolean boolean24 = node19.checkTreeTypeAwareEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray25 = scriptOrFnNode23.getParamAndVarConst();
        java.lang.String[] strArray26 = scriptOrFnNode23.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        loggerErrorManager10.report(checkLevel14, jSError27);
        compilerOptions0.reportMissingOverride = checkLevel14;
        boolean boolean30 = compilerOptions0.tightenTypes;
        boolean boolean31 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }
}

