import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        try {
            com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '#', node1, node2, node3, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4', node1, node2, node3, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node1, node2, node3, node4, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("", "", "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "or" + "'", str1.equals("or"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!" };
        try {
            com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make("hi!", 100, (int) (byte) 0, diagnosticType3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("or", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.NO_DUPLICATE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_CONST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("or", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray8 = new java.lang.String[] { "or", "", "or" };
        try {
            com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("or", (int) '4', (int) (byte) 1, checkLevel3, diagnosticType4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        try {
            com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((-2), node1, node2, node3, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("or");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.jscomp.JSModule jSModule0 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        java.lang.String[] strArray10 = new java.lang.String[] { "", "hi!", "", "hi!", "hi!", "or" };
        try {
            com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("hi!", (int) (short) 0, (int) (byte) 0, diagnosticType3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        node14.setVarArgs(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        int int31 = scriptOrFnNode29.getFunctionCount();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode40 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode44 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode36, (com.google.javascript.rhino.Node) scriptOrFnNode40, (com.google.javascript.rhino.Node) scriptOrFnNode44);
        try {
            com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(100, node14, (com.google.javascript.rhino.Node) scriptOrFnNode29, node45, (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        try {
            com.google.javascript.jscomp.JSModule[] jSModuleArray3 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray9 = new java.lang.String[] { "", "hi!", "or", "INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100" };
        try {
            com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("", (int) (short) -1, 15, checkLevel3, diagnosticType4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage3("goog.exportSymbol", (java.lang.Object) 6, (java.lang.Object) "", (java.lang.Object) "goog.exportSymbol");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportSymbol");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast18 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal1, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        java.lang.Object obj3 = null;
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage3("or", (java.lang.Object) 100.0d, (java.lang.Object) jSTypeNative2, obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property or");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("or");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        boolean boolean15 = scriptOrFnNode5.isVarArgs();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode20, (com.google.javascript.rhino.Node) scriptOrFnNode24, (com.google.javascript.rhino.Node) scriptOrFnNode28);
        try {
            com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(12, (com.google.javascript.rhino.Node) scriptOrFnNode5, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "", (int) (byte) 1);
        int int5 = tokenStream4.getToken();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str5 = jSSourceFile4.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str9 = jSSourceFile8.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str13 = jSSourceFile12.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str17 = jSSourceFile16.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile12, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, jSSourceFileArray18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str27 = jSSourceFile26.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile26 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList29 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList29, jSSourceFileArray28);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = null;
        try {
            com.google.javascript.jscomp.Result result32 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList29, compilerOptions31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "or" + "'", str5.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "or" + "'", str17.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFileArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "or" + "'", str27.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType jSType5 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] { jSType5 };
//        try {
//            com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createConstructorType(jSType3, false, jSTypeArray6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = scriptOrFnNode5.getJSDocInfo();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("", nodeList1, (com.google.javascript.rhino.Node) scriptOrFnNode5, 49, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSDocInfo6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str8 = jSSourceFile7.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile12, jSSourceFile15, jSSourceFile18 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList20 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList20, jSSourceFileArray19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str28 = jSSourceFile27.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray35 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24, jSSourceFile27, jSSourceFile31, jSSourceFile34 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList36 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList36, jSSourceFileArray35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        try {
            com.google.javascript.jscomp.Result result39 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList20, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList36, compilerOptions38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "or" + "'", str8.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFileArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "or" + "'", str28.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFileArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        int int3 = context1.getLanguageVersion();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        node14.setVarArgs(true);
        boolean boolean17 = node14.isVarArgs();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 100, node14);
        try {
            int int20 = node18.getExistingIntProp((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node5 = scriptOrFnNode3.getAncestor(49);
        try {
            com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node5 = scriptOrFnNode3.getAncestor(49);
        try {
            com.google.javascript.rhino.Node node7 = node5.getAncestor((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        boolean boolean17 = scriptOrFnNode12.isOptionalArg();
        com.google.javascript.rhino.Node node18 = scriptOrFnNode12.getNext();
        try {
            node18.detachChildren();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(node18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region4 = jSSourceFile2.getRegion((int) 'a');
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray21 = scriptOrFnNode20.getParamAndVarNames();
        boolean boolean22 = scriptOrFnNode20.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node23 = null;
        try {
            scriptOrFnNode12.replaceChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode20, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.Collection<com.google.javascript.jscomp.JSModule> jSModuleCollection0 = null;
        try {
            com.google.javascript.jscomp.JSModule[] jSModuleArray1 = com.google.javascript.jscomp.JSModule.sortJsModules(jSModuleCollection0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        try {
            int int15 = scriptOrFnNode8.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode4.setBaseLineno(17);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean11 = scriptOrFnNode10.isNoSideEffectsCall();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20, (com.google.javascript.rhino.Node) scriptOrFnNode24);
        try {
            com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode24, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry2.createFunctionTypeWithNewReturnType(functionType6, jSType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        try {
            com.google.javascript.rhino.jstype.EnumType enumType8 = jSTypeRegistry2.createEnumType("", jSType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16);
        int int18 = scriptOrFnNode16.getFunctionCount();
        scriptOrFnNode16.removeParamOrVar("");
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast21 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal3, (com.google.javascript.rhino.Node) scriptOrFnNode16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Object obj0 = null;
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        boolean boolean8 = jSTypeRegistry2.canPropertyBeDefined(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry2.createOptionalNullableType(jSType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError4 = null;
        loggerErrorManager2.println(checkLevel3, jSError4);
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = null;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter6, logger7);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError10 = null;
        loggerErrorManager8.println(checkLevel9, jSError10);
        com.google.javascript.jscomp.JSError jSError12 = null;
        try {
            loggerErrorManager2.report(checkLevel9, jSError12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        try {
            com.google.javascript.rhino.jstype.EnumType enumType7 = jSTypeRegistry2.createEnumType("", jSType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        scriptOrFnNode8.setCompilerData((java.lang.Object) (byte) 0);
        scriptOrFnNode8.setOptionalArg(false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { scriptOrFnNode9 };
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(42, nodeArray15, (int) (short) 100, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        java.lang.String str3 = context1.getImplementationVersion();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        try {
            context1.unseal((java.lang.Object) jSTypeNative4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "goog.exportSymbol", "@IMPLEMENTATION.VERSION@");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("@IMPLEMENTATION.VERSION@");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property @IMPLEMENTATION.VERSION@");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str17 = jSSourceFile16.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, jSSourceFileArray18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str24 = jSSourceFile23.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str40 = jSSourceFile39.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray42 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile27, jSSourceFile30, jSSourceFile33, jSSourceFile36, jSSourceFile39 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList43 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList43, jSSourceFileArray42);
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = null;
        try {
            com.google.javascript.jscomp.Result result46 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList43, compilerOptions45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "or" + "'", str17.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFileArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "or" + "'", str24.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "or" + "'", str40.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFileArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str5 = jSSourceFile4.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str12 = jSSourceFile11.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11, false);
        try {
            jSModule1.addAfter(compilerInput8, compilerInput15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "or" + "'", str5.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "or" + "'", str12.equals("or"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        try {
            compiler0.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        int int15 = scriptOrFnNode13.getFunctionCount();
        scriptOrFnNode13.removeParamOrVar("");
        com.google.javascript.rhino.Node node18 = scriptOrFnNode13.getFirstChild();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean23 = scriptOrFnNode22.wasEmptyNode();
        try {
            com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(42, node18, (com.google.javascript.rhino.Node) scriptOrFnNode22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode19, (com.google.javascript.rhino.Node) scriptOrFnNode23, (com.google.javascript.rhino.Node) scriptOrFnNode27);
        node28.setVarArgs(true);
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(17, (com.google.javascript.rhino.Node) scriptOrFnNode5, node28, 4095, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            com.google.javascript.rhino.Node node3 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        java.lang.String str14 = scriptOrFnNode4.toString();
        try {
            java.lang.String str15 = scriptOrFnNode4.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100" + "'", str14.equals("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray17 = scriptOrFnNode16.getParamAndVarNames();
        boolean boolean18 = scriptOrFnNode16.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry9.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode16, objectType19);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType6, objectType20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectType20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry2.createFunctionTypeWithNewReturnType(functionType3, (com.google.javascript.rhino.jstype.JSType) objectType17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((-2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("language version", "", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        try {
            int int4 = compiler0.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str4 = jSSourceFile3.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region9 = jSSourceFile7.getRegion((int) 'a');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str20 = jSSourceFile19.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray24 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3, jSSourceFile7, jSSourceFile12, jSSourceFile19, jSSourceFile23 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList25 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList25, jSSourceFileArray24);
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule30 = new com.google.javascript.jscomp.JSModule("or");
        jSModule28.addDependency(jSModule30);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet32 = jSModule28.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule jSModule34 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule36 = new com.google.javascript.jscomp.JSModule("or");
        jSModule34.addDependency(jSModule36);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet38 = jSModule34.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule jSModule40 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule42 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule44 = new com.google.javascript.jscomp.JSModule("or");
        jSModule42.addDependency(jSModule44);
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] { jSModule28, jSModule34, jSModule40, jSModule42 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList47 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList47, jSModuleArray46);
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = null;
        try {
            com.google.javascript.jscomp.Result result50 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList25, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList47, compilerOptions49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "or" + "'", str4.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNull(region9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFileArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jSModuleSet32);
        org.junit.Assert.assertNotNull(jSModuleSet38);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        try {
            compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = null;
        try {
            com.google.javascript.jscomp.Result result9 = compiler0.compile(jSSourceFile5, jSSourceFileArray7, compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope4 = compiler3.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState5 = compiler3.getState();
        compiler0.setState(intermediateState5);
        try {
            compiler0.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNotNull(intermediateState5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("@IMPLEMENTATION.VERSION@", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.reportCodeChange();
        try {
            compiler0.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        int int15 = scriptOrFnNode13.getFunctionCount();
        scriptOrFnNode13.removeParamOrVar("");
        com.google.javascript.rhino.Node node18 = scriptOrFnNode13.getFirstChild();
        java.lang.String str19 = scriptOrFnNode13.toString();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode24, (com.google.javascript.rhino.Node) scriptOrFnNode28, (com.google.javascript.rhino.Node) scriptOrFnNode32);
        scriptOrFnNode32.removeParamOrVar("@IMPLEMENTATION.VERSION@");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode40 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode44 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode48 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode40, (com.google.javascript.rhino.Node) scriptOrFnNode44, (com.google.javascript.rhino.Node) scriptOrFnNode48);
        scriptOrFnNode44.setCompilerData((java.lang.Object) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode60 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode64 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode56, (com.google.javascript.rhino.Node) scriptOrFnNode60, (com.google.javascript.rhino.Node) scriptOrFnNode64);
        boolean boolean66 = scriptOrFnNode56.isVarArgs();
        boolean boolean68 = scriptOrFnNode56.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode73 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode77 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode81 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode73, (com.google.javascript.rhino.Node) scriptOrFnNode77, (com.google.javascript.rhino.Node) scriptOrFnNode81);
        boolean boolean83 = scriptOrFnNode73.isVarArgs();
        boolean boolean85 = scriptOrFnNode73.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node86 = scriptOrFnNode56.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode73);
        try {
            com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(40, (com.google.javascript.rhino.Node) scriptOrFnNode13, (com.google.javascript.rhino.Node) scriptOrFnNode32, (com.google.javascript.rhino.Node) scriptOrFnNode44, node86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100" + "'", str19.equals("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(node86);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str7 = jSSourceFile6.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6, true);
        com.google.javascript.rhino.Node node11 = compiler0.parse(jSSourceFile6);
        java.lang.String str12 = jSSourceFile6.getOriginalPath();
        java.lang.String str14 = jSSourceFile6.getLine((int) (byte) 1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "or" + "'", str7.equals("or"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "or" + "'", str12.equals("or"));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            compiler0.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str5 = jSSourceFile4.getOriginalPath();
        java.lang.String str6 = jSSourceFile4.toString();
        com.google.javascript.jscomp.JSModule[] jSModuleArray7 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = null;
        try {
            com.google.javascript.jscomp.Result result9 = compiler0.compile(jSSourceFile4, jSModuleArray7, compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSModuleArray7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            boolean boolean3 = compiler0.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportSymbol", "hi!", "hi!");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.FunctionNode functionNode17 = null;
        try {
            int int18 = scriptOrFnNode12.addFunction(functionNode17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        try {
            boolean boolean4 = compiler3.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getOptimizationLevel();
        context1.setCompileFunctionsWithDynamicScope(true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context1.addPropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isQuotedString();
        boolean boolean7 = scriptOrFnNode5.isNoSideEffectsCall();
        java.lang.String str8 = closureCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal11 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback10);
        com.google.javascript.jscomp.Compiler compiler12 = nodeTraversal11.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode17, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25);
        int int27 = scriptOrFnNode25.getFunctionCount();
        scriptOrFnNode25.removeParamOrVar("");
        boolean boolean30 = scriptOrFnNode25.isOptionalArg();
        int int33 = scriptOrFnNode25.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast34 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal11, (com.google.javascript.rhino.Node) scriptOrFnNode25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(compiler12);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 42, 12, 42);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isQuotedString();
        com.google.javascript.rhino.Node node5 = scriptOrFnNode3.removeChildren();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = scriptOrFnNode13.getJSDocInfo();
        try {
            scriptOrFnNode3.replaceChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(jSDocInfo14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) '#', 4095);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 4095.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        java.lang.String str8 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportSymbol" + "'", str8.equals("goog.exportSymbol"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate61 = null;
        try {
            boolean boolean62 = objectType57.setValidator(jSTypePredicate61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry2.getType("()");
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(jSType6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("<No stack trace available>", "<No stack trace available>");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        java.lang.String str4 = ecmaError1.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError" + "'", str4.equals("TypeError"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(49);
        boolean boolean2 = node1.isOnlyModifiesThisCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        lightweightMessageFormatter11.setColorize(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray22 = scriptOrFnNode21.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType17, strArray22);
        try {
            java.lang.String str24 = lightweightMessageFormatter11.formatWarning(jSError23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("goog.global", "<No stack trace available>");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", "EOF", "()", "goog.exportSymbol");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Object obj0 = null;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean7 = scriptOrFnNode6.isQuotedString();
        boolean boolean8 = scriptOrFnNode6.isNoSideEffectsCall();
        java.lang.String str9 = closureCodingConvention1.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode6);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode15, (com.google.javascript.rhino.Node) scriptOrFnNode19, (com.google.javascript.rhino.Node) scriptOrFnNode23);
        node24.setVarArgs(true);
        boolean boolean27 = node24.isVarArgs();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 100, node24);
        node24.setCharno((int) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode40 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode44 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode36, (com.google.javascript.rhino.Node) scriptOrFnNode40, (com.google.javascript.rhino.Node) scriptOrFnNode44);
        node45.setVarArgs(true);
        boolean boolean48 = node45.isVarArgs();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 100, node45);
        node45.setCharno((int) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode60 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode64 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode56, (com.google.javascript.rhino.Node) scriptOrFnNode60, (com.google.javascript.rhino.Node) scriptOrFnNode64);
        node65.setVarArgs(true);
        java.lang.String str68 = node45.checkTreeEquals(node65);
        java.lang.String str69 = closureCodingConvention1.extractClassNameIfProvide(node24, node45);
        java.lang.RuntimeException runtimeException70 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0, (java.lang.Object) str69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportSymbol" + "'", str2.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(runtimeException70);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            com.google.javascript.rhino.Context.reportWarning("EOF");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "return" + "'", str1.equals("return"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = scriptOrFnNode5.getJSDocInfo();
        scriptOrFnNode5.putBooleanProp(0, false);
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        boolean boolean12 = closureCodingConvention0.isConstant("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(jSDocInfo6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        java.lang.String str4 = jSSourceFile2.toString();
        java.io.Reader reader5 = jSSourceFile2.getCodeReader();
        java.lang.String str6 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            com.google.javascript.rhino.Context.reportWarning("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", "goog.exportSymbol", 4, "goog.exportSymbol", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        boolean boolean15 = scriptOrFnNode5.isVarArgs();
        boolean boolean17 = scriptOrFnNode5.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = scriptOrFnNode5.children();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode22.setBaseLineno(17);
        int int25 = scriptOrFnNode22.getEncodedSourceEnd();
        java.lang.String[] strArray26 = scriptOrFnNode22.getParamAndVarNames();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str28 = closureCodingConvention27.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode41 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode33, (com.google.javascript.rhino.Node) scriptOrFnNode37, (com.google.javascript.rhino.Node) scriptOrFnNode41);
        node42.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship45 = closureCodingConvention27.getDelegateRelationship(node42);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention46 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str47 = closureCodingConvention46.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode51 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean52 = scriptOrFnNode51.isQuotedString();
        boolean boolean53 = scriptOrFnNode51.isNoSideEffectsCall();
        java.lang.String str54 = closureCodingConvention46.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode51);
        boolean boolean55 = closureCodingConvention27.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode51);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode60 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean61 = scriptOrFnNode60.wasEmptyNode();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode60);
        scriptOrFnNode60.removeParamOrVar("goog.exportSymbol");
        scriptOrFnNode60.putBooleanProp((int) (short) -1, true);
        try {
            com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode22, (com.google.javascript.rhino.Node) scriptOrFnNode51, (com.google.javascript.rhino.Node) scriptOrFnNode60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportSymbol" + "'", str28.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "goog.exportSymbol" + "'", str47.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError4 = null;
        loggerErrorManager2.println(checkLevel3, jSError4);
        double double6 = loggerErrorManager2.getTypedPercent();
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.SourceFile sourceFile7 = null;
        try {
            compilerInput6.setSourceFile(sourceFile7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(4, "<No stack trace available>");
        boolean boolean3 = node2.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.Parser parser0 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str4 = jSSourceFile3.getOriginalPath();
        java.lang.String str5 = jSSourceFile3.toString();
        java.io.Reader reader6 = jSSourceFile3.getCodeReader();
        try {
            com.google.javascript.rhino.TokenStream tokenStream9 = new com.google.javascript.rhino.TokenStream(parser0, reader6, "com.google.javascript.rhino.EcmaError: : hi! (null#1)", 120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(reader6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, true);
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry30.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray38 = scriptOrFnNode37.getParamAndVarNames();
        boolean boolean39 = scriptOrFnNode37.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType40 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType41 = jSTypeRegistry30.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode37, objectType40);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair42 = objectType27.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry60.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode67 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray68 = scriptOrFnNode67.getParamAndVarNames();
        boolean boolean69 = scriptOrFnNode67.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType70 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSTypeRegistry60.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode67, objectType70);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair72 = objectType57.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType71);
        boolean boolean74 = objectType41.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType71, false);
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75, true);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        boolean boolean80 = jSTypeRegistry77.declareType("", jSType79);
        com.google.javascript.rhino.ErrorReporter errorReporter81 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry83 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter81, true);
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry83.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode90 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray91 = scriptOrFnNode90.getParamAndVarNames();
        boolean boolean92 = scriptOrFnNode90.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType93 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType94 = jSTypeRegistry83.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode90, objectType93);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray95 = new com.google.javascript.rhino.jstype.JSType[] { objectType94 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList96 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean97 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList96, jSTypeArray95);
        com.google.javascript.rhino.Node node98 = jSTypeRegistry77.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList96);
        com.google.javascript.rhino.jstype.FunctionType functionType99 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType41, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList96);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(objectType41);
        org.junit.Assert.assertNotNull(typePair42);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(strArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(typePair72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNull(jSType85);
        org.junit.Assert.assertNotNull(strArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(objectType94);
        org.junit.Assert.assertNotNull(jSTypeArray95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(node98);
        org.junit.Assert.assertNotNull(functionType99);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        int int12 = compiler0.getErrorCount();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput14 = compiler0.getInput("goog.global");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean7 = composeWarningsGuard3.disables(diagnosticGroup6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        boolean boolean9 = composeWarningsGuard3.disables(diagnosticGroup8);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        try {
            int int4 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeActivationName("");
        int int5 = context1.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, 100L);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("return", "language version", 2, "", 12);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: return (language version#2)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, true);
        com.google.javascript.rhino.Node node17 = compiler7.parse(jSSourceFile12);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        com.google.javascript.rhino.Node node19 = compilerInput4.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        try {
            java.util.Collection<java.lang.String> strCollection20 = compilerInput4.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20);
        boolean boolean22 = scriptOrFnNode12.isVarArgs();
        boolean boolean24 = scriptOrFnNode12.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean26 = scriptOrFnNode12.isSyntheticBlock();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("return", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20);
        boolean boolean22 = scriptOrFnNode12.isVarArgs();
        boolean boolean24 = scriptOrFnNode12.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags26 = new com.google.javascript.rhino.Node.SideEffectFlags();
        boolean boolean27 = sideEffectFlags26.areAllFlagsSet();
        try {
            scriptOrFnNode12.setSideEffectFlags(sideEffectFlags26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got INSTANCEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention10 = compiler0.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getOptimizationLevel();
        context1.setCompileFunctionsWithDynamicScope(true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context1.removePropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder4 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str7 = closureCodingConvention6.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode11 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean12 = scriptOrFnNode11.isNoSideEffectsCall();
        boolean boolean13 = closureCodingConvention6.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode11);
        try {
            compiler0.toSource(codeBuilder4, 49, (com.google.javascript.rhino.Node) scriptOrFnNode11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportSymbol" + "'", str7.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        boolean boolean14 = objectType13.isFunctionPrototypeType();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray4 = scriptOrFnNode3.getParamAndVarNames();
        scriptOrFnNode3.addParam("or");
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = objectType27.unboxesTo();
        try {
            boolean boolean62 = jSType61.isNullType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNull(jSType61);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        ecmaError1.initLineSource("hi!");
        java.lang.Throwable[] throwableArray4 = ecmaError1.getSuppressed();
        int int5 = ecmaError1.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Object obj0 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0, (java.lang.Object) "or");
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(runtimeException4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("or", (int) (short) 10, (int) '#');
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getOptimizationLevel();
        context1.setCompileFunctionsWithDynamicScope(true);
        boolean boolean5 = context1.hasCompileFunctionsWithDynamicScope();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        lightweightMessageFormatter11.setColorize(true);
        lightweightMessageFormatter11.setColorize(true);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("null", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isQuotedString();
        java.lang.String str5 = scriptOrFnNode3.getSourceName();
        int int6 = scriptOrFnNode3.getLineno();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention3 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str4 = closureCodingConvention3.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection5 = closureCodingConvention3.getAssertionFunctions();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(0, "<No stack trace available>");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode13, (com.google.javascript.rhino.Node) scriptOrFnNode17, (com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.lang.String str23 = closureCodingConvention3.extractClassNameIfRequire(node8, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("or");
        jSModule25.addDependency(jSModule27);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList29 = jSModule27.getInputs();
        try {
            java.lang.String str30 = com.google.javascript.rhino.ScriptRuntime.getMessage4("function ({1920498015}): {823343230}", (java.lang.Object) "EOF", (java.lang.Object) compiler2, (java.lang.Object) str23, (java.lang.Object) compilerInputList29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property function ({1920498015}): {823343230}");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(compilerInputList29);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("or");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property or");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(160);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        int int4 = ecmaError1.columnNumber();
        java.lang.String str5 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError: goog.exportSymbol" + "'", str5.equals("TypeError: goog.exportSymbol"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.wasEmptyNode();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode5);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) 10, (java.lang.Object) scriptOrFnNode5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        try {
            boolean boolean6 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        scriptOrFnNode4.removeParamOrVar("goog.exportSymbol");
        java.lang.Appendable appendable9 = null;
        try {
            scriptOrFnNode4.appendStringTree(appendable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray18 = scriptOrFnNode17.getParamAndVarNames();
        boolean boolean19 = scriptOrFnNode17.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType20 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry10.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode17, objectType20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        boolean boolean33 = scriptOrFnNode31.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry24.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode31, objectType34);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair36 = objectType21.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType35);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, true);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry40.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray48 = scriptOrFnNode47.getParamAndVarNames();
        boolean boolean49 = scriptOrFnNode47.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType50 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry40.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode47, objectType50);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, true);
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry54.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode61 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray62 = scriptOrFnNode61.getParamAndVarNames();
        boolean boolean63 = scriptOrFnNode61.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType64 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType65 = jSTypeRegistry54.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode61, objectType64);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair66 = objectType51.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType65);
        boolean boolean68 = objectType35.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType65, false);
        com.google.javascript.rhino.jstype.JSType jSType69 = objectType35.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        boolean boolean75 = jSTypeRegistry72.declareType("", jSType74);
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry78.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode85 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray86 = scriptOrFnNode85.getParamAndVarNames();
        boolean boolean87 = scriptOrFnNode85.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType88 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType89 = jSTypeRegistry78.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode85, objectType88);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] { objectType89 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList91 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean92 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList91, jSTypeArray90);
        com.google.javascript.rhino.Node node93 = jSTypeRegistry72.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList91);
        com.google.javascript.rhino.jstype.FunctionType functionType94 = jSTypeRegistry7.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType35, node93);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable95 = functionType94.getParameters();
        com.google.javascript.rhino.jstype.ObjectType objectType96 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType94);
        com.google.javascript.rhino.JSDocInfo jSDocInfo97 = objectType96.getJSDocInfo();
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(typePair36);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectType65);
        org.junit.Assert.assertNotNull(typePair66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(functionType94);
        org.junit.Assert.assertNotNull(nodeIterable95);
        org.junit.Assert.assertNotNull(objectType96);
        org.junit.Assert.assertNull(jSDocInfo97);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler10, callback11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope14 = compiler13.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState15 = compiler13.getState();
        compiler10.setState(intermediateState15);
        compiler0.setState(intermediateState15);
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule21 = new com.google.javascript.jscomp.JSModule("or");
        jSModule19.addDependency(jSModule21);
        com.google.javascript.jscomp.JSModule jSModule24 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("or");
        jSModule24.addDependency(jSModule26);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet28 = jSModule24.getThisAndAllDependencies();
        jSModule21.addDependency(jSModule24);
        try {
            java.lang.String str30 = compiler0.toSource(jSModule21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(scope14);
        org.junit.Assert.assertNotNull(intermediateState15);
        org.junit.Assert.assertNotNull(jSModuleSet28);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        ecmaError1.initLineSource("hi!");
        java.lang.String str4 = ecmaError1.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        boolean boolean1 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesThis();
        int int3 = sideEffectFlags0.valueOf();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("error reporter", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback16);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str21 = jSSourceFile20.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile20);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile20, true);
        com.google.javascript.rhino.Node node25 = compiler15.parse(jSSourceFile20);
        com.google.javascript.rhino.Node node26 = compiler15.getRoot();
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) boolean14, (java.lang.Object) node26);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "or" + "'", str21.equals("or"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(runtimeException27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        boolean boolean17 = scriptOrFnNode12.isOptionalArg();
        int int20 = scriptOrFnNode12.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        scriptOrFnNode12.detachChildren();
        try {
            scriptOrFnNode12.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("or", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(0, "<No stack trace available>");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        java.lang.String str20 = closureCodingConvention0.extractClassNameIfRequire(node5, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        scriptOrFnNode14.putBooleanProp(7, false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        scriptOrFnNode21.setEncodedSourceBounds(32, 26);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        int int12 = compiler0.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal15 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler13, callback14);
        compiler13.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str20 = jSSourceFile19.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19, true);
        com.google.javascript.rhino.Node node24 = compiler13.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSModule[] jSModuleArray25 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = null;
        try {
            com.google.javascript.jscomp.Result result27 = compiler0.compile(jSSourceFile19, jSModuleArray25, compilerOptions26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "or" + "'", str20.equals("or"));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(jSModuleArray25);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("");
        boolean boolean4 = googleCodingConvention0.isPrivate("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = null;
        try {
            compiler0.initOptions(compilerOptions12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.new FileLevelJsDocBuilder();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: reflection call to com.google.javascript.rhino.Node$FileLevelJsDocBuilder with null for superclass argument");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput4.getModule();
        try {
            java.lang.String str8 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Scope scope3 = nodeTraversal2.getScope();
        org.junit.Assert.assertNull(scope3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(6, 6, 14);
        try {
            int int5 = scriptOrFnNode3.getExistingIntProp(120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.Node node17 = scriptOrFnNode12.getFirstChild();
        scriptOrFnNode12.setEndLineno((int) (short) 10);
        com.google.javascript.rhino.Node node20 = scriptOrFnNode12.getNext();
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        boolean boolean10 = jSTypeRegistry7.declareType("", jSType9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry13.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray21 = scriptOrFnNode20.getParamAndVarNames();
        boolean boolean22 = scriptOrFnNode20.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType23 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType24 = jSTypeRegistry13.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode20, objectType23);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] { objectType24 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        try {
            nodeTraversal2.traverse(node28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(objectType24);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isQuotedString();
        boolean boolean5 = scriptOrFnNode3.isNoSideEffectsCall();
        scriptOrFnNode3.setWasEmptyNode(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        java.lang.String str4 = jSSourceFile2.toString();
        java.io.Reader reader5 = jSSourceFile2.getCodeReader();
        java.lang.String str6 = jSSourceFile2.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = objectType13.toObjectType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = null;
        objectType13.setPropertyJSDocInfo("or", jSDocInfo31, false);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNotNull(objectType29);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        boolean boolean45 = scriptOrFnNode43.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry36.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode43, objectType46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry50.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray58 = scriptOrFnNode57.getParamAndVarNames();
        boolean boolean59 = scriptOrFnNode57.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry50.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode57, objectType60);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType47.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType61);
        boolean boolean64 = objectType31.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType61, false);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType31.forceResolve(errorReporter65, jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.EnumType enumType68 = jSTypeRegistry2.createEnumType("<No stack trace available>", jSType67);
        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry72.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode79 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray80 = scriptOrFnNode79.getParamAndVarNames();
        boolean boolean81 = scriptOrFnNode79.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType82 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType83 = jSTypeRegistry72.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode79, objectType82);
        try {
            jSTypeRegistry2.registerPropertyOnType("com.google.javascript.rhino.EcmaError: : hi! (null#1)", (com.google.javascript.rhino.jstype.JSType) objectType82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(enumType68);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(objectType83);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.JSDocInfo jSDocInfo91 = functionType89.getOwnPropertyJSDocInfo("or");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNull(jSDocInfo91);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("@IMPLEMENTATION.VERSION@");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray30 = scriptOrFnNode29.getParamAndVarNames();
        boolean boolean31 = scriptOrFnNode29.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType32 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry22.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode29, objectType32);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair34 = objectType19.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType33);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry38.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode45 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray46 = scriptOrFnNode45.getParamAndVarNames();
        boolean boolean47 = scriptOrFnNode45.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType48 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry38.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode45, objectType48);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, true);
        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode59 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray60 = scriptOrFnNode59.getParamAndVarNames();
        boolean boolean61 = scriptOrFnNode59.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType62 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType63 = jSTypeRegistry52.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode59, objectType62);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair64 = objectType49.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType63);
        boolean boolean66 = objectType33.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType63, false);
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType33.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, true);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        boolean boolean73 = jSTypeRegistry70.declareType("", jSType72);
        com.google.javascript.rhino.ErrorReporter errorReporter74 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter74, true);
        com.google.javascript.rhino.jstype.JSType jSType78 = jSTypeRegistry76.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode83 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray84 = scriptOrFnNode83.getParamAndVarNames();
        boolean boolean85 = scriptOrFnNode83.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType86 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType87 = jSTypeRegistry76.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode83, objectType86);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray88 = new com.google.javascript.rhino.jstype.JSType[] { objectType87 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList89 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean90 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList89, jSTypeArray88);
        com.google.javascript.rhino.Node node91 = jSTypeRegistry70.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList89);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry5.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType33, node91);
        com.google.javascript.rhino.Node node93 = null;
        try {
            java.lang.String str94 = googleCodingConvention0.extractClassNameIfRequire(node91, node93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(typePair34);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(objectType63);
        org.junit.Assert.assertNotNull(typePair64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNull(jSType78);
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(objectType87);
        org.junit.Assert.assertNotNull(jSTypeArray88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        boolean boolean61 = objectType57.isNominalType();
        boolean boolean62 = objectType57.isArrayType();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getOptimizationLevel();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context1.getErrorReporter();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(errorReporter3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray4 = scriptOrFnNode3.getParamAndVarNames();
        try {
            scriptOrFnNode3.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        scriptOrFnNode8.setVarArgs(false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str20 = closureCodingConvention19.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean25 = scriptOrFnNode24.isQuotedString();
        boolean boolean26 = scriptOrFnNode24.isNoSideEffectsCall();
        java.lang.String str27 = closureCodingConvention19.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean28 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode24);
        scriptOrFnNode24.setEncodedSourceBounds((int) (byte) 100, (int) ' ');
        boolean boolean32 = scriptOrFnNode24.isOptionalArg();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportSymbol" + "'", str20.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, true);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        boolean boolean6 = jSTypeRegistry3.declareType("", jSType5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray17 = scriptOrFnNode16.getParamAndVarNames();
        boolean boolean18 = scriptOrFnNode16.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry9.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode16, objectType19);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] { objectType20 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.Node node24 = jSTypeRegistry3.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(4, "<No stack trace available>");
        try {
            java.lang.String str28 = com.google.javascript.rhino.ScriptRuntime.getMessage2("function ({146683846}): {1882061578}", (java.lang.Object) jSTypeRegistry3, (java.lang.Object) "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property function ({146683846}): {1882061578}");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.rhino.Node node5 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType9, strArray14);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray20 = scriptOrFnNode19.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError21 = nodeTraversal2.makeError(node5, diagnosticType9, strArray20);
        com.google.javascript.rhino.Node node22 = nodeTraversal2.getEnclosingFunction();
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.Node node17 = scriptOrFnNode12.getFirstChild();
        java.lang.String[] strArray18 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean20 = scriptOrFnNode12.addConst("");
        boolean boolean22 = scriptOrFnNode12.getBooleanProp(34);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        jSSourceFile5.setOriginalPath("return");
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("");
        boolean boolean4 = googleCodingConvention0.isPrivate("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        java.lang.String str5 = googleCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler6, callback7);
        com.google.javascript.jscomp.Compiler compiler9 = nodeTraversal8.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean14 = scriptOrFnNode13.isNoSideEffectsCall();
        int int16 = scriptOrFnNode13.getIntProp((int) (short) 10);
        int int17 = scriptOrFnNode13.getSideEffectFlags();
        scriptOrFnNode13.setLineno(30);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast20 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal8, (com.google.javascript.rhino.Node) scriptOrFnNode13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(compiler9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("TypeError: goog.exportSymbol", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.rhino.Node node12 = compiler0.getRoot();
        try {
            java.lang.String str15 = compiler0.getSourceLine("goog.global", 38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray8 = scriptOrFnNode7.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType3, strArray8);
        java.text.MessageFormat messageFormat10 = diagnosticType3.format;
        java.lang.String[] strArray12 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
        java.text.MessageFormat messageFormat14 = diagnosticType3.format;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean20 = scriptOrFnNode19.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray33 = scriptOrFnNode32.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType28, strArray33);
        java.text.MessageFormat messageFormat35 = diagnosticType28.format;
        java.lang.String[] strArray37 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode19, checkLevel21, diagnosticType24, strArray37);
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray37);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(messageFormat10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(messageFormat14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(messageFormat35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSError40);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("or");
        jSModule8.addDependency(jSModule10);
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule15 = new com.google.javascript.jscomp.JSModule("or");
        jSModule13.addDependency(jSModule15);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet17 = jSModule13.getThisAndAllDependencies();
        jSModule10.addDependency(jSModule13);
        compilerInput6.setModule(jSModule10);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSModuleSet17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = compiler0.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        boolean boolean61 = objectType57.isNominalType();
        boolean boolean62 = objectType57.isUnknownType();
        boolean boolean63 = objectType57.isEnumType();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo61 = objectType27.getJSDocInfo();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNull(jSDocInfo61);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str9 = jSSourceFile8.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, true);
        com.google.javascript.rhino.Node node13 = compiler3.parse(jSSourceFile8);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter14 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback16);
        com.google.javascript.jscomp.Compiler compiler18 = nodeTraversal17.getCompiler();
        com.google.javascript.jscomp.Scope scope19 = nodeTraversal17.getScope();
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray29 = scriptOrFnNode28.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType24, strArray29);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray35 = scriptOrFnNode34.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError36 = nodeTraversal17.makeError(node20, diagnosticType24, strArray35);
        java.lang.String str37 = lightweightMessageFormatter14.formatError(jSError36);
        try {
            compiler0.report(jSError36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "or" + "'", str9.equals("or"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(compiler18);
        org.junit.Assert.assertNull(scope19);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + ": ERROR - Exceeded max number of optimization iterations: {0}\n" + "'", str37.equals(": ERROR - Exceeded max number of optimization iterations: {0}\n"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable95 = functionType89.getAllImplementedInterfaces();
        boolean boolean97 = functionType89.isPropertyTypeInferred("return");
        boolean boolean98 = functionType89.matchesUint32Context();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNotNull(objectTypeIterable95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        scriptOrFnNode9.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node17 = scriptOrFnNode9.getAncestor(0);
        scriptOrFnNode9.setBaseLineno((int) (byte) 1);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode24, (com.google.javascript.rhino.Node) scriptOrFnNode28, (com.google.javascript.rhino.Node) scriptOrFnNode32);
        int int34 = scriptOrFnNode32.getFunctionCount();
        scriptOrFnNode32.removeParamOrVar("");
        boolean boolean37 = scriptOrFnNode32.isOptionalArg();
        int int40 = scriptOrFnNode32.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        try {
            com.google.javascript.rhino.Node node41 = scriptOrFnNode9.getChildBefore((com.google.javascript.rhino.Node) scriptOrFnNode32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node5 = scriptOrFnNode3.getAncestor(49);
        try {
            boolean boolean6 = node5.isNoSideEffectsCall();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry2.createDefaultObjectUnion(jSType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean4 = closureCodingConvention0.isExported("return", false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray8 = scriptOrFnNode7.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType3, strArray8);
        java.text.MessageFormat messageFormat10 = diagnosticType3.format;
        java.lang.String[] strArray12 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = diagnosticType3.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(messageFormat10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        java.lang.String str3 = context1.getImplementationVersion();
        int int4 = context1.getLanguageVersion();
        boolean boolean5 = context1.isSealed();
        context1.setCompileFunctionsWithDynamicScope(true);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("@IMPLEMENTATION.VERSION@");
        java.lang.String str3 = googleCodingConvention0.getGlobalObject();
        boolean boolean5 = googleCodingConvention0.isPrivate("Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.global" + "'", str3.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup4;
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError11 = null;
        loggerErrorManager9.println(checkLevel10, jSError11);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup4, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup4;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        scriptOrFnNode4.removeProp(0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.rhino.Node node5 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType9, strArray14);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray20 = scriptOrFnNode19.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError21 = nodeTraversal2.makeError(node5, diagnosticType9, strArray20);
        try {
            com.google.javascript.jscomp.JSModule jSModule22 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        try {
            java.lang.String str7 = compilerInput6.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        boolean boolean7 = node6.isQuotedString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("or");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.setCompileFunctionsWithDynamicScope(true);
        context1.setLanguageVersion((int) (short) 100);
        int int7 = context1.getLanguageVersion();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType97 = functionType89.getConstructor();
        boolean boolean98 = functionType89.canBeCalled();
        com.google.javascript.rhino.jstype.ObjectType objectType99 = functionType89.dereference();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(functionType97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertNotNull(objectType99);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        com.google.javascript.rhino.Node node96 = null;
        functionType89.setSource(node96);
        boolean boolean98 = functionType89.isReturnTypeInferred();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        java.lang.String str4 = jSSourceFile2.toString();
        java.io.Reader reader5 = jSSourceFile2.getCodeReader();
        java.lang.String str6 = jSSourceFile2.getName();
        java.lang.String str8 = jSSourceFile2.getLine((int) (short) -1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        boolean boolean20 = closureCodingConvention0.isExported("or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError4 = null;
        loggerErrorManager2.println(checkLevel3, jSError4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode11 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean12 = scriptOrFnNode11.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray25 = scriptOrFnNode24.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType20, strArray25);
        java.text.MessageFormat messageFormat27 = diagnosticType20.format;
        java.lang.String[] strArray29 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray29);
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode11, checkLevel13, diagnosticType16, strArray29);
        com.google.javascript.jscomp.CheckLevel checkLevel32 = diagnosticType16.defaultLevel;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode36.setBaseLineno(17);
        int int39 = scriptOrFnNode36.getEncodedSourceEnd();
        java.lang.String[] strArray40 = scriptOrFnNode36.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make(diagnosticType16, strArray40);
        try {
            loggerErrorManager2.println(checkLevel6, jSError41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNotNull(messageFormat27);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        int int12 = compiler0.getErrorCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker13 = compiler0.tracker;
        java.lang.String str14 = compiler0.getAstDotGraph();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(performanceTracker13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        jSTypeRegistry2.forwardDeclareType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder26 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode31, (com.google.javascript.rhino.Node) scriptOrFnNode35, (com.google.javascript.rhino.Node) scriptOrFnNode39);
        node40.setVarArgs(true);
        boolean boolean43 = node40.isVarArgs();
        com.google.javascript.rhino.Node node44 = functionParamBuilder26.newParameterFromNode(node40);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode48 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = scriptOrFnNode48.getJSDocInfo();
        scriptOrFnNode48.putBooleanProp(0, false);
        com.google.javascript.rhino.Node node53 = functionParamBuilder26.newParameterFromNode((com.google.javascript.rhino.Node) scriptOrFnNode48);
        com.google.javascript.rhino.Node node54 = node53.detachFromParent();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSDocInfo49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        boolean boolean45 = scriptOrFnNode43.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry36.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode43, objectType46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry50.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray58 = scriptOrFnNode57.getParamAndVarNames();
        boolean boolean59 = scriptOrFnNode57.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry50.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode57, objectType60);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType47.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType61);
        boolean boolean64 = objectType31.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType61, false);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType31.forceResolve(errorReporter65, jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.EnumType enumType68 = jSTypeRegistry2.createEnumType("<No stack trace available>", jSType67);
        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry72.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode79 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray80 = scriptOrFnNode79.getParamAndVarNames();
        boolean boolean81 = scriptOrFnNode79.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType82 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType83 = jSTypeRegistry72.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode79, objectType82);
        com.google.javascript.rhino.jstype.JSType jSType85 = objectType83.findPropertyType("TypeError");
        com.google.javascript.rhino.jstype.JSType jSType87 = objectType83.getRestrictedTypeGivenToBooleanOutcome(true);
        jSTypeRegistry2.registerPropertyOnType("function ({146683846}): {1882061578}", jSType87);
        boolean boolean89 = jSType87.isResolved();
        boolean boolean90 = jSType87.isObject();
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(enumType68);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(objectType83);
        org.junit.Assert.assertNull(jSType85);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList5 = jSModule3.getInputs();
        try {
            java.lang.String str6 = jSModule3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(compilerInputList5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        java.lang.String str4 = jSSourceFile2.toString();
        java.io.Reader reader5 = jSSourceFile2.getCodeReader();
        java.lang.String str6 = jSSourceFile2.toString();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.util.Locale locale1 = null;
        java.util.Locale locale2 = context0.setLocale(locale1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = objectType27.unboxesTo();
        java.util.Set<java.lang.String> strSet62 = objectType27.getOwnPropertyNames();
        boolean boolean63 = objectType27.isUnionType();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean boolean35 = scriptOrFnNode21.isSyntheticBlock();
        boolean boolean36 = scriptOrFnNode21.isOnlyModifiesThisCall();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20);
        boolean boolean22 = scriptOrFnNode12.isVarArgs();
        boolean boolean24 = scriptOrFnNode12.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode38 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode30, (com.google.javascript.rhino.Node) scriptOrFnNode34, (com.google.javascript.rhino.Node) scriptOrFnNode38);
        scriptOrFnNode34.setCompilerData((java.lang.Object) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode50 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode54 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode46, (com.google.javascript.rhino.Node) scriptOrFnNode50, (com.google.javascript.rhino.Node) scriptOrFnNode54);
        int int56 = scriptOrFnNode54.getFunctionCount();
        scriptOrFnNode54.removeParamOrVar("");
        boolean boolean59 = scriptOrFnNode54.isOptionalArg();
        int int62 = scriptOrFnNode54.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        com.google.javascript.rhino.Node node63 = scriptOrFnNode34.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode54);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship64 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode34);
        java.lang.String str65 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(delegateRelationship64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "goog.exportProperty" + "'", str65.equals("goog.exportProperty"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList5 = jSModule3.getInputs();
        boolean boolean7 = jSModule3.removeByName("");
        jSModule3.removeAll();
        try {
            java.lang.String str9 = jSModule3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(compilerInputList5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        boolean boolean90 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        com.google.javascript.rhino.Node node91 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope93 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType95 = jSTypeRegistry2.createFromTypeNodes(node91, "<No stack trace available>", jSTypeStaticScope93, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20);
        boolean boolean22 = scriptOrFnNode12.isVarArgs();
        boolean boolean24 = scriptOrFnNode12.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention26 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str27 = closureCodingConvention26.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = scriptOrFnNode31.getJSDocInfo();
        scriptOrFnNode31.putBooleanProp(0, false);
        boolean boolean36 = closureCodingConvention26.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode31);
        try {
            com.google.javascript.rhino.Node node37 = scriptOrFnNode12.removeChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportSymbol" + "'", str27.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.setCompileFunctionsWithDynamicScope(true);
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler10, callback11);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope14 = compiler13.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState15 = compiler13.getState();
        compiler10.setState(intermediateState15);
        compiler0.setState(intermediateState15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
        compiler0.tracker = performanceTracker18;
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(scope14);
        org.junit.Assert.assertNotNull(intermediateState15);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        jSTypeRegistry2.forwardDeclareType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder26 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode31, (com.google.javascript.rhino.Node) scriptOrFnNode35, (com.google.javascript.rhino.Node) scriptOrFnNode39);
        node40.setVarArgs(true);
        boolean boolean43 = node40.isVarArgs();
        com.google.javascript.rhino.Node node44 = functionParamBuilder26.newParameterFromNode(node40);
        try {
            double double45 = node40.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF [jsdoc_info: 1] is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(node44);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("function ({1704469334}): {249350611}", "function ({1704469334}): {249350611}", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 29, (int) (byte) 0, 1);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<java.lang.String> strList5 = jSModule1.getProvides();
        jSModule1.removeAll();
        try {
            java.lang.String str7 = jSModule1.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strList5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20);
        boolean boolean22 = scriptOrFnNode12.isVarArgs();
        boolean boolean24 = scriptOrFnNode12.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode38 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode30, (com.google.javascript.rhino.Node) scriptOrFnNode34, (com.google.javascript.rhino.Node) scriptOrFnNode38);
        scriptOrFnNode34.setCompilerData((java.lang.Object) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode46 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode50 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode54 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode46, (com.google.javascript.rhino.Node) scriptOrFnNode50, (com.google.javascript.rhino.Node) scriptOrFnNode54);
        int int56 = scriptOrFnNode54.getFunctionCount();
        scriptOrFnNode54.removeParamOrVar("");
        boolean boolean59 = scriptOrFnNode54.isOptionalArg();
        int int62 = scriptOrFnNode54.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        com.google.javascript.rhino.Node node63 = scriptOrFnNode34.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode54);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship64 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode34);
        try {
            int int66 = scriptOrFnNode34.getExistingIntProp((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(delegateRelationship64);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean boolean35 = scriptOrFnNode21.isSyntheticBlock();
        scriptOrFnNode21.putIntProp((int) '4', 4095);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode51 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode43, (com.google.javascript.rhino.Node) scriptOrFnNode47, (com.google.javascript.rhino.Node) scriptOrFnNode51);
        scriptOrFnNode51.removeParamOrVar("@IMPLEMENTATION.VERSION@");
        boolean boolean55 = scriptOrFnNode51.wasEmptyNode();
        try {
            com.google.javascript.rhino.Node node56 = scriptOrFnNode21.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Node has existing properties.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isQuotedString();
        com.google.javascript.rhino.Node node5 = scriptOrFnNode3.removeChildren();
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray19 = scriptOrFnNode18.getParamAndVarNames();
        boolean boolean20 = scriptOrFnNode18.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry11.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode18, objectType21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, true);
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry25.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray33 = scriptOrFnNode32.getParamAndVarNames();
        boolean boolean34 = scriptOrFnNode32.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType35 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSTypeRegistry25.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode32, objectType35);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair37 = objectType22.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, true);
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry41.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode48 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray49 = scriptOrFnNode48.getParamAndVarNames();
        boolean boolean50 = scriptOrFnNode48.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType51 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType52 = jSTypeRegistry41.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode48, objectType51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, true);
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry55.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode62 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray63 = scriptOrFnNode62.getParamAndVarNames();
        boolean boolean64 = scriptOrFnNode62.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType65 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType66 = jSTypeRegistry55.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode62, objectType65);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair67 = objectType52.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType66);
        boolean boolean69 = objectType36.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType66, false);
        com.google.javascript.rhino.jstype.JSType jSType70 = objectType36.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        boolean boolean76 = jSTypeRegistry73.declareType("", jSType75);
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, true);
        com.google.javascript.rhino.jstype.JSType jSType81 = jSTypeRegistry79.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode86 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray87 = scriptOrFnNode86.getParamAndVarNames();
        boolean boolean88 = scriptOrFnNode86.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType89 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType90 = jSTypeRegistry79.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode86, objectType89);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray91 = new com.google.javascript.rhino.jstype.JSType[] { objectType90 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList92 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean93 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList92, jSTypeArray91);
        com.google.javascript.rhino.Node node94 = jSTypeRegistry73.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList92);
        com.google.javascript.rhino.jstype.FunctionType functionType95 = jSTypeRegistry8.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType36, node94);
        boolean boolean96 = functionType95.hasReferenceName();
        boolean boolean97 = functionType95.isInterface();
        java.util.Set<java.lang.String> strSet98 = functionType95.getPropertyNames();
        scriptOrFnNode3.setDirectives(strSet98);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertNotNull(typePair37);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(objectType52);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(objectType66);
        org.junit.Assert.assertNotNull(typePair67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNull(jSType81);
        org.junit.Assert.assertNotNull(strArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(objectType90);
        org.junit.Assert.assertNotNull(jSTypeArray91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(functionType95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertNotNull(strSet98);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        jSTypeRegistry2.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray17 = scriptOrFnNode16.getParamAndVarNames();
        boolean boolean18 = scriptOrFnNode16.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry9.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode16, objectType19);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType20.findPropertyType("TypeError");
        boolean boolean23 = objectType20.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry2.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType20);
        boolean boolean26 = objectType20.hasOwnProperty("function ({1920498015}): {823343230}");
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean3 = closureCodingConvention0.isExported("<No stack trace available>");
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.String[] strArray0 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        boolean boolean8 = jSTypeRegistry2.canPropertyBeDefined(jSType6, "");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.InstanceObjectType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isNoSideEffectsCall();
        int int6 = scriptOrFnNode3.getIntProp((int) (short) 10);
        int int7 = scriptOrFnNode3.getSideEffectFlags();
        int int8 = scriptOrFnNode3.getCharno();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, (long) 7);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler12, callback13);
        com.google.javascript.jscomp.Compiler compiler15 = nodeTraversal14.getCompiler();
        com.google.javascript.jscomp.Scope scope16 = nodeTraversal14.getScope();
        com.google.javascript.rhino.Node node17 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray26 = scriptOrFnNode25.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType21, strArray26);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal14.makeError(node17, diagnosticType21, strArray32);
        java.lang.String str34 = lightweightMessageFormatter11.formatError(jSError33);
        com.google.javascript.jscomp.Compiler compiler35 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback36 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal37 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler35, callback36);
        com.google.javascript.jscomp.Compiler compiler38 = nodeTraversal37.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean44 = scriptOrFnNode43.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel45 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType52, strArray57);
        java.text.MessageFormat messageFormat59 = diagnosticType52.format;
        java.lang.String[] strArray61 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make(diagnosticType52, strArray61);
        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode43, checkLevel45, diagnosticType48, strArray61);
        compiler38.report(jSError63);
        com.google.javascript.jscomp.MessageFormatter messageFormatter65 = null;
        java.util.logging.Logger logger66 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager67 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter65, logger66);
        com.google.javascript.jscomp.CheckLevel checkLevel68 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError69 = null;
        loggerErrorManager67.println(checkLevel68, jSError69);
        com.google.javascript.jscomp.ErrorFormat errorFormat71 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler72 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback73 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal74 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler72, callback73);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str78 = jSSourceFile77.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput79 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77);
        com.google.javascript.jscomp.CompilerInput compilerInput81 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77, true);
        com.google.javascript.rhino.Node node82 = compiler72.parse(jSSourceFile77);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter83 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler72);
        com.google.javascript.rhino.Node node84 = compiler72.getRoot();
        int int85 = compiler72.getErrorCount();
        com.google.javascript.jscomp.MessageFormatter messageFormatter87 = errorFormat71.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler72, true);
        java.lang.String str88 = jSError63.format(checkLevel68, messageFormatter87);
        try {
            java.lang.String str89 = lightweightMessageFormatter11.formatError(jSError63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(compiler15);
        org.junit.Assert.assertNull(scope16);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + ": ERROR - Exceeded max number of optimization iterations: {0}\n" + "'", str34.equals(": ERROR - Exceeded max number of optimization iterations: {0}\n"));
        org.junit.Assert.assertNotNull(compiler38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(messageFormat59);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNotNull(jSError63);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat71);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "or" + "'", str78.equals("or"));
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNull(node84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertNotNull(messageFormatter87);
        org.junit.Assert.assertNull(str88);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        scriptOrFnNode4.detachChildren();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.rhino.Node node11 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler0.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(errorManager12);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        boolean boolean45 = scriptOrFnNode43.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry36.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode43, objectType46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry50.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray58 = scriptOrFnNode57.getParamAndVarNames();
        boolean boolean59 = scriptOrFnNode57.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry50.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode57, objectType60);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType47.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType61);
        boolean boolean64 = objectType31.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType61, false);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType31.forceResolve(errorReporter65, jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.EnumType enumType68 = jSTypeRegistry2.createEnumType("<No stack trace available>", jSType67);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        com.google.javascript.rhino.jstype.JSType.TypePair typePair70 = enumType68.getTypesUnderShallowInequality(jSType69);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(enumType68);
        org.junit.Assert.assertNotNull(typePair70);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        java.lang.String str97 = functionPrototypeType96.toString();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "{...}" + "'", str97.equals("{...}"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable90 = functionType89.getParameters();
        com.google.javascript.rhino.jstype.ObjectType objectType91 = functionType89.getImplicitPrototype();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(nodeIterable90);
        org.junit.Assert.assertNotNull(objectType91);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str4 = jSSourceFile3.getOriginalPath();
        java.lang.String str5 = jSSourceFile3.toString();
        java.io.Reader reader6 = jSSourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromReader("null", reader6);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = jSModule1.getByName("TypeError: goog.exportSymbol");
        org.junit.Assert.assertNull(compilerInput6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isBooleanObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback4);
        compiler3.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str10 = jSSourceFile9.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, true);
        com.google.javascript.rhino.Node node14 = compiler3.parse(jSSourceFile9);
        java.lang.String str15 = jSSourceFile9.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str19 = jSSourceFile18.getOriginalPath();
        java.lang.String str20 = jSSourceFile18.toString();
        java.io.Reader reader21 = jSSourceFile18.getCodeReader();
        java.lang.String str22 = jSSourceFile18.getCode();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str26 = jSSourceFile25.getOriginalPath();
        java.lang.String str27 = jSSourceFile25.toString();
        java.io.Reader reader28 = jSSourceFile25.getCodeReader();
        java.lang.String str29 = jSSourceFile25.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str33 = jSSourceFile32.getOriginalPath();
        com.google.javascript.jscomp.Compiler compiler34 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback35 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal36 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler34, callback35);
        compiler34.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str41 = jSSourceFile40.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40);
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40, true);
        com.google.javascript.rhino.Node node45 = compiler34.parse(jSSourceFile40);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray46 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9, jSSourceFile18, jSSourceFile25, jSSourceFile32, jSSourceFile40 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray47 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = null;
        try {
            com.google.javascript.jscomp.Result result49 = compiler0.compile(jSSourceFileArray46, jSSourceFileArray47, compilerOptions48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "or" + "'", str10.equals("or"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "or" + "'", str15.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(reader21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "or" + "'", str41.equals("or"));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(jSSourceFileArray46);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        boolean boolean7 = node6.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags8 = null;
        try {
            node6.setSideEffectFlags(sideEffectFlags8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        ecmaError1.initLineSource("hi!");
        java.lang.Throwable[] throwableArray4 = ecmaError1.getSuppressed();
        java.lang.String str5 = ecmaError1.getName();
        try {
            ecmaError1.initLineSource("function ({1704469334}): {249350611}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError" + "'", str5.equals("TypeError"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        java.lang.String str94 = functionType89.getTemplateTypeName();
//        boolean boolean95 = functionType89.isNullType();
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({460352397}): {1337071389}" + "'", str93.equals("function ({460352397}): {1337071389}"));
//        org.junit.Assert.assertNull(str94);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeActivationName("");
        context1.removeActivationName("");
        boolean boolean8 = context1.isActivationNeeded("");
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat1 = diagnosticType0.format;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        try {
            int int3 = diagnosticType0.compareTo(diagnosticType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(messageFormat1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType97 = functionType89.getConstructor();
        boolean boolean98 = functionType89.canBeCalled();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType99 = functionType89.getPrototype();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(functionType97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertNotNull(functionPrototypeType99);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        jSTypeRegistry2.forwardDeclareType("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSTypeRegistry2.createAnonymousObjectType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(objectType26);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        node10.setJSDocInfo(jSDocInfo11);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, true);
        com.google.javascript.rhino.Node node17 = compiler7.parse(jSSourceFile12);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        com.google.javascript.rhino.Node node19 = compilerInput4.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "TypeError", false);
        com.google.javascript.jscomp.Region region24 = compilerInput4.getRegion(26);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(region24);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        boolean boolean97 = functionType89.hasInstanceType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType97 = functionType89.getConstructor();
        boolean boolean98 = functionType89.canBeCalled();
        boolean boolean99 = functionType89.isInterface();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(functionType97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        boolean boolean6 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode7 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        jSTypeRegistry2.setResolveMode(resolveMode7);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry2.getType(jSTypeStaticScope9, "EOF", "function ({1920498015}): {823343230}", 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + resolveMode7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode7.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
        org.junit.Assert.assertNotNull(jSType14);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        boolean boolean92 = functionType89.isObject();
        boolean boolean93 = functionType89.isOrdinaryFunction();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.util.Set<java.lang.String> strSet35 = scriptOrFnNode21.getDirectives();
        int int36 = scriptOrFnNode21.getRegexpCount();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(strSet35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        node34.detachChildren();
        com.google.javascript.rhino.Node node37 = node34.getAncestor(46);
        try {
            java.lang.Class<?> wildcardClass38 = node37.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node37);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(100, "hi!");
        boolean boolean6 = node5.hasChildren();
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compiler0, (java.lang.Object) node5);
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler8, callback9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope12 = compiler11.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState13 = compiler11.getState();
        compiler8.setState(intermediateState13);
        compiler0.setState(intermediateState13);
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback17 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal18 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler16, callback17);
        compiler16.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str23 = jSSourceFile22.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22, true);
        com.google.javascript.rhino.Node node27 = compiler16.parse(jSSourceFile22);
        java.lang.String str28 = jSSourceFile22.getOriginalPath();
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("return", generator30);
        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback33 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal34 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler32, callback33);
        compiler32.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str39 = jSSourceFile38.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38);
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38, true);
        com.google.javascript.rhino.Node node43 = compiler32.parse(jSSourceFile38);
        java.lang.String str44 = jSSourceFile38.getOriginalPath();
        java.lang.String str46 = jSSourceFile38.getLine((int) (byte) 1);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray47 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile22, jSSourceFile31, jSSourceFile38 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        com.google.javascript.jscomp.Compiler compiler51 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback52 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal53 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler51, callback52);
        compiler51.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str58 = jSSourceFile57.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput59 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.CompilerInput compilerInput61 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57, true);
        com.google.javascript.rhino.Node node62 = compiler51.parse(jSSourceFile57);
        java.lang.String str63 = jSSourceFile57.getOriginalPath();
        java.lang.String str65 = jSSourceFile57.getLine((int) (byte) 1);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray66 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile50, jSSourceFile57 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = null;
        try {
            compiler0.init(jSSourceFileArray47, jSSourceFileArray66, compilerOptions67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(runtimeException7);
        org.junit.Assert.assertNull(scope12);
        org.junit.Assert.assertNotNull(intermediateState13);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "or" + "'", str23.equals("or"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "or" + "'", str28.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "or" + "'", str39.equals("or"));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "or" + "'", str44.equals("or"));
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(jSSourceFileArray47);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "or" + "'", str58.equals("or"));
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "or" + "'", str63.equals("or"));
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertNotNull(jSSourceFileArray66);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean7 = scriptOrFnNode6.wasEmptyNode();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode6);
        boolean boolean9 = node8.isUnscopedQualifiedName();
        context1.removeThreadLocal((java.lang.Object) boolean9);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray18 = scriptOrFnNode17.getParamAndVarNames();
        boolean boolean19 = scriptOrFnNode17.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType20 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry10.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode17, objectType20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        boolean boolean33 = scriptOrFnNode31.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry24.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode31, objectType34);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair36 = objectType21.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType35);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, true);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry40.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray48 = scriptOrFnNode47.getParamAndVarNames();
        boolean boolean49 = scriptOrFnNode47.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType50 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry40.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode47, objectType50);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, true);
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry54.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode61 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray62 = scriptOrFnNode61.getParamAndVarNames();
        boolean boolean63 = scriptOrFnNode61.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType64 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType65 = jSTypeRegistry54.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode61, objectType64);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair66 = objectType51.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType65);
        boolean boolean68 = objectType35.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType65, false);
        com.google.javascript.rhino.jstype.JSType jSType69 = objectType35.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        boolean boolean75 = jSTypeRegistry72.declareType("", jSType74);
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry78.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode85 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray86 = scriptOrFnNode85.getParamAndVarNames();
        boolean boolean87 = scriptOrFnNode85.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType88 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType89 = jSTypeRegistry78.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode85, objectType88);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] { objectType89 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList91 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean92 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList91, jSTypeArray90);
        com.google.javascript.rhino.Node node93 = jSTypeRegistry72.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList91);
        com.google.javascript.rhino.jstype.FunctionType functionType94 = jSTypeRegistry7.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType35, node93);
        com.google.javascript.rhino.jstype.ObjectType objectType95 = jSTypeRegistry2.createObjectType(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(typePair36);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectType65);
        org.junit.Assert.assertNotNull(typePair66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(functionType94);
        org.junit.Assert.assertNotNull(objectType95);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        boolean boolean35 = scriptOrFnNode21.isSyntheticBlock();
        try {
            com.google.javascript.rhino.Node node36 = com.google.javascript.jscomp.NodeUtil.newExpr((com.google.javascript.rhino.Node) scriptOrFnNode21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        int int15 = scriptOrFnNode13.getFunctionCount();
        scriptOrFnNode13.removeParamOrVar("");
        com.google.javascript.rhino.Node node18 = scriptOrFnNode13.getFirstChild();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node18 };
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0, nodeArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(28);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pos" + "'", str1.equals("pos"));
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        boolean boolean94 = functionType89.isConstructor();
//        try {
//            boolean boolean95 = functionType89.hasUnknownSupertype();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({1803934833}): {1871178175}" + "'", str93.equals("function ({1803934833}): {1871178175}"));
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        java.lang.String str3 = context1.getImplementationVersion();
//        int int4 = context1.getLanguageVersion();
//        boolean boolean5 = context1.isSealed();
//        boolean boolean7 = context1.isActivationNeeded("function ({1920498015}): {823343230}");
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        lightweightMessageFormatter11.setColorize(true);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger14);
        lightweightMessageFormatter11.setColorize(false);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.reportCodeChange();
        compiler0.disableThreads();
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        int int97 = functionType89.getMaxArguments();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1 + "'", int97 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable90 = functionType89.getParameters();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList91 = functionType89.getSubTypes();
        boolean boolean93 = functionType89.isPropertyTypeInferred("function ({1773287363}): {2008203786}");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(nodeIterable90);
        org.junit.Assert.assertNull(functionTypeList91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("function ({1704469334}): {249350611}", "function ({1595398090}): {1399939059}", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        boolean boolean1 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesArguments();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, true);
        com.google.javascript.rhino.Node node17 = compiler7.parse(jSSourceFile12);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        com.google.javascript.rhino.Node node19 = compilerInput4.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "TypeError", false);
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler23, callback24);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str29 = jSSourceFile28.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, true);
        com.google.javascript.rhino.Node node33 = compiler23.parse(jSSourceFile28);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter34 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler23);
        int int35 = compiler23.getErrorCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker36 = compiler23.tracker;
        compilerInput22.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler23);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "or" + "'", str29.equals("or"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(performanceTracker36);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray18 = scriptOrFnNode17.getParamAndVarNames();
        boolean boolean19 = scriptOrFnNode17.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType20 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry10.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode17, objectType20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        boolean boolean33 = scriptOrFnNode31.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry24.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode31, objectType34);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair36 = objectType21.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType35);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, true);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry40.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray48 = scriptOrFnNode47.getParamAndVarNames();
        boolean boolean49 = scriptOrFnNode47.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType50 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry40.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode47, objectType50);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, true);
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry54.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode61 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray62 = scriptOrFnNode61.getParamAndVarNames();
        boolean boolean63 = scriptOrFnNode61.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType64 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType65 = jSTypeRegistry54.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode61, objectType64);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair66 = objectType51.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType65);
        boolean boolean68 = objectType35.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType65, false);
        com.google.javascript.rhino.jstype.JSType jSType69 = objectType35.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        boolean boolean75 = jSTypeRegistry72.declareType("", jSType74);
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry78.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode85 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray86 = scriptOrFnNode85.getParamAndVarNames();
        boolean boolean87 = scriptOrFnNode85.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType88 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType89 = jSTypeRegistry78.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode85, objectType88);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] { objectType89 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList91 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean92 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList91, jSTypeArray90);
        com.google.javascript.rhino.Node node93 = jSTypeRegistry72.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList91);
        com.google.javascript.rhino.jstype.FunctionType functionType94 = jSTypeRegistry7.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType35, node93);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable95 = functionType94.getParameters();
        com.google.javascript.rhino.jstype.ObjectType objectType96 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType94);
        boolean boolean97 = functionType94.isStringValueType();
        boolean boolean99 = functionType94.isPropertyTypeInferred("");
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(typePair36);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectType65);
        org.junit.Assert.assertNotNull(typePair66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(functionType94);
        org.junit.Assert.assertNotNull(nodeIterable95);
        org.junit.Assert.assertNotNull(objectType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("()", "null");
        java.lang.String str3 = ecmaError2.getName();
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = ecmaError2.getScriptStackTrace(filenameFilter4);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "()" + "'", str3.equals("()"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!", "null", (int) (byte) 1, "()", 38);
        java.lang.String str7 = ecmaError6.toString();
        java.lang.Throwable[] throwableArray8 = ecmaError6.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "com.google.javascript.rhino.EcmaError: : hi! (null#1)" + "'", str7.equals("com.google.javascript.rhino.EcmaError: : hi! (null#1)"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("JSC_OPTIMIZE_LOOP_ERROR", "pos");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!", "null", (int) (byte) 1, "()", 38);
        java.lang.String str7 = ecmaError6.toString();
        int int8 = ecmaError6.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "com.google.javascript.rhino.EcmaError: : hi! (null#1)" + "'", str7.equals("com.google.javascript.rhino.EcmaError: : hi! (null#1)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.forwardDeclareType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        boolean boolean6 = jSTypeRegistry2.isForwardDeclaredType("function ({460352397}): {1337071389}");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = googleCodingConvention0.getDelegateRelationship(node1);
        org.junit.Assert.assertNull(delegateRelationship2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        int int92 = functionType89.getMinArguments();
        com.google.javascript.rhino.jstype.JSType jSType93 = functionType89.unboxesTo();
        boolean boolean95 = functionType89.isPropertyTypeDeclared("goog.exportProperty");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        boolean boolean94 = functionType89.isNativeObjectType();
//        boolean boolean96 = functionType89.hasProperty(": ERROR - Exceeded max number of optimization iterations: {0}\n");
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({316341747}): {1694998584}" + "'", str93.equals("function ({316341747}): {1694998584}"));
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            com.google.javascript.rhino.Context.reportWarning("return");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        boolean boolean1 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesThis();
        boolean boolean3 = sideEffectFlags0.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        ecmaError1.initLineSource("hi!");
        java.lang.Throwable[] throwableArray4 = ecmaError1.getSuppressed();
        ecmaError1.initColumnNumber(45);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getEncodedSourceEnd();
        com.google.javascript.rhino.Node node15 = scriptOrFnNode12.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str17 = closureCodingConvention16.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean22 = scriptOrFnNode21.isNoSideEffectsCall();
        boolean boolean23 = closureCodingConvention16.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode21);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode28, (com.google.javascript.rhino.Node) scriptOrFnNode32, (com.google.javascript.rhino.Node) scriptOrFnNode36);
        boolean boolean38 = scriptOrFnNode28.isVarArgs();
        boolean boolean40 = scriptOrFnNode28.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship41 = closureCodingConvention16.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode28);
        try {
            node15.removeChild((com.google.javascript.rhino.Node) scriptOrFnNode28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportSymbol" + "'", str17.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(delegateRelationship41);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        java.lang.String str97 = functionType89.getReferenceName();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertNull(str97);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        jSTypeRegistry2.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray17 = scriptOrFnNode16.getParamAndVarNames();
        boolean boolean18 = scriptOrFnNode16.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry9.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode16, objectType19);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType20.findPropertyType("TypeError");
        boolean boolean23 = objectType20.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry2.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType20);
        com.google.javascript.rhino.jstype.ObjectType objectType25 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry28.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray36 = scriptOrFnNode35.getParamAndVarNames();
        boolean boolean37 = scriptOrFnNode35.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry28.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode35, objectType38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, true);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry42.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode49 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray50 = scriptOrFnNode49.getParamAndVarNames();
        boolean boolean51 = scriptOrFnNode49.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType52 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSTypeRegistry42.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode49, objectType52);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair54 = objectType39.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType53);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, true);
        jSTypeRegistry57.setLastGeneration(true);
        jSTypeRegistry57.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, true);
        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode71 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray72 = scriptOrFnNode71.getParamAndVarNames();
        boolean boolean73 = scriptOrFnNode71.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType74 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry64.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode71, objectType74);
        com.google.javascript.rhino.jstype.JSType jSType77 = objectType75.findPropertyType("TypeError");
        boolean boolean78 = objectType75.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry57.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType75);
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSTypeRegistry57.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair81 = objectType53.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType jSType82 = objectType25.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType53);
        boolean boolean83 = objectType25.isObject();
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(objectType53);
        org.junit.Assert.assertNotNull(typePair54);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertNotNull(typePair81);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("goog.global", "function ({146683846}): {1882061578}");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType9, strArray14);
        java.text.MessageFormat messageFormat16 = diagnosticType9.format;
        java.lang.String[] strArray18 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray18);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = composeWarningsGuard3.level(jSError19);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(messageFormat16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNull(checkLevel20);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup4;
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError11 = null;
        loggerErrorManager9.println(checkLevel10, jSError11);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup4, checkLevel10);
        com.google.javascript.jscomp.JSError jSError14 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticGroupWarningsGuard13.level(jSError14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("or");
        jSModule6.addDependency(jSModule8);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule6.getThisAndAllDependencies();
        jSModule3.addDependency(jSModule6);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList12 = jSModule3.getDependencies();
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertNotNull(jSModuleList12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.jscomp.Scope scope5 = nodeTraversal2.getScope();
        java.lang.String str6 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode11 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode11, (com.google.javascript.rhino.Node) scriptOrFnNode15, (com.google.javascript.rhino.Node) scriptOrFnNode19);
        int int21 = scriptOrFnNode19.getFunctionCount();
        scriptOrFnNode19.removeParamOrVar("");
        boolean boolean24 = scriptOrFnNode19.isOptionalArg();
        int int27 = scriptOrFnNode19.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { scriptOrFnNode19 };
        try {
            nodeTraversal2.traverseRoots(nodeArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNull(scope5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(nodeArray28);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.rhino.Node node11 = compiler0.getRoot();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput13 = compiler0.getInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("goog.global", "goog.global", "TypeError: goog.exportSymbol");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference("or");
        java.lang.String str4 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray15 = scriptOrFnNode14.getParamAndVarNames();
        boolean boolean16 = scriptOrFnNode14.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry7.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode14, objectType17);
        scriptOrFnNode14.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node22 = scriptOrFnNode14.getAncestor(0);
        try {
            java.lang.String str23 = closureCodingConvention0.getSingletonGetterClassName(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        scriptOrFnNode8.setType((int) (short) 10);
        int int16 = scriptOrFnNode8.getRegexpCount();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isGeneratingSource();
//        boolean boolean3 = context1.isGeneratingDebugChanged();
//        java.util.Locale locale4 = null;
//        java.util.Locale locale5 = context1.setLocale(locale4);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNull(locale5);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            com.google.javascript.rhino.Context.reportWarning("function ({1595398090}): {1399939059}", "function ({1773287363}): {2008203786}", 44, "hi!", (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        boolean boolean17 = scriptOrFnNode12.isOptionalArg();
        com.google.javascript.rhino.Node node18 = scriptOrFnNode12.getNext();
        int int19 = scriptOrFnNode12.getType();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = scriptOrFnNode12.children();
        scriptOrFnNode12.removeParamOrVar("com.google.javascript.rhino.EcmaError: : hi! (null#1)");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(nodeIterable20);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function ({146683846}): {1882061578}", (int) (short) 10, 0);
        java.lang.String str4 = functionNode3.getFunctionName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "function ({146683846}): {1882061578}" + "'", str4.equals("function ({146683846}): {1882061578}"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("error reporter", (int) '4', 7);
        functionNode3.setType((-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable97 = functionPrototypeType96.getCtorImplementedInterfaces();
        boolean boolean98 = functionPrototypeType96.matchesStringContext();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertNotNull(objectTypeIterable97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("EOF");
        java.io.FilenameFilter filenameFilter2 = null;
        java.lang.String str3 = evaluatorException1.getScriptStackTrace(filenameFilter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        boolean boolean1 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setThrows();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode3.setBaseLineno(17);
        int int6 = scriptOrFnNode3.getEncodedSourceEnd();
        java.lang.Appendable appendable7 = null;
        try {
            scriptOrFnNode3.appendStringTree(appendable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("function ({146683846}): {1882061578}", "goog.exportProperty");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str13 = jSSourceFile12.getOriginalPath();
        java.lang.String str14 = jSSourceFile12.toString();
        java.io.Reader reader15 = jSSourceFile12.getCodeReader();
        java.lang.String str16 = jSSourceFile12.getName();
        com.google.javascript.rhino.Context context17 = null;
        com.google.javascript.rhino.Context context18 = com.google.javascript.rhino.Context.enter(context17);
        boolean boolean19 = context18.isGeneratingSource();
        context18.removeActivationName("");
        context18.setLanguageVersion(0);
        java.lang.RuntimeException runtimeException24 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSSourceFile12, (java.lang.Object) 0);
        com.google.javascript.rhino.Node node25 = compiler0.parse(jSSourceFile12);
        boolean boolean26 = compiler0.hasErrors();
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(context18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        jSTypeRegistry2.setTemplateTypeName("function ({1595398090}): {1399939059}");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray11 = scriptOrFnNode10.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType6, strArray11);
        java.text.MessageFormat messageFormat13 = diagnosticType6.format;
        java.lang.String[] strArray15 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray15);
        int int17 = diagnosticType2.compareTo(diagnosticType6);
        java.lang.String str18 = diagnosticType6.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(messageFormat13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-23) + "'", int17 == (-23));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str18.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        boolean boolean94 = functionType89.isReturnTypeInferred();
//        boolean boolean95 = functionType89.canBeCalled();
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({2118766111}): {1092353437}" + "'", str93.equals("function ({2118766111}): {1092353437}"));
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        boolean boolean97 = functionPrototypeType96.matchesObjectContext();
        boolean boolean98 = functionPrototypeType96.matchesNumberContext();
        boolean boolean99 = functionPrototypeType96.isFunctionPrototypeType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.forwardDeclareType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean10 = scriptOrFnNode9.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode9);
        scriptOrFnNode9.removeParamOrVar("goog.exportSymbol");
        scriptOrFnNode9.putBooleanProp((int) (short) -1, true);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry2.createFromTypeNodes((com.google.javascript.rhino.Node) scriptOrFnNode9, "function ({1472272120}): {1167130349}", jSTypeStaticScope18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100 [catch_scope_prop: 1]");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        scriptOrFnNode4.removeParamOrVar("goog.exportSymbol");
        scriptOrFnNode4.putBooleanProp((int) (short) -1, true);
        boolean boolean12 = scriptOrFnNode4.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(4, "<No stack trace available>");
        com.google.javascript.rhino.JSDocInfo jSDocInfo3 = node2.getJSDocInfo();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(jSDocInfo3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean9 = scriptOrFnNode8.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray22 = scriptOrFnNode21.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType17, strArray22);
        java.text.MessageFormat messageFormat24 = diagnosticType17.format;
        java.lang.String[] strArray26 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode8, checkLevel10, diagnosticType13, strArray26);
        compiler3.report(jSError28);
        try {
            compiler3.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(messageFormat24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSError28);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray4 = scriptOrFnNode3.getParamAndVarNames();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13, (com.google.javascript.rhino.Node) scriptOrFnNode17);
        int int19 = scriptOrFnNode17.getEncodedSourceEnd();
        com.google.javascript.rhino.Node node20 = scriptOrFnNode17.getNext();
        try {
            boolean boolean21 = scriptOrFnNode3.checkTreeTypeAwareEqualsSilent(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = compiler3.getRoot();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("return", generator7);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str12 = jSSourceFile11.getOriginalPath();
        java.lang.String str13 = jSSourceFile11.toString();
        java.io.Reader reader14 = jSSourceFile11.getCodeReader();
        java.lang.String str15 = jSSourceFile11.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str19 = jSSourceFile18.getOriginalPath();
        java.lang.String str20 = jSSourceFile18.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str24 = jSSourceFile23.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str29 = jSSourceFile28.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray31 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile11, jSSourceFile18, jSSourceFile23, jSSourceFile28 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = null;
        try {
            compiler3.init(jSSourceFileArray5, jSSourceFileArray31, compilerOptions32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(reader14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "or" + "'", str24.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "or" + "'", str29.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFileArray31);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope62 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = objectType27.forceResolve(errorReporter61, jSTypeStaticScope62);
        boolean boolean65 = objectType27.isPropertyInExterns("hi!");
        com.google.javascript.rhino.jstype.JSType jSType66 = objectType27.getIndexType();
        boolean boolean68 = objectType27.hasOwnProperty("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("or");
        jSModule6.addDependency(jSModule8);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule6.getThisAndAllDependencies();
        jSModule3.addDependency(jSModule6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str15 = jSSourceFile14.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
        jSModule3.remove(compilerInput18);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet20 = jSModule3.getAllDependencies();
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule24 = new com.google.javascript.jscomp.JSModule("or");
        jSModule22.addDependency(jSModule24);
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule29 = new com.google.javascript.jscomp.JSModule("or");
        jSModule27.addDependency(jSModule29);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet31 = jSModule27.getThisAndAllDependencies();
        jSModule24.addDependency(jSModule27);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str36 = jSSourceFile35.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput37, true);
        jSModule27.add(compilerInput39);
        try {
            jSModule3.add(compilerInput39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "or" + "'", str15.equals("or"));
        org.junit.Assert.assertNotNull(jSModuleSet20);
        org.junit.Assert.assertNotNull(jSModuleSet31);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "or" + "'", str36.equals("or"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        boolean boolean61 = objectType57.isNominalType();
        boolean boolean62 = objectType57.isUnknownType();
        boolean boolean63 = objectType57.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType65 = objectType57.findPropertyType("");
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(jSType65);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        java.lang.String str3 = context1.getImplementationVersion();
        int int4 = context1.getLanguageVersion();
        boolean boolean5 = context1.isSealed();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context1.removePropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        boolean boolean94 = functionType89.hasReferenceName();
        boolean boolean95 = functionType89.canBeCalled();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = objectType13.toObjectType();
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.restrictByNotNullOrUndefined();
        com.google.javascript.rhino.jstype.JSType jSType32 = objectType29.findPropertyType("com.google.javascript.rhino.EcmaError: : hi! (null#1)");
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNull(jSType32);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray18 = scriptOrFnNode17.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType13, strArray18);
        java.text.MessageFormat messageFormat20 = diagnosticType13.format;
        java.lang.String[] strArray22 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode4, checkLevel6, diagnosticType9, strArray22);
        java.lang.String str25 = diagnosticType9.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(messageFormat20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + ": ()" + "'", str25.equals(": ()"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        boolean boolean17 = scriptOrFnNode12.isOptionalArg();
        java.lang.String str18 = scriptOrFnNode12.getSourceName();
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(100, "hi!");
        boolean boolean6 = node5.hasChildren();
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compiler0, (java.lang.Object) node5);
        try {
            boolean boolean8 = compiler0.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        try {
            com.google.javascript.jscomp.JSModule jSModule4 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(120);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler11, callback12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str17 = jSSourceFile16.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16, true);
        com.google.javascript.rhino.Node node21 = compiler11.parse(jSSourceFile16);
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = null;
        try {
            com.google.javascript.jscomp.Result result24 = compiler7.compile(jSSourceFile16, jSModuleArray22, compilerOptions23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "or" + "'", str17.equals("or"));
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope4 = compiler3.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState5 = compiler3.getState();
        compiler0.setState(intermediateState5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            compiler0.initOptions(compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNotNull(intermediateState5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = functionType4.toObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(objectType5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }
}

