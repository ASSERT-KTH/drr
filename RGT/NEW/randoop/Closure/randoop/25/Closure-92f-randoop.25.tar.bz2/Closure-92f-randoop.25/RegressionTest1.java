import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        jSTypeRegistry2.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray17 = scriptOrFnNode16.getParamAndVarNames();
        boolean boolean18 = scriptOrFnNode16.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry9.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode16, objectType19);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType20.findPropertyType("TypeError");
        boolean boolean23 = objectType20.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry2.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType20);
        com.google.javascript.rhino.jstype.ObjectType objectType25 = jSTypeRegistry2.createAnonymousObjectType();
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(objectType25);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("pos", "function ({316341747}): {1694998584}", "Unknown class name");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput4.getModule();
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("or");
        jSModule9.addDependency(jSModule11);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList13 = jSModule11.getInputs();
        compilerInput4.setModule(jSModule11);
        jSModule11.removeAll();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertNotNull(compilerInputList13);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = ecmaError1.getScriptStackTrace(filenameFilter3);
        java.lang.String str5 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        boolean boolean45 = scriptOrFnNode43.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry36.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode43, objectType46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry50.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray58 = scriptOrFnNode57.getParamAndVarNames();
        boolean boolean59 = scriptOrFnNode57.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry50.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode57, objectType60);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType47.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType61);
        boolean boolean64 = objectType31.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType61, false);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType31.forceResolve(errorReporter65, jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.EnumType enumType68 = jSTypeRegistry2.createEnumType("<No stack trace available>", jSType67);
        boolean boolean69 = jSType67.isRecordType();
        boolean boolean70 = jSType67.isNominalType();
        boolean boolean71 = jSType67.isAllType();
        com.google.javascript.rhino.jstype.JSType jSType72 = jSType67.unboxesTo();
        boolean boolean73 = jSType67.isOrdinaryFunction();
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(enumType68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 29);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        double double10 = loggerErrorManager5.getTypedPercent();
        loggerErrorManager5.generateReport();
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "hi!", 14);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = null;
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder5);
        int int7 = tokenStream4.getTokenno();
        int int8 = tokenStream4.getToken();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 38 + "'", int8 == 38);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray8 = scriptOrFnNode7.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType3, strArray8);
        java.text.MessageFormat messageFormat10 = diagnosticType3.format;
        java.lang.String[] strArray12 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray12);
        java.lang.String str14 = jSError13.description;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(messageFormat10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Exceeded max number of optimization iterations: <No stack trace available>" + "'", str14.equals("Exceeded max number of optimization iterations: <No stack trace available>"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        compiler0.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = compiler0.tracker;
        com.google.javascript.jscomp.Scope scope5 = compiler0.getTopScope();
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNull(performanceTracker4);
        org.junit.Assert.assertNull(scope5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("or");
        jSModule6.addDependency(jSModule8);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule6.getThisAndAllDependencies();
        jSModule3.addDependency(jSModule6);
        int int12 = jSModule6.getDepth();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str16 = jSSourceFile15.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput17, true);
        java.lang.String str20 = compilerInput19.getCode();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19, true);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19, true);
        jSModule6.remove(compilerInput19);
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler26, callback27);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str32 = jSSourceFile31.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31, true);
        com.google.javascript.rhino.Node node36 = compiler26.parse(jSSourceFile31);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter37 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler26);
        int int38 = compiler26.getErrorCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker39 = compiler26.tracker;
        try {
            jSModule6.sortInputsByDeps(compiler26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "or" + "'", str16.equals("or"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "or" + "'", str32.equals("or"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(performanceTracker39);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        boolean boolean95 = functionType89.matchesUint32Context();
        java.lang.String str96 = functionType89.getTemplateTypeName();
        boolean boolean98 = functionType89.isPropertyInExterns("{...}");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNull(str96);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.setCompileFunctionsWithDynamicScope(true);
        context1.setLanguageVersion((int) (short) 100);
        context1.addActivationName("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(4095);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            com.google.javascript.rhino.Context.reportWarning("function ({1773287363}): {2008203786}");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        ecmaError1.initLineNumber(44);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.Node node4 = functionParamBuilder3.build();
        com.google.javascript.rhino.Node node5 = functionParamBuilder3.build();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = compiler3.getRoot();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt5 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt5);
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable97 = functionPrototypeType96.getCtorImplementedInterfaces();
        boolean boolean98 = functionPrototypeType96.isNativeObjectType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertNotNull(objectTypeIterable97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("");
        boolean boolean4 = googleCodingConvention0.isPrivate("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        java.lang.String str5 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean7 = googleCodingConvention0.isValidEnumKey("return");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeActivationName("");
        context1.removeActivationName("");
        boolean boolean7 = context1.isGeneratingSource();
        boolean boolean8 = context1.isGeneratingSource();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType98 = functionType89.getPropertyType("()");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(jSType98);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        node13.setVarArgs(true);
        boolean boolean16 = node13.isVarArgs();
        java.lang.String str20 = node13.toString(true, false, true);
        boolean boolean21 = node13.hasMoreThanOneChild();
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "EOF" + "'", str20.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.jscomp.Region region9 = compilerInput6.getRegion(15);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNull(region9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        int int2 = codeBuilder0.getLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        jSTypeRegistry2.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray17 = scriptOrFnNode16.getParamAndVarNames();
        boolean boolean18 = scriptOrFnNode16.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry9.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode16, objectType19);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType20.findPropertyType("TypeError");
        boolean boolean23 = objectType20.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry2.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType20);
        jSTypeRegistry2.setLastGeneration(false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSType24);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback19);
        com.google.javascript.jscomp.Compiler compiler21 = nodeTraversal20.getCompiler();
        com.google.javascript.jscomp.Scope scope22 = nodeTraversal20.getScope();
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType27, strArray32);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray38 = scriptOrFnNode37.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError39 = nodeTraversal20.makeError(node23, diagnosticType27, strArray38);
        java.lang.String[] strArray41 = new java.lang.String[] { "Not declared as a type name" };
        com.google.javascript.jscomp.JSError jSError42 = nodeTraversal2.makeError(node17, diagnosticType27, strArray41);
        int int43 = nodeTraversal2.getLineNumber();
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNotNull(compiler21);
        org.junit.Assert.assertNull(scope22);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        ecmaError1.initLineSource("hi!");
        ecmaError1.initSourceName("Not declared as a type name");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray24 = scriptOrFnNode23.getParamAndVarNames();
        boolean boolean25 = scriptOrFnNode23.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry16.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode23, objectType26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = objectType13.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray54 = scriptOrFnNode53.getParamAndVarNames();
        boolean boolean55 = scriptOrFnNode53.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry46.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode53, objectType56);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair58 = objectType43.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean60 = objectType27.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType57, false);
        java.util.Set<java.lang.String> strSet61 = objectType57.getOwnPropertyNames();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(typePair58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(strSet61);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        boolean boolean18 = node15.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 100, node15);
        int int20 = node15.getLineno();
        boolean boolean21 = node15.isNoSideEffectsCall();
        try {
            com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(43, node15, 52, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<java.lang.String> strList5 = jSModule1.getProvides();
        jSModule1.removeAll();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = jSModule1.getByName("function ({547577475}): {1536191071}");
        com.google.javascript.jscomp.CompilerInput compilerInput10 = jSModule1.getByName("language version");
        org.junit.Assert.assertNotNull(strList5);
        org.junit.Assert.assertNull(compilerInput8);
        org.junit.Assert.assertNull(compilerInput10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        boolean boolean90 = functionType89.hasReferenceName();
        com.google.javascript.rhino.jstype.FunctionType functionType91 = functionType89.getConstructor();
        try {
            boolean boolean92 = functionType91.matchesNumberContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(functionType91);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("@IMPLEMENTATION.VERSION@");
        boolean boolean5 = googleCodingConvention0.isExported("error reporter", true);
        boolean boolean8 = googleCodingConvention0.isExported("", false);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(47, (int) (short) -1, 0);
        try {
            boolean boolean13 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: REGEXP [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput3 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative3);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet6 = jSTypeRegistry2.getTypesWithProperty("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(objectTypeSet6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeActivationName("");
        context1.removeActivationName("");
        boolean boolean7 = context1.isGeneratingDebugChanged();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function ({460352397}): {1337071389}");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback19);
        com.google.javascript.jscomp.Compiler compiler21 = nodeTraversal20.getCompiler();
        com.google.javascript.jscomp.Scope scope22 = nodeTraversal20.getScope();
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType27, strArray32);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray38 = scriptOrFnNode37.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError39 = nodeTraversal20.makeError(node23, diagnosticType27, strArray38);
        java.lang.String[] strArray41 = new java.lang.String[] { "Not declared as a type name" };
        com.google.javascript.jscomp.JSError jSError42 = nodeTraversal2.makeError(node17, diagnosticType27, strArray41);
        java.lang.String str43 = jSError42.description;
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNotNull(compiler21);
        org.junit.Assert.assertNull(scope22);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Exceeded max number of optimization iterations: Not declared as a type name" + "'", str43.equals("Exceeded max number of optimization iterations: Not declared as a type name"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("or");
        jSModule6.addDependency(jSModule8);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule6.getThisAndAllDependencies();
        jSModule3.addDependency(jSModule6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str15 = jSSourceFile14.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput16, true);
        jSModule6.add(compilerInput18);
        com.google.javascript.jscomp.Region region21 = compilerInput18.getRegion((int) '4');
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "or" + "'", str15.equals("or"));
        org.junit.Assert.assertNull(region21);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        try {
//            com.google.javascript.rhino.Context.reportError("EOF", "function ({1920498015}): {823343230}", 12, "com.google.javascript.rhino.EcmaError: : hi! (null#1)", 26);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: EOF (function ({1920498015}): {823343230}#12)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = scriptOrFnNode3.getJSDocInfo();
        scriptOrFnNode3.putBooleanProp(0, false);
        int int8 = scriptOrFnNode3.getCharno();
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        java.lang.String str94 = functionType89.getTemplateTypeName();
//        boolean boolean96 = functionType89.isPropertyInExterns(": ERROR - Exceeded max number of optimization iterations: {0}\n");
//        boolean boolean97 = functionType89.isConstructor();
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({1344927007}): {1824904782}" + "'", str93.equals("function ({1344927007}): {1824904782}"));
//        org.junit.Assert.assertNull(str94);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.Node node17 = scriptOrFnNode12.getFirstChild();
        java.lang.String[] strArray18 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean20 = scriptOrFnNode12.addConst("");
        int int21 = scriptOrFnNode12.getRegexpCount();
        scriptOrFnNode12.setOptionalArg(true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function ({146683846}): {1882061578}");
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        try {
            jSModule1.sortInputsByDeps(compiler2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = jSTypeRegistry2.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry18.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray26 = scriptOrFnNode25.getParamAndVarNames();
        boolean boolean27 = scriptOrFnNode25.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType28 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry18.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode25, objectType28);
        com.google.javascript.rhino.jstype.JSType jSType31 = objectType29.findPropertyType("TypeError");
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, true);
        jSTypeRegistry34.setLastGeneration(true);
        jSTypeRegistry34.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, true);
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry41.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode48 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray49 = scriptOrFnNode48.getParamAndVarNames();
        boolean boolean50 = scriptOrFnNode48.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType51 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType52 = jSTypeRegistry41.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode48, objectType51);
        com.google.javascript.rhino.jstype.JSType jSType54 = objectType52.findPropertyType("TypeError");
        boolean boolean55 = objectType52.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry34.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType52);
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        boolean boolean62 = jSTypeRegistry59.declareType("", jSType61);
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, true);
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry65.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode72 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray73 = scriptOrFnNode72.getParamAndVarNames();
        boolean boolean74 = scriptOrFnNode72.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType75 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry65.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode72, objectType75);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] { objectType76 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean79 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList78, jSTypeArray77);
        com.google.javascript.rhino.Node node80 = jSTypeRegistry59.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList78);
        com.google.javascript.rhino.Node node81 = jSTypeRegistry34.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList78);
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType29, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList78);
        boolean boolean83 = functionType82.isOrdinaryFunction();
        java.util.Set<java.lang.String> strSet84 = functionType82.getPropertyNames();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNull(errorReporter15);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(objectType52);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(strSet84);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.restrictByNotNullOrUndefined();
//        boolean boolean96 = jSType95.isNominalType();
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({1442240340}): {1841014297}" + "'", str93.equals("function ({1442240340}): {1841014297}"));
//        org.junit.Assert.assertNotNull(objectTypeIterable94);
//        org.junit.Assert.assertNotNull(jSType95);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray8 = scriptOrFnNode7.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType3, strArray8);
        int int10 = jSError9.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("function ({1920498015}): {823343230}", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(100, "hi!");
        node2.detachChildren();
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode18, (com.google.javascript.rhino.Node) scriptOrFnNode22, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean boolean28 = scriptOrFnNode18.isVarArgs();
        boolean boolean30 = scriptOrFnNode18.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode35, (com.google.javascript.rhino.Node) scriptOrFnNode39, (com.google.javascript.rhino.Node) scriptOrFnNode43);
        boolean boolean45 = scriptOrFnNode35.isVarArgs();
        boolean boolean47 = scriptOrFnNode35.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node48 = scriptOrFnNode18.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode35);
        com.google.javascript.rhino.Node node49 = scriptOrFnNode9.clonePropsFrom(node48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = null;
        node48.setJSDocInfo(jSDocInfo50);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode60 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode64 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode56, (com.google.javascript.rhino.Node) scriptOrFnNode60, (com.google.javascript.rhino.Node) scriptOrFnNode64);
        int int66 = scriptOrFnNode64.getFunctionCount();
        scriptOrFnNode64.removeParamOrVar("");
        com.google.javascript.rhino.Node node69 = scriptOrFnNode64.getFirstChild();
        java.lang.String[] strArray70 = scriptOrFnNode64.getParamAndVarNames();
        int int71 = scriptOrFnNode64.getParamAndVarCount();
        try {
            com.google.javascript.rhino.Node node72 = node48.getChildBefore((com.google.javascript.rhino.Node) scriptOrFnNode64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNull(node69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        boolean boolean97 = functionPrototypeType96.matchesObjectContext();
        boolean boolean98 = functionPrototypeType96.matchesNumberContext();
        boolean boolean99 = functionPrototypeType96.isEnumElementType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.Node node17 = scriptOrFnNode12.getFirstChild();
        scriptOrFnNode12.setEndLineno((int) (short) 10);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = scriptOrFnNode12.siblings();
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable20);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        boolean boolean95 = functionType89.isInterface();
        boolean boolean97 = functionType89.isPropertyTypeDeclared("<No stack trace available>");
        com.google.javascript.rhino.jstype.ObjectType objectType98 = functionType89.toObjectType();
        com.google.javascript.rhino.jstype.JSType jSType99 = objectType98.getParameterType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertNotNull(objectType98);
        org.junit.Assert.assertNull(jSType99);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(4095, 19, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("com.google.javascript.rhino.EcmaError: : hi! (null#1)");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        boolean boolean97 = functionPrototypeType96.matchesNumberContext();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray30 = scriptOrFnNode29.getParamAndVarNames();
        boolean boolean31 = scriptOrFnNode29.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType32 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry22.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode29, objectType32);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair34 = objectType19.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType33);
        jSTypeRegistry2.registerPropertyOnType("goog.exportSymbol", (com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative36, jSTypeNative37, jSTypeNative38, jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry2.createUnionType(jSTypeNativeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
        com.google.javascript.rhino.jstype.JSType jSType49 = jSTypeRegistry47.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode54 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray55 = scriptOrFnNode54.getParamAndVarNames();
        boolean boolean56 = scriptOrFnNode54.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType57 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType58 = jSTypeRegistry47.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode54, objectType57);
        scriptOrFnNode54.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node62 = scriptOrFnNode54.getAncestor(0);
        scriptOrFnNode54.setBaseLineno((int) (byte) 1);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry2.createInterfaceType("hi!", (com.google.javascript.rhino.Node) scriptOrFnNode54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(typePair34);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(objectType58);
        org.junit.Assert.assertNotNull(node62);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        boolean boolean17 = scriptOrFnNode12.isOptionalArg();
        int int20 = scriptOrFnNode12.addRegexp("@IMPLEMENTATION.VERSION@", "<No stack trace available>");
        scriptOrFnNode12.detachChildren();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = null;
        scriptOrFnNode12.setJSDocInfo(jSDocInfo22);
        com.google.javascript.rhino.Node node24 = scriptOrFnNode12.cloneTree();
        com.google.javascript.rhino.Node node25 = scriptOrFnNode12.cloneNode();
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("");
        org.junit.Assert.assertNull(jSType3);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = null;
//        boolean boolean7 = composeWarningsGuard3.enables(diagnosticGroup6);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable19 = node15.children();
        com.google.javascript.rhino.Node node20 = node15.getFirstChild();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertNotNull(nodeIterable19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet4 = jSTypeRegistry2.getTypesWithProperty("function ({146683846}): {1882061578}");
        jSTypeRegistry2.resetForTypeCheck();
        org.junit.Assert.assertNotNull(objectTypeSet4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode11 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode11, (com.google.javascript.rhino.Node) scriptOrFnNode15, (com.google.javascript.rhino.Node) scriptOrFnNode19);
        boolean boolean21 = scriptOrFnNode11.isVarArgs();
        boolean boolean23 = scriptOrFnNode11.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode(13);
        try {
            node6.addChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode11, (com.google.javascript.rhino.Node) scriptOrFnNode25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node has siblings.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable95 = functionType89.getAllImplementedInterfaces();
        boolean boolean96 = functionType89.isNoObjectType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNotNull(objectTypeIterable95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode18, (com.google.javascript.rhino.Node) scriptOrFnNode22, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        boolean boolean28 = scriptOrFnNode18.isVarArgs();
        boolean boolean30 = scriptOrFnNode18.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode35, (com.google.javascript.rhino.Node) scriptOrFnNode39, (com.google.javascript.rhino.Node) scriptOrFnNode43);
        boolean boolean45 = scriptOrFnNode35.isVarArgs();
        boolean boolean47 = scriptOrFnNode35.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node48 = scriptOrFnNode18.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode35);
        com.google.javascript.rhino.Node node49 = scriptOrFnNode9.clonePropsFrom(node48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = null;
        node48.setJSDocInfo(jSDocInfo50);
        com.google.javascript.rhino.Node node52 = node48.cloneTree();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node52);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode11 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode7, (com.google.javascript.rhino.Node) scriptOrFnNode11, (com.google.javascript.rhino.Node) scriptOrFnNode15);
        node16.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = closureCodingConvention1.getDelegateRelationship(node16);
        boolean boolean20 = defaultCodingConvention0.isPropertyTestFunction(node16);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray31 = scriptOrFnNode30.getParamAndVarNames();
        boolean boolean32 = scriptOrFnNode30.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry23.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode30, objectType33);
        scriptOrFnNode30.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node38 = scriptOrFnNode30.getAncestor(0);
        scriptOrFnNode30.setBaseLineno((int) (byte) 1);
        boolean boolean41 = defaultCodingConvention0.isPropertyTestFunction((com.google.javascript.rhino.Node) scriptOrFnNode30);
        scriptOrFnNode30.setEndLineno(25);
        try {
            com.google.javascript.rhino.Node node45 = scriptOrFnNode30.getChildAtIndex(43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportSymbol" + "'", str2.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("or");
        jSModule6.addDependency(jSModule8);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule6.getThisAndAllDependencies();
        jSModule3.addDependency(jSModule6);
        int int12 = jSModule6.getDepth();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str16 = jSSourceFile15.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput17, true);
        java.lang.String str20 = compilerInput19.getCode();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19, true);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19, true);
        jSModule6.remove(compilerInput19);
        java.lang.String str26 = jSModule6.toString();
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "or" + "'", str16.equals("or"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "or" + "'", str26.equals("or"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable95 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.ObjectType objectType96 = functionType89.getImplicitPrototype();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNotNull(objectTypeIterable95);
        org.junit.Assert.assertNotNull(objectType96);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        boolean boolean93 = functionType89.isFunctionType();
        boolean boolean94 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNull(jSType95);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable97 = functionPrototypeType96.getCtorImplementedInterfaces();
        boolean boolean98 = functionPrototypeType96.isFunctionPrototypeType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertNotNull(objectTypeIterable97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str20 = closureCodingConvention19.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean25 = scriptOrFnNode24.isQuotedString();
        boolean boolean26 = scriptOrFnNode24.isNoSideEffectsCall();
        java.lang.String str27 = closureCodingConvention19.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean28 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode24);
        scriptOrFnNode24.setEncodedSourceBounds((int) (byte) 100, (int) ' ');
        java.lang.String str32 = scriptOrFnNode24.getSourceName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportSymbol" + "'", str20.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "function ({460352397}): {1337071389}", 0);
        java.lang.String str4 = evaluatorException3.sourceName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "function ({460352397}): {1337071389}" + "'", str4.equals("function ({460352397}): {1337071389}"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("@IMPLEMENTATION.VERSION@");
        boolean boolean5 = googleCodingConvention0.isExported("error reporter", true);
        boolean boolean7 = googleCodingConvention0.isValidEnumKey("function ({1595398090}): {1399939059}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode3.setBaseLineno(17);
        int int6 = scriptOrFnNode3.getEncodedSourceEnd();
        java.lang.String[] strArray7 = scriptOrFnNode3.getParamAndVarNames();
        int int8 = scriptOrFnNode3.getEndLineno();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(0, "<No stack trace available>");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        java.lang.String str20 = closureCodingConvention0.extractClassNameIfRequire(node5, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        boolean boolean22 = scriptOrFnNode14.hasParamOrVar("Exceeded max number of optimization iterations: <No stack trace available>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        java.lang.String str3 = ecmaError1.details();
        int int4 = ecmaError1.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: goog.exportSymbol" + "'", str3.equals("TypeError: goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        boolean boolean90 = functionType89.hasReferenceName();
        boolean boolean91 = functionType89.hasCachedValues();
        com.google.javascript.rhino.jstype.JSType jSType92 = functionType89.getReturnType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(jSType92);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(4, "()");
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode3.setBaseLineno(17);
        int int6 = scriptOrFnNode3.getEncodedSourceEnd();
        boolean boolean7 = scriptOrFnNode3.isLocalResultCall();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        com.google.javascript.rhino.Node node96 = null;
        functionType89.setSource(node96);
        com.google.javascript.rhino.JSDocInfo jSDocInfo99 = functionType89.getOwnPropertyJSDocInfo("goog.exportProperty");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(jSDocInfo99);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        jSTypeRegistry2.forwardDeclareType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder26 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        try {
            boolean boolean28 = functionParamBuilder26.addVarArgs(jSType27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray1 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList2 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList2, warningsGuardArray1);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard4 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList2);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        boolean boolean6 = composeWarningsGuard4.disables(diagnosticGroup5);
//        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup5;
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = null;
//        java.util.logging.Logger logger9 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter8, logger9);
//        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.OFF;
//        com.google.javascript.jscomp.JSError jSError12 = null;
//        loggerErrorManager10.println(checkLevel11, jSError12);
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel11);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("function ({1595398090}): {1399939059}", checkLevel11, "");
//        org.junit.Assert.assertNotNull(warningsGuardArray1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType16);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput4.getModule();
        compilerInput4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable97 = functionPrototypeType96.getCtorImplementedInterfaces();
        boolean boolean99 = functionPrototypeType96.hasOwnProperty("null");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertNotNull(objectTypeIterable97);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode5, (com.google.javascript.rhino.Node) scriptOrFnNode9, (com.google.javascript.rhino.Node) scriptOrFnNode13);
        node14.setVarArgs(true);
        boolean boolean17 = node14.isVarArgs();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 100, node14);
        int int19 = node14.getLineno();
        boolean boolean20 = node14.isNoSideEffectsCall();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection21 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(nodeCollection21);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup1;
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback5);
        com.google.javascript.jscomp.Compiler compiler7 = nodeTraversal6.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean13 = scriptOrFnNode12.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray26 = scriptOrFnNode25.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType21, strArray26);
        java.text.MessageFormat messageFormat28 = diagnosticType21.format;
        java.lang.String[] strArray30 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray30);
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode12, checkLevel14, diagnosticType17, strArray30);
        compiler7.report(jSError32);
        com.google.javascript.jscomp.MessageFormatter messageFormatter34 = null;
        java.util.logging.Logger logger35 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager36 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter34, logger35);
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError38 = null;
        loggerErrorManager36.println(checkLevel37, jSError38);
        com.google.javascript.jscomp.ErrorFormat errorFormat40 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler41 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback42 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal43 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler41, callback42);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str47 = jSSourceFile46.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46);
        com.google.javascript.jscomp.CompilerInput compilerInput50 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, true);
        com.google.javascript.rhino.Node node51 = compiler41.parse(jSSourceFile46);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter52 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler41);
        com.google.javascript.rhino.Node node53 = compiler41.getRoot();
        int int54 = compiler41.getErrorCount();
        com.google.javascript.jscomp.MessageFormatter messageFormatter56 = errorFormat40.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler41, true);
        java.lang.String str57 = jSError32.format(checkLevel37, messageFormatter56);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard58 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup1, checkLevel37);
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
        org.junit.Assert.assertNotNull(compiler7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(messageFormat28);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat40);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "or" + "'", str47.equals("or"));
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(messageFormatter56);
        org.junit.Assert.assertNull(str57);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.rhino.Node node12 = compiler0.getRoot();
        com.google.javascript.rhino.Node node13 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap14 = compiler0.getSourceMap();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNull(sourceMap14);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isNoSideEffectsCall();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode20 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16, (com.google.javascript.rhino.Node) scriptOrFnNode20);
        boolean boolean22 = scriptOrFnNode12.isVarArgs();
        boolean boolean24 = scriptOrFnNode12.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode12);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention26 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str28 = closureCodingConvention27.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode41 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode33, (com.google.javascript.rhino.Node) scriptOrFnNode37, (com.google.javascript.rhino.Node) scriptOrFnNode41);
        node42.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship45 = closureCodingConvention27.getDelegateRelationship(node42);
        boolean boolean46 = defaultCodingConvention26.isPropertyTestFunction(node42);
        java.lang.String str47 = closureCodingConvention0.identifyTypeDefAssign(node42);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportSymbol" + "'", str28.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        boolean boolean29 = jSTypeRegistry26.declareType("", jSType28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray40 = scriptOrFnNode39.getParamAndVarNames();
        boolean boolean41 = scriptOrFnNode39.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType42 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry32.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode39, objectType42);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] { objectType43 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList45, jSTypeArray44);
        com.google.javascript.rhino.Node node47 = jSTypeRegistry26.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList45);
        jSTypeRegistry26.forwardDeclareType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, true);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        boolean boolean55 = jSTypeRegistry52.declareType("", jSType54);
        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, true);
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode65 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray66 = scriptOrFnNode65.getParamAndVarNames();
        boolean boolean67 = scriptOrFnNode65.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry58.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode65, objectType68);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] { objectType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList71 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList71, jSTypeArray70);
        com.google.javascript.rhino.Node node73 = jSTypeRegistry52.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList71);
        jSTypeRegistry52.forwardDeclareType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder76 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry52);
        com.google.javascript.rhino.jstype.JSType jSType81 = jSTypeRegistry52.createNamedType("TypeError: goog.exportSymbol", "hi!", 52, 1);
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry26.createDefaultObjectUnion(jSType81);
        com.google.javascript.rhino.ErrorReporter errorReporter83 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry85 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter83, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative86 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType87 = jSTypeRegistry85.getNativeObjectType(jSTypeNative86);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray89 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType90 = jSTypeRegistry26.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType87, true, jSTypeArray89);
        com.google.javascript.rhino.jstype.JSType jSType91 = jSTypeRegistry2.createUnionType(jSTypeArray89);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope92 = null;
        com.google.javascript.rhino.jstype.JSType jSType97 = jSTypeRegistry2.getType(jSTypeStaticScope92, "or", "", 6, 45);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(strArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSTypeArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + jSTypeNative86 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative86.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
        org.junit.Assert.assertNotNull(objectType87);
        org.junit.Assert.assertNotNull(jSTypeArray89);
        org.junit.Assert.assertNotNull(functionType90);
        org.junit.Assert.assertNotNull(jSType91);
        org.junit.Assert.assertNotNull(jSType97);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable19 = node15.children();
        node15.setOptionalArg(true);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertNotNull(nodeIterable19);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.reportCodeChange();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = compiler0.getInput("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "", (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = null;
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder5);
        java.lang.Class<?> wildcardClass7 = tokenStream4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        boolean boolean1 = context0.isGeneratingDebugChanged();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean7 = scriptOrFnNode6.wasEmptyNode();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode6);
        boolean boolean9 = node8.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node10 = node8.getNext();
        try {
            context0.unseal((java.lang.Object) node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(node10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        int int2 = ecmaError1.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("function ({1344927007}): {1824904782}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(function ({1344927007}): {1824904782})" + "'", str1.equals("(function ({1344927007}): {1824904782})"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isNoSideEffectsCall();
        int int5 = scriptOrFnNode3.getRegexpCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
//        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
//        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
//        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
//        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
//        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
//        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
//        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
//        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
//        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
//        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
//        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
//        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
//        java.lang.String str93 = functionType89.toDebugHashCodeString();
//        boolean boolean94 = functionType89.isNativeObjectType();
//        boolean boolean95 = functionType89.isArrayType();
//        org.junit.Assert.assertNull(jSType7);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(objectType16);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(objectType30);
//        org.junit.Assert.assertNotNull(typePair31);
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectType46);
//        org.junit.Assert.assertNull(jSType51);
//        org.junit.Assert.assertNotNull(strArray57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(objectType60);
//        org.junit.Assert.assertNotNull(typePair61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNull(jSType64);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(strArray81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(strSet92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "function ({1189517534}): {803578967}" + "'", str93.equals("function ({1189517534}): {803578967}"));
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        jSTypeRegistry2.forwardDeclareType("hi!");
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder26 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode31, (com.google.javascript.rhino.Node) scriptOrFnNode35, (com.google.javascript.rhino.Node) scriptOrFnNode39);
        node40.setVarArgs(true);
        boolean boolean43 = node40.isVarArgs();
        com.google.javascript.rhino.Node node44 = functionParamBuilder26.newParameterFromNode(node40);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode49 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode53 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode49, (com.google.javascript.rhino.Node) scriptOrFnNode53, (com.google.javascript.rhino.Node) scriptOrFnNode57);
        int int59 = scriptOrFnNode57.getFunctionCount();
        scriptOrFnNode57.removeParamOrVar("");
        com.google.javascript.rhino.Node node62 = scriptOrFnNode57.getFirstChild();
        scriptOrFnNode57.setEndLineno((int) (short) 10);
        com.google.javascript.rhino.Node node65 = functionParamBuilder26.newParameterFromNode((com.google.javascript.rhino.Node) scriptOrFnNode57);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNull(node62);
        org.junit.Assert.assertNotNull(node65);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode4.setBaseLineno(17);
        int int7 = scriptOrFnNode4.getEncodedSourceEnd();
        com.google.javascript.rhino.FunctionNode functionNode11 = new com.google.javascript.rhino.FunctionNode("error reporter", (int) '4', 7);
        boolean boolean12 = functionNode11.getIgnoreDynamicScope();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(26, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) functionNode11);
        java.lang.String str14 = functionNode11.getFunctionName();
        com.google.javascript.rhino.Node node15 = functionNode11.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable16 = functionNode11.children();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "error reporter" + "'", str14.equals("error reporter"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(nodeIterable16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        boolean boolean92 = functionType89.isObject();
        boolean boolean93 = functionType89.isNumberObjectType();
        boolean boolean94 = functionType89.hasInstanceType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean5 = scriptOrFnNode4.wasEmptyNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(38, (com.google.javascript.rhino.Node) scriptOrFnNode4);
        scriptOrFnNode4.removeParamOrVar("goog.exportSymbol");
        boolean boolean10 = scriptOrFnNode4.addConst("Exceeded max number of optimization iterations: Not declared as a type name");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean4 = scriptOrFnNode3.isQuotedString();
        scriptOrFnNode3.removeParamOrVar("Exceeded max number of optimization iterations: Not declared as a type name");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        int int92 = functionType89.getMinArguments();
        com.google.javascript.rhino.jstype.JSType jSType93 = functionType89.unboxesTo();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType94 = functionType89.getPrototype();
        boolean boolean95 = functionPrototypeType94.hasReferenceName();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertNotNull(functionPrototypeType94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean9 = scriptOrFnNode8.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray22 = scriptOrFnNode21.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType17, strArray22);
        java.text.MessageFormat messageFormat24 = diagnosticType17.format;
        java.lang.String[] strArray26 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode8, checkLevel10, diagnosticType13, strArray26);
        compiler3.report(jSError28);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState30 = compiler3.getState();
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray31 = compiler3.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(messageFormat24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(intermediateState30);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode3.setBaseLineno(17);
        boolean boolean7 = scriptOrFnNode3.hasParamOrVar("null");
        com.google.javascript.rhino.Node node8 = scriptOrFnNode3.removeFirstChild();
        boolean boolean9 = scriptOrFnNode3.isUnscopedQualifiedName();
        boolean boolean10 = scriptOrFnNode3.isOnlyModifiesThisCall();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        boolean boolean94 = functionType89.hasReferenceName();
        boolean boolean95 = functionType89.isVoidType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo97 = null;
        functionType89.setPropertyJSDocInfo("goog.exportSymbol", jSDocInfo97, true);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.ObjectType objectType97 = functionType89.getTypeOfThis();
        boolean boolean98 = objectType97.isResolved();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(objectType97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        boolean boolean6 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.InstanceObjectType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback19);
        com.google.javascript.jscomp.Compiler compiler21 = nodeTraversal20.getCompiler();
        com.google.javascript.jscomp.Scope scope22 = nodeTraversal20.getScope();
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType27, strArray32);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray38 = scriptOrFnNode37.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError39 = nodeTraversal20.makeError(node23, diagnosticType27, strArray38);
        java.lang.String[] strArray41 = new java.lang.String[] { "Not declared as a type name" };
        com.google.javascript.jscomp.JSError jSError42 = nodeTraversal2.makeError(node17, diagnosticType27, strArray41);
        java.lang.String str43 = jSError42.sourceName;
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNotNull(compiler21);
        org.junit.Assert.assertNull(scope22);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.jscomp.Scope scope5 = nodeTraversal2.getScope();
        java.lang.String str6 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = scriptOrFnNode10.getJSDocInfo();
        scriptOrFnNode10.putBooleanProp(0, false);
        com.google.javascript.rhino.Node node15 = scriptOrFnNode10.getParent();
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList17 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList17, warningsGuardArray16);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList17);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean21 = composeWarningsGuard19.disables(diagnosticGroup20);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup20;
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError27 = null;
        loggerErrorManager25.println(checkLevel26, jSError27);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard29 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel26);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray38 = scriptOrFnNode37.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType33, strArray38);
        java.text.MessageFormat messageFormat40 = diagnosticType33.format;
        java.lang.String[] strArray42 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray42);
        java.text.MessageFormat messageFormat44 = diagnosticType33.format;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode49 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean50 = scriptOrFnNode49.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel51 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode62 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray63 = scriptOrFnNode62.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType58, strArray63);
        java.text.MessageFormat messageFormat65 = diagnosticType58.format;
        java.lang.String[] strArray67 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError68 = com.google.javascript.jscomp.JSError.make(diagnosticType58, strArray67);
        com.google.javascript.jscomp.JSError jSError69 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode49, checkLevel51, diagnosticType54, strArray67);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = diagnosticType54.defaultLevel;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode74 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        scriptOrFnNode74.setBaseLineno(17);
        int int77 = scriptOrFnNode74.getEncodedSourceEnd();
        java.lang.String[] strArray78 = scriptOrFnNode74.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError79 = com.google.javascript.jscomp.JSError.make(diagnosticType54, strArray78);
        com.google.javascript.jscomp.JSError jSError80 = nodeTraversal2.makeError((com.google.javascript.rhino.Node) scriptOrFnNode10, checkLevel26, diagnosticType33, strArray78);
        int int81 = nodeTraversal2.getLineNumber();
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNull(scope5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(jSDocInfo11);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNotNull(messageFormat44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(messageFormat65);
        org.junit.Assert.assertNotNull(strArray67);
        org.junit.Assert.assertNotNull(jSError68);
        org.junit.Assert.assertNotNull(jSError69);
        org.junit.Assert.assertTrue("'" + checkLevel70 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel70.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertNotNull(jSError79);
        org.junit.Assert.assertNotNull(jSError80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable97 = functionType89.getCtorImplementedInterfaces();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable97);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.Node node4 = functionParamBuilder3.build();
        java.lang.Appendable appendable5 = null;
        try {
            node4.appendStringTree(appendable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet5 = jSModule1.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("or");
        jSModule7.addDependency(jSModule9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = jSModule7.getByName("TypeError: goog.exportSymbol");
        com.google.javascript.jscomp.JSModule[] jSModuleArray13 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule7 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph14 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray13);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.jscomp.JSModuleGraph.ModuleDependenceException; message: Modules not in dependency order: or preceded or");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleSet5);
        org.junit.Assert.assertNull(compilerInput12);
        org.junit.Assert.assertNotNull(jSModuleArray13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable90 = functionType89.getParameters();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList91 = functionType89.getSubTypes();
        boolean boolean92 = functionType89.isUnknownType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(nodeIterable90);
        org.junit.Assert.assertNull(functionTypeList91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, true);
        com.google.javascript.rhino.Node node17 = compiler7.parse(jSSourceFile12);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        com.google.javascript.rhino.Node node19 = compiler7.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = compiler7.getTypeRegistry();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str25 = jSSourceFile24.getOriginalPath();
        java.lang.String str26 = jSSourceFile24.toString();
        java.io.Reader reader27 = jSSourceFile24.getCodeReader();
        java.lang.String str28 = jSSourceFile24.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24 };
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule33 = new com.google.javascript.jscomp.JSModule("or");
        jSModule31.addDependency(jSModule33);
        com.google.javascript.jscomp.JSModule jSModule36 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule38 = new com.google.javascript.jscomp.JSModule("or");
        jSModule36.addDependency(jSModule38);
        com.google.javascript.jscomp.JSModule jSModule41 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule43 = new com.google.javascript.jscomp.JSModule("or");
        jSModule41.addDependency(jSModule43);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet45 = jSModule41.getThisAndAllDependencies();
        jSModule38.addDependency(jSModule41);
        int int47 = jSModule41.getDepth();
        com.google.javascript.jscomp.JSModule jSModule49 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule51 = new com.google.javascript.jscomp.JSModule("or");
        jSModule49.addDependency(jSModule51);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList53 = jSModule51.getInputs();
        boolean boolean55 = jSModule51.removeByName("");
        com.google.javascript.jscomp.JSModule[] jSModuleArray56 = new com.google.javascript.jscomp.JSModule[] { jSModule33, jSModule41, jSModule51 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = null;
        try {
            compiler7.init(jSSourceFileArray29, jSModuleArray56, compilerOptions57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(jSTypeRegistry21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(reader27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray29);
        org.junit.Assert.assertNotNull(jSModuleSet45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(compilerInputList53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSModuleArray56);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("error reporter", (int) '4', 7);
        boolean boolean4 = functionNode3.getIgnoreDynamicScope();
        int int5 = functionNode3.getFunctionType();
        boolean boolean6 = functionNode3.requiresActivation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        boolean boolean97 = functionPrototypeType96.matchesObjectContext();
        boolean boolean98 = functionPrototypeType96.hasCachedValues();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("Unknown class name", 0, 22);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str20 = closureCodingConvention19.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean25 = scriptOrFnNode24.isQuotedString();
        boolean boolean26 = scriptOrFnNode24.isNoSideEffectsCall();
        java.lang.String str27 = closureCodingConvention19.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean28 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode24);
        java.lang.String str29 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean34 = scriptOrFnNode33.isQuotedString();
        boolean boolean35 = scriptOrFnNode33.isNoSideEffectsCall();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = closureCodingConvention0.getDelegateRelationship((com.google.javascript.rhino.Node) scriptOrFnNode33);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportSymbol" + "'", str20.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.global" + "'", str29.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(delegateRelationship36);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList5 = jSModule3.getInputs();
        boolean boolean7 = jSModule3.removeByName("TypeError");
        java.lang.String str8 = jSModule3.getName();
        org.junit.Assert.assertNotNull(compilerInputList5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "or" + "'", str8.equals("or"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        com.google.javascript.rhino.Node node96 = null;
        functionType89.setSource(node96);
        boolean boolean98 = functionType89.matchesNumberContext();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray15 = scriptOrFnNode14.getParamAndVarNames();
        boolean boolean16 = scriptOrFnNode14.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry7.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode14, objectType17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, true);
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry21.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray29 = scriptOrFnNode28.getParamAndVarNames();
        boolean boolean30 = scriptOrFnNode28.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType31 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry21.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode28, objectType31);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair33 = objectType18.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        jSTypeRegistry36.setLastGeneration(true);
        jSTypeRegistry36.forwardDeclareType("or");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, true);
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry43.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode50 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray51 = scriptOrFnNode50.getParamAndVarNames();
        boolean boolean52 = scriptOrFnNode50.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType53 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType54 = jSTypeRegistry43.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode50, objectType53);
        com.google.javascript.rhino.jstype.JSType jSType56 = objectType54.findPropertyType("TypeError");
        boolean boolean57 = objectType54.matchesInt32Context();
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry36.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType54);
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry36.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair60 = objectType32.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType59);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode65 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode69 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode73 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode65, (com.google.javascript.rhino.Node) scriptOrFnNode69, (com.google.javascript.rhino.Node) scriptOrFnNode73);
        scriptOrFnNode69.setType((int) (short) 10);
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType59, (com.google.javascript.rhino.Node) scriptOrFnNode69);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNotNull(typePair33);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertNotNull(typePair60);
        org.junit.Assert.assertNotNull(functionType77);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup4;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        compilerInput6.setModule(jSModule8);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("");
        boolean boolean4 = googleCodingConvention0.isPrivate("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        boolean boolean6 = googleCodingConvention0.isPrivate("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        int int14 = scriptOrFnNode12.getFunctionCount();
        scriptOrFnNode12.removeParamOrVar("");
        com.google.javascript.rhino.Node node17 = scriptOrFnNode12.getFirstChild();
        try {
            com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.new FileLevelJsDocBuilder();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: reflection call to com.google.javascript.rhino.Node$FileLevelJsDocBuilder with null for superclass argument");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        java.lang.String str7 = compilerInput6.getCode();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, true);
        compilerInput6.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or" + "'", str3.equals("or"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        scriptOrFnNode8.setType((int) (short) 10);
        boolean boolean16 = scriptOrFnNode8.isOptionalArg();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = scriptOrFnNode8.children();
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(nodeIterable17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getIndexType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType96 = functionType89.getPrototype();
        boolean boolean97 = functionPrototypeType96.matchesObjectContext();
        boolean boolean98 = functionPrototypeType96.matchesNumberContext();
        java.util.Set set99 = functionPrototypeType96.getOwnPropertyNames();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertNotNull(functionPrototypeType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertNotNull(set99);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.ObjectType objectType2 = jSTypeRegistry1.createAnonymousObjectType();
        org.junit.Assert.assertNotNull(objectType2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError(": ERROR - Exceeded max number of optimization iterations: {0}\n", "function ({2118766111}): {1092353437}");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 45");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet5 = jSModule1.getThisAndAllDependencies();
        jSModule1.setDepth(130);
        org.junit.Assert.assertNotNull(jSModuleSet5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        node23.setOptionalArg(true);
        node23.removeProp(8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(100, "hi!");
        boolean boolean6 = node5.hasChildren();
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compiler0, (java.lang.Object) node5);
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler8, callback9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope12 = compiler11.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState13 = compiler11.getState();
        compiler8.setState(intermediateState13);
        compiler0.setState(intermediateState13);
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler0.getSourceMap();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(runtimeException7);
        org.junit.Assert.assertNull(scope12);
        org.junit.Assert.assertNotNull(intermediateState13);
        org.junit.Assert.assertNull(sourceMap16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        boolean boolean95 = functionType89.matchesUint32Context();
        boolean boolean96 = functionType89.hasInstanceType();
        boolean boolean97 = functionType89.isVoidType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        boolean boolean14 = scriptOrFnNode4.isVarArgs();
        boolean boolean16 = scriptOrFnNode4.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode25 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode21, (com.google.javascript.rhino.Node) scriptOrFnNode25, (com.google.javascript.rhino.Node) scriptOrFnNode29);
        boolean boolean31 = scriptOrFnNode21.isVarArgs();
        boolean boolean33 = scriptOrFnNode21.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node34 = scriptOrFnNode4.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode21);
        node34.detachChildren();
        java.util.Set<java.lang.String> strSet36 = node34.getDirectives();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(strSet36);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        boolean boolean95 = functionType89.isInterface();
        boolean boolean97 = functionType89.isPropertyTypeDeclared("<No stack trace available>");
        com.google.javascript.rhino.jstype.ObjectType objectType98 = functionType89.toObjectType();
        boolean boolean99 = functionType89.isNativeObjectType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertNotNull(objectType98);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(or)" + "'", str1.equals("(or)"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(0, "<No stack trace available>");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        java.lang.String str20 = closureCodingConvention0.extractClassNameIfRequire(node5, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        java.lang.String str21 = node5.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "EOF <No stack trace available>" + "'", str21.equals("EOF <No stack trace available>"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getOptimizationLevel();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference("or");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode22, (com.google.javascript.rhino.Node) scriptOrFnNode26, (com.google.javascript.rhino.Node) scriptOrFnNode30);
        boolean boolean32 = scriptOrFnNode22.isVarArgs();
        boolean boolean34 = scriptOrFnNode22.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode47 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode39, (com.google.javascript.rhino.Node) scriptOrFnNode43, (com.google.javascript.rhino.Node) scriptOrFnNode47);
        boolean boolean49 = scriptOrFnNode39.isVarArgs();
        boolean boolean51 = scriptOrFnNode39.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node52 = scriptOrFnNode22.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode39);
        com.google.javascript.rhino.Node node53 = scriptOrFnNode13.clonePropsFrom(node52);
        boolean boolean54 = node52.isSyntheticBlock();
        try {
            java.util.List<java.lang.String> strList55 = closureCodingConvention0.identifyTypeDeclarationCall(node52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        int int92 = functionType89.getMinArguments();
        boolean boolean94 = functionType89.isPropertyTypeDeclared(": ERROR - Exceeded max number of optimization iterations: {0}\n");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(0, "<No stack trace available>");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14, (com.google.javascript.rhino.Node) scriptOrFnNode18);
        java.lang.String str20 = closureCodingConvention0.extractClassNameIfRequire(node5, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        boolean boolean22 = closureCodingConvention0.isSuperClassReference("function ({1920498015}): {823343230}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        int int92 = functionType89.getMinArguments();
        com.google.javascript.rhino.jstype.JSType jSType93 = functionType89.unboxesTo();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType94 = functionType89.getPrototype();
        boolean boolean95 = functionPrototypeType94.isNativeObjectType();
        com.google.javascript.rhino.jstype.JSType jSType97 = functionPrototypeType94.findPropertyType("EOF");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertNotNull(functionPrototypeType94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNull(jSType97);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        boolean boolean90 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        com.google.javascript.rhino.jstype.ObjectType objectType91 = jSTypeRegistry2.createAnonymousObjectType();
        jSTypeRegistry2.setTemplateTypeName("");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(objectType91);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager5.println(checkLevel6, jSError7);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str13 = jSSourceFile12.getOriginalPath();
        java.lang.String str14 = jSSourceFile12.toString();
        java.io.Reader reader15 = jSSourceFile12.getCodeReader();
        java.lang.String str16 = jSSourceFile12.getName();
        com.google.javascript.rhino.Context context17 = null;
        com.google.javascript.rhino.Context context18 = com.google.javascript.rhino.Context.enter(context17);
        boolean boolean19 = context18.isGeneratingSource();
        context18.removeActivationName("");
        context18.setLanguageVersion(0);
        java.lang.RuntimeException runtimeException24 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSSourceFile12, (java.lang.Object) 0);
        com.google.javascript.rhino.Node node25 = compiler0.parse(jSSourceFile12);
        java.lang.String str26 = jSSourceFile12.getOriginalPath();
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(context18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        scriptOrFnNode9.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node17 = scriptOrFnNode9.getAncestor(0);
        scriptOrFnNode9.setBaseLineno((int) (byte) 1);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString(34, "function ({1920498015}): {823343230}", 120, 7);
        scriptOrFnNode9.addChildrenToBack(node24);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node24);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        lightweightMessageFormatter11.setColorize(true);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler14, callback15);
        com.google.javascript.jscomp.Compiler compiler17 = nodeTraversal16.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean23 = scriptOrFnNode22.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray36 = scriptOrFnNode35.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType31, strArray36);
        java.text.MessageFormat messageFormat38 = diagnosticType31.format;
        java.lang.String[] strArray40 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make(diagnosticType31, strArray40);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode22, checkLevel24, diagnosticType27, strArray40);
        compiler17.report(jSError42);
        try {
            java.lang.String str44 = lightweightMessageFormatter11.formatWarning(jSError42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(compiler17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(messageFormat38);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean9 = scriptOrFnNode8.wasEmptyNode();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("", "()");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray22 = scriptOrFnNode21.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType17, strArray22);
        java.text.MessageFormat messageFormat24 = diagnosticType17.format;
        java.lang.String[] strArray26 = new java.lang.String[] { "<No stack trace available>" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray26);
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode8, checkLevel10, diagnosticType13, strArray26);
        compiler3.report(jSError28);
        com.google.javascript.jscomp.CheckLevel checkLevel30 = jSError28.level;
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(messageFormat24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        int int4 = ecmaError1.columnNumber();
        java.lang.String str5 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError: goog.exportSymbol" + "'", str5.equals("TypeError: goog.exportSymbol"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList5 = jSModule3.getInputs();
        boolean boolean7 = jSModule3.removeByName("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = jSModule3.getByName("goog.exportProperty");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput14, true);
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler17, callback18);
        compilerInput16.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        int int21 = compiler17.getWarningCount();
        try {
            jSModule3.sortInputsByDeps(compiler17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(compilerInputList5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(compilerInput9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "or" + "'", str13.equals("or"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportSymbol");
        java.lang.String str2 = ecmaError1.getScriptStackTrace();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        int int4 = ecmaError1.columnNumber();
        ecmaError1.initSourceName("(function ({1344927007}): {1824904782})");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        com.google.javascript.rhino.JSDocInfo jSDocInfo93 = null;
        functionType89.setPropertyJSDocInfo("language version", jSDocInfo93, false);
        boolean boolean96 = functionType89.isBooleanObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType97 = functionType89.getConstructor();
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType98 = functionType97.getInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(functionType97);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        java.lang.String str3 = context1.getImplementationVersion();
        context1.setInstructionObserverThreshold(49);
        context1.setCompileFunctionsWithDynamicScope(false);
        int int8 = context1.getInstructionObserverThreshold();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 49 + "'", int8 == 49);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str6 = jSSourceFile5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, true);
        com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        int int12 = compiler0.getErrorCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker13 = compiler0.tracker;
        com.google.javascript.jscomp.PerformanceTracker performanceTracker14 = null;
        compiler0.tracker = performanceTracker14;
        try {
            java.lang.String[] strArray16 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "or" + "'", str6.equals("or"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(performanceTracker13);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("JSC_OPTIMIZE_LOOP_ERROR", false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("or");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("or");
        jSModule1.addDependency(jSModule3);
        java.util.List<java.lang.String> strList5 = jSModule1.getProvides();
        java.util.List<java.lang.String> strList6 = jSModule1.getProvides();
        org.junit.Assert.assertNotNull(strList5);
        org.junit.Assert.assertNotNull(strList6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("function ({1489922516}): {1758479278}", "goog.exportSymbol", "hi!", 37, "Exceeded max number of optimization iterations: <No stack trace available>", 0);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(41, node1, 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        boolean boolean45 = scriptOrFnNode43.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry36.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode43, objectType46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry50.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray58 = scriptOrFnNode57.getParamAndVarNames();
        boolean boolean59 = scriptOrFnNode57.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry50.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode57, objectType60);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType47.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType61);
        boolean boolean64 = objectType31.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType61, false);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType31.forceResolve(errorReporter65, jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.EnumType enumType68 = jSTypeRegistry2.createEnumType("<No stack trace available>", jSType67);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder69 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(enumType68);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("hi!", checkLevel1, "null");
        java.text.MessageFormat messageFormat4 = diagnosticType3.format;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(messageFormat4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12, (com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback19);
        com.google.javascript.jscomp.Compiler compiler21 = nodeTraversal20.getCompiler();
        com.google.javascript.jscomp.Scope scope22 = nodeTraversal20.getScope();
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray32 = scriptOrFnNode31.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", 12, 14, diagnosticType27, strArray32);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray38 = scriptOrFnNode37.getParamAndVarNames();
        com.google.javascript.jscomp.JSError jSError39 = nodeTraversal20.makeError(node23, diagnosticType27, strArray38);
        java.lang.String[] strArray41 = new java.lang.String[] { "Not declared as a type name" };
        com.google.javascript.jscomp.JSError jSError42 = nodeTraversal2.makeError(node17, diagnosticType27, strArray41);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput43 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(compiler3);
        org.junit.Assert.assertNotNull(compiler21);
        org.junit.Assert.assertNull(scope22);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingSource();
        context1.removeActivationName("");
        context1.setLanguageVersion(0);
        boolean boolean7 = context1.isGeneratingSource();
        java.lang.String str8 = context1.getImplementationVersion();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str8.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean6 = scriptOrFnNode5.isQuotedString();
        boolean boolean7 = scriptOrFnNode5.isNoSideEffectsCall();
        java.lang.String str8 = closureCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode5);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode18 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode14, (com.google.javascript.rhino.Node) scriptOrFnNode18, (com.google.javascript.rhino.Node) scriptOrFnNode22);
        node23.setVarArgs(true);
        boolean boolean26 = node23.isVarArgs();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 100, node23);
        node23.setCharno((int) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode35 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode35, (com.google.javascript.rhino.Node) scriptOrFnNode39, (com.google.javascript.rhino.Node) scriptOrFnNode43);
        node44.setVarArgs(true);
        boolean boolean47 = node44.isVarArgs();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) 100, node44);
        node44.setCharno((int) (byte) 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode55 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode59 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode63 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode55, (com.google.javascript.rhino.Node) scriptOrFnNode59, (com.google.javascript.rhino.Node) scriptOrFnNode63);
        node64.setVarArgs(true);
        java.lang.String str67 = node44.checkTreeEquals(node64);
        java.lang.String str68 = closureCodingConvention0.extractClassNameIfProvide(node23, node44);
        com.google.javascript.rhino.Node node69 = node23.getLastSibling();
        boolean boolean70 = node69.isNoSideEffectsCall();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode75 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode79 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode83 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode75, (com.google.javascript.rhino.Node) scriptOrFnNode79, (com.google.javascript.rhino.Node) scriptOrFnNode83);
        int int85 = scriptOrFnNode83.getFunctionCount();
        scriptOrFnNode83.removeParamOrVar("");
        com.google.javascript.rhino.Node node88 = scriptOrFnNode83.getFirstChild();
        java.lang.String str89 = scriptOrFnNode83.toString();
        try {
            node69.removeChild((com.google.javascript.rhino.Node) scriptOrFnNode83);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNull(node88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100" + "'", str89.equals("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("function ({547577475}): {1536191071}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        int int92 = functionType89.getMinArguments();
        com.google.javascript.rhino.jstype.JSType jSType93 = functionType89.unboxesTo();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType94 = functionType89.getPrototype();
        boolean boolean96 = functionPrototypeType94.isPropertyTypeDeclared("TypeError");
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertNotNull(functionPrototypeType94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = functionType89.getAllImplementedInterfaces();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable95 = functionType89.getAllImplementedInterfaces();
        int int96 = functionType89.getMaxArguments();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNotNull(objectTypeIterable95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("()", "null");
        java.lang.String str3 = ecmaError2.getName();
        int int4 = ecmaError2.columnNumber();
        java.lang.Throwable throwable5 = null;
        try {
            ecmaError2.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "()" + "'", str3.equals("()"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("or", "hi!");
        java.lang.String str7 = jSSourceFile6.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6, true);
        com.google.javascript.rhino.Node node11 = compiler1.parse(jSSourceFile6);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter12 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node13 = compiler1.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager14 = compiler1.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = null;
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter15, logger16);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.JSError jSError19 = null;
        loggerErrorManager17.println(checkLevel18, jSError19);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "or" + "'", str7.equals("or"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(errorManager14);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(messageFormatter23);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", 40, 26);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) '4', 48, 0);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry6.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray14 = scriptOrFnNode13.getParamAndVarNames();
        boolean boolean15 = scriptOrFnNode13.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry6.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode13, objectType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray28 = scriptOrFnNode27.getParamAndVarNames();
        boolean boolean29 = scriptOrFnNode27.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry20.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode27, objectType30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair32 = objectType17.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray44 = scriptOrFnNode43.getParamAndVarNames();
        boolean boolean45 = scriptOrFnNode43.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry36.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode43, objectType46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry50.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode57 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray58 = scriptOrFnNode57.getParamAndVarNames();
        boolean boolean59 = scriptOrFnNode57.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry50.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode57, objectType60);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType47.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType61);
        boolean boolean64 = objectType31.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType61, false);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        com.google.javascript.rhino.jstype.JSType jSType67 = objectType31.forceResolve(errorReporter65, jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.EnumType enumType68 = jSTypeRegistry2.createEnumType("<No stack trace available>", jSType67);
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry2.createNamedType("", "", (int) (byte) 0, 160);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention74 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str75 = closureCodingConvention74.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode79 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo80 = scriptOrFnNode79.getJSDocInfo();
        scriptOrFnNode79.putBooleanProp(0, false);
        boolean boolean84 = closureCodingConvention74.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode79);
        boolean boolean86 = closureCodingConvention74.isConstantKey("TypeError: goog.exportSymbol");
        boolean boolean87 = jSType73.equals((java.lang.Object) closureCodingConvention74);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(typePair32);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(enumType68);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "goog.exportSymbol" + "'", str75.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(jSDocInfo80);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("@IMPLEMENTATION.VERSION@", "function ({1489922516}): {1758479278}", 120);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("function ({316341747}): {1694998584}", ": ERROR - Exceeded max number of optimization iterations: {0}\n", 0, "function ({146683846}): {1882061578}", (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable90 = functionType89.getParameters();
        boolean boolean91 = functionType89.hasReferenceName();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(nodeIterable90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        boolean boolean1 = context0.isGeneratingDebugChanged();
        boolean boolean2 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray10 = scriptOrFnNode9.getParamAndVarNames();
        boolean boolean11 = scriptOrFnNode9.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode9, objectType12);
        scriptOrFnNode9.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node17 = scriptOrFnNode9.getAncestor(0);
        int int18 = scriptOrFnNode9.getFunctionCount();
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(35);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        boolean boolean5 = jSTypeRegistry2.declareType("", jSType4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray16 = scriptOrFnNode15.getParamAndVarNames();
        boolean boolean17 = scriptOrFnNode15.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry8.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode15, objectType18);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType19 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        node23.setOptionalArg(true);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable26 = node23.getAncestors();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(ancestorIterable26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        boolean boolean16 = scriptOrFnNode6.isVarArgs();
        boolean boolean18 = scriptOrFnNode6.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode27 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode23, (com.google.javascript.rhino.Node) scriptOrFnNode27, (com.google.javascript.rhino.Node) scriptOrFnNode31);
        boolean boolean33 = scriptOrFnNode23.isVarArgs();
        boolean boolean35 = scriptOrFnNode23.addConst("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        com.google.javascript.rhino.Node node36 = scriptOrFnNode6.clonePropsFrom((com.google.javascript.rhino.Node) scriptOrFnNode23);
        boolean[] booleanArray37 = scriptOrFnNode23.getParamAndVarConst();
        try {
            com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("Not declared as a type name", nodeList1, (com.google.javascript.rhino.Node) scriptOrFnNode23, 32, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(booleanArray37);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode6, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode14);
        node15.setVarArgs(true);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str20 = closureCodingConvention19.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        boolean boolean25 = scriptOrFnNode24.isQuotedString();
        boolean boolean26 = scriptOrFnNode24.isNoSideEffectsCall();
        java.lang.String str27 = closureCodingConvention19.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode24);
        boolean boolean28 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode24);
        scriptOrFnNode24.detachChildren();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportSymbol" + "'", str20.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode8, (com.google.javascript.rhino.Node) scriptOrFnNode12);
        java.lang.String str14 = scriptOrFnNode4.toString();
        boolean boolean15 = scriptOrFnNode4.isVarArgs();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100" + "'", str14.equals("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray13 = scriptOrFnNode12.getParamAndVarNames();
        boolean boolean14 = scriptOrFnNode12.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry5.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode12, objectType15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray27 = scriptOrFnNode26.getParamAndVarNames();
        boolean boolean28 = scriptOrFnNode26.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode26, objectType29);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair31 = objectType16.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray43 = scriptOrFnNode42.getParamAndVarNames();
        boolean boolean44 = scriptOrFnNode42.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry35.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode42, objectType45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode56 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray57 = scriptOrFnNode56.getParamAndVarNames();
        boolean boolean58 = scriptOrFnNode56.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSTypeRegistry49.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode56, objectType59);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair61 = objectType46.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType30.defineInferredProperty("language version", (com.google.javascript.rhino.jstype.JSType) objectType60, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = objectType30.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        boolean boolean70 = jSTypeRegistry67.declareType("", jSType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.getType("hi!");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode80 = new com.google.javascript.rhino.ScriptOrFnNode((int) '4', (int) (short) 100, (int) (short) 10);
        java.lang.String[] strArray81 = scriptOrFnNode80.getParamAndVarNames();
        boolean boolean82 = scriptOrFnNode80.hasMoreThanOneChild();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry73.createObjectType("INSTANCEOF [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100", (com.google.javascript.rhino.Node) scriptOrFnNode80, objectType83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType84 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.Node node88 = jSTypeRegistry67.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType30, node88);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = null;
        boolean boolean91 = functionType89.setPrototype(functionPrototypeType90);
        java.util.Set<java.lang.String> strSet92 = functionType89.getPropertyNames();
        int int93 = functionType89.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable94 = functionType89.getParameters();
        com.google.javascript.rhino.jstype.JSType jSType95 = functionType89.getReturnType();
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(typePair31);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNotNull(typePair61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(nodeIterable94);
        org.junit.Assert.assertNotNull(jSType95);
    }
}

