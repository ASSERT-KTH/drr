import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "hi!", "", "hi!", "" };
        try {
            com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("", (int) (short) 0, (int) ' ', checkLevel3, diagnosticType4, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.regexp(node0, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        java.lang.Object obj10 = node8.getProp(0);
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.label(node3, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        try {
            node3.setDouble((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: PARAM_LIST is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        boolean boolean9 = node8.isParamList();
        try {
            com.google.javascript.rhino.Node node10 = node3.removeChildAfter(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.comma(node0, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        try {
            com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, node1, node2, node6, node11, (int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!", "hi!", "" };
        try {
            com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isParamList();
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.sub(node3, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Node.INPUT_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.regexp(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            int int4 = compilerInput3.getNumLines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.ifNode(node3, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V1;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        com.google.javascript.rhino.Node node6 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        try {
            node0.addChildAfter(node6, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        java.lang.Object obj9 = node7.getProp(0);
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.tryFinally(node3, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        boolean boolean9 = node8.isParamList();
        boolean boolean10 = node8.isNull();
        boolean boolean11 = node8.isBlock();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        java.lang.Object obj17 = node15.getProp(0);
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.tryCatchFinally(node3, node8, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str1 = diagnosticType0.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isTry();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node3, node7, node9 };
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.script(nodeArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNotNull(nodeArray15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            com.google.javascript.jscomp.SourceFile sourceFile4 = compilerInput3.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = null;
        java.lang.String[] strArray9 = null;
        try {
            com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node4, checkLevel7, diagnosticType8, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        try {
            java.lang.String str6 = node3.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: PARAM_LIST is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.rhino.InputId inputId4 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, inputId4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        try {
            int int7 = node3.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 0");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            java.util.Collection<java.lang.String> strCollection4 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        boolean boolean7 = node4.isBlock();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.propdef(node0, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node0.isAnd();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        java.lang.Object obj12 = node10.getProp(0);
        boolean boolean13 = node10.isSyntheticBlock();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.eq(node0, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWith();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.String str12 = node7.checkTreeEquals(node11);
        boolean boolean13 = node7.isAnd();
        java.lang.String str14 = node7.getQualifiedName();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.tryCatchFinally(node3, node7, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str12.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions.Reach reach2 = null;
        try {
            compilerOptions0.setInlineVariables(reach2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.String str12 = node7.checkTreeEquals(node11);
        boolean boolean13 = node11.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        java.lang.String str19 = node14.checkTreeEquals(node18);
        try {
            node3.replaceChildAfter(node11, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str12.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str19.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.sheq(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.Node node0 = null;
        java.lang.String str1 = com.google.javascript.jscomp.NodeUtil.getSourceName(node0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isParamList();
        boolean boolean13 = node11.isNull();
        com.google.javascript.rhino.jstype.JSType jSType14 = node11.getJSType();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.propdef(node3, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSType14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        java.util.Set<java.lang.String> strSet6 = node4.getDirectives();
        boolean boolean7 = node4.isWith();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        java.lang.String str13 = node8.checkTreeEquals(node12);
        boolean boolean14 = node8.isAnd();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.function(node0, node4, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str13.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node0.isAnd();
        java.lang.String str7 = node0.getQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isParamList();
        boolean boolean13 = node11.isNull();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.and(node0, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        boolean boolean13 = node10.isBlock();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        java.lang.String str19 = node14.checkTreeEquals(node18);
        boolean boolean20 = node14.isAnd();
        java.lang.String str21 = node14.getQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList24 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList24, nodeArray23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList24);
        boolean boolean27 = node26.isParamList();
        boolean boolean28 = node26.isNull();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 1, node26);
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList31 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList31, nodeArray30);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList31);
        boolean boolean34 = node33.isParamList();
        boolean boolean35 = node33.isNull();
        boolean boolean36 = node33.isBlock();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] { node3, node10, node14, node26, node33, node37 };
        try {
            com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.arraylit(nodeArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str19.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(nodeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(nodeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray38);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.throwNode(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.add(node3, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        java.lang.String str6 = node1.checkTreeEquals(node5);
        com.google.javascript.rhino.Node node7 = node5.getFirstChild();
        try {
            java.util.List<java.lang.String> strList8 = closureCodingConvention0.identifyTypeDeclarationCall(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str6.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            int int5 = compilerInput3.getNumLines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isParamList();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.JSType jSType19 = node16.getJSType();
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.tryCatchFinally(node7, node11, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(jSType19);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.io.Reader reader2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromReader("hi!", reader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, true);
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        java.lang.Object obj12 = node10.getProp(0);
        boolean boolean13 = node10.isSyntheticBlock();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node3, node10, node14 };
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList(nodeArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        boolean boolean13 = node10.isBlock();
        boolean boolean14 = node10.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList17);
        java.lang.String str20 = node15.checkTreeEquals(node19);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList23 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList23, nodeArray22);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList23);
        boolean boolean26 = node25.isParamList();
        boolean boolean27 = node25.isNull();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 1, node25);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList30 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList30, nodeArray29);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList30);
        boolean boolean33 = node32.isParamList();
        boolean boolean34 = node32.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile35 = node32.getStaticSourceFile();
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node3, node10, node19, node28, node32 };
        try {
            com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.block(nodeArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str20.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(staticSourceFile35);
        org.junit.Assert.assertNotNull(nodeArray36);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        java.lang.Appendable appendable7 = null;
        try {
            node3.appendStringTree(appendable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.lineBreak = true;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node0.isAnd();
        int int7 = node0.getCharno();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions12.checkProvides = checkLevel20;
        compilerOptions0.checkRequires = checkLevel20;
        compilerOptions0.jqueryPass = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isInstanceOf();
        boolean boolean7 = node3.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("Unknown class name", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$Unknown class name" + "'", str2.equals("module$Unknown class name"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isInstanceOf();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node3.getStaticSourceFile();
        boolean boolean8 = node3.isAssignAdd();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node node8 = node3.getParent();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        boolean boolean15 = node13.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        java.lang.String str21 = node16.checkTreeEquals(node20);
        try {
            com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.forIn(node8, node13, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str21.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setCrossModuleMethodMotion(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(locationMappingList4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node6.getStaticSourceFile();
        boolean boolean9 = node6.isNot();
        try {
            nodeTraversal2.traverse(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            com.google.javascript.jscomp.Region region6 = compilerInput3.getRegion(52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 1, node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder8.append("hi!");
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isNot();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isScript();
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.regexp(node3, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType3, functionType4, objectType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isParamList();
        boolean boolean11 = node9.isNull();
        try {
            com.google.javascript.rhino.Node node12 = node3.removeChildAfter(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping2 = new com.google.javascript.jscomp.SourceMap.LocationMapping("module$Unknown class name", "Unknown class name");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile11 = node9.getStaticSourceFile();
        boolean boolean12 = node9.isNot();
        boolean boolean13 = node9.isBreak();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.eq(node3, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(staticSourceFile11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.setReserveRawExports(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isTry();
        java.util.Set<java.lang.String> strSet7 = node5.getDirectives();
        boolean boolean8 = node5.isInstanceOf();
        com.google.javascript.rhino.Node node9 = node0.clonePropsFrom(node5);
        try {
            java.lang.String str10 = node0.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: CONTINUE is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("Unknown class name", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType3, functionType4, objectType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile6 = node4.getStaticSourceFile();
        boolean boolean7 = node4.isNot();
        boolean boolean8 = node0.isEquivalentToTyped(node4);
        com.google.javascript.rhino.Node node9 = null;
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.tryFinally(node0, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(staticSourceFile6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.regexp(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        compilerOptions0.jqueryPass = true;
        compilerOptions0.setRenamePrefix("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("goog.exportProperty", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: unexpected quote char:a");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.removeUnusedPrototypeProperties = false;
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.generatePseudoNames;
        compilerOptions3.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions3.checkRequires;
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet12 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet12, strArray11);
        compilerOptions3.setIdGenerators((java.util.Set<java.lang.String>) strSet12);
        compilerOptions1.setStripTypes((java.util.Set<java.lang.String>) strSet12);
        compilerOptions1.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = compilerOptions1.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy19 = compilerOptions1.propertyRenaming;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = diagnosticType20.defaultLevel;
        compilerOptions1.checkProvides = checkLevel21;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel21, "Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy19.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType24);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isInstanceOf();
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = null;
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        boolean boolean16 = node15.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile17 = node15.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node15.siblings();
        try {
            com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, node10, node11, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(staticSourceFile17);
        org.junit.Assert.assertNotNull(nodeIterable18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition6 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation7 = aliasTransformationHandler4.logAliasTransformation("hi!", aliasTransformationSourcePosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNew();
        int int6 = node3.getChildCount();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setMoveFunctionDeclarations(false);
        boolean boolean11 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean12 = compilerOptions0.jqueryPass;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.syntheticBlockStartMarker = "hi!";
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        boolean boolean12 = compilerOptions0.removeUnusedVars;
        compilerOptions0.setCollapseProperties(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node0.isAnd();
        boolean boolean7 = node0.isAdd();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isWhile();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.newNode(node6, nodeArray10);
        try {
            nodeTraversal2.traverse(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidSimpleName("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        java.lang.String str6 = node1.checkTreeEquals(node5);
        boolean boolean7 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        java.lang.String str14 = node11.getQualifiedName();
        node5.addChildrenToFront(node11);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = closureCodingConvention16.getDelegateRelationship(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isParamList();
        boolean boolean25 = node23.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile26 = node23.getStaticSourceFile();
        java.lang.String str27 = closureCodingConvention16.extractClassNameIfRequire(node19, node23);
        node5.addChildrenToBack(node19);
        try {
            com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(0, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str6.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(staticSourceFile26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        try {
            node8.addChildBefore(node9, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        compilerOptions0.setDefineToNumberLiteral("goog.exportProperty", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder2 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            compiler1.toSource(codeBuilder2, 48, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile12 = node10.getStaticSourceFile();
        boolean boolean13 = node10.isNot();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node10.siblings();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.comma(node3, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(staticSourceFile12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeIterable14);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        try {
            com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setOptimizeCalls(true);
        compilerOptions0.setCheckCaja(true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = null;
        compilerOptions0.setWarningsGuard(composeWarningsGuard10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.generatePseudoNames;
        compilerOptions14.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions14.checkRequires;
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet23 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet23, strArray22);
        compilerOptions14.setIdGenerators((java.util.Set<java.lang.String>) strSet23);
        compilerOptions12.setStripTypes((java.util.Set<java.lang.String>) strSet23);
        compilerOptions12.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat29 = compilerOptions12.errorFormat;
        compilerOptions0.setErrorFormat(errorFormat29);
        compilerOptions0.setProtectHiddenSideEffects(false);
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(errorFormat29);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        try {
            com.google.javascript.rhino.Node node7 = compilerInput3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap5 = compilerOptions0.getDefineReplacements();
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertNotNull(strMap5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput3 = compiler1.newExternInput("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean5 = closureCodingConvention0.isValidEnumKey("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        java.lang.String str6 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setAliasStringsBlacklist("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        java.util.Map<java.lang.String, com.google.javascript.jscomp.CheckLevel> strMap8 = null;
        try {
            compilerOptions0.setPropertyInvalidationErrors(strMap8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile5.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str11 = jSSourceFile9.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile14.clearCachedSource();
        java.lang.String str16 = jSSourceFile14.getCode();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str21 = jSSourceFile19.getLine((int) '#');
        jSSourceFile19.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile26.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile14, jSSourceFile19, jSSourceFile26 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        compilerOptions29.jqueryPass = false;
        compilerOptions29.setAliasStringsBlacklist("hi!");
        try {
            com.google.javascript.jscomp.Result result36 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray28, compilerOptions29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        java.util.Set<java.lang.String> strSet6 = node4.getDirectives();
        boolean boolean7 = node4.isWhile();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.newNode(node4, nodeArray8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList(nodeArray8);
        com.google.javascript.rhino.Node node11 = null;
        int int12 = node10.getIndexOfChild(node11);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship13 = closureCodingConvention0.getClassesDefinedByCall(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        try {
            com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.optimizeParameters = true;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        java.lang.String str14 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.setDefineToStringLiteral("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTypeOf();
        boolean boolean5 = node3.isNoSideEffectsCall();
        boolean boolean6 = node3.isTry();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile3 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node2);
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isTry();
        java.util.Set<java.lang.String> strSet9 = node7.getDirectives();
        boolean boolean10 = node7.isInstanceOf();
        com.google.javascript.rhino.Node node11 = node2.clonePropsFrom(node7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean14 = diagnosticGroup12.matches(diagnosticType13);
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node11, diagnosticType13, strArray16);
        com.google.javascript.rhino.Node node18 = null;
        try {
            com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.ifNode(node0, node11, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(staticSourceFile3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.JSModule jSModule5 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node node3 = node1.getLastChild();
        boolean boolean4 = node1.isNoSideEffectsCall();
        node1.setSourceEncodedPosition(0);
        com.google.javascript.rhino.Node node7 = null;
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4', node1, node7, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray4 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkProvides;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.generatePseudoNames;
        compilerOptions6.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions6.setCssRenamingMap(cssRenamingMap11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.generatePseudoNames;
        compilerOptions13.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions13.checkRequires;
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        compilerOptions13.setIdGenerators((java.util.Set<java.lang.String>) strSet22);
        compilerOptions6.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet22);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet22);
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setRenamePrefixNamespace("");
        boolean boolean22 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        try {
            com.google.javascript.rhino.Node node5 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        boolean boolean6 = node3.isBlock();
        boolean boolean7 = node3.hasMoreThanOneChild();
        boolean boolean8 = node3.isSetterDef();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT;
        com.google.javascript.jscomp.DiagnosticGroups.CONST = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        java.lang.String str7 = compilerInput6.getName();
        com.google.javascript.rhino.InputId inputId9 = new com.google.javascript.rhino.InputId("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str10 = inputId9.getIdName();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, inputId9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str10.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String str4 = compiler1.getSourceLine("", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.rhino.InputId inputId8 = new com.google.javascript.rhino.InputId("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput9 = compiler1.getInput(inputId8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 1, node4);
        try {
            com.google.javascript.rhino.Node node8 = node7.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        compilerOptions0.setLooseTypes(false);
        compilerOptions0.setCommonJSModulePathPrefix("goog.exportProperty");
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        java.lang.String str9 = node4.checkTreeEquals(node8);
        boolean boolean10 = node4.isAnd();
        try {
            nodeTraversal2.traverse(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str9.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAppNameStr("");
        compilerOptions0.inlineConstantVars = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(logger23);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = loggerErrorManager24.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean27 = compilerOptions26.generatePseudoNames;
        boolean boolean28 = compilerOptions26.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions26.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError30 = null;
        loggerErrorManager24.println(checkLevel29, jSError30);
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel29);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap33 = compilerOptions0.getTweakReplacements();
        boolean boolean34 = compilerOptions0.removeUnusedPrototypeProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isInstanceOf();
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean13 = diagnosticGroup11.matches(diagnosticType12);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node10, diagnosticType12, strArray15);
        int int17 = jSError16.getNodeSourceOffset();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.JSType jSType19 = node16.getJSType();
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        boolean boolean21 = node20.isOnlyModifiesThisCall();
        boolean boolean22 = node20.isName();
        try {
            com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.getelem(node5, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        java.util.Map<java.lang.String, java.lang.Object> strMap7 = null;
        compilerOptions0.setDefineReplacements(strMap7);
        compilerOptions0.devirtualizePrototypeMethods = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap11 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap11;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setSummaryDetailLevel((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "hi!", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        compilerOptions0.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList19);
        byte[] byteArray22 = new byte[] {};
        compilerOptions0.setInputVariableMapSerialized(byteArray22);
        compilerOptions0.setTweakToDoubleLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", 0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(byteArray22);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        java.lang.String[] strArray5 = new java.lang.String[] { "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet6);
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean10 = compilerOptions0.aliasExternals;
        compilerOptions0.optimizeCalls = true;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        java.lang.Object obj12 = node10.getProp(0);
        java.lang.String str13 = node10.getQualifiedName();
        node4.addChildrenToFront(node10);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node16 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship17 = closureCodingConvention15.getDelegateRelationship(node16);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isParamList();
        boolean boolean24 = node22.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile25 = node22.getStaticSourceFile();
        java.lang.String str26 = closureCodingConvention15.extractClassNameIfRequire(node18, node22);
        node4.addChildrenToBack(node18);
        com.google.javascript.rhino.Node node28 = null;
        try {
            com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.doNode(node4, node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(delegateRelationship17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(staticSourceFile25);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        boolean boolean10 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = compilerOptions0.variableRenaming;
        compilerOptions0.removeDeadCode = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy30.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node node8 = node3.getParent();
        boolean boolean9 = node3.isNull();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        boolean boolean16 = node15.isParamList();
        boolean boolean17 = node15.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile18 = node15.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId19 = null;
        node15.setInputId(inputId19);
        boolean boolean21 = closureCodingConvention11.isOptionalParameter(node15);
        boolean boolean22 = detailLevel10.apply(node15);
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList24 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList24, nodeArray23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList24);
        boolean boolean27 = node26.isTry();
        java.util.Set<java.lang.String> strSet28 = node26.getDirectives();
        boolean boolean29 = node26.isWhile();
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.newNode(node26, nodeArray30);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.paramList(nodeArray30);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.newNode(node15, nodeArray30);
        try {
            com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.switchNode(node3, nodeArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(staticSourceFile18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(nodeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(strSet28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(nodeArray30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder41 = null;
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList44 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList44, nodeArray43);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList44);
        boolean boolean47 = node46.isParamList();
        boolean boolean48 = node46.isNull();
        com.google.javascript.rhino.jstype.JSType jSType49 = node46.getJSType();
        com.google.javascript.rhino.Node node50 = node46.getLastSibling();
        boolean boolean51 = node50.isOnlyModifiesThisCall();
        try {
            compiler1.toSource(codeBuilder41, 2147483647, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray5 = compilerOptions4.inputPropertyMapSerialized;
        compilerOptions4.setShadowVariables(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.generatePseudoNames;
        compilerOptions8.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions8.checkRequires;
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet17 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet17, strArray16);
        compilerOptions8.setIdGenerators((java.util.Set<java.lang.String>) strSet17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.generatePseudoNames;
        compilerOptions20.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.generatePseudoNames;
        compilerOptions24.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions24.checkRequires;
        compilerOptions20.checkProvides = checkLevel28;
        compilerOptions8.checkRequires = checkLevel28;
        compilerOptions4.setCheckGlobalThisLevel(checkLevel28);
        compilerOptions0.setCheckMissingReturn(checkLevel28);
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.JSModule jSModule38 = null;
        try {
            java.lang.String[] strArray39 = compiler1.toSourceArray(jSModule38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("()", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: unexpected quote char:4");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node8 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = closureCodingConvention7.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        boolean boolean15 = node14.isParamList();
        boolean boolean16 = node14.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile17 = node14.getStaticSourceFile();
        java.lang.String str18 = closureCodingConvention7.extractClassNameIfRequire(node10, node14);
        boolean boolean19 = node10.isOr();
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.doNode(node0, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(staticSourceFile17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "()");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        java.lang.Object obj17 = node15.getProp(0);
        boolean boolean18 = node15.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        java.lang.String str25 = node20.checkTreeEquals(node24);
        boolean boolean26 = node24.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean31 = node30.isTry();
        java.util.Set<java.lang.String> strSet32 = node30.getDirectives();
        boolean boolean33 = node30.isWith();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList35 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList35, nodeArray34);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList35);
        node24.addChildAfter(node30, node37);
        java.lang.String str39 = closureCodingConvention0.extractClassNameIfRequire(node15, node37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList42 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList42, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList42);
        java.lang.String str45 = node40.checkTreeEquals(node44);
        com.google.javascript.rhino.Node node46 = node44.getFirstChild();
        try {
            node37.addChildrenToFront(node46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str25.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(strSet32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str45.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(node46);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        boolean boolean9 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 1, node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node4.getJsDocBuilderForNode();
        boolean boolean9 = node4.isOr();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) -1, (byte) 1, (byte) -1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        boolean boolean10 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        int int22 = node20.getIntProp(100);
        com.google.javascript.rhino.Node node23 = node16.useSourceInfoIfMissingFromForTree(node20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isTry();
        com.google.javascript.rhino.Node node30 = node24.srcref(node28);
        boolean boolean31 = node30.isThis();
        try {
            com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.assign(node16, node30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile13 = node11.getStaticSourceFile();
        boolean boolean14 = node11.isNot();
        boolean boolean15 = node7.isEquivalentToTyped(node11);
        node3.addChildrenToFront(node11);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(staticSourceFile13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap32 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap32;
        java.lang.String str34 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        boolean boolean11 = node4.hasOneChild();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile9.clearCachedSource();
        com.google.javascript.rhino.Node node11 = compiler6.parse(jSSourceFile9);
        try {
            compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        int int6 = node3.getCharno();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTypeOf();
        boolean boolean12 = node10.isNoSideEffectsCall();
        int int13 = node10.getType();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.comma(node3, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 83 + "'", int13 == 83);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        boolean boolean12 = node3.isOr();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        java.lang.String str18 = node13.checkTreeEquals(node17);
        boolean boolean19 = node13.isAnd();
        java.lang.String str20 = node13.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.label(node3, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str18.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        java.lang.Object obj12 = node10.getProp(0);
        java.lang.String str13 = node10.getQualifiedName();
        node4.addChildrenToFront(node10);
        boolean boolean15 = node4.isEmpty();
        int int16 = node4.getType();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 83 + "'", int16 == 83);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
//        boolean boolean4 = compilerInput3.isExtern();
//        java.util.logging.Logger logger5 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
//        loggerErrorManager6.generateReport();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions8.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
//        byte[] byteArray12 = compilerOptions8.inputPropertyMapSerialized;
//        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkProvides;
//        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
//        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
//        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
//        boolean boolean19 = node18.isParamList();
//        boolean boolean20 = node18.isNull();
//        com.google.javascript.rhino.jstype.JSType jSType21 = node18.getJSType();
//        com.google.javascript.rhino.Node node22 = node18.getLastSibling();
//        com.google.javascript.rhino.Node node23 = node18.getParent();
//        boolean boolean24 = node18.isNull();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray31 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
//        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node18, diagnosticType25, strArray31);
//        com.google.javascript.jscomp.CheckLevel checkLevel33 = jSError32.level;
//        int int34 = jSError32.lineNumber;
//        loggerErrorManager6.report(checkLevel13, jSError32);
//        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
//        try {
//            compilerInput3.removeRequire("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(nodeArray15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNull(node23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(diagnosticType25);
//        org.junit.Assert.assertNotNull(strArray31);
//        org.junit.Assert.assertNotNull(jSError32);
//        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        boolean boolean9 = node3.isDefaultCase();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isParamList();
        boolean boolean11 = node9.isNew();
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.tryCatch(node3, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray12 = compilerOptions11.inputPropertyMapSerialized;
        compilerOptions11.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        compilerOptions11.setAggressiveVarCheck(checkLevel19);
        compilerOptions0.setReportUnknownTypes(checkLevel19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        boolean boolean12 = compilerOptions0.aliasAllStrings;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        boolean boolean2 = node1.isArrayLit();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isScript();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isTry();
        com.google.javascript.rhino.Node node11 = null;
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.ifNode(node3, node9, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Object obj1 = null;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("goog.exportProperty", obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.setAliasStringsBlacklist("Unknown class name");
        boolean boolean13 = compilerOptions0.checkTypes;
        compilerOptions0.setAppNameStr("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.optimizeParameters = true;
        compilerOptions0.inlineVariables = true;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean32 = closureCodingConvention0.isPrototypeAlias(node31);
        com.google.javascript.rhino.Node node33 = null;
        try {
            com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.var(node31, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setSpecializeInitialModule(false);
        boolean boolean6 = compilerOptions0.markAsCompiled;
        compilerOptions0.setProtectHiddenSideEffects(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isTry();
        java.util.Set<java.lang.String> strSet18 = node16.getDirectives();
        boolean boolean19 = node16.isWhile();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.newNode(node16, nodeArray20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList(nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.newNode(node5, nodeArray20);
        node23.setVarArgs(true);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions0.checkRequires;
        compilerOptions0.collapseAnonymousFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("goog.exportProperty", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile6 = builder0.buildFromCode("", "()");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions0.setTracer(tracerMode14);
        compilerOptions0.setTweakToBooleanLiteral("", true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node3.new FileLevelJsDocBuilder();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable8 = node3.children();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.neg(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeIterable8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.setCheckTypes(false);
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        node3.setSourceFileForTesting("");
        try {
            node3.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: not a StringNode");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray5 = compilerOptions4.inputPropertyMapSerialized;
        compilerOptions4.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions4.sourceMapLocationMappings;
        compilerOptions0.sourceMapLocationMappings = locationMappingList8;
        compilerOptions0.generateExports = true;
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertNotNull(locationMappingList8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        boolean boolean4 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 1, node10);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = closureCodingConvention14.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        boolean boolean22 = node21.isParamList();
        boolean boolean23 = node21.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile24 = node21.getStaticSourceFile();
        java.lang.String str25 = closureCodingConvention14.extractClassNameIfRequire(node17, node21);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList27 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList27, nodeArray26);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList27);
        boolean boolean30 = node29.isParamList();
        boolean boolean31 = node29.isNull();
        com.google.javascript.rhino.jstype.JSType jSType32 = node29.getJSType();
        node21.addChildrenToBack(node29);
        java.lang.String str34 = closureCodingConvention5.extractClassNameIfProvide(node10, node29);
        try {
            java.lang.String str35 = closureCodingConvention0.getSingletonGetterClassName(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(staticSourceFile24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.markAsCompiled = true;
        compilerOptions0.printInputDelimiter = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy11 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy11;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy11 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy11.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node3.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor7 = ancestorIterable6.iterator();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor8 = ancestorIterable6.iterator();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertNotNull(nodeItor7);
        org.junit.Assert.assertNotNull(nodeItor8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        boolean boolean17 = node16.isVoid();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap4 = compilerOptions0.customPasses;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        int int7 = node4.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = jSSourceFile2.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        try {
            java.lang.String str7 = compilerInput6.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isTry();
        java.util.Set<java.lang.String> strSet7 = node5.getDirectives();
        boolean boolean8 = node5.isInstanceOf();
        com.google.javascript.rhino.Node node9 = node0.clonePropsFrom(node5);
        try {
            node0.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: not a StringNode");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        compiler1.rebuildInputsFromModules();
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = com.google.javascript.rhino.Node.STATIC_SOURCE_FILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions0.setTracer(tracerMode14);
        compilerOptions0.setExportTestFunctions(false);
        boolean boolean18 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        java.lang.String str6 = node1.checkTreeEquals(node5);
        boolean boolean7 = node1.isAnd();
        java.lang.String str8 = node1.getQualifiedName();
        try {
            java.lang.String str9 = com.google.javascript.rhino.ScriptRuntime.getMessage1("goog.exportProperty", (java.lang.Object) str8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str6.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node3.siblings();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        com.google.javascript.rhino.Node node14 = node10.getLastSibling();
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = node14.isName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention17 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node18 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = closureCodingConvention17.getDelegateRelationship(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        boolean boolean25 = node24.isParamList();
        boolean boolean26 = node24.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile27 = node24.getStaticSourceFile();
        java.lang.String str28 = closureCodingConvention17.extractClassNameIfRequire(node20, node24);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList30 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList30, nodeArray29);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList30);
        boolean boolean33 = node32.isParamList();
        boolean boolean34 = node32.isNull();
        com.google.javascript.rhino.jstype.JSType jSType35 = node32.getJSType();
        node24.addChildrenToBack(node32);
        try {
            com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.forIn(node3, node14, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(staticSourceFile27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(jSType35);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        int int22 = node20.getIntProp(100);
        com.google.javascript.rhino.Node node23 = node16.useSourceInfoIfMissingFromForTree(node20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isTry();
        com.google.javascript.rhino.Node node30 = node24.srcref(node28);
        try {
            com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.comma(node20, node30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isDelProp();
        boolean boolean6 = node3.isTrue();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder8 = null;
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        boolean boolean14 = node13.isParamList();
        boolean boolean15 = node13.isNull();
        com.google.javascript.rhino.jstype.JSType jSType16 = node13.getJSType();
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        com.google.javascript.rhino.Node node18 = node13.getParent();
        boolean boolean19 = node13.isNull();
        try {
            compiler1.toSource(codeBuilder8, 39, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        boolean boolean12 = node3.isOr();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile14 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node13);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        boolean boolean19 = node18.isTry();
        java.util.Set<java.lang.String> strSet20 = node18.getDirectives();
        boolean boolean21 = node18.isInstanceOf();
        com.google.javascript.rhino.Node node22 = node13.clonePropsFrom(node18);
        boolean boolean23 = node18.isCall();
        node3.addChildrenToFront(node18);
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(staticSourceFile14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler27 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback28 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal29 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler27, callback28);
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList31 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList31, nodeArray30);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList31);
        java.lang.Object obj35 = node33.getProp(0);
        boolean boolean36 = node33.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder37 = node33.new FileLevelJsDocBuilder();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable38 = node33.children();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast39 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal29, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(nodeIterable38);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        boolean boolean10 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions12.checkProvides = checkLevel20;
        compilerOptions0.checkRequires = checkLevel20;
        java.lang.String str23 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel27);
        boolean boolean29 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setExternExportsPath("");
        boolean boolean3 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = null;
        compilerOptions0.setWarningsGuard(composeWarningsGuard9);
        boolean boolean11 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        java.lang.String str7 = node2.checkTreeEquals(node6);
        boolean boolean8 = node6.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        java.lang.Object obj14 = node12.getProp(0);
        java.lang.String str15 = node12.getQualifiedName();
        node6.addChildrenToFront(node12);
        boolean boolean17 = node6.isEmpty();
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.getprop(node0, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str7.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", generator1);
        java.lang.String str3 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str3.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.deadAssignmentElimination = false;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.propdef(node3, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType15 = null;
        closureCodingConvention0.applySubclassRelationship(functionType13, functionType14, subclassType15);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention17 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        boolean boolean22 = node21.isParamList();
        boolean boolean23 = node21.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile24 = node21.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId25 = null;
        node21.setInputId(inputId25);
        boolean boolean27 = closureCodingConvention17.isOptionalParameter(node21);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship28 = closureCodingConvention0.getClassesDefinedByCall(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(staticSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        boolean boolean6 = compilerOptions0.removeUnusedPrototypeProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput3.getAst();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(sourceAst5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node7 = node3.getFirstChild();
        try {
            boolean boolean8 = node7.isAssignAdd();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean32 = closureCodingConvention0.isPrototypeAlias(node31);
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList34 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList34, nodeArray33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList34);
        boolean boolean37 = node36.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile38 = node36.getStaticSourceFile();
        boolean boolean39 = node36.isNot();
        boolean boolean40 = node36.isBreak();
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship41 = closureCodingConvention0.getClassesDefinedByCall(node36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(nodeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(staticSourceFile38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        java.lang.String str7 = compilerInput6.getName();
        try {
            java.util.Collection<java.lang.String> strCollection8 = compilerInput6.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getErrors();
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isParamList();
        boolean boolean11 = node9.isNull();
        com.google.javascript.rhino.jstype.JSType jSType12 = node9.getJSType();
        com.google.javascript.rhino.Node node13 = node9.getLastSibling();
        com.google.javascript.rhino.Node node14 = node9.getParent();
        boolean boolean15 = node9.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node9, diagnosticType16, strArray22);
        try {
            loggerErrorManager1.println(checkLevel4, jSError23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int int1 = com.google.javascript.jscomp.NodeUtil.getInverseOperator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = compilerOptions0.variableRenaming;
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy30.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        compilerOptions0.disambiguateProperties = false;
        boolean boolean7 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.prettyPrint = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
//        boolean boolean4 = compilerInput3.isExtern();
//        java.util.logging.Logger logger5 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
//        loggerErrorManager6.generateReport();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions8.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
//        byte[] byteArray12 = compilerOptions8.inputPropertyMapSerialized;
//        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkProvides;
//        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
//        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
//        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
//        boolean boolean19 = node18.isParamList();
//        boolean boolean20 = node18.isNull();
//        com.google.javascript.rhino.jstype.JSType jSType21 = node18.getJSType();
//        com.google.javascript.rhino.Node node22 = node18.getLastSibling();
//        com.google.javascript.rhino.Node node23 = node18.getParent();
//        boolean boolean24 = node18.isNull();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray31 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
//        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node18, diagnosticType25, strArray31);
//        com.google.javascript.jscomp.CheckLevel checkLevel33 = jSError32.level;
//        int int34 = jSError32.lineNumber;
//        loggerErrorManager6.report(checkLevel13, jSError32);
//        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
//        com.google.javascript.jscomp.JSModule jSModule37 = compilerInput3.getModule();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(nodeArray15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNull(node23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(diagnosticType25);
//        org.junit.Assert.assertNotNull(strArray31);
//        org.junit.Assert.assertNotNull(jSError32);
//        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNull(jSModule37);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions12.checkProvides = checkLevel20;
        compilerOptions0.checkRequires = checkLevel20;
        java.lang.String str23 = compilerOptions0.syntheticBlockEndMarker;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap24 = compilerOptions0.customPasses;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = null;
        compilerOptions0.setWarningsGuard(composeWarningsGuard9);
        compilerOptions0.setRecordFunctionInformation(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isInstanceOf();
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean13 = diagnosticGroup11.matches(diagnosticType12);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node10, diagnosticType12, strArray15);
        java.lang.String[] strArray17 = null;
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray17);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(jSError18);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setOptimizeCalls(false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setCollapseProperties(false);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy5, propertyRenamingPolicy6);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.breakNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isNot();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.block(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "goog.exportProperty", "goog.abstractMethod");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("()");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.generatePseudoNames;
        compilerOptions6.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkRequires;
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        compilerOptions6.setIdGenerators((java.util.Set<java.lang.String>) strSet15);
        compilerOptions4.setStripTypes((java.util.Set<java.lang.String>) strSet15);
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "hi!", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.ArrayList<java.lang.String> strList23 = new java.util.ArrayList<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList23, strArray22);
        compilerOptions4.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList23);
        com.google.javascript.jscomp.SourceAst sourceAst26 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(sourceAst26, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst30 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(sourceAst30, "", true);
        com.google.javascript.jscomp.JSModule jSModule34 = compilerInput33.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst35 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput38 = new com.google.javascript.jscomp.CompilerInput(sourceAst35, "", true);
        com.google.javascript.jscomp.JSModule jSModule39 = null;
        compilerInput38.setModule(jSModule39);
        com.google.javascript.jscomp.SourceAst sourceAst41 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(sourceAst41, "", true);
        com.google.javascript.jscomp.JSModule jSModule45 = compilerInput44.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst46 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(sourceAst46, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput52 = new com.google.javascript.jscomp.CompilerInput(sourceAst46, "hi!", true);
        java.lang.String str53 = compilerInput52.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str58 = jSSourceFile56.getLine((int) '#');
        jSSourceFile56.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput60 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile56);
        com.google.javascript.jscomp.SourceAst sourceAst61 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput64 = new com.google.javascript.jscomp.CompilerInput(sourceAst61, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput67 = new com.google.javascript.jscomp.CompilerInput(sourceAst61, "hi!", true);
        java.lang.String str68 = compilerInput67.getName();
        com.google.javascript.jscomp.SourceAst sourceAst69 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput(sourceAst69, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput75 = new com.google.javascript.jscomp.CompilerInput(sourceAst69, "hi!", true);
        com.google.javascript.jscomp.SourceAst sourceAst76 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput79 = new com.google.javascript.jscomp.CompilerInput(sourceAst76, "", true);
        com.google.javascript.jscomp.JSModule jSModule80 = null;
        compilerInput79.setModule(jSModule80);
        com.google.javascript.jscomp.SourceAst sourceAst82 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput85 = new com.google.javascript.jscomp.CompilerInput(sourceAst82, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst86 = compilerInput85.getSourceAst();
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray87 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput29, compilerInput33, compilerInput38, compilerInput44, compilerInput52, compilerInput60, compilerInput67, compilerInput75, compilerInput79, compilerInput85 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList88 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean89 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList88, compilerInputArray87);
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList90 = jSModuleGraph3.manageDependencies((java.util.List<java.lang.String>) strList23, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(jSModule34);
        org.junit.Assert.assertNull(jSModule45);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertNull(sourceAst86);
        org.junit.Assert.assertNotNull(compilerInputArray87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        boolean boolean12 = node3.isOr();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.block();
        boolean boolean14 = node13.hasChildren();
        node3.addChildToBack(node13);
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setTweakToBooleanLiteral("module$Unknown class name", true);
        boolean boolean10 = compilerOptions0.checkSymbols;
        compilerOptions0.syntheticBlockEndMarker = "module$Unknown class name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        java.lang.Object obj17 = node15.getProp(0);
        boolean boolean18 = node15.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        java.lang.String str25 = node20.checkTreeEquals(node24);
        boolean boolean26 = node24.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean31 = node30.isTry();
        java.util.Set<java.lang.String> strSet32 = node30.getDirectives();
        boolean boolean33 = node30.isWith();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList35 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList35, nodeArray34);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList35);
        node24.addChildAfter(node30, node37);
        java.lang.String str39 = closureCodingConvention0.extractClassNameIfRequire(node15, node37);
        boolean boolean41 = closureCodingConvention0.isConstantKey("hi!");
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str25.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(strSet32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 1, node16);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isTry();
        java.util.Set<java.lang.String> strSet25 = node23.getDirectives();
        boolean boolean26 = node23.isWith();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node23.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        boolean boolean30 = node29.isArrayLit();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList33 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList33, nodeArray32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList33);
        java.lang.String str36 = node31.checkTreeEquals(node35);
        boolean boolean37 = node35.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList39 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList39, nodeArray38);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList39);
        boolean boolean42 = node41.isTry();
        java.util.Set<java.lang.String> strSet43 = node41.getDirectives();
        boolean boolean44 = node41.isWith();
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList46 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList46, nodeArray45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList46);
        node35.addChildAfter(node41, node48);
        com.google.javascript.rhino.Node node50 = node35.getLastChild();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList53 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList53, nodeArray52);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList53);
        boolean boolean56 = node55.isParamList();
        boolean boolean57 = node51.isEquivalentToTyped(node55);
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList59);
        java.lang.Object obj63 = node61.getProp(0);
        com.google.javascript.rhino.Node node64 = node61.removeChildren();
        node61.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray68 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList69 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList69, nodeArray68);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList69);
        java.lang.String str72 = node67.checkTreeEquals(node71);
        com.google.javascript.rhino.JSDocInfo jSDocInfo73 = node67.getJSDocInfo();
        com.google.javascript.rhino.Node node74 = node61.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node[] nodeArray75 = new com.google.javascript.rhino.Node[] { node16, node23, node29, node35, node55, node61 };
        try {
            com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.IR.call(node7, nodeArray75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(strSet25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str36.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(strSet43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(obj63);
        org.junit.Assert.assertNull(node64);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str72.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(nodeArray75);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isInstanceOf();
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean13 = diagnosticGroup11.matches(diagnosticType12);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node10, diagnosticType12, strArray15);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node10.children();
        boolean boolean18 = node10.isThis();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setExternExports(true);
        boolean boolean10 = compilerOptions0.removeDeadCode;
        compilerOptions0.setInlineLocalVariables(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setTweakToBooleanLiteral("goog.abstractMethod", true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        java.lang.String str7 = com.google.javascript.jscomp.NodeUtil.getSourceName(node3);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        int int3 = loggerErrorManager1.getWarningCount();
        double double4 = loggerErrorManager1.getTypedPercent();
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setCoalesceVariableNames(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel6);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.lang.String str5 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile15 = node12.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId16 = null;
        node12.setInputId(inputId16);
        boolean boolean18 = closureCodingConvention8.isOptionalParameter(node12);
        boolean boolean19 = detailLevel7.apply(node12);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isTry();
        java.util.Set<java.lang.String> strSet25 = node23.getDirectives();
        boolean boolean26 = node23.isWhile();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.newNode(node23, nodeArray27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList(nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.newNode(node12, nodeArray27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.newNode(node3, nodeArray27);
        com.google.javascript.rhino.Node node32 = node3.removeFirstChild();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(staticSourceFile15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(strSet25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(node32);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput3.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback38);
        com.google.javascript.jscomp.JSModule jSModule40 = nodeTraversal39.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNull(jSModule40);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.Node node9 = node4.getParent();
        boolean boolean10 = node4.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node4, diagnosticType11, strArray17);
        java.util.Set<java.lang.String> strSet19 = node4.getDirectives();
        boolean boolean20 = node4.isScript();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setMoveFunctionDeclarations(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = compilerOptions0.cssRenamingMap;
        boolean boolean12 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback38);
        boolean boolean40 = compiler1.acceptEcmaScript5();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList41 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray42 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList43 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList43, jSModuleArray42);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph45 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList43);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions46.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray51 = compilerOptions50.inputPropertyMapSerialized;
        compilerOptions50.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList54 = compilerOptions50.sourceMapLocationMappings;
        compilerOptions46.sourceMapLocationMappings = locationMappingList54;
        compilerOptions46.setCollapsePropertiesOnExternTypes(true);
        compilerOptions46.inputDelimiter = "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n";
        try {
            com.google.javascript.jscomp.Result result60 = compiler1.compileModules(jSSourceFileList41, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList43, compilerOptions46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(jSModuleArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(byteArray51);
        org.junit.Assert.assertNotNull(locationMappingList54);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.setAliasStringsBlacklist("Unknown class name");
        boolean boolean13 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray14 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList15 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList15, warningsGuardArray14);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard17);
        compilerOptions0.setPropertyAffinity(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setSpecializeInitialModule(false);
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setRenamePrefixNamespace("");
        com.google.javascript.jscomp.DependencyOptions dependencyOptions22 = new com.google.javascript.jscomp.DependencyOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        compilerOptions23.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions23.checkRequires;
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet32 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet32, strArray31);
        compilerOptions23.setIdGenerators((java.util.Set<java.lang.String>) strSet32);
        dependencyOptions22.setEntryPoints((java.util.Collection<java.lang.String>) strSet32);
        compilerOptions0.setDependencyOptions(dependencyOptions22);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap37 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap37;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        boolean boolean9 = node8.isTypeOf();
        boolean boolean10 = node8.isTypeOf();
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("", "goog.exportProperty");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile16 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node15);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isTry();
        java.util.Set<java.lang.String> strSet22 = node20.getDirectives();
        boolean boolean23 = node20.isInstanceOf();
        com.google.javascript.rhino.Node node24 = node15.clonePropsFrom(node20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean27 = diagnosticGroup25.matches(diagnosticType26);
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node24, diagnosticType26, strArray29);
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node8, diagnosticType13, strArray29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.defaultLevel;
        java.lang.String[] strArray37 = null;
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", (int) (byte) -1, 0, diagnosticType35, strArray37);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean41 = diagnosticGroup39.matches(diagnosticType40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str43 = diagnosticType42.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions45.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions45.checkMissingGetCssNameLevel;
        diagnosticType44.level = checkLevel48;
        com.google.javascript.jscomp.SourceAst sourceAst50 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput53 = new com.google.javascript.jscomp.CompilerInput(sourceAst50, "", true);
        com.google.javascript.jscomp.JSModule jSModule54 = compilerInput53.getModule();
        com.google.javascript.jscomp.JSModule jSModule55 = null;
        compilerInput53.setModule(jSModule55);
        boolean boolean57 = diagnosticType44.equals((java.lang.Object) compilerInput53);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray58 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType13, diagnosticType35, diagnosticType40, diagnosticType42, diagnosticType44 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup59 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray58);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(staticSourceFile16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(diagnosticGroup39);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str43.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(jSModule54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(diagnosticTypeArray58);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile10.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str16 = jSSourceFile14.getLine((int) '#');
        jSSourceFile14.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str19 = jSSourceFile14.getCode();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str24 = jSSourceFile22.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile27.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile14, jSSourceFile22, jSSourceFile27 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray30 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean32 = compilerOptions31.generatePseudoNames;
        boolean boolean33 = compilerOptions31.checkSuspiciousCode;
        compilerOptions31.jqueryPass = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler36 = compilerOptions31.getAliasTransformationHandler();
        com.google.javascript.jscomp.Result result37 = compiler1.compile(jSSourceFileArray29, jSModuleArray30, compilerOptions31);
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        compilerOptions31.setCheckMissingReturn(checkLevel38);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray29);
        org.junit.Assert.assertNotNull(jSModuleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler36);
        org.junit.Assert.assertNotNull(result37);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        boolean boolean2 = node1.isLocalResultCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.voidNode(node3);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isParamList();
        boolean boolean11 = node9.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile12 = node9.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId13 = null;
        node9.setInputId(inputId13);
        boolean boolean15 = closureCodingConvention5.isOptionalParameter(node9);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention17 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        boolean boolean22 = node21.isParamList();
        boolean boolean23 = node21.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile24 = node21.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId25 = null;
        node21.setInputId(inputId25);
        boolean boolean27 = closureCodingConvention17.isOptionalParameter(node21);
        boolean boolean28 = detailLevel16.apply(node21);
        boolean boolean29 = closureCodingConvention5.isPrototypeAlias(node21);
        com.google.javascript.rhino.Node node30 = node3.clonePropsFrom(node21);
        try {
            int int32 = node30.getExistingIntProp(39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 39");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(staticSourceFile12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(detailLevel16);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(staticSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.generatePseudoNames;
        compilerOptions19.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        compilerOptions23.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions23.checkRequires;
        compilerOptions19.checkProvides = checkLevel27;
        compilerOptions0.checkRequires = checkLevel27;
        boolean boolean30 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.setPrettyPrint(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        com.google.javascript.rhino.Node node6 = node4.getFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        try {
            node6.setJSType(jSType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        boolean boolean12 = compilerOptions0.removeUnusedVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray14 = compilerOptions13.inputPropertyMapSerialized;
        compilerOptions13.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.generatePseudoNames;
        compilerOptions17.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions17.checkRequires;
        compilerOptions13.setAggressiveVarCheck(checkLevel21);
        compilerOptions0.reportMissingOverride = checkLevel21;
        com.google.javascript.jscomp.SourceMap.Format format24 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.setSourceMapFormat(format24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format24);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        java.lang.String[] strArray5 = null;
        com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", (int) (byte) -1, 0, diagnosticType3, strArray5);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = jSError6.level;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = jSError6.level;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(jSError6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isTry();
        java.util.Set<java.lang.String> strSet22 = node20.getDirectives();
        boolean boolean23 = node20.isInstanceOf();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile24 = node20.getStaticSourceFile();
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.regexp(node9, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(staticSourceFile24);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode2 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config4 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode2, false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        compilerOptions6.checkGlobalNamesLevel = checkLevel11;
        compilerOptions6.removeUnusedPrototypeProperties = false;
        compilerOptions6.setMoveFunctionDeclarations(false);
        java.util.Set<java.lang.String> strSet17 = compilerOptions6.stripTypes;
        com.google.javascript.jscomp.parsing.Config config18 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode2, false, strSet17);
        org.junit.Assert.assertTrue("'" + languageMode2 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode2.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNotNull(config18);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile14 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node13);
        com.google.javascript.rhino.Node node15 = node13.getLastChild();
        boolean boolean16 = node13.isNoSideEffectsCall();
        try {
            boolean boolean17 = closureCodingConvention0.isPropertyTestFunction(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(staticSourceFile14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.setAliasStringsBlacklist("Unknown class name");
        boolean boolean13 = compilerOptions0.checkTypes;
        compilerOptions0.lineBreak = true;
        boolean boolean16 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.labelRenaming = true;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        boolean boolean15 = node14.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile16 = node14.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node14.siblings();
        com.google.javascript.rhino.InputId inputId18 = node14.getInputId();
        try {
            com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.or(node10, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(staticSourceFile16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertNull(inputId18);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWith();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node3.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile9 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node8);
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        boolean boolean14 = node13.isTry();
        java.util.Set<java.lang.String> strSet15 = node13.getDirectives();
        boolean boolean16 = node13.isInstanceOf();
        com.google.javascript.rhino.Node node17 = node8.clonePropsFrom(node13);
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.or(node3, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(staticSourceFile9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(strSet15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setAliasStringsBlacklist("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.coalesceVariableNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setFlowSensitiveInlineVariables(true);
        java.lang.String[] strArray15 = new java.lang.String[] { "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions10.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.printInputDelimiter = false;
        boolean boolean22 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        boolean boolean7 = node3.isFalse();
        boolean boolean8 = node3.isLabel();
        node3.setLength((int) ' ');
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "goog.abstractMethod");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        java.lang.String str38 = compiler1.getAstDotGraph();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        java.lang.Object obj32 = node30.getProp(0);
        com.google.javascript.rhino.Node node33 = node30.removeChildren();
        node30.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList38 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList38, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList38);
        java.lang.String str41 = node36.checkTreeEquals(node40);
        com.google.javascript.rhino.JSDocInfo jSDocInfo42 = node36.getJSDocInfo();
        com.google.javascript.rhino.Node node43 = node30.copyInformationFromForTree(node36);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList45 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList45, nodeArray44);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList45);
        int int49 = node47.getIntProp(100);
        com.google.javascript.rhino.Node node50 = node43.useSourceInfoIfMissingFromForTree(node47);
        try {
            java.lang.String str51 = closureCodingConvention0.getSingletonGetterClassName(node47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str41.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(node50);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(logger20);
        com.google.javascript.jscomp.JSError[] jSErrorArray22 = loggerErrorManager21.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError27 = null;
        loggerErrorManager21.println(checkLevel26, jSError27);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel26;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean31 = compilerOptions30.generatePseudoNames;
        compilerOptions30.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions30.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap35 = null;
        compilerOptions30.setCssRenamingMap(cssRenamingMap35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean38 = compilerOptions37.generatePseudoNames;
        compilerOptions37.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions37.checkRequires;
        java.lang.String[] strArray45 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet46 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet46, strArray45);
        compilerOptions37.setIdGenerators((java.util.Set<java.lang.String>) strSet46);
        compilerOptions30.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet46);
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet46);
        compilerOptions0.setRemoveUnusedPrototypePropertiesInExterns(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSErrorArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        java.lang.String str6 = node3.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.defaultCase(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.not(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder8 = null;
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        boolean boolean14 = node13.isParamList();
        try {
            compiler1.toSource(codeBuilder8, 1, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 49, 31);
        node3.setOptionalArg(false);
        boolean boolean6 = node3.isRegExp();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setOptimizeCalls(true);
        compilerOptions0.setOutputJsStringUsage(false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node15 = compiler10.parse(jSSourceFile13);
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.label(node3, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy21 = compilerOptions0.variableRenaming;
        compilerOptions0.setCheckControlStructures(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.generatePseudoNames;
        boolean boolean26 = compilerOptions24.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions24.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList28 = compilerOptions24.sourceMapLocationMappings;
        compilerOptions24.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format31 = compilerOptions24.sourceMapFormat;
        compilerOptions0.setSourceMapFormat(format31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy21 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy21.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList28);
        org.junit.Assert.assertNotNull(format31);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        com.google.javascript.rhino.Node node14 = node10.getLastSibling();
        com.google.javascript.rhino.Node node15 = node10.getParent();
        boolean boolean16 = node10.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node10, diagnosticType17, strArray23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean26 = compilerOptions25.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean28 = compilerOptions27.generatePseudoNames;
        compilerOptions27.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions27.checkRequires;
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet36 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet36, strArray35);
        compilerOptions27.setIdGenerators((java.util.Set<java.lang.String>) strSet36);
        compilerOptions25.setStripTypes((java.util.Set<java.lang.String>) strSet36);
        compilerOptions25.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat42 = compilerOptions25.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy43 = compilerOptions25.propertyRenaming;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = diagnosticType44.defaultLevel;
        compilerOptions25.checkProvides = checkLevel45;
        diagnosticType17.level = checkLevel45;
        java.lang.String[] strArray48 = null;
        try {
            nodeTraversal2.report(node5, diagnosticType17, strArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(errorFormat42);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy43 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy43.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("goog.exportProperty", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$goog.exportProperty" + "'", str2.equals("module$goog.exportProperty"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("module$goog.exportProperty", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str29 = jSSourceFile27.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile27 };
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList33 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList33, nodeArray32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList33);
        boolean boolean36 = node35.isParamList();
        boolean boolean37 = node35.isNull();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 1, node35);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str43 = jSSourceFile41.getLine((int) '#');
        jSSourceFile41.clearCachedSource();
        node35.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str50 = jSSourceFile48.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray51 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile41, jSSourceFile48 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean53 = compilerOptions52.generatePseudoNames;
        boolean boolean54 = compilerOptions52.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions52.checkUnreachableCode;
        compilerOptions52.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode58 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions52.setLanguageIn(languageMode58);
        compiler24.init(jSSourceFileArray30, jSSourceFileArray51, compilerOptions52);
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean62 = compilerOptions61.generatePseudoNames;
        compilerOptions61.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel65 = compilerOptions61.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap66 = null;
        compilerOptions61.setCssRenamingMap(cssRenamingMap66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean69 = compilerOptions68.generatePseudoNames;
        compilerOptions68.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel72 = compilerOptions68.checkRequires;
        java.lang.String[] strArray76 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet77 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet77, strArray76);
        compilerOptions68.setIdGenerators((java.util.Set<java.lang.String>) strSet77);
        compilerOptions61.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet77);
        compilerOptions61.setRenamePrefixNamespace("");
        compilerOptions61.optimizeReturns = false;
        com.google.javascript.jscomp.Result result85 = compiler1.compile(jSSourceFile18, jSSourceFileArray30, compilerOptions61);
        java.lang.String str86 = jSSourceFile18.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(jSSourceFileArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode58 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode58.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "" + "'", str86.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        java.lang.String str7 = com.google.javascript.jscomp.NodeUtil.getSourceName(node4);
        node4.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions12.checkProvides = checkLevel20;
        compilerOptions0.checkRequires = checkLevel20;
        java.lang.String str23 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel27);
        compilerOptions0.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode31 = null;
        compilerOptions0.setTracer(tracerMode31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        boolean boolean5 = compilerOptions0.foldConstants;
        boolean boolean6 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isInstanceOf();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node3.getStaticSourceFile();
        boolean boolean8 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node3);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.setAggressiveVarCheck(checkLevel8);
        boolean boolean10 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(logger23);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = loggerErrorManager24.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean27 = compilerOptions26.generatePseudoNames;
        boolean boolean28 = compilerOptions26.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions26.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError30 = null;
        loggerErrorManager24.println(checkLevel29, jSError30);
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel29);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap33 = compilerOptions0.getTweakReplacements();
        compilerOptions0.setCollapseObjectLiterals(false);
        boolean boolean36 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        compilerOptions0.setLooseTypes(false);
        compilerOptions0.setLineBreak(true);
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 1, node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node4.getJsDocBuilderForNode();
        boolean boolean9 = node4.isFunction();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        loggerErrorManager6.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray12 = compilerOptions8.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        boolean boolean19 = node18.isParamList();
        boolean boolean20 = node18.isNull();
        com.google.javascript.rhino.jstype.JSType jSType21 = node18.getJSType();
        com.google.javascript.rhino.Node node22 = node18.getLastSibling();
        com.google.javascript.rhino.Node node23 = node18.getParent();
        boolean boolean24 = node18.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node18, diagnosticType25, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = jSError32.level;
        int int34 = jSError32.lineNumber;
        loggerErrorManager6.report(checkLevel13, jSError32);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.rhino.InputId inputId37 = compilerInput3.getInputId();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(byteArray12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(inputId37);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.OFF;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile10.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str16 = jSSourceFile14.getLine((int) '#');
        jSSourceFile14.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str19 = jSSourceFile14.getCode();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str24 = jSSourceFile22.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile27.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile14, jSSourceFile22, jSSourceFile27 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray30 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean32 = compilerOptions31.generatePseudoNames;
        boolean boolean33 = compilerOptions31.checkSuspiciousCode;
        compilerOptions31.jqueryPass = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler36 = compilerOptions31.getAliasTransformationHandler();
        com.google.javascript.jscomp.Result result37 = compiler1.compile(jSSourceFileArray29, jSModuleArray30, compilerOptions31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean39 = compilerOptions38.generatePseudoNames;
        compilerOptions38.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean43 = compilerOptions42.generatePseudoNames;
        compilerOptions42.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions42.checkRequires;
        compilerOptions38.checkProvides = checkLevel46;
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard48 = null;
        compilerOptions38.setWarningsGuard(composeWarningsGuard48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean51 = compilerOptions50.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean53 = compilerOptions52.generatePseudoNames;
        compilerOptions52.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel56 = compilerOptions52.checkRequires;
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet61 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet61, strArray60);
        compilerOptions52.setIdGenerators((java.util.Set<java.lang.String>) strSet61);
        compilerOptions50.setStripTypes((java.util.Set<java.lang.String>) strSet61);
        compilerOptions50.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat67 = compilerOptions50.errorFormat;
        compilerOptions38.setErrorFormat(errorFormat67);
        compilerOptions31.setErrorFormat(errorFormat67);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray29);
        org.junit.Assert.assertNotNull(jSModuleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler36);
        org.junit.Assert.assertNotNull(result37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + checkLevel56 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel56.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(errorFormat67);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setInferTypes(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        java.lang.Object obj17 = node15.getProp(0);
        boolean boolean18 = node15.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        java.lang.String str25 = node20.checkTreeEquals(node24);
        boolean boolean26 = node24.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean31 = node30.isTry();
        java.util.Set<java.lang.String> strSet32 = node30.getDirectives();
        boolean boolean33 = node30.isWith();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList35 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList35, nodeArray34);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList35);
        node24.addChildAfter(node30, node37);
        java.lang.String str39 = closureCodingConvention0.extractClassNameIfRequire(node15, node37);
        boolean boolean40 = node37.isAnd();
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList42 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList42, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList42);
        boolean boolean45 = node44.isParamList();
        boolean boolean46 = node44.isNull();
        node44.setSourceFileForTesting("");
        try {
            com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.regexp(node37, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str25.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(strSet32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", (-1), 15);
        boolean boolean4 = node3.isVar();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node3.getAncestors();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable7 = node3.getAncestors();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertNotNull(ancestorIterable7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        boolean boolean7 = node6.isThis();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        com.google.javascript.rhino.Node node14 = node11.removeChildren();
        node11.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        java.lang.String str22 = node17.checkTreeEquals(node21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node17.getJSDocInfo();
        com.google.javascript.rhino.Node node24 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        int int30 = node28.getIntProp(100);
        com.google.javascript.rhino.Node node31 = node24.useSourceInfoIfMissingFromForTree(node28);
        com.google.javascript.rhino.Node node32 = node6.clonePropsFrom(node28);
        try {
            node32.setDouble((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: CONTINUE is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str22.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        compilerInput3.setModule(jSModule4);
        try {
            compilerInput3.removeRequire("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.checkSuspiciousCode = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        boolean boolean7 = node6.isThis();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        com.google.javascript.rhino.Node node14 = node11.removeChildren();
        node11.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        java.lang.String str22 = node17.checkTreeEquals(node21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node17.getJSDocInfo();
        com.google.javascript.rhino.Node node24 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        int int30 = node28.getIntProp(100);
        com.google.javascript.rhino.Node node31 = node24.useSourceInfoIfMissingFromForTree(node28);
        com.google.javascript.rhino.Node node32 = node6.clonePropsFrom(node28);
        boolean boolean33 = node32.isQuotedString();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str22.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setSpecializeInitialModule(false);
        boolean boolean6 = compilerOptions0.markAsCompiled;
        compilerOptions0.aliasStringsBlacklist = "Unknown class name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.setDeadAssignmentElimination(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile15 = node12.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId16 = null;
        node12.setInputId(inputId16);
        boolean boolean18 = closureCodingConvention8.isOptionalParameter(node12);
        boolean boolean19 = detailLevel7.apply(node12);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isTry();
        java.util.Set<java.lang.String> strSet25 = node23.getDirectives();
        boolean boolean26 = node23.isWhile();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.newNode(node23, nodeArray27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList(nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.newNode(node12, nodeArray27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.newNode(node3, nodeArray27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.block(nodeArray27);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(staticSourceFile15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(strSet25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isInstanceOf();
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean13 = diagnosticGroup11.matches(diagnosticType12);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node10, diagnosticType12, strArray15);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node10.children();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        java.lang.Object obj23 = node21.getProp(0);
        com.google.javascript.rhino.Node node24 = node21.removeChildren();
        node21.setWasEmptyNode(false);
        boolean boolean27 = node21.isHook();
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList29 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList29, nodeArray28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList29);
        boolean boolean32 = node31.isParamList();
        boolean boolean33 = node31.isNull();
        com.google.javascript.rhino.jstype.JSType jSType34 = node31.getJSType();
        com.google.javascript.rhino.Node node35 = node31.getLastSibling();
        boolean boolean36 = node35.isLabelName();
        try {
            node10.replaceChildAfter(node21, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String str2 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        boolean boolean6 = jSSourceFile2.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.parsing.Config config4 = null;
        com.google.javascript.rhino.head.ErrorReporter errorReporter5 = null;
        java.util.logging.Logger logger6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile2, "", config4, errorReporter5, logger6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        compilerOptions9.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions9.checkRequires;
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions9.setIdGenerators((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        compilerOptions9.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions9.checkRequires;
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions9.setIdGenerators((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.setRewriteNewDateGoogNow(false);
        compilerOptions0.setInlineVariables(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1, node5);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node10 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = closureCodingConvention9.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        java.lang.String str20 = closureCodingConvention9.extractClassNameIfRequire(node12, node16);
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        boolean boolean25 = node24.isParamList();
        boolean boolean26 = node24.isNull();
        com.google.javascript.rhino.jstype.JSType jSType27 = node24.getJSType();
        node16.addChildrenToBack(node24);
        java.lang.String str29 = closureCodingConvention0.extractClassNameIfProvide(node5, node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList32 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList32, nodeArray31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList32);
        boolean boolean35 = node34.isTry();
        com.google.javascript.rhino.Node node36 = node30.srcref(node34);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel37 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention38 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList40 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList40, nodeArray39);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList40);
        boolean boolean43 = node42.isParamList();
        boolean boolean44 = node42.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile45 = node42.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId46 = null;
        node42.setInputId(inputId46);
        boolean boolean48 = closureCodingConvention38.isOptionalParameter(node42);
        boolean boolean49 = detailLevel37.apply(node42);
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList51 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList51, nodeArray50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList51);
        boolean boolean54 = node53.isTry();
        java.util.Set<java.lang.String> strSet55 = node53.getDirectives();
        boolean boolean56 = node53.isWhile();
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.newNode(node53, nodeArray57);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.paramList(nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.newNode(node42, nodeArray57);
        java.lang.String str61 = closureCodingConvention0.extractClassNameIfProvide(node34, node42);
        com.google.javascript.rhino.Node node62 = node34.cloneTree();
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList64 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList64, nodeArray63);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList64);
        boolean boolean67 = node66.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile68 = node66.getStaticSourceFile();
        boolean boolean69 = node66.isAdd();
        try {
            com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.IR.getelem(node62, node66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(detailLevel37);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(staticSourceFile45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(strSet55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(staticSourceFile68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.setAliasStringsBlacklist("Unknown class name");
        boolean boolean13 = compilerOptions0.checkTypes;
        compilerOptions0.lineBreak = true;
        boolean boolean16 = compilerOptions0.isExternExportsEnabled();
        java.lang.String str17 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        java.lang.Object obj11 = node9.getProp(0);
        com.google.javascript.rhino.Node node12 = node9.removeChildren();
        node9.setWasEmptyNode(false);
        boolean boolean15 = node9.isHook();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        java.lang.String str21 = node16.checkTreeEquals(node20);
        boolean boolean22 = node20.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList24 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList24, nodeArray23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList24);
        java.lang.Object obj28 = node26.getProp(0);
        java.lang.String str29 = node26.getQualifiedName();
        node20.addChildrenToFront(node26);
        java.lang.String str31 = closureCodingConvention0.extractClassNameIfProvide(node9, node20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str21.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(nodeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        java.lang.String[] strArray5 = new java.lang.String[] { "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet6);
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean10 = compilerOptions0.aliasExternals;
        com.google.javascript.jscomp.MessageBundle messageBundle11 = compilerOptions0.messageBundle;
        compilerOptions0.setPropertyAffinity(true);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(messageBundle11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setOptimizeCalls(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions5.checkMissingGetCssNameLevel;
        compilerOptions5.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        compilerOptions11.checkProvides = checkLevel19;
        compilerOptions5.checkGlobalThisLevel = checkLevel19;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel19;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean26 = compilerOptions25.generatePseudoNames;
        compilerOptions25.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions25.checkRequires;
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet34 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet34, strArray33);
        compilerOptions25.setIdGenerators((java.util.Set<java.lang.String>) strSet34);
        compilerOptions23.setStripTypes((java.util.Set<java.lang.String>) strSet34);
        compilerOptions23.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat40 = compilerOptions23.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy41 = compilerOptions23.propertyRenaming;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = diagnosticType42.defaultLevel;
        compilerOptions23.checkProvides = checkLevel43;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel43;
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(errorFormat40);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy41 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy41.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.reportMissingOverride = checkLevel7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.checkRequires;
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions11.setIdGenerators((java.util.Set<java.lang.String>) strSet20);
        compilerOptions9.setStripTypes((java.util.Set<java.lang.String>) strSet20);
        compilerOptions9.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat26 = compilerOptions9.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions9.propertyRenaming;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy27;
        compilerOptions0.setManageClosureDependencies(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(errorFormat26);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node3.siblings();
        com.google.javascript.rhino.InputId inputId7 = node3.getInputId();
        boolean boolean8 = node3.isSetterDef();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertNull(inputId7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType15 = null;
        closureCodingConvention0.applySubclassRelationship(functionType13, functionType14, subclassType15);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isParamList();
        boolean boolean22 = node20.isNull();
        com.google.javascript.rhino.jstype.JSType jSType23 = node20.getJSType();
        com.google.javascript.rhino.Node node24 = node20.getLastSibling();
        boolean boolean25 = node24.isOnlyModifiesThisCall();
        node24.addSuppression("hi!");
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship28 = closureCodingConvention0.getClassesDefinedByCall(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
//        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
//        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
//        boolean boolean4 = node3.isTry();
//        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
//        boolean boolean6 = node3.isNot();
//        com.google.javascript.jscomp.SourceAst sourceAst7 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "", true);
//        boolean boolean11 = compilerInput10.isExtern();
//        java.util.logging.Logger logger12 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(logger12);
//        loggerErrorManager13.generateReport();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions15.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
//        byte[] byteArray19 = compilerOptions15.inputPropertyMapSerialized;
//        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.checkProvides;
//        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] {};
//        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList23 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
//        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList23, nodeArray22);
//        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList23);
//        boolean boolean26 = node25.isParamList();
//        boolean boolean27 = node25.isNull();
//        com.google.javascript.rhino.jstype.JSType jSType28 = node25.getJSType();
//        com.google.javascript.rhino.Node node29 = node25.getLastSibling();
//        com.google.javascript.rhino.Node node30 = node25.getParent();
//        boolean boolean31 = node25.isNull();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray38 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
//        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node25, diagnosticType32, strArray38);
//        com.google.javascript.jscomp.CheckLevel checkLevel40 = jSError39.level;
//        int int41 = jSError39.lineNumber;
//        loggerErrorManager13.report(checkLevel20, jSError39);
//        compilerInput10.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
//        com.google.javascript.rhino.InputId inputId44 = compilerInput10.getInputId();
//        node3.setInputId(inputId44);
//        org.junit.Assert.assertNotNull(nodeArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(node3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(staticSourceFile5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(byteArray19);
//        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(nodeArray22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(node25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(jSType28);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNull(node30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(diagnosticType32);
//        org.junit.Assert.assertNotNull(strArray38);
//        org.junit.Assert.assertNotNull(jSError39);
//        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(inputId44);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        int int6 = node3.getSourceOffset();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.generatePseudoNames;
        compilerOptions6.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkRequires;
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        compilerOptions6.setIdGenerators((java.util.Set<java.lang.String>) strSet15);
        compilerOptions4.setStripTypes((java.util.Set<java.lang.String>) strSet15);
        compilerOptions4.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat21 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions4.checkUnreachableCode;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isParamList();
        boolean boolean30 = node28.isNull();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 1, node28);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str36 = jSSourceFile34.getLine((int) '#');
        jSSourceFile34.clearCachedSource();
        node28.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile34);
        boolean boolean39 = diagnosticType23.equals((java.lang.Object) node28);
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList42 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList42, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList42);
        boolean boolean45 = node44.isParamList();
        boolean boolean46 = node44.isNull();
        com.google.javascript.rhino.jstype.JSType jSType47 = node44.getJSType();
        com.google.javascript.rhino.Node node48 = node44.getLastSibling();
        com.google.javascript.rhino.Node node49 = node44.getParent();
        boolean boolean50 = node44.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray57 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node44, diagnosticType51, strArray57);
        try {
            com.google.javascript.jscomp.JSError jSError59 = nodeTraversal2.makeError(node3, checkLevel22, diagnosticType23, strArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(errorFormat21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode6 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions0.setLanguageIn(languageMode6);
        boolean boolean8 = compilerOptions0.optimizeReturns;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray10 = compilerOptions9.inputPropertyMapSerialized;
        compilerOptions9.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler13 = compilerOptions9.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode6.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(byteArray10);
        org.junit.Assert.assertNotNull(aliasTransformationHandler13);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray5 = compilerOptions4.inputPropertyMapSerialized;
        compilerOptions4.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions4.sourceMapLocationMappings;
        compilerOptions0.sourceMapLocationMappings = locationMappingList8;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setRemoveDeadCode(true);
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertNotNull(locationMappingList8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = null;
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        boolean boolean18 = node17.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node17.getStaticSourceFile();
        boolean boolean20 = node17.isNot();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast21 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal13, node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 1, node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder8.append("goog.exportProperty");
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.generatePseudoNames;
//        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
//        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
//        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
//        compilerOptions0.setReportPath("Unknown class name");
//        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
//        compilerOptions0.reportMissingOverride = checkLevel7;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean10 = compilerOptions9.generatePseudoNames;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean12 = compilerOptions11.generatePseudoNames;
//        compilerOptions11.checkTypes = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.checkRequires;
//        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
//        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
//        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
//        compilerOptions11.setIdGenerators((java.util.Set<java.lang.String>) strSet20);
//        compilerOptions9.setStripTypes((java.util.Set<java.lang.String>) strSet20);
//        compilerOptions9.setAliasKeywords(false);
//        com.google.javascript.jscomp.ErrorFormat errorFormat26 = compilerOptions9.errorFormat;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions9.propertyRenaming;
//        compilerOptions0.propertyRenaming = propertyRenamingPolicy27;
//        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] {};
//        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList31 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
//        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList31, nodeArray30);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList31);
//        boolean boolean34 = node33.isParamList();
//        boolean boolean35 = node33.isNull();
//        com.google.javascript.rhino.jstype.JSType jSType36 = node33.getJSType();
//        com.google.javascript.rhino.Node node37 = node33.getLastSibling();
//        com.google.javascript.rhino.Node node38 = node33.getParent();
//        boolean boolean39 = node33.isNull();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray46 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
//        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node33, diagnosticType40, strArray46);
//        com.google.javascript.jscomp.CheckLevel checkLevel48 = jSError47.level;
//        compilerOptions0.aggressiveVarCheck = checkLevel48;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions51.deadAssignmentElimination = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions51.checkMissingGetCssNameLevel;
//        diagnosticType50.level = checkLevel54;
//        compilerOptions0.setCheckRequires(checkLevel54);
//        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode57 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3;
//        compilerOptions0.setLanguageIn(languageMode57);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(locationMappingList4);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(strArray19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(errorFormat26);
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(nodeArray30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(jSType36);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertNull(node38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(diagnosticType40);
//        org.junit.Assert.assertNotNull(strArray46);
//        org.junit.Assert.assertNotNull(jSError47);
//        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType50);
//        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + languageMode57 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode57.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node3.getAncestors();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile13 = node11.getStaticSourceFile();
        boolean boolean14 = node11.isNot();
        boolean boolean15 = node7.isEquivalentToTyped(node11);
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList17);
        com.google.javascript.rhino.Node node20 = node11.clonePropsFrom(node19);
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.catchNode(node3, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(staticSourceFile13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setAliasStringsBlacklist("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.setSyntheticBlockStartMarker("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean5 = closureCodingConvention0.isValidEnumKey("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        boolean boolean7 = closureCodingConvention0.isPrivate("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy21 = compilerOptions0.variableRenaming;
        compilerOptions0.setCheckControlStructures(true);
        compilerOptions0.setRuntimeTypeCheckLogFunction("goog.abstractMethod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy21 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy21.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTypeOf();
        boolean boolean6 = node4.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 0, node4);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean1 = node0.isGetProp();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.setDefineToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.setLineLengthThreshold(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        boolean boolean9 = node3.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        boolean boolean7 = node6.isThis();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        com.google.javascript.rhino.Node node14 = node11.removeChildren();
        node11.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        java.lang.String str22 = node17.checkTreeEquals(node21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node17.getJSDocInfo();
        com.google.javascript.rhino.Node node24 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        int int30 = node28.getIntProp(100);
        com.google.javascript.rhino.Node node31 = node24.useSourceInfoIfMissingFromForTree(node28);
        com.google.javascript.rhino.Node node32 = node6.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node33 = node6.removeChildren();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str22.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node33);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        java.lang.String str7 = node3.getQualifiedName();
        boolean boolean9 = node3.getBooleanProp((int) (byte) -1);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.checkControlStructures = true;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.generatePseudoNames;
        compilerOptions3.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions3.checkRequires;
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet12 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet12, strArray11);
        compilerOptions3.setIdGenerators((java.util.Set<java.lang.String>) strSet12);
        compilerOptions1.setStripTypes((java.util.Set<java.lang.String>) strSet12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.generatePseudoNames;
        compilerOptions17.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions17.checkRequires;
        compilerOptions16.checkGlobalNamesLevel = checkLevel21;
        compilerOptions1.checkUnreachableCode = checkLevel21;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.generatePseudoNames;
        boolean boolean26 = compilerOptions24.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions24.checkUnreachableCode;
        compilerOptions1.setCheckGlobalThisLevel(checkLevel27);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard29 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel27);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = null;
        try {
            boolean boolean31 = diagnosticGroupWarningsGuard29.disables(diagnosticGroup30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setSpecializeInitialModule(false);
        boolean boolean6 = compilerOptions0.markAsCompiled;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("()", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        boolean boolean12 = compilerOptions0.gatherCssNames;
        compilerOptions0.reserveRawExports = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setCollapseProperties(false);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray5 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard6 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray5);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard6);
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions0.getCodingConvention();
        compilerOptions0.setComputeFunctionSideEffects(false);
        org.junit.Assert.assertNotNull(warningsGuardArray5);
        org.junit.Assert.assertNull(codingConvention8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        boolean boolean6 = node3.isBlock();
        boolean boolean7 = node3.hasMoreThanOneChild();
        try {
            node3.setString("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: PARAM_LIST is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setExportTestFunctions(false);
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setAliasKeywords(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isScript();
        com.google.javascript.rhino.Node node6 = node3.getFirstChild();
        try {
            node6.setType(4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        try {
            java.lang.String str6 = compilerInput3.getLine((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        try {
            com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        boolean boolean5 = compilerOptions0.optimizeCalls;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node0.isEquivalentToTyped(node4);
        boolean boolean7 = node4.isDebugger();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str11 = jSSourceFile9.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        boolean boolean18 = node17.isParamList();
        boolean boolean19 = node17.isNull();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 1, node17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str25 = jSSourceFile23.getLine((int) '#');
        jSSourceFile23.clearCachedSource();
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str32 = jSSourceFile30.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile30 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean35 = compilerOptions34.generatePseudoNames;
        boolean boolean36 = compilerOptions34.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions34.checkUnreachableCode;
        compilerOptions34.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode40 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions34.setLanguageIn(languageMode40);
        compiler6.init(jSSourceFileArray12, jSSourceFileArray33, compilerOptions34);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList45 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList45, nodeArray44);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList45);
        boolean boolean48 = node47.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile49 = node47.getStaticSourceFile();
        int int50 = node47.getCharno();
        boolean boolean51 = node47.isLocalResultCall();
        com.google.javascript.jscomp.NodeTraversal.Callback callback52 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler6, node47, callback52);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode40 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode40.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(staticSourceFile49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAppNameStr("");
        boolean boolean9 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.Object obj6 = node4.getProp(0);
        boolean boolean7 = node4.isSyntheticBlock();
        boolean boolean8 = node4.isFalse();
        boolean boolean9 = node4.isLabel();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.voidNode(node13);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList17);
        boolean boolean20 = node19.isParamList();
        boolean boolean21 = node19.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile22 = node19.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId23 = null;
        node19.setInputId(inputId23);
        boolean boolean25 = closureCodingConvention15.isOptionalParameter(node19);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel26 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList29 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList29, nodeArray28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList29);
        boolean boolean32 = node31.isParamList();
        boolean boolean33 = node31.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile34 = node31.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId35 = null;
        node31.setInputId(inputId35);
        boolean boolean37 = closureCodingConvention27.isOptionalParameter(node31);
        boolean boolean38 = detailLevel26.apply(node31);
        boolean boolean39 = closureCodingConvention15.isPrototypeAlias(node31);
        com.google.javascript.rhino.Node node40 = node13.clonePropsFrom(node31);
        boolean boolean41 = node40.isDelProp();
        java.lang.String str42 = closureCodingConvention0.extractClassNameIfRequire(node4, node40);
        boolean boolean43 = node40.hasOneChild();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(staticSourceFile22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(detailLevel26);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(staticSourceFile34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy21 = compilerOptions0.variableRenaming;
        compilerOptions0.setCheckControlStructures(true);
        boolean boolean24 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy21 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy21.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList13);
        java.lang.Object obj17 = node15.getProp(0);
        boolean boolean18 = node15.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        java.lang.String str25 = node20.checkTreeEquals(node24);
        boolean boolean26 = node24.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean31 = node30.isTry();
        java.util.Set<java.lang.String> strSet32 = node30.getDirectives();
        boolean boolean33 = node30.isWith();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList35 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList35, nodeArray34);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList35);
        node24.addChildAfter(node30, node37);
        java.lang.String str39 = closureCodingConvention0.extractClassNameIfRequire(node15, node37);
        try {
            node15.setSideEffectFlags((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got PARAM_LIST");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str25.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(strSet32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput3.getAst();
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertNull(sourceAst5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setReserveRawExports(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Unknown class name", "goog.exportProperty");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray4 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertNull(byteArray4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        boolean boolean9 = node3.isHook();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler10 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler10, callback11);
        java.lang.String str13 = nodeTraversal12.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        java.lang.Object obj19 = node17.getProp(0);
        com.google.javascript.rhino.Node node20 = node17.removeChildren();
        node17.setWasEmptyNode(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler27 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback28 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal29 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler27, callback28);
        java.lang.String str30 = nodeTraversal29.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList32 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList32, nodeArray31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList32);
        boolean boolean35 = node34.isParamList();
        boolean boolean36 = node34.isScript();
        com.google.javascript.rhino.Node node37 = node34.getFirstChild();
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions39.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions39.checkMissingGetCssNameLevel;
        diagnosticType38.level = checkLevel42;
        com.google.javascript.jscomp.SourceAst sourceAst44 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(sourceAst44, "", true);
        com.google.javascript.jscomp.JSModule jSModule48 = compilerInput47.getModule();
        com.google.javascript.jscomp.JSModule jSModule49 = null;
        compilerInput47.setModule(jSModule49);
        boolean boolean51 = diagnosticType38.equals((java.lang.Object) compilerInput47);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList54 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList54, nodeArray53);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList54);
        boolean boolean57 = node56.isParamList();
        boolean boolean58 = node56.isNull();
        com.google.javascript.rhino.jstype.JSType jSType59 = node56.getJSType();
        com.google.javascript.rhino.Node node60 = node56.getLastSibling();
        com.google.javascript.rhino.Node node61 = node56.getParent();
        boolean boolean62 = node56.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray69 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node56, diagnosticType63, strArray69);
        com.google.javascript.jscomp.JSError jSError71 = nodeTraversal29.makeError(node34, diagnosticType38, strArray69);
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList77 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList77, nodeArray76);
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList77);
        boolean boolean80 = node79.isParamList();
        boolean boolean81 = node79.isNull();
        com.google.javascript.rhino.jstype.JSType jSType82 = node79.getJSType();
        com.google.javascript.rhino.Node node83 = node79.getLastSibling();
        com.google.javascript.rhino.Node node84 = node79.getParent();
        boolean boolean85 = node79.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType86 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray92 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node79, diagnosticType86, strArray92);
        com.google.javascript.jscomp.JSError jSError94 = com.google.javascript.jscomp.JSError.make(diagnosticType74, strArray92);
        com.google.javascript.jscomp.JSError jSError95 = nodeTraversal12.makeError(node17, checkLevel26, diagnosticType38, strArray92);
        com.google.javascript.rhino.Node node96 = null;
        try {
            node3.replaceChildAfter(node17, node96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(node37);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(jSModule48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(diagnosticType74);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNull(node84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(diagnosticType86);
        org.junit.Assert.assertNotNull(strArray92);
        org.junit.Assert.assertNotNull(jSError93);
        org.junit.Assert.assertNotNull(jSError94);
        org.junit.Assert.assertNotNull(jSError95);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.voidNode(node3);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isParamList();
        boolean boolean11 = node9.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile12 = node9.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId13 = null;
        node9.setInputId(inputId13);
        boolean boolean15 = closureCodingConvention5.isOptionalParameter(node9);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention17 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList19 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList19, nodeArray18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList19);
        boolean boolean22 = node21.isParamList();
        boolean boolean23 = node21.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile24 = node21.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId25 = null;
        node21.setInputId(inputId25);
        boolean boolean27 = closureCodingConvention17.isOptionalParameter(node21);
        boolean boolean28 = detailLevel16.apply(node21);
        boolean boolean29 = closureCodingConvention5.isPrototypeAlias(node21);
        com.google.javascript.rhino.Node node30 = node3.clonePropsFrom(node21);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList33 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList33, nodeArray32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList33);
        java.lang.String str36 = node31.checkTreeEquals(node35);
        boolean boolean37 = node35.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList39 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList39, nodeArray38);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList39);
        java.lang.Object obj43 = node41.getProp(0);
        java.lang.String str44 = node41.getQualifiedName();
        node35.addChildrenToFront(node41);
        boolean boolean46 = node35.isEmpty();
        try {
            com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.var(node3, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(staticSourceFile12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(detailLevel16);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(staticSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str36.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node0.isEquivalentToTyped(node4);
        node0.setLineno(4095);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = com.google.javascript.jscomp.NodeUtil.getInverseOperator((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            boolean boolean7 = jSModuleGraph4.dependsOn(jSModule5, jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setOptimizeCalls(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions5.checkMissingGetCssNameLevel;
        compilerOptions5.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        compilerOptions11.checkProvides = checkLevel19;
        compilerOptions5.checkGlobalThisLevel = checkLevel19;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel19;
        java.lang.String str23 = compilerOptions0.renamePrefixNamespace;
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.setAliasStringsBlacklist("Unknown class name");
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions15.setIdGenerators((java.util.Set<java.lang.String>) strSet24);
        compilerOptions13.setStripTypes((java.util.Set<java.lang.String>) strSet24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        compilerOptions29.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions29.checkRequires;
        compilerOptions28.checkGlobalNamesLevel = checkLevel33;
        compilerOptions13.checkUnreachableCode = checkLevel33;
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean37 = compilerOptions36.generatePseudoNames;
        boolean boolean38 = compilerOptions36.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions36.checkUnreachableCode;
        compilerOptions13.setCheckGlobalThisLevel(checkLevel39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean42 = compilerOptions41.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean44 = compilerOptions43.generatePseudoNames;
        compilerOptions43.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel47 = compilerOptions43.checkRequires;
        java.lang.String[] strArray51 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet52 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet52, strArray51);
        compilerOptions43.setIdGenerators((java.util.Set<java.lang.String>) strSet52);
        compilerOptions41.setStripTypes((java.util.Set<java.lang.String>) strSet52);
        compilerOptions41.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat58 = compilerOptions41.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy59 = compilerOptions41.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel60 = compilerOptions41.checkRequires;
        compilerOptions13.checkMissingReturn = checkLevel60;
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel60);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(errorFormat58);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy59 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy59.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        boolean boolean9 = node7.isDec();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap5 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setDefineToDoubleLiteral("", 1.0d);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray13 = compilerOptions9.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.generatePseudoNames;
        compilerOptions14.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions14.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap19 = null;
        compilerOptions14.setCssRenamingMap(cssRenamingMap19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.generatePseudoNames;
        compilerOptions21.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions21.checkRequires;
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        compilerOptions21.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        compilerOptions14.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet30);
        compilerOptions9.stripNamePrefixes = strSet30;
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean37 = compilerOptions36.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean39 = compilerOptions38.generatePseudoNames;
        compilerOptions38.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions38.checkRequires;
        java.lang.String[] strArray46 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet47 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet47, strArray46);
        compilerOptions38.setIdGenerators((java.util.Set<java.lang.String>) strSet47);
        compilerOptions36.setStripTypes((java.util.Set<java.lang.String>) strSet47);
        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "hi!", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.ArrayList<java.lang.String> strList55 = new java.util.ArrayList<java.lang.String>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList55, strArray54);
        compilerOptions36.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList55);
        com.google.javascript.jscomp.CompilerOptions.Reach reach58 = com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY;
        compilerOptions36.setInlineVariables(reach58);
        compilerOptions0.setInlineFunctions(reach58);
        org.junit.Assert.assertNotNull(strMap5);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + reach58 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY + "'", reach58.equals(com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        loggerErrorManager6.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray12 = compilerOptions8.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        boolean boolean19 = node18.isParamList();
        boolean boolean20 = node18.isNull();
        com.google.javascript.rhino.jstype.JSType jSType21 = node18.getJSType();
        com.google.javascript.rhino.Node node22 = node18.getLastSibling();
        com.google.javascript.rhino.Node node23 = node18.getParent();
        boolean boolean24 = node18.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node18, diagnosticType25, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = jSError32.level;
        int int34 = jSError32.lineNumber;
        loggerErrorManager6.report(checkLevel13, jSError32);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(byteArray12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray15 = compilerOptions11.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = null;
        compilerOptions16.setCssRenamingMap(cssRenamingMap21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        compilerOptions23.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions23.checkRequires;
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet32 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet32, strArray31);
        compilerOptions23.setIdGenerators((java.util.Set<java.lang.String>) strSet32);
        compilerOptions16.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet32);
        compilerOptions11.stripNamePrefixes = strSet32;
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet32);
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(inputId7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setMoveFunctionDeclarations(false);
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypes;
        compilerOptions0.setRemoveTryCatchFinally(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1, node5);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node10 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = closureCodingConvention9.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        java.lang.String str20 = closureCodingConvention9.extractClassNameIfRequire(node12, node16);
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        boolean boolean25 = node24.isParamList();
        boolean boolean26 = node24.isNull();
        com.google.javascript.rhino.jstype.JSType jSType27 = node24.getJSType();
        node16.addChildrenToBack(node24);
        java.lang.String str29 = closureCodingConvention0.extractClassNameIfProvide(node5, node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList32 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList32, nodeArray31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList32);
        boolean boolean35 = node34.isTry();
        com.google.javascript.rhino.Node node36 = node30.srcref(node34);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel37 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention38 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList40 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList40, nodeArray39);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList40);
        boolean boolean43 = node42.isParamList();
        boolean boolean44 = node42.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile45 = node42.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId46 = null;
        node42.setInputId(inputId46);
        boolean boolean48 = closureCodingConvention38.isOptionalParameter(node42);
        boolean boolean49 = detailLevel37.apply(node42);
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList51 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList51, nodeArray50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList51);
        boolean boolean54 = node53.isTry();
        java.util.Set<java.lang.String> strSet55 = node53.getDirectives();
        boolean boolean56 = node53.isWhile();
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.newNode(node53, nodeArray57);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.paramList(nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.newNode(node42, nodeArray57);
        java.lang.String str61 = closureCodingConvention0.extractClassNameIfProvide(node34, node42);
        com.google.javascript.rhino.Node node62 = node42.getParent();
        node62.setVarArgs(false);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(detailLevel37);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(staticSourceFile45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(strSet55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(node62);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = compilerOptions0.variableRenaming;
        boolean boolean31 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy30.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setMoveFunctionDeclarations(false);
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypes;
        compilerOptions0.setDefineToStringLiteral("module$goog.exportProperty", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        java.lang.String str7 = com.google.javascript.jscomp.NodeUtil.getSourceName(node4);
        boolean boolean8 = node4.isOr();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isTry();
        java.util.Set<java.lang.String> strSet7 = node5.getDirectives();
        boolean boolean8 = node5.isInstanceOf();
        com.google.javascript.rhino.Node node9 = node0.clonePropsFrom(node5);
        boolean boolean10 = node5.isOptionalArg();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = node5.getJSDocInfo();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSDocInfo11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str2 = inputId1.getIdName();
        java.lang.String str3 = inputId1.getIdName();
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput7.getModule();
        boolean boolean9 = inputId1.equals((java.lang.Object) jSModule8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str2.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str3.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        loggerErrorManager6.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray12 = compilerOptions8.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        boolean boolean19 = node18.isParamList();
        boolean boolean20 = node18.isNull();
        com.google.javascript.rhino.jstype.JSType jSType21 = node18.getJSType();
        com.google.javascript.rhino.Node node22 = node18.getLastSibling();
        com.google.javascript.rhino.Node node23 = node18.getParent();
        boolean boolean24 = node18.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node18, diagnosticType25, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = jSError32.level;
        int int34 = jSError32.lineNumber;
        loggerErrorManager6.report(checkLevel13, jSError32);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.rhino.InputId inputId37 = compilerInput3.getInputId();
        com.google.javascript.jscomp.JSModule jSModule38 = null;
        compilerInput3.setModule(jSModule38);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(byteArray12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(inputId37);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isLabelName();
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.getprop(node0, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.jqueryPass = false;
        compilerOptions0.setInferTypes(true);
        java.lang.String str7 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.rhino.jstype.ObjectType objectType0 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType2 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface(objectType0, "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile9 = null;
        node3.setStaticSourceFile(staticSourceFile9);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "Unknown class name";
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean7 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        java.lang.Object obj12 = node10.getProp(0);
        java.lang.String str13 = node10.getQualifiedName();
        node4.addChildrenToFront(node10);
        com.google.javascript.rhino.Node[] nodeArray15 = null;
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.call(node4, nodeArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile10.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str16 = jSSourceFile14.getLine((int) '#');
        jSSourceFile14.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str19 = jSSourceFile14.getCode();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str24 = jSSourceFile22.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile27.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile14, jSSourceFile22, jSSourceFile27 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray30 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean32 = compilerOptions31.generatePseudoNames;
        boolean boolean33 = compilerOptions31.checkSuspiciousCode;
        compilerOptions31.jqueryPass = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler36 = compilerOptions31.getAliasTransformationHandler();
        com.google.javascript.jscomp.Result result37 = compiler1.compile(jSSourceFileArray29, jSModuleArray30, compilerOptions31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean39 = compilerOptions38.generatePseudoNames;
        boolean boolean40 = compilerOptions38.checkSuspiciousCode;
        compilerOptions38.jqueryPass = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler43 = compilerOptions38.getAliasTransformationHandler();
        compilerOptions31.setAliasTransformationHandler(aliasTransformationHandler43);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray29);
        org.junit.Assert.assertNotNull(jSModuleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler36);
        org.junit.Assert.assertNotNull(result37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler43);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setTightenTypes(true);
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.setUnaliasableGlobals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.markAsCompiled = true;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray7 = compilerOptions3.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions3.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        boolean boolean14 = node13.isParamList();
        boolean boolean15 = node13.isNull();
        com.google.javascript.rhino.jstype.JSType jSType16 = node13.getJSType();
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        com.google.javascript.rhino.Node node18 = node13.getParent();
        boolean boolean19 = node13.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node13, diagnosticType20, strArray26);
        com.google.javascript.jscomp.CheckLevel checkLevel28 = jSError27.level;
        int int29 = jSError27.lineNumber;
        loggerErrorManager1.report(checkLevel8, jSError27);
        double double31 = loggerErrorManager1.getTypedPercent();
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        boolean boolean7 = closureCodingConvention0.isValidEnumKey("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.setCollapseObjectLiterals(true);
        compilerOptions0.ambiguateProperties = true;
        compilerOptions0.setAliasKeywords(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        boolean boolean3 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.SourceFile sourceFile1 = new com.google.javascript.jscomp.SourceFile("goog.abstractMethod");
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setCollapseObjectLiterals(false);
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setReportPath("Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        boolean boolean7 = node3.isFalse();
        boolean boolean8 = node3.isGetElem();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setCollapseObjectLiterals(false);
        boolean boolean8 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isTry();
        java.util.Set<java.lang.String> strSet7 = node5.getDirectives();
        boolean boolean8 = node5.isInstanceOf();
        com.google.javascript.rhino.Node node9 = node0.clonePropsFrom(node5);
        boolean boolean10 = node5.isOptionalArg();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node12 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = closureCodingConvention11.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        boolean boolean19 = node18.isParamList();
        boolean boolean20 = node18.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile21 = node18.getStaticSourceFile();
        java.lang.String str22 = closureCodingConvention11.extractClassNameIfRequire(node14, node18);
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList24 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList24, nodeArray23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList24);
        java.lang.Object obj28 = node26.getProp(0);
        boolean boolean29 = node26.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder30 = node26.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList33 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList33, nodeArray32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList33);
        java.lang.String str36 = node31.checkTreeEquals(node35);
        boolean boolean37 = node35.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList39 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList39, nodeArray38);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList39);
        boolean boolean42 = node41.isTry();
        java.util.Set<java.lang.String> strSet43 = node41.getDirectives();
        boolean boolean44 = node41.isWith();
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList46 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList46, nodeArray45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList46);
        node35.addChildAfter(node41, node48);
        java.lang.String str50 = closureCodingConvention11.extractClassNameIfRequire(node26, node48);
        try {
            com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.eq(node5, node48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(staticSourceFile21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(nodeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str36.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(strSet43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(str50);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setExternExports(true);
        boolean boolean10 = compilerOptions0.removeDeadCode;
        boolean boolean11 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "hi!", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        compilerOptions0.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList19);
        byte[] byteArray22 = new byte[] {};
        compilerOptions0.setInputVariableMapSerialized(byteArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.setRemoveClosureAsserts(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        java.util.Map<java.lang.String, com.google.javascript.jscomp.CheckLevel> strMap4 = null;
        try {
            compilerOptions0.setPropertyInvalidationErrors(strMap4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.inlineVariables = false;
        compilerOptions0.setPreferLineBreakAtEndOfFile(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long0 = com.google.javascript.rhino.InputId.serialVersionUID;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType11, functionType12, objectType13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.setRemoveUnusedLocalVars(false);
        compilerOptions0.removeTryCatchFinally = true;
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions12.checkProvides = checkLevel20;
        compilerOptions0.checkRequires = checkLevel20;
        com.google.javascript.jscomp.ErrorFormat errorFormat23 = null;
        compilerOptions0.errorFormat = errorFormat23;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isTry();
        java.util.Set<java.lang.String> strSet18 = node16.getDirectives();
        boolean boolean19 = node16.isWhile();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.newNode(node16, nodeArray20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList(nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.newNode(node5, nodeArray20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.objectlit(nodeArray20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.block(nodeArray20);
        boolean boolean26 = node25.isName();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        boolean boolean13 = node5.isLabel();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray4 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.generatePseudoNames;
        compilerOptions5.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions5.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = null;
        compilerOptions5.setCssRenamingMap(cssRenamingMap10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions12.checkRequires;
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        compilerOptions12.setIdGenerators((java.util.Set<java.lang.String>) strSet21);
        compilerOptions5.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet21);
        compilerOptions0.stripNamePrefixes = strSet21;
        compilerOptions0.setInlineVariables(true);
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str2 = inputId1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "InputId: Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str2.equals("InputId: Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
    }
}

