import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = null;
        compilerOptions0.setWarningsGuard(composeWarningsGuard10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.generatePseudoNames;
        compilerOptions14.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions14.checkRequires;
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet23 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet23, strArray22);
        compilerOptions14.setIdGenerators((java.util.Set<java.lang.String>) strSet23);
        compilerOptions12.setStripTypes((java.util.Set<java.lang.String>) strSet23);
        compilerOptions12.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat29 = compilerOptions12.errorFormat;
        compilerOptions0.setErrorFormat(errorFormat29);
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(errorFormat29);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("goog.abstractMethod", 52, 1);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        compilerOptions29.setRenamePrefix("module$Unknown class name");
        compilerOptions29.setChainCalls(true);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
//        try {
//            java.lang.String str2 = diagnosticGroup0.toString();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("goog.exportProperty", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder5 = builder0.withCharset(charset4);
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(builder5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.jqueryPass = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions7.checkMissingGetCssNameLevel;
        compilerOptions7.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.generatePseudoNames;
        compilerOptions13.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.generatePseudoNames;
        compilerOptions17.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions17.checkRequires;
        compilerOptions13.checkProvides = checkLevel21;
        compilerOptions7.checkGlobalThisLevel = checkLevel21;
        compilerOptions0.checkProvides = checkLevel21;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray29 = compilerOptions25.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean31 = compilerOptions30.generatePseudoNames;
        compilerOptions30.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean35 = compilerOptions34.generatePseudoNames;
        compilerOptions34.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions34.checkRequires;
        compilerOptions30.checkProvides = checkLevel38;
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard40 = null;
        compilerOptions30.setWarningsGuard(composeWarningsGuard40);
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean43 = compilerOptions42.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean45 = compilerOptions44.generatePseudoNames;
        compilerOptions44.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions44.checkRequires;
        java.lang.String[] strArray52 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet53 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet53, strArray52);
        compilerOptions44.setIdGenerators((java.util.Set<java.lang.String>) strSet53);
        compilerOptions42.setStripTypes((java.util.Set<java.lang.String>) strSet53);
        compilerOptions42.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat59 = compilerOptions42.errorFormat;
        compilerOptions30.setErrorFormat(errorFormat59);
        compilerOptions30.setProtectHiddenSideEffects(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean66 = compilerOptions65.generatePseudoNames;
        compilerOptions65.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = compilerOptions65.checkRequires;
        java.lang.String[] strArray73 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet74 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet74, strArray73);
        compilerOptions65.setIdGenerators((java.util.Set<java.lang.String>) strSet74);
        compilerOptions63.setStripTypes((java.util.Set<java.lang.String>) strSet74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean80 = compilerOptions79.generatePseudoNames;
        compilerOptions79.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions79.checkRequires;
        compilerOptions78.checkGlobalNamesLevel = checkLevel83;
        compilerOptions63.checkUnreachableCode = checkLevel83;
        com.google.javascript.jscomp.CompilerOptions compilerOptions86 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean87 = compilerOptions86.generatePseudoNames;
        boolean boolean88 = compilerOptions86.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel89 = compilerOptions86.checkUnreachableCode;
        compilerOptions63.setCheckGlobalThisLevel(checkLevel89);
        compilerOptions63.coalesceVariableNames = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy93 = compilerOptions63.variableRenaming;
        compilerOptions30.setVariableRenaming(variableRenamingPolicy93);
        compilerOptions25.setVariableRenaming(variableRenamingPolicy93);
        compilerOptions0.setVariableRenaming(variableRenamingPolicy93);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(errorFormat59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + checkLevel89 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel89.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy93 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy93.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isNot();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node3.siblings();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isTypeOf();
        boolean boolean13 = node11.isNoSideEffectsCall();
        int int14 = node11.getType();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.regexp(node3, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeIterable7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 83 + "'", int14 == 83);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean11 = compilerOptions0.printInputDelimiter;
        compilerOptions0.setDebugFunctionSideEffectsPath("hi!");
        compilerOptions0.setOptimizeReturns(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile10.clearCachedSource();
        try {
            compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node3.new FileLevelJsDocBuilder();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable8 = node3.children();
        java.lang.Appendable appendable9 = null;
        try {
            node3.appendStringTree(appendable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeIterable8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.setCollapseObjectLiterals(true);
        compilerOptions0.ambiguateProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        compilerOptions0.setReportUnknownTypes(checkLevel11);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        java.lang.String str6 = jSSourceFile2.getOriginalPath();
        try {
            int int8 = jSSourceFile2.getLineOffset(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
//        jSSourceFile4.clearCachedSource();
//        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = compiler1.getTypeRegistry();
//        try {
//            compiler1.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(node6);
//        org.junit.Assert.assertNotNull(jSTypeRegistry7);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = compiler1.getTypeRegistry();
        try {
            com.google.javascript.jscomp.Region region10 = compiler1.getSourceRegion("goog.exportProperty", 43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(jSTypeRegistry7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker38 = null;
        compiler1.tracker = performanceTracker38;
        com.google.javascript.jscomp.JSModule jSModule40 = null;
        try {
            java.lang.String[] strArray41 = compiler1.toSourceArray(jSModule40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        java.lang.String str3 = closureCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        int int12 = node10.getIntProp(43);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.breakNode(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "hi!", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        compilerOptions0.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList19);
        com.google.javascript.jscomp.CompilerOptions.Reach reach22 = com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY;
        compilerOptions0.setInlineVariables(reach22);
        compilerOptions0.setOptimizeParameters(false);
        boolean boolean26 = compilerOptions0.generatePseudoNames;
        boolean boolean27 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + reach22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY + "'", reach22.equals(com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        node16.addSuppression("()");
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean32 = closureCodingConvention0.isPrototypeAlias(node31);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node34 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship35 = closureCodingConvention33.getDelegateRelationship(node34);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList38 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList38, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList38);
        boolean boolean41 = node40.isParamList();
        boolean boolean42 = node40.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile43 = node40.getStaticSourceFile();
        java.lang.String str44 = closureCodingConvention33.extractClassNameIfRequire(node36, node40);
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList46 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList46, nodeArray45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList46);
        java.lang.Object obj50 = node48.getProp(0);
        boolean boolean51 = node48.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder52 = node48.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList55 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList55, nodeArray54);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList55);
        java.lang.String str58 = node53.checkTreeEquals(node57);
        boolean boolean59 = node57.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList61 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList61, nodeArray60);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList61);
        boolean boolean64 = node63.isTry();
        java.util.Set<java.lang.String> strSet65 = node63.getDirectives();
        boolean boolean66 = node63.isWith();
        com.google.javascript.rhino.Node[] nodeArray67 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList68 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList68, nodeArray67);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList68);
        node57.addChildAfter(node63, node70);
        java.lang.String str72 = closureCodingConvention33.extractClassNameIfRequire(node48, node70);
        com.google.javascript.rhino.Node[] nodeArray73 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList74 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList74, nodeArray73);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList74);
        boolean boolean77 = node76.isParamList();
        boolean boolean78 = node76.isNull();
        node70.addChildToFront(node76);
        try {
            boolean boolean80 = closureCodingConvention0.isPropertyTestFunction(node70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(delegateRelationship35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(staticSourceFile43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str58.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(strSet65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(nodeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(nodeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        boolean boolean5 = node3.isIf();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        boolean boolean9 = node7.isName();
        boolean boolean10 = node7.isVar();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.Node node9 = node4.getParent();
        boolean boolean10 = node4.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node4, diagnosticType11, strArray17);
        try {
            com.google.javascript.rhino.Node node19 = node4.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        compilerOptions0.jqueryPass = true;
        compilerOptions0.setShadowVariables(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        java.util.Set<java.lang.String> strSet12 = node10.getDirectives();
        boolean boolean13 = node10.isWith();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        node4.addChildAfter(node10, node17);
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo19 = com.google.javascript.jscomp.NodeUtil.getFunctionJSDocInfo(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions0.setTracer(tracerMode14);
        compilerOptions0.setExportTestFunctions(false);
        java.util.Set<java.lang.String> strSet18 = null;
        compilerOptions0.setStripNamePrefixes(strSet18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setExternExportsPath("");
        compilerOptions0.setCollapseVariableDeclarations(true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        boolean boolean8 = node3.isExprResult();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.pos(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker38 = null;
        compiler1.tracker = performanceTracker38;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode40 = compiler1.languageMode();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + languageMode40 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode40.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray5 = compilerOptions4.inputPropertyMapSerialized;
        compilerOptions4.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions4.aliasStringsBlacklist = "hi!";
        java.lang.String[] strArray17 = new java.lang.String[] { "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "module$Unknown class name", "module$Unknown class name", "goog.abstractMethod", "goog.abstractMethod", "goog.abstractMethod", "goog.abstractMethod" };
        java.util.ArrayList<java.lang.String> strList18 = new java.util.ArrayList<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList18, strArray17);
        compilerOptions4.setManageClosureDependencies((java.util.List<java.lang.String>) strList18);
        com.google.javascript.jscomp.SourceAst sourceAst21 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(sourceAst21, "", true);
        com.google.javascript.jscomp.JSModule jSModule25 = compilerInput24.getModule();
        com.google.javascript.jscomp.JSModule jSModule26 = null;
        compilerInput24.setModule(jSModule26);
        com.google.javascript.jscomp.SourceAst sourceAst28 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(sourceAst28, "", true);
        boolean boolean32 = compilerInput31.isExtern();
        java.lang.String str33 = compilerInput31.toString();
        com.google.javascript.jscomp.SourceAst sourceAst34 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(sourceAst34, "", true);
        com.google.javascript.jscomp.JSModule jSModule38 = compilerInput37.getModule();
        com.google.javascript.jscomp.JSModule jSModule39 = null;
        compilerInput37.setModule(jSModule39);
        com.google.javascript.jscomp.SourceAst sourceAst41 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(sourceAst41, "", true);
        boolean boolean45 = compilerInput44.isExtern();
        java.lang.String str46 = compilerInput44.toString();
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray47 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput24, compilerInput31, compilerInput37, compilerInput44 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList48 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList48, compilerInputArray47);
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList50 = jSModuleGraph3.manageDependencies((java.util.List<java.lang.String>) strList18, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(jSModule25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNull(jSModule38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertNotNull(compilerInputArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray4 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkProvides;
        java.lang.Object obj6 = compilerOptions0.clone();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node4 = null;
        try {
            java.util.List<java.lang.String> strList5 = closureCodingConvention0.identifyTypeDeclarationCall(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode6 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions0.setLanguageIn(languageMode6);
        boolean boolean8 = compilerOptions0.optimizeReturns;
        java.lang.String str9 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode6.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile15 = node12.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId16 = null;
        node12.setInputId(inputId16);
        boolean boolean18 = closureCodingConvention8.isOptionalParameter(node12);
        boolean boolean19 = detailLevel7.apply(node12);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isTry();
        java.util.Set<java.lang.String> strSet25 = node23.getDirectives();
        boolean boolean26 = node23.isWhile();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.newNode(node23, nodeArray27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList(nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.newNode(node12, nodeArray27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.newNode(node3, nodeArray27);
        boolean boolean32 = node31.isAssign();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(staticSourceFile15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(strSet25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setAliasStringsBlacklist("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.setProcessCommonJSModules(false);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions15.checkMissingGetCssNameLevel;
        diagnosticType14.level = checkLevel18;
        compilerOptions0.setWarningLevel(diagnosticGroup12, checkLevel18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node node3 = node1.getLastChild();
        boolean boolean4 = node1.isNoSideEffectsCall();
        node1.setSourceEncodedPosition(0);
        com.google.javascript.rhino.Node node7 = null;
        com.google.javascript.rhino.Node node8 = null;
        com.google.javascript.rhino.Node node9 = null;
        try {
            com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, node1, node7, node8, node9, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.closurePass = true;
        compilerOptions0.setAliasStringsBlacklist("Unknown class name");
        boolean boolean13 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray14 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList15 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList15, warningsGuardArray14);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard17);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup19;
        boolean boolean21 = composeWarningsGuard17.disables(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setAliasExternals(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setInferTypes(false);
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(logger20);
        com.google.javascript.jscomp.JSError[] jSErrorArray22 = loggerErrorManager21.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError27 = null;
        loggerErrorManager21.println(checkLevel26, jSError27);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel26;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean31 = compilerOptions30.generatePseudoNames;
        compilerOptions30.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions30.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap35 = null;
        compilerOptions30.setCssRenamingMap(cssRenamingMap35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean38 = compilerOptions37.generatePseudoNames;
        compilerOptions37.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions37.checkRequires;
        java.lang.String[] strArray45 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet46 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet46, strArray45);
        compilerOptions37.setIdGenerators((java.util.Set<java.lang.String>) strSet46);
        compilerOptions30.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet46);
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet46);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.generatePseudoNames;
        compilerOptions51.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions51.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap56 = null;
        compilerOptions51.setCssRenamingMap(cssRenamingMap56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean59 = compilerOptions58.generatePseudoNames;
        compilerOptions58.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions58.checkRequires;
        java.lang.String[] strArray66 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet67 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet67, strArray66);
        compilerOptions58.setIdGenerators((java.util.Set<java.lang.String>) strSet67);
        compilerOptions51.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet67);
        compilerOptions0.stripTypes = strSet67;
        compilerOptions0.checkControlStructures = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSErrorArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.optimizeParameters = true;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        java.lang.String str14 = compilerOptions0.aliasStringsBlacklist;
        java.lang.String str15 = compilerOptions0.renamePrefix;
        compilerOptions0.checkSymbols = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setTightenTypes(true);
        compilerOptions0.computeFunctionSideEffects = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap7 = compilerOptions0.cssRenamingMap;
        compilerOptions0.setIgnoreCajaProperties(true);
        org.junit.Assert.assertNull(cssRenamingMap7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray4 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkProvides;
        boolean boolean6 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        int int3 = loggerErrorManager1.getWarningCount();
        int int4 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.setDefineToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        boolean boolean1 = node0.hasChildren();
        java.util.Set<java.lang.String> strSet2 = node0.getDirectives();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(strSet2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        java.lang.String str6 = node3.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.block(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node0.isEquivalentToTyped(node4);
        try {
            double double7 = node4.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: PARAM_LIST is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) -1);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList7 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList7, nodeArray6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList7);
        boolean boolean10 = node9.isTry();
        java.util.Set<java.lang.String> strSet11 = node9.getDirectives();
        boolean boolean12 = node9.isWhile();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.newNode(node9, nodeArray13);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList(nodeArray13);
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.switchNode(node3, nodeArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(strSet11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isContinue();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("", "InputId: Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setCrossModuleCodeMotion(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.generatePseudoNames;
        compilerOptions8.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions8.checkRequires;
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet17 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet17, strArray16);
        compilerOptions8.setIdGenerators((java.util.Set<java.lang.String>) strSet17);
        compilerOptions6.setStripTypes((java.util.Set<java.lang.String>) strSet17);
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "hi!", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.ArrayList<java.lang.String> strList25 = new java.util.ArrayList<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList25, strArray24);
        compilerOptions6.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList25);
        compilerOptions0.setReplaceStringsFunctionDescriptions((java.util.List<java.lang.String>) strList25);
        boolean boolean29 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        java.lang.String str1 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<accessControls>" + "'", str1.equals("DiagnosticGroup<accessControls>"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean32 = closureCodingConvention0.isPrototypeAlias(node31);
        java.lang.String str33 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str34 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention35 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList38 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList38, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList38);
        boolean boolean41 = node40.isParamList();
        boolean boolean42 = node40.isNull();
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 1, node40);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention44 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node45 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = closureCodingConvention44.getDelegateRelationship(node45);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList49 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList49, nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList49);
        boolean boolean52 = node51.isParamList();
        boolean boolean53 = node51.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile54 = node51.getStaticSourceFile();
        java.lang.String str55 = closureCodingConvention44.extractClassNameIfRequire(node47, node51);
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList57 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList57, nodeArray56);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList57);
        boolean boolean60 = node59.isParamList();
        boolean boolean61 = node59.isNull();
        com.google.javascript.rhino.jstype.JSType jSType62 = node59.getJSType();
        node51.addChildrenToBack(node59);
        java.lang.String str64 = closureCodingConvention35.extractClassNameIfProvide(node40, node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray66 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList67 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList67, nodeArray66);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList67);
        boolean boolean70 = node69.isTry();
        com.google.javascript.rhino.Node node71 = node65.srcref(node69);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel72 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention73 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray74 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList75 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean76 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList75, nodeArray74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList75);
        boolean boolean78 = node77.isParamList();
        boolean boolean79 = node77.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile80 = node77.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId81 = null;
        node77.setInputId(inputId81);
        boolean boolean83 = closureCodingConvention73.isOptionalParameter(node77);
        boolean boolean84 = detailLevel72.apply(node77);
        com.google.javascript.rhino.Node[] nodeArray85 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList86 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList86, nodeArray85);
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList86);
        boolean boolean89 = node88.isTry();
        java.util.Set<java.lang.String> strSet90 = node88.getDirectives();
        boolean boolean91 = node88.isWhile();
        com.google.javascript.rhino.Node[] nodeArray92 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node93 = com.google.javascript.rhino.IR.newNode(node88, nodeArray92);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.IR.paramList(nodeArray92);
        com.google.javascript.rhino.Node node95 = com.google.javascript.rhino.IR.newNode(node77, nodeArray92);
        java.lang.String str96 = closureCodingConvention35.extractClassNameIfProvide(node69, node77);
        com.google.javascript.rhino.Node node97 = node77.getParent();
        boolean boolean98 = closureCodingConvention0.isOptionalParameter(node97);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.exportProperty" + "'", str33.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(delegateRelationship46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(staticSourceFile54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(detailLevel72);
        org.junit.Assert.assertNotNull(nodeArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSourceFile80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(nodeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNull(strSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(nodeArray92);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNull(str96);
        org.junit.Assert.assertNotNull(node97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.setAggressiveVarCheck(checkLevel8);
        compilerOptions0.sourceMapOutputPath = "";
        compilerOptions0.setComputeFunctionSideEffects(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput3.getModule();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isLabelName();
        java.lang.String str2 = com.google.javascript.jscomp.NodeUtil.getSourceName(node0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        java.lang.Object obj9 = node3.getProp(42);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        com.google.javascript.jscomp.SourceMap.Format format5 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setRemoveUnusedPrototypeProperties(false);
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(1, nodeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.aliasStringsBlacklist = "hi!";
        java.lang.String[] strArray13 = new java.lang.String[] { "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "module$Unknown class name", "module$Unknown class name", "goog.abstractMethod", "goog.abstractMethod", "goog.abstractMethod", "goog.abstractMethod" };
        java.util.ArrayList<java.lang.String> strList14 = new java.util.ArrayList<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList14, strArray13);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList14);
        compilerOptions0.setCollapseAnonymousFunctions(true);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str0 = com.google.javascript.jscomp.ProcessCommonJSModules.DEFAULT_FILENAME_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "./" + "'", str0.equals("./"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.checkTypes = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap20 = null;
        compilerOptions15.setCssRenamingMap(cssRenamingMap20);
        compilerOptions15.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.generatePseudoNames;
        compilerOptions24.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions24.checkRequires;
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet33 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet33, strArray32);
        compilerOptions24.setIdGenerators((java.util.Set<java.lang.String>) strSet33);
        compilerOptions15.setStripTypes((java.util.Set<java.lang.String>) strSet33);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy37 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions15.propertyRenaming = propertyRenamingPolicy37;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy37);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy37 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy37.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.setAggressiveVarCheck(checkLevel8);
        compilerOptions0.sourceMapOutputPath = "";
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions12.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions12.setCssRenamingMap(cssRenamingMap17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.generatePseudoNames;
        compilerOptions19.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.checkRequires;
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet28 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet28, strArray27);
        compilerOptions19.setIdGenerators((java.util.Set<java.lang.String>) strSet28);
        compilerOptions12.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet28);
        java.util.logging.Logger logger32 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager33 = new com.google.javascript.jscomp.LoggerErrorManager(logger32);
        com.google.javascript.jscomp.JSError[] jSErrorArray34 = loggerErrorManager33.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean36 = compilerOptions35.generatePseudoNames;
        boolean boolean37 = compilerOptions35.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions35.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError39 = null;
        loggerErrorManager33.println(checkLevel38, jSError39);
        compilerOptions12.checkMissingGetCssNameLevel = checkLevel38;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel38);
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig43 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.sourceMapOutputPath = "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n";
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSErrorArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("()", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$()" + "'", str2.equals("module$()"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.jqueryPass = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions7.checkMissingGetCssNameLevel;
        compilerOptions7.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.generatePseudoNames;
        compilerOptions13.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.generatePseudoNames;
        compilerOptions17.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions17.checkRequires;
        compilerOptions13.checkProvides = checkLevel21;
        compilerOptions7.checkGlobalThisLevel = checkLevel21;
        compilerOptions0.checkProvides = checkLevel21;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap25 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap25);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        compiler1.rebuildInputsFromModules();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter42 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.util.logging.Logger logger43 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager44 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter42, logger43);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(30, 49, 31);
        node4.setOptionalArg(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        boolean boolean9 = compilerOptions7.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions7.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList11 = compilerOptions7.sourceMapLocationMappings;
        compilerOptions7.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions7.reportMissingOverride = checkLevel14;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.generatePseudoNames;
        compilerOptions18.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions18.checkRequires;
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet27 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet27, strArray26);
        compilerOptions18.setIdGenerators((java.util.Set<java.lang.String>) strSet27);
        compilerOptions16.setStripTypes((java.util.Set<java.lang.String>) strSet27);
        compilerOptions16.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat33 = compilerOptions16.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy34 = compilerOptions16.propertyRenaming;
        compilerOptions7.propertyRenaming = propertyRenamingPolicy34;
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList38 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList38, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList38);
        boolean boolean41 = node40.isParamList();
        boolean boolean42 = node40.isNull();
        com.google.javascript.rhino.jstype.JSType jSType43 = node40.getJSType();
        com.google.javascript.rhino.Node node44 = node40.getLastSibling();
        com.google.javascript.rhino.Node node45 = node40.getParent();
        boolean boolean46 = node40.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray53 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node40, diagnosticType47, strArray53);
        com.google.javascript.jscomp.CheckLevel checkLevel55 = jSError54.level;
        compilerOptions7.aggressiveVarCheck = checkLevel55;
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions58.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = compilerOptions58.checkMissingGetCssNameLevel;
        diagnosticType57.level = checkLevel61;
        compilerOptions7.setCheckRequires(checkLevel61);
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.DiagnosticType.error("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "hi!");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile69 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node68);
        com.google.javascript.rhino.Node[] nodeArray70 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList71 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList71, nodeArray70);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList71);
        boolean boolean74 = node73.isTry();
        java.util.Set<java.lang.String> strSet75 = node73.getDirectives();
        boolean boolean76 = node73.isInstanceOf();
        com.google.javascript.rhino.Node node77 = node68.clonePropsFrom(node73);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup78 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType79 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean80 = diagnosticGroup78.matches(diagnosticType79);
        java.lang.String[] strArray82 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError83 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node77, diagnosticType79, strArray82);
        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make("()", node4, checkLevel61, diagnosticType66, strArray82);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(errorFormat33);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy34 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy34.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(staticSourceFile69);
        org.junit.Assert.assertNotNull(nodeArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(strSet75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(diagnosticGroup78);
        org.junit.Assert.assertNotNull(diagnosticType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(strArray82);
        org.junit.Assert.assertNotNull(jSError83);
        org.junit.Assert.assertNotNull(jSError84);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        boolean boolean9 = node8.isParamList();
        boolean boolean10 = node8.isNull();
        com.google.javascript.rhino.jstype.JSType jSType11 = node8.getJSType();
        com.google.javascript.rhino.Node node12 = node8.getLastSibling();
        com.google.javascript.rhino.Node node13 = node8.getParent();
        boolean boolean14 = node8.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray21 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node8, diagnosticType15, strArray21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = jSError22.getType();
        java.lang.String str24 = jSError22.description;
        loggerErrorManager1.report(checkLevel3, jSError22);
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "()" + "'", str24.equals("()"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str29 = jSSourceFile27.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile27 };
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList33 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList33, nodeArray32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList33);
        boolean boolean36 = node35.isParamList();
        boolean boolean37 = node35.isNull();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 1, node35);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str43 = jSSourceFile41.getLine((int) '#');
        jSSourceFile41.clearCachedSource();
        node35.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str50 = jSSourceFile48.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray51 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile41, jSSourceFile48 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean53 = compilerOptions52.generatePseudoNames;
        boolean boolean54 = compilerOptions52.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions52.checkUnreachableCode;
        compilerOptions52.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode58 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions52.setLanguageIn(languageMode58);
        compiler24.init(jSSourceFileArray30, jSSourceFileArray51, compilerOptions52);
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean62 = compilerOptions61.generatePseudoNames;
        compilerOptions61.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel65 = compilerOptions61.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap66 = null;
        compilerOptions61.setCssRenamingMap(cssRenamingMap66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean69 = compilerOptions68.generatePseudoNames;
        compilerOptions68.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel72 = compilerOptions68.checkRequires;
        java.lang.String[] strArray76 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet77 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet77, strArray76);
        compilerOptions68.setIdGenerators((java.util.Set<java.lang.String>) strSet77);
        compilerOptions61.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet77);
        compilerOptions61.setRenamePrefixNamespace("");
        compilerOptions61.optimizeReturns = false;
        com.google.javascript.jscomp.Result result85 = compiler1.compile(jSSourceFile18, jSSourceFileArray30, compilerOptions61);
        java.lang.String[] strArray86 = compiler1.toSourceArray();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(jSSourceFileArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode58 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode58.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertNotNull(strArray86);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.Object obj6 = node4.getProp(0);
        boolean boolean7 = node4.isSyntheticBlock();
        boolean boolean8 = node4.isFalse();
        boolean boolean9 = node4.isLabel();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.voidNode(node13);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList17);
        boolean boolean20 = node19.isParamList();
        boolean boolean21 = node19.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile22 = node19.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId23 = null;
        node19.setInputId(inputId23);
        boolean boolean25 = closureCodingConvention15.isOptionalParameter(node19);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel26 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList29 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList29, nodeArray28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList29);
        boolean boolean32 = node31.isParamList();
        boolean boolean33 = node31.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile34 = node31.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId35 = null;
        node31.setInputId(inputId35);
        boolean boolean37 = closureCodingConvention27.isOptionalParameter(node31);
        boolean boolean38 = detailLevel26.apply(node31);
        boolean boolean39 = closureCodingConvention15.isPrototypeAlias(node31);
        com.google.javascript.rhino.Node node40 = node13.clonePropsFrom(node31);
        boolean boolean41 = node40.isDelProp();
        java.lang.String str42 = closureCodingConvention0.extractClassNameIfRequire(node4, node40);
        boolean boolean43 = node4.isDefaultCase();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(staticSourceFile22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(detailLevel26);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(staticSourceFile34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean11 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        boolean boolean14 = compilerOptions12.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions12.checkUnreachableCode;
        compilerOptions12.setCrossModuleCodeMotion(true);
        compilerOptions12.setCheckTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions12.checkProvides;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel20;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        boolean boolean17 = node3.isCall();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.reportMissingOverride = checkLevel7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.checkRequires;
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions11.setIdGenerators((java.util.Set<java.lang.String>) strSet20);
        compilerOptions9.setStripTypes((java.util.Set<java.lang.String>) strSet20);
        compilerOptions9.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat26 = compilerOptions9.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions9.propertyRenaming;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy27;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        compilerOptions29.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions29.checkRequires;
        java.lang.String[] strArray37 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet38 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet38, strArray37);
        compilerOptions29.setIdGenerators((java.util.Set<java.lang.String>) strSet38);
        compilerOptions0.stripTypePrefixes = strSet38;
        boolean boolean42 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.setAliasAllStrings(false);
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(errorFormat26);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("goog.exportProperty", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.io.File file4 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromFile(file4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setShadowVariables(false);
        boolean boolean4 = compilerOptions0.collapseProperties;
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.setRenamePrefixNamespace("PARAM_LIST");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setMoveFunctionDeclarations(false);
        compilerOptions0.setCommonJSModulePathPrefix("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.DependencyOptions dependencyOptions0 = new com.google.javascript.jscomp.DependencyOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        compilerOptions1.setIdGenerators((java.util.Set<java.lang.String>) strSet10);
        dependencyOptions0.setEntryPoints((java.util.Collection<java.lang.String>) strSet10);
        dependencyOptions0.setDependencySorting(true);
        dependencyOptions0.setMoocherDropping(false);
        dependencyOptions0.setDependencyPruning(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.generatePseudoNames;
        compilerOptions6.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.generatePseudoNames;
        compilerOptions10.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions10.checkRequires;
        compilerOptions6.checkProvides = checkLevel14;
        compilerOptions0.checkGlobalThisLevel = checkLevel14;
        compilerOptions0.setCommonJSModulePathPrefix("()");
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray20 = compilerOptions19.inputPropertyMapSerialized;
        compilerOptions19.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler23 = compilerOptions19.getAliasTransformationHandler();
        java.util.Set<java.lang.String> strSet24 = compilerOptions19.aliasableStrings;
        java.util.Set<java.lang.String> strSet25 = compilerOptions19.aliasableStrings;
        compilerOptions0.setAliasableStrings(strSet25);
        compilerOptions0.coalesceVariableNames = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertNotNull(aliasTransformationHandler23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertNotNull(strSet25);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str11 = jSSourceFile9.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        boolean boolean18 = node17.isParamList();
        boolean boolean19 = node17.isNull();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 1, node17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str25 = jSSourceFile23.getLine((int) '#');
        jSSourceFile23.clearCachedSource();
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str32 = jSSourceFile30.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile30 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean35 = compilerOptions34.generatePseudoNames;
        boolean boolean36 = compilerOptions34.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions34.checkUnreachableCode;
        compilerOptions34.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode40 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions34.setLanguageIn(languageMode40);
        compiler6.init(jSSourceFileArray12, jSSourceFileArray33, compilerOptions34);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("module$goog.exportProperty", charset45);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray47 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile46 };
        java.io.PrintStream printStream48 = null;
        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler(printStream48);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile52.clearCachedSource();
        com.google.javascript.rhino.Node node54 = compiler49.parse(jSSourceFile52);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState55 = compiler49.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile58 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile58.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str64 = jSSourceFile62.getLine((int) '#');
        jSSourceFile62.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput66 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile62);
        java.lang.String str67 = jSSourceFile62.getCode();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile70 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str72 = jSSourceFile70.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile75.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray77 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile58, jSSourceFile62, jSSourceFile70, jSSourceFile75 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray78 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean80 = compilerOptions79.generatePseudoNames;
        boolean boolean81 = compilerOptions79.checkSuspiciousCode;
        compilerOptions79.jqueryPass = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler84 = compilerOptions79.getAliasTransformationHandler();
        com.google.javascript.jscomp.Result result85 = compiler49.compile(jSSourceFileArray77, jSModuleArray78, compilerOptions79);
        com.google.javascript.jscomp.CompilerOptions compilerOptions86 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray87 = compilerOptions86.inputPropertyMapSerialized;
        compilerOptions86.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy90 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions86.setPropertyRenaming(propertyRenamingPolicy90);
        compiler6.init(jSSourceFileArray47, jSModuleArray78, compilerOptions86);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode40 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode40.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFileArray47);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(intermediateState55);
        org.junit.Assert.assertNotNull(jSSourceFile58);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile70);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertNotNull(jSSourceFileArray77);
        org.junit.Assert.assertNotNull(jSModuleArray78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler84);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertNull(byteArray87);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy90 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy90.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        com.google.javascript.rhino.Node node14 = node10.getLastSibling();
        com.google.javascript.rhino.Node node15 = node10.getParent();
        boolean boolean16 = node10.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node10, diagnosticType17, strArray23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = jSError24.getType();
        java.lang.String[] strArray26 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", 30, (int) (short) 1, diagnosticType25, strArray26);
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        compilerOptions29.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions29.checkRequires;
        compilerOptions28.checkGlobalNamesLevel = checkLevel33;
        compilerOptions28.removeUnusedPrototypeProperties = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray41 = compilerOptions37.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions37.checkProvides;
        compilerOptions28.checkUnreachableCode = checkLevel42;
        com.google.javascript.jscomp.MessageFormatter messageFormatter44 = null;
        java.lang.String str45 = jSError27.format(checkLevel42, messageFormatter44);
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel50 = diagnosticType49.defaultLevel;
        java.lang.String[] strArray51 = null;
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", (int) (byte) -1, 0, diagnosticType49, strArray51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList58 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList58, nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList58);
        boolean boolean61 = node60.isParamList();
        boolean boolean62 = node60.isNull();
        com.google.javascript.rhino.jstype.JSType jSType63 = node60.getJSType();
        com.google.javascript.rhino.Node node64 = node60.getLastSibling();
        com.google.javascript.rhino.Node node65 = node60.getParent();
        boolean boolean66 = node60.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray73 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node60, diagnosticType67, strArray73);
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make(diagnosticType55, strArray73);
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 40, (int) (byte) -1, checkLevel42, diagnosticType49, strArray73);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray41);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertTrue("'" + checkLevel50 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel50.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(jSError75);
        org.junit.Assert.assertNotNull(jSError76);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        compilerOptions0.disambiguateProperties = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy7 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy7 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy7.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        com.google.javascript.rhino.Node node10 = null;
        int int11 = node9.getIndexOfChild(node10);
        boolean boolean12 = node9.isUnscopedQualifiedName();
        boolean boolean13 = node9.isString();
        boolean boolean14 = node9.isQuotedString();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.toString();
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput3.getAst();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(sourceAst6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        com.google.javascript.jscomp.ErrorManager errorManager41 = compiler1.getErrorManager();
        java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap42 = compiler1.getInputsById();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput44 = compiler1.newExternInput("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(errorManager41);
        org.junit.Assert.assertNotNull(inputIdMap42);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setCheckControlStructures(true);
        boolean boolean8 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        boolean boolean5 = node3.isHook();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node node2 = node0.getLastChild();
        boolean boolean3 = node0.isWith();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        java.util.Set<java.lang.String> strSet6 = node4.getDirectives();
        boolean boolean7 = node4.isWhile();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.newNode(node4, nodeArray8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.comma(node0, node9);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNew();
        node3.setSourceEncodedPosition(83);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        boolean boolean4 = compilerOptions2.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions2.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions2.sourceMapLocationMappings;
        compilerOptions2.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        compilerOptions2.reportMissingOverride = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.generatePseudoNames;
        compilerOptions13.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions13.checkRequires;
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        compilerOptions13.setIdGenerators((java.util.Set<java.lang.String>) strSet22);
        compilerOptions11.setStripTypes((java.util.Set<java.lang.String>) strSet22);
        compilerOptions11.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat28 = compilerOptions11.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy29 = compilerOptions11.propertyRenaming;
        compilerOptions2.propertyRenaming = propertyRenamingPolicy29;
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean32 = compilerOptions31.generatePseudoNames;
        compilerOptions31.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions31.checkRequires;
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet40 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet40, strArray39);
        compilerOptions31.setIdGenerators((java.util.Set<java.lang.String>) strSet40);
        compilerOptions2.stripTypePrefixes = strSet40;
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet40);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(errorFormat28);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy29 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy29.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        java.util.Map<java.lang.String, java.lang.Object> strMap7 = null;
        compilerOptions0.setDefineReplacements(strMap7);
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.setAliasKeywords(true);
        compilerOptions0.setInlineGetters(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        int int22 = node20.getIntProp(100);
        com.google.javascript.rhino.Node node23 = node16.useSourceInfoIfMissingFromForTree(node20);
        java.lang.String str24 = node20.toString();
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.var(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PARAM_LIST" + "'", str24.equals("PARAM_LIST"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        compilerOptions9.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions9.checkRequires;
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions9.setIdGenerators((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet18);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy22 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy22;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy22.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.aggressiveVarCheck;
        boolean boolean15 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.Object obj6 = node4.getProp(0);
        boolean boolean7 = node4.isSyntheticBlock();
        boolean boolean8 = node4.isFalse();
        boolean boolean9 = node4.isLabel();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.voidNode(node13);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList17);
        boolean boolean20 = node19.isParamList();
        boolean boolean21 = node19.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile22 = node19.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId23 = null;
        node19.setInputId(inputId23);
        boolean boolean25 = closureCodingConvention15.isOptionalParameter(node19);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel26 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList29 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList29, nodeArray28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList29);
        boolean boolean32 = node31.isParamList();
        boolean boolean33 = node31.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile34 = node31.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId35 = null;
        node31.setInputId(inputId35);
        boolean boolean37 = closureCodingConvention27.isOptionalParameter(node31);
        boolean boolean38 = detailLevel26.apply(node31);
        boolean boolean39 = closureCodingConvention15.isPrototypeAlias(node31);
        com.google.javascript.rhino.Node node40 = node13.clonePropsFrom(node31);
        boolean boolean41 = node40.isDelProp();
        java.lang.String str42 = closureCodingConvention0.extractClassNameIfRequire(node4, node40);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList44 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList44, nodeArray43);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList44);
        java.lang.Object obj48 = node46.getProp(0);
        boolean boolean49 = node46.isSyntheticBlock();
        com.google.javascript.rhino.Node node50 = node46.getFirstChild();
        boolean boolean51 = closureCodingConvention0.isVarArgsParameter(node50);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(staticSourceFile22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(detailLevel26);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(staticSourceFile34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        compilerOptions29.setRenamePrefix("module$Unknown class name");
        boolean boolean40 = compilerOptions29.aliasExternals;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        com.google.javascript.rhino.Node node8 = node2.srcref(node6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node9);
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        boolean boolean15 = node14.isTry();
        java.util.Set<java.lang.String> strSet16 = node14.getDirectives();
        boolean boolean17 = node14.isInstanceOf();
        com.google.javascript.rhino.Node node18 = node9.clonePropsFrom(node14);
        boolean boolean19 = node14.isOptionalArg();
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = node14.getJSDocInfo();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] { node8, node14 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(36, nodeArray21);
        try {
            com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, nodeArray21, 31, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(jSDocInfo20);
        org.junit.Assert.assertNotNull(nodeArray21);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode2 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config4 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode2, false);
        com.google.javascript.jscomp.parsing.Config config6 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode2, false);
        org.junit.Assert.assertTrue("'" + languageMode2 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode2.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config4);
        org.junit.Assert.assertNotNull(config6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setShadowVariables(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        compilerOptions4.setIdGenerators((java.util.Set<java.lang.String>) strSet13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.generatePseudoNames;
        compilerOptions20.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.checkRequires;
        compilerOptions16.checkProvides = checkLevel24;
        compilerOptions4.checkRequires = checkLevel24;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean29 = compilerOptions28.generatePseudoNames;
        boolean boolean30 = compilerOptions28.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions28.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList32 = compilerOptions28.sourceMapLocationMappings;
        compilerOptions28.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        compilerOptions28.reportMissingOverride = checkLevel35;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean38 = compilerOptions37.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean40 = compilerOptions39.generatePseudoNames;
        compilerOptions39.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions39.checkRequires;
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet48 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet48, strArray47);
        compilerOptions39.setIdGenerators((java.util.Set<java.lang.String>) strSet48);
        compilerOptions37.setStripTypes((java.util.Set<java.lang.String>) strSet48);
        compilerOptions37.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat54 = compilerOptions37.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy55 = compilerOptions37.propertyRenaming;
        compilerOptions28.propertyRenaming = propertyRenamingPolicy55;
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList59);
        boolean boolean62 = node61.isParamList();
        boolean boolean63 = node61.isNull();
        com.google.javascript.rhino.jstype.JSType jSType64 = node61.getJSType();
        com.google.javascript.rhino.Node node65 = node61.getLastSibling();
        com.google.javascript.rhino.Node node66 = node61.getParent();
        boolean boolean67 = node61.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray74 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node61, diagnosticType68, strArray74);
        com.google.javascript.jscomp.CheckLevel checkLevel76 = jSError75.level;
        compilerOptions28.aggressiveVarCheck = checkLevel76;
        com.google.javascript.jscomp.DiagnosticType diagnosticType78 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions79.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel82 = compilerOptions79.checkMissingGetCssNameLevel;
        diagnosticType78.level = checkLevel82;
        compilerOptions28.setCheckRequires(checkLevel82);
        compilerOptions0.setCheckUnreachableCode(checkLevel82);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(errorFormat54);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy55 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy55.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(diagnosticType68);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertNotNull(jSError75);
        org.junit.Assert.assertTrue("'" + checkLevel76 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel76.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType78);
        org.junit.Assert.assertTrue("'" + checkLevel82 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel82.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        try {
            int int6 = jSSourceFile2.getLineOffset(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setExternExportsPath("");
        compilerOptions0.setDefineToDoubleLiteral("", (double) 48);
        compilerOptions0.setFoldConstants(true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("module$()", "goog.abstractMethod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$module$()" + "'", str2.equals("module$module$()"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setSpecializeInitialModule(false);
        boolean boolean6 = compilerOptions0.markAsCompiled;
        boolean boolean7 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy4);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray7 = anonymousFunctionNamingPolicy6.getReservedCharacters();
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy6;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        java.util.Set<java.lang.String> strSet12 = node10.getDirectives();
        boolean boolean13 = node10.isWith();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        node4.addChildAfter(node10, node17);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.voidNode(node22);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isParamList();
        boolean boolean30 = node28.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile31 = node28.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId32 = null;
        node28.setInputId(inputId32);
        boolean boolean34 = closureCodingConvention24.isOptionalParameter(node28);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel35 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention36 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList38 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList38, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList38);
        boolean boolean41 = node40.isParamList();
        boolean boolean42 = node40.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile43 = node40.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId44 = null;
        node40.setInputId(inputId44);
        boolean boolean46 = closureCodingConvention36.isOptionalParameter(node40);
        boolean boolean47 = detailLevel35.apply(node40);
        boolean boolean48 = closureCodingConvention24.isPrototypeAlias(node40);
        com.google.javascript.rhino.Node node49 = node22.clonePropsFrom(node40);
        boolean boolean50 = node49.isDelProp();
        com.google.javascript.rhino.Node node51 = node10.copyInformationFromForTree(node49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile53 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node52);
        com.google.javascript.rhino.Node node54 = node52.getLastChild();
        boolean boolean55 = node52.isNoSideEffectsCall();
        boolean boolean56 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node52);
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList58 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList58, nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList58);
        boolean boolean61 = node60.isTry();
        boolean boolean62 = node52.isEquivalentTo(node60);
        com.google.javascript.rhino.Node node63 = node10.copyInformationFrom(node52);
        boolean boolean64 = node10.isDebugger();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(staticSourceFile31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(detailLevel35);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(staticSourceFile43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(staticSourceFile53);
        org.junit.Assert.assertNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("PARAM_LIST");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property PARAM_LIST");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        boolean boolean12 = node11.isTry();
        java.util.Set<java.lang.String> strSet13 = node11.getDirectives();
        boolean boolean14 = node11.isWith();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.getelem(node3, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(strSet13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        compilerOptions9.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions9.checkRequires;
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions9.setIdGenerators((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet18);
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile1 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.rhino.Node node2 = node0.getLastChild();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isTry();
        com.google.javascript.rhino.Node node9 = node3.srcref(node7);
        boolean boolean10 = node9.isThis();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        java.lang.Object obj16 = node14.getProp(0);
        com.google.javascript.rhino.Node node17 = node14.removeChildren();
        node14.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        java.lang.String str25 = node20.checkTreeEquals(node24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = node20.getJSDocInfo();
        com.google.javascript.rhino.Node node27 = node14.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList29 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList29, nodeArray28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList29);
        int int33 = node31.getIntProp(100);
        com.google.javascript.rhino.Node node34 = node27.useSourceInfoIfMissingFromForTree(node31);
        com.google.javascript.rhino.Node node35 = node9.clonePropsFrom(node31);
        try {
            node2.addChildrenToFront(node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(staticSourceFile1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str25.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray8 = compilerOptions4.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions4.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        boolean boolean15 = node14.isParamList();
        boolean boolean16 = node14.isNull();
        com.google.javascript.rhino.jstype.JSType jSType17 = node14.getJSType();
        com.google.javascript.rhino.Node node18 = node14.getLastSibling();
        com.google.javascript.rhino.Node node19 = node14.getParent();
        boolean boolean20 = node14.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node14, diagnosticType21, strArray27);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = jSError28.level;
        int int30 = jSError28.lineNumber;
        loggerErrorManager2.report(checkLevel9, jSError28);
        boolean boolean32 = diagnosticGroup0.matches(jSError28);
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions35.checkMissingGetCssNameLevel;
        diagnosticType34.level = checkLevel38;
        com.google.javascript.jscomp.SourceAst sourceAst40 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(sourceAst40, "", true);
        com.google.javascript.jscomp.JSModule jSModule44 = compilerInput43.getModule();
        com.google.javascript.jscomp.JSModule jSModule45 = null;
        compilerInput43.setModule(jSModule45);
        boolean boolean47 = diagnosticType34.equals((java.lang.Object) compilerInput43);
        boolean boolean48 = diagnosticGroup0.matches(diagnosticType34);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(jSModule44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str11 = jSSourceFile9.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        boolean boolean18 = node17.isParamList();
        boolean boolean19 = node17.isNull();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 1, node17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str25 = jSSourceFile23.getLine((int) '#');
        jSSourceFile23.clearCachedSource();
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str32 = jSSourceFile30.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile30 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean35 = compilerOptions34.generatePseudoNames;
        boolean boolean36 = compilerOptions34.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions34.checkUnreachableCode;
        compilerOptions34.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode40 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions34.setLanguageIn(languageMode40);
        compiler6.init(jSSourceFileArray12, jSSourceFileArray33, compilerOptions34);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker44 = compiler6.tracker;
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode40 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode40.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNull(performanceTracker44);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        java.util.Set<java.lang.String> strSet12 = node10.getDirectives();
        boolean boolean13 = node10.isWith();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        node4.addChildAfter(node10, node17);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.voidNode(node22);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isParamList();
        boolean boolean30 = node28.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile31 = node28.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId32 = null;
        node28.setInputId(inputId32);
        boolean boolean34 = closureCodingConvention24.isOptionalParameter(node28);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel35 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention36 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList38 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList38, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList38);
        boolean boolean41 = node40.isParamList();
        boolean boolean42 = node40.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile43 = node40.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId44 = null;
        node40.setInputId(inputId44);
        boolean boolean46 = closureCodingConvention36.isOptionalParameter(node40);
        boolean boolean47 = detailLevel35.apply(node40);
        boolean boolean48 = closureCodingConvention24.isPrototypeAlias(node40);
        com.google.javascript.rhino.Node node49 = node22.clonePropsFrom(node40);
        boolean boolean50 = node49.isDelProp();
        com.google.javascript.rhino.Node node51 = node10.copyInformationFromForTree(node49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile53 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node52);
        com.google.javascript.rhino.Node node54 = node52.getLastChild();
        boolean boolean55 = node52.isNoSideEffectsCall();
        boolean boolean56 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node52);
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList58 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList58, nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList58);
        boolean boolean61 = node60.isTry();
        boolean boolean62 = node52.isEquivalentTo(node60);
        com.google.javascript.rhino.Node node63 = node10.copyInformationFrom(node52);
        com.google.javascript.rhino.JSDocInfo jSDocInfo64 = node63.getJSDocInfo();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(staticSourceFile31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(detailLevel35);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(staticSourceFile43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(staticSourceFile53);
        org.junit.Assert.assertNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSDocInfo64);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("PARAM_LIST", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.setCustomPasses(customPassExecutionTimeMultimap6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setOptimizeCalls(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions5.checkMissingGetCssNameLevel;
        compilerOptions5.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        compilerOptions11.checkProvides = checkLevel19;
        compilerOptions5.checkGlobalThisLevel = checkLevel19;
        compilerOptions5.setCommonJSModulePathPrefix("()");
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray25 = compilerOptions24.inputPropertyMapSerialized;
        compilerOptions24.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler28 = compilerOptions24.getAliasTransformationHandler();
        java.util.Set<java.lang.String> strSet29 = compilerOptions24.aliasableStrings;
        java.util.Set<java.lang.String> strSet30 = compilerOptions24.aliasableStrings;
        compilerOptions5.setAliasableStrings(strSet30);
        compilerOptions0.setStripNamePrefixes(strSet30);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray25);
        org.junit.Assert.assertNotNull(aliasTransformationHandler28);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNotNull(strSet30);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("module$module$()");
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setDefineToDoubleLiteral("", 10.0d);
        java.lang.Class<?> wildcardClass7 = compilerOptions0.getClass();
        compilerOptions0.setInlineConstantVars(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions12.checkRequires;
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        compilerOptions12.setIdGenerators((java.util.Set<java.lang.String>) strSet21);
        compilerOptions10.setStripTypes((java.util.Set<java.lang.String>) strSet21);
        compilerOptions10.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat27 = compilerOptions10.errorFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions10.checkUnreachableCode;
        compilerOptions0.setCheckUnreachableCode(checkLevel28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(errorFormat27);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.voidNode(node4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isParamList();
        boolean boolean12 = node10.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile13 = node10.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId14 = null;
        node10.setInputId(inputId14);
        boolean boolean16 = closureCodingConvention6.isOptionalParameter(node10);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel17 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention18 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isParamList();
        boolean boolean24 = node22.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile25 = node22.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId26 = null;
        node22.setInputId(inputId26);
        boolean boolean28 = closureCodingConvention18.isOptionalParameter(node22);
        boolean boolean29 = detailLevel17.apply(node22);
        boolean boolean30 = closureCodingConvention6.isPrototypeAlias(node22);
        com.google.javascript.rhino.Node node31 = node4.clonePropsFrom(node22);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention32 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node33 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention32.getDelegateRelationship(node33);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList37 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList37, nodeArray36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList37);
        boolean boolean40 = node39.isParamList();
        boolean boolean41 = node39.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile42 = node39.getStaticSourceFile();
        java.lang.String str43 = closureCodingConvention32.extractClassNameIfRequire(node35, node39);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList45 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList45, nodeArray44);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList45);
        java.lang.Object obj49 = node47.getProp(0);
        boolean boolean50 = node47.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder51 = node47.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList54 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList54, nodeArray53);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList54);
        java.lang.String str57 = node52.checkTreeEquals(node56);
        boolean boolean58 = node56.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList60 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList60, nodeArray59);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList60);
        boolean boolean63 = node62.isTry();
        java.util.Set<java.lang.String> strSet64 = node62.getDirectives();
        boolean boolean65 = node62.isWith();
        com.google.javascript.rhino.Node[] nodeArray66 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList67 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList67, nodeArray66);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList67);
        node56.addChildAfter(node62, node69);
        java.lang.String str71 = closureCodingConvention32.extractClassNameIfRequire(node47, node69);
        com.google.javascript.rhino.Node[] nodeArray72 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList73 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList73, nodeArray72);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList73);
        boolean boolean76 = node75.isTypeOf();
        boolean boolean77 = node75.isNoSideEffectsCall();
        int int78 = node75.getType();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray80 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList81 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList81, nodeArray80);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList81);
        boolean boolean84 = node83.isTry();
        com.google.javascript.rhino.Node node85 = node79.srcref(node83);
        boolean boolean86 = node85.isThis();
        try {
            com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(51, node22, node69, node75, node85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(staticSourceFile13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(detailLevel17);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(staticSourceFile25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(staticSourceFile42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str57.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(strSet64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(nodeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(nodeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 83 + "'", int78 == 83);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(nodeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNew();
        int int10 = node7.getChildCount();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isParamList();
        boolean boolean24 = node22.isNull();
        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
        com.google.javascript.rhino.Node node27 = node22.getParent();
        boolean boolean28 = node22.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node22, diagnosticType29, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node7, checkLevel11, diagnosticType14, strArray35);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel39 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention40 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList42 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList42, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList42);
        boolean boolean45 = node44.isParamList();
        boolean boolean46 = node44.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile47 = node44.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId48 = null;
        node44.setInputId(inputId48);
        boolean boolean50 = closureCodingConvention40.isOptionalParameter(node44);
        boolean boolean51 = detailLevel39.apply(node44);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList53 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList53, nodeArray52);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList53);
        boolean boolean56 = node55.isTry();
        java.util.Set<java.lang.String> strSet57 = node55.getDirectives();
        boolean boolean58 = node55.isWhile();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.newNode(node55, nodeArray59);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.paramList(nodeArray59);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.newNode(node44, nodeArray59);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.objectlit(nodeArray59);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.block(nodeArray59);
        nodeTraversal2.traverseRoots(nodeArray59);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(detailLevel39);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(staticSourceFile47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(strSet57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        com.google.javascript.jscomp.ErrorManager errorManager41 = compiler1.getErrorManager();
        java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap42 = compiler1.getInputsById();
        com.google.javascript.jscomp.JSModule jSModule43 = null;
        try {
            java.lang.String str44 = compiler1.toSource(jSModule43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(errorManager41);
        org.junit.Assert.assertNotNull(inputIdMap42);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setCheckControlStructures(true);
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        com.google.javascript.jscomp.ErrorManager errorManager41 = compiler1.getErrorManager();
        com.google.javascript.jscomp.NodeTraversal.Callback callback42 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal43 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback42);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(errorManager41);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray2 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray2);
        boolean boolean4 = composeWarningsGuard1.disables(diagnosticGroup3);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroupArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        compilerOptions1.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkRequires;
        compilerOptions0.checkGlobalNamesLevel = checkLevel5;
        compilerOptions0.setLineBreak(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard warningsGuard13 = null;
        try {
            compilerOptions0.addWarningsGuard(warningsGuard13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean3 = diagnosticGroup0.matches(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        loggerErrorManager6.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray12 = compilerOptions8.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        boolean boolean19 = node18.isParamList();
        boolean boolean20 = node18.isNull();
        com.google.javascript.rhino.jstype.JSType jSType21 = node18.getJSType();
        com.google.javascript.rhino.Node node22 = node18.getLastSibling();
        com.google.javascript.rhino.Node node23 = node18.getParent();
        boolean boolean24 = node18.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node18, diagnosticType25, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = jSError32.level;
        int int34 = jSError32.lineNumber;
        loggerErrorManager6.report(checkLevel13, jSError32);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.rhino.InputId inputId37 = compilerInput3.getInputId();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(byteArray12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(inputId37);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(logger20);
        com.google.javascript.jscomp.JSError[] jSErrorArray22 = loggerErrorManager21.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError27 = null;
        loggerErrorManager21.println(checkLevel26, jSError27);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel26;
        compilerOptions0.setGenerateExports(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSErrorArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNew();
        int int10 = node7.getChildCount();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isParamList();
        boolean boolean24 = node22.isNull();
        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
        com.google.javascript.rhino.Node node27 = node22.getParent();
        boolean boolean28 = node22.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node22, diagnosticType29, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node7, checkLevel11, diagnosticType14, strArray35);
        int int39 = nodeTraversal2.getLineNumber();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(logger23);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = loggerErrorManager24.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean27 = compilerOptions26.generatePseudoNames;
        boolean boolean28 = compilerOptions26.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions26.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError30 = null;
        loggerErrorManager24.println(checkLevel29, jSError30);
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel29);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap33 = compilerOptions0.getTweakReplacements();
        compilerOptions0.setRemoveUnusedPrototypePropertiesInExterns(true);
        compilerOptions0.setDefineToStringLiteral("", "DiagnosticGroup<accessControls>");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap33);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.optimizeParameters = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode12 = null;
        compilerOptions0.setTracer(tracerMode12);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean16 = closureCodingConvention14.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isTry();
        com.google.javascript.rhino.Node node24 = node18.srcref(node22);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isTry();
        java.util.Set<java.lang.String> strSet30 = node28.getDirectives();
        boolean boolean31 = node28.isWhile();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.newNode(node28, nodeArray32);
        java.lang.String str34 = closureCodingConvention14.extractClassNameIfRequire(node18, node28);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList36 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList36, nodeArray35);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList36);
        java.lang.Object obj40 = node38.getProp(0);
        com.google.javascript.rhino.Node node41 = node38.removeChildren();
        node38.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList46 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList46, nodeArray45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList46);
        java.lang.String str49 = node44.checkTreeEquals(node48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = node44.getJSDocInfo();
        com.google.javascript.rhino.Node node51 = node38.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList53 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList53, nodeArray52);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList53);
        int int57 = node55.getIntProp(100);
        com.google.javascript.rhino.Node node58 = node51.useSourceInfoIfMissingFromForTree(node55);
        java.lang.String str59 = node55.toString();
        node28.addChildrenToBack(node55);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str49.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "PARAM_LIST" + "'", str59.equals("PARAM_LIST"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = compiler1.languageMode();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(jSTypeRegistry7);
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearSideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setThrows();
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setCrossModuleCodeMotion(true);
        compilerOptions0.setCheckTypes(false);
        compilerOptions0.setTweakToStringLiteral("module$goog.exportProperty", "Not declared as a type name");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap32 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap32;
        compilerOptions0.coalesceVariableNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.setAggressiveVarCheck(checkLevel8);
        compilerOptions0.sourceMapOutputPath = "";
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.generateExports = true;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.jqueryPass = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler5 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setRemoveClosureAsserts(true);
        com.google.javascript.jscomp.MessageBundle messageBundle8 = null;
        compilerOptions0.setMessageBundle(messageBundle8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler5);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        java.util.Set<java.lang.String> strSet5 = node3.getDirectives();
        boolean boolean6 = node3.isWhile();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node3, nodeArray7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList(nodeArray7);
        int int12 = node10.getIntProp(43);
        com.google.javascript.rhino.Node node13 = node10.getNext();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setSyntheticBlockEndMarker("module$()");
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setCollapseProperties(false);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray5 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard6 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray5);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard6);
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions0.getCodingConvention();
        compilerOptions0.enableExternExports(true);
        org.junit.Assert.assertNotNull(warningsGuardArray5);
        org.junit.Assert.assertNull(codingConvention8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        boolean boolean13 = closureCodingConvention0.isSuperClassReference("goog.abstractMethod");
        java.lang.String str14 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.abstractMethod" + "'", str14.equals("goog.abstractMethod"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("goog.exportProperty", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.io.InputStream inputStream5 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile6 = builder0.buildFromInputStream("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", inputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isTry();
        java.util.Set<java.lang.String> strSet18 = node16.getDirectives();
        boolean boolean19 = node16.isWhile();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.newNode(node16, nodeArray20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList(nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.newNode(node5, nodeArray20);
        java.lang.Appendable appendable24 = null;
        try {
            node23.appendStringTree(appendable24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions7.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.collapseAnonymousFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.reportMissingOverride = checkLevel7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.checkRequires;
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions11.setIdGenerators((java.util.Set<java.lang.String>) strSet20);
        compilerOptions9.setStripTypes((java.util.Set<java.lang.String>) strSet20);
        compilerOptions9.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat26 = compilerOptions9.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions9.propertyRenaming;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy27;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        compilerOptions29.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions29.checkRequires;
        java.lang.String[] strArray37 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet38 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet38, strArray37);
        compilerOptions29.setIdGenerators((java.util.Set<java.lang.String>) strSet38);
        compilerOptions0.stripTypePrefixes = strSet38;
        boolean boolean42 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.setAliasAllStrings(false);
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(errorFormat26);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray15 = compilerOptions11.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = null;
        compilerOptions16.setCssRenamingMap(cssRenamingMap21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        compilerOptions23.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions23.checkRequires;
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet32 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet32, strArray31);
        compilerOptions23.setIdGenerators((java.util.Set<java.lang.String>) strSet32);
        compilerOptions16.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet32);
        compilerOptions11.stripNamePrefixes = strSet32;
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet32);
        com.google.javascript.jscomp.CheckLevel checkLevel38 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.checkGlobalNamesLevel = checkLevel38;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setInstrumentationTemplate("InputId: Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(locationMappingList4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.generatePseudoNames;
        boolean boolean25 = compilerOptions23.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions23.checkUnreachableCode;
        compilerOptions0.setCheckGlobalThisLevel(checkLevel26);
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap32 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap32;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        boolean boolean12 = node3.isOr();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.not(node3);
        try {
            double double14 = node13.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NOT is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        try {
            boolean boolean9 = jSModuleGraph3.dependsOn(jSModule7, jSModule8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        compilerOptions29.setRenamePrefix("module$Unknown class name");
        java.util.logging.Logger logger40 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager41 = new com.google.javascript.jscomp.LoggerErrorManager(logger40);
        com.google.javascript.jscomp.JSError[] jSErrorArray42 = loggerErrorManager41.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean44 = compilerOptions43.generatePseudoNames;
        boolean boolean45 = compilerOptions43.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions43.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError47 = null;
        loggerErrorManager41.println(checkLevel46, jSError47);
        compilerOptions29.setCheckMissingGetCssNameLevel(checkLevel46);
        compilerOptions29.devirtualizePrototypeMethods = false;
        compilerOptions29.setAliasExternals(true);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(jSErrorArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNew();
        int int10 = node7.getChildCount();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isParamList();
        boolean boolean24 = node22.isNull();
        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
        com.google.javascript.rhino.Node node27 = node22.getParent();
        boolean boolean28 = node22.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node22, diagnosticType29, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node7, checkLevel11, diagnosticType14, strArray35);
        try {
            com.google.javascript.jscomp.JSModule jSModule39 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType15 = null;
        closureCodingConvention0.applySubclassRelationship(functionType13, functionType14, subclassType15);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.hasMoreThanOneChild();
        com.google.javascript.jscomp.CodingConvention.Bind bind22 = closureCodingConvention0.describeFunctionBind(node20);
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(bind22);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        java.lang.String str6 = jSSourceFile2.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setMarkNoSideEffectCalls(true);
        compilerOptions0.checkSymbols = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setCheckControlStructures(true);
        compilerOptions0.closurePass = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.generatePseudoNames;
        boolean boolean5 = compilerOptions3.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions3.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError7 = null;
        loggerErrorManager1.println(checkLevel6, jSError7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        boolean boolean11 = compilerOptions9.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions9.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList13 = compilerOptions9.sourceMapLocationMappings;
        compilerOptions9.setReportPath("Unknown class name");
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        compilerOptions9.reportMissingOverride = checkLevel16;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.generatePseudoNames;
        compilerOptions20.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.checkRequires;
        java.lang.String[] strArray28 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet29 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet29, strArray28);
        compilerOptions20.setIdGenerators((java.util.Set<java.lang.String>) strSet29);
        compilerOptions18.setStripTypes((java.util.Set<java.lang.String>) strSet29);
        compilerOptions18.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat35 = compilerOptions18.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy36 = compilerOptions18.propertyRenaming;
        compilerOptions9.propertyRenaming = propertyRenamingPolicy36;
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList40 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList40, nodeArray39);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList40);
        boolean boolean43 = node42.isParamList();
        boolean boolean44 = node42.isNull();
        com.google.javascript.rhino.jstype.JSType jSType45 = node42.getJSType();
        com.google.javascript.rhino.Node node46 = node42.getLastSibling();
        com.google.javascript.rhino.Node node47 = node42.getParent();
        boolean boolean48 = node42.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray55 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node42, diagnosticType49, strArray55);
        com.google.javascript.jscomp.CheckLevel checkLevel57 = jSError56.level;
        compilerOptions9.aggressiveVarCheck = checkLevel57;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel63 = compilerOptions60.checkMissingGetCssNameLevel;
        diagnosticType59.level = checkLevel63;
        compilerOptions9.setCheckRequires(checkLevel63);
        java.util.logging.Logger logger66 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager67 = new com.google.javascript.jscomp.LoggerErrorManager(logger66);
        com.google.javascript.jscomp.CheckLevel checkLevel68 = null;
        com.google.javascript.rhino.Node[] nodeArray70 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList71 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList71, nodeArray70);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList71);
        boolean boolean74 = node73.isParamList();
        boolean boolean75 = node73.isNull();
        com.google.javascript.rhino.jstype.JSType jSType76 = node73.getJSType();
        com.google.javascript.rhino.Node node77 = node73.getLastSibling();
        com.google.javascript.rhino.Node node78 = node73.getParent();
        boolean boolean79 = node73.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray86 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError87 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node73, diagnosticType80, strArray86);
        com.google.javascript.jscomp.DiagnosticType diagnosticType88 = jSError87.getType();
        loggerErrorManager67.report(checkLevel68, jSError87);
        loggerErrorManager1.report(checkLevel63, jSError87);
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(errorFormat35);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy36 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy36.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertTrue("'" + checkLevel63 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel63.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertNotNull(jSError87);
        org.junit.Assert.assertNotNull(diagnosticType88);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback38);
        boolean boolean40 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.ErrorManager errorManager41 = compiler1.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler(errorManager41);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(errorManager41);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile8 = node5.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId9 = null;
        node5.setInputId(inputId9);
        boolean boolean11 = closureCodingConvention1.isOptionalParameter(node5);
        boolean boolean12 = detailLevel0.apply(node5);
        boolean boolean13 = node5.isFalse();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(staticSourceFile8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = node0.getJSDocInfo();
        node0.setSourceEncodedPosition((int) (byte) 0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean32 = closureCodingConvention0.isPrototypeAlias(node31);
        java.lang.String str33 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile35 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node34);
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList37 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList37, nodeArray36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList37);
        boolean boolean40 = node39.isTry();
        java.util.Set<java.lang.String> strSet41 = node39.getDirectives();
        boolean boolean42 = node39.isInstanceOf();
        com.google.javascript.rhino.Node node43 = node34.clonePropsFrom(node39);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.abstractMethod" + "'", str33.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(staticSourceFile35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(strSet41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setCrossModuleCodeMotion(true);
        boolean boolean6 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node node3 = node1.getLastChild();
        boolean boolean4 = node1.isNoSideEffectsCall();
        boolean boolean5 = node1.isString();
        boolean boolean6 = node1.isSwitch();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean8 = node1.isGetterDef();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.setAggressiveVarCheck(checkLevel8);
        compilerOptions0.sourceMapOutputPath = "";
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions12.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions12.setCssRenamingMap(cssRenamingMap17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.generatePseudoNames;
        compilerOptions19.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.checkRequires;
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet28 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet28, strArray27);
        compilerOptions19.setIdGenerators((java.util.Set<java.lang.String>) strSet28);
        compilerOptions12.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet28);
        java.util.logging.Logger logger32 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager33 = new com.google.javascript.jscomp.LoggerErrorManager(logger32);
        com.google.javascript.jscomp.JSError[] jSErrorArray34 = loggerErrorManager33.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean36 = compilerOptions35.generatePseudoNames;
        boolean boolean37 = compilerOptions35.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions35.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError39 = null;
        loggerErrorManager33.println(checkLevel38, jSError39);
        compilerOptions12.checkMissingGetCssNameLevel = checkLevel38;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel38);
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig43 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.setRecordFunctionInformation(false);
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSErrorArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        java.lang.String[] strArray5 = new java.lang.String[] { "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet6);
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean10 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        boolean boolean4 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.Node node9 = node4.getParent();
        boolean boolean10 = node4.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node4, diagnosticType11, strArray17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.generatePseudoNames;
        compilerOptions21.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions21.checkRequires;
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        compilerOptions21.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        compilerOptions19.setStripTypes((java.util.Set<java.lang.String>) strSet30);
        compilerOptions19.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat36 = compilerOptions19.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy37 = compilerOptions19.propertyRenaming;
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticType38.defaultLevel;
        compilerOptions19.checkProvides = checkLevel39;
        diagnosticType11.level = checkLevel39;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = diagnosticType11.level;
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(errorFormat36);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy37 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy37.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setCollapseProperties(false);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray5 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard6 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray5);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard6);
        compilerOptions0.setCheckControlStructures(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.generatePseudoNames;
        compilerOptions10.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.generatePseudoNames;
        compilerOptions14.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions14.checkRequires;
        compilerOptions10.checkProvides = checkLevel18;
        compilerOptions10.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        boolean boolean22 = compilerOptions10.removeUnusedVars;
        compilerOptions10.locale = "()";
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions10.brokenClosureRequiresLevel;
        compilerOptions0.checkProvides = checkLevel25;
        java.lang.String str27 = compilerOptions0.locale;
        org.junit.Assert.assertNotNull(warningsGuardArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        boolean boolean7 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray9 = compilerOptions8.inputPropertyMapSerialized;
        compilerOptions8.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        compilerOptions12.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions12.checkRequires;
        compilerOptions8.setAggressiveVarCheck(checkLevel16);
        compilerOptions8.sourceMapOutputPath = "";
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.generatePseudoNames;
        compilerOptions20.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap25 = null;
        compilerOptions20.setCssRenamingMap(cssRenamingMap25);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean28 = compilerOptions27.generatePseudoNames;
        compilerOptions27.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions27.checkRequires;
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet36 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet36, strArray35);
        compilerOptions27.setIdGenerators((java.util.Set<java.lang.String>) strSet36);
        compilerOptions20.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet36);
        java.util.logging.Logger logger40 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager41 = new com.google.javascript.jscomp.LoggerErrorManager(logger40);
        com.google.javascript.jscomp.JSError[] jSErrorArray42 = loggerErrorManager41.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean44 = compilerOptions43.generatePseudoNames;
        boolean boolean45 = compilerOptions43.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions43.checkUnreachableCode;
        com.google.javascript.jscomp.JSError jSError47 = null;
        loggerErrorManager41.println(checkLevel46, jSError47);
        compilerOptions20.checkMissingGetCssNameLevel = checkLevel46;
        compilerOptions8.setBrokenClosureRequiresLevel(checkLevel46);
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig51 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions8);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig51);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(jSErrorArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        boolean boolean6 = node3.isSyntheticBlock();
        boolean boolean7 = node3.isFalse();
        boolean boolean8 = node3.isLabel();
        boolean boolean9 = node3.isIf();
        boolean boolean10 = node3.isRegExp();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "Unknown class name";
        compilerOptions0.setDisambiguateProperties(false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler1, callback2);
        java.lang.String str4 = nodeTraversal3.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        boolean boolean9 = node8.isParamList();
        boolean boolean10 = node8.isNew();
        int int11 = node8.getChildCount();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isParamList();
        boolean boolean25 = node23.isNull();
        com.google.javascript.rhino.jstype.JSType jSType26 = node23.getJSType();
        com.google.javascript.rhino.Node node27 = node23.getLastSibling();
        com.google.javascript.rhino.Node node28 = node23.getParent();
        boolean boolean29 = node23.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray36 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node23, diagnosticType30, strArray36);
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType18, strArray36);
        com.google.javascript.jscomp.JSError jSError39 = nodeTraversal3.makeError(node8, checkLevel12, diagnosticType15, strArray36);
        try {
            com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.propdef(node0, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode6 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions0.setLanguageIn(languageMode6);
        boolean boolean8 = compilerOptions0.optimizeReturns;
        boolean boolean9 = compilerOptions0.convertToDottedProperties;
        boolean boolean10 = compilerOptions0.removeDeadCode;
        compilerOptions0.checkControlStructures = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode6.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback38);
        boolean boolean40 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState41 = compiler1.getState();
        boolean boolean42 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList44 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList44, nodeArray43);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList44);
        boolean boolean47 = node46.isParamList();
        boolean boolean48 = node46.isScript();
        com.google.javascript.rhino.Node node49 = node46.getFirstChild();
        com.google.javascript.jscomp.NodeTraversal.Callback callback50 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node46, callback50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(intermediateState41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(node49);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setAssumeStrictThis(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("hi!", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1, node5);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node10 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = closureCodingConvention9.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        java.lang.String str20 = closureCodingConvention9.extractClassNameIfRequire(node12, node16);
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        boolean boolean25 = node24.isParamList();
        boolean boolean26 = node24.isNull();
        com.google.javascript.rhino.jstype.JSType jSType27 = node24.getJSType();
        node16.addChildrenToBack(node24);
        java.lang.String str29 = closureCodingConvention0.extractClassNameIfProvide(node5, node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList32 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList32, nodeArray31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList32);
        boolean boolean35 = node34.isTry();
        com.google.javascript.rhino.Node node36 = node30.srcref(node34);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel37 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention38 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList40 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList40, nodeArray39);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList40);
        boolean boolean43 = node42.isParamList();
        boolean boolean44 = node42.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile45 = node42.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId46 = null;
        node42.setInputId(inputId46);
        boolean boolean48 = closureCodingConvention38.isOptionalParameter(node42);
        boolean boolean49 = detailLevel37.apply(node42);
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList51 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList51, nodeArray50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList51);
        boolean boolean54 = node53.isTry();
        java.util.Set<java.lang.String> strSet55 = node53.getDirectives();
        boolean boolean56 = node53.isWhile();
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.newNode(node53, nodeArray57);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.paramList(nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.newNode(node42, nodeArray57);
        java.lang.String str61 = closureCodingConvention0.extractClassNameIfProvide(node34, node42);
        com.google.javascript.rhino.Node node62 = node42.getParent();
        com.google.javascript.jscomp.SourceFile.Generator generator64 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator64);
        node42.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile65);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(detailLevel37);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(staticSourceFile45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(strSet55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        java.util.Set<java.lang.String> strSet12 = node10.getDirectives();
        boolean boolean13 = node10.isWith();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        node4.addChildAfter(node10, node17);
        boolean boolean19 = node4.isDebugger();
        java.lang.String str23 = node4.toString(false, false, true);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = node4.siblings();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PARAM_LIST" + "'", str23.equals("PARAM_LIST"));
        org.junit.Assert.assertNotNull(nodeIterable24);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        compiler1.rebuildInputsFromModules();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter42 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str49 = jSSourceFile47.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile47 };
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList53 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList53, nodeArray52);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList53);
        boolean boolean56 = node55.isParamList();
        boolean boolean57 = node55.isNull();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) 1, node55);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str63 = jSSourceFile61.getLine((int) '#');
        jSSourceFile61.clearCachedSource();
        node55.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile61);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str70 = jSSourceFile68.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray71 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile61, jSSourceFile68 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean73 = compilerOptions72.generatePseudoNames;
        boolean boolean74 = compilerOptions72.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions72.checkUnreachableCode;
        compilerOptions72.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode78 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions72.setLanguageIn(languageMode78);
        compiler44.init(jSSourceFileArray50, jSSourceFileArray71, compilerOptions72);
        com.google.javascript.jscomp.NodeTraversal.Callback callback81 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal82 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler44, callback81);
        boolean boolean83 = compiler44.acceptEcmaScript5();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState84 = compiler44.getState();
        compiler1.setState(intermediateState84);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(jSSourceFile68);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(jSSourceFileArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode78 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode78.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(intermediateState84);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = null;
        compilerOptions0.setWarningsGuard(composeWarningsGuard10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.generatePseudoNames;
        compilerOptions14.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions14.checkRequires;
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet23 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet23, strArray22);
        compilerOptions14.setIdGenerators((java.util.Set<java.lang.String>) strSet23);
        compilerOptions12.setStripTypes((java.util.Set<java.lang.String>) strSet23);
        compilerOptions12.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat29 = compilerOptions12.errorFormat;
        compilerOptions0.setErrorFormat(errorFormat29);
        compilerOptions0.setProtectHiddenSideEffects(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean34 = compilerOptions33.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean36 = compilerOptions35.generatePseudoNames;
        compilerOptions35.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions35.checkRequires;
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet44 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet44, strArray43);
        compilerOptions35.setIdGenerators((java.util.Set<java.lang.String>) strSet44);
        compilerOptions33.setStripTypes((java.util.Set<java.lang.String>) strSet44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean50 = compilerOptions49.generatePseudoNames;
        compilerOptions49.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions49.checkRequires;
        compilerOptions48.checkGlobalNamesLevel = checkLevel53;
        compilerOptions33.checkUnreachableCode = checkLevel53;
        com.google.javascript.jscomp.CompilerOptions compilerOptions56 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean57 = compilerOptions56.generatePseudoNames;
        boolean boolean58 = compilerOptions56.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions56.checkUnreachableCode;
        compilerOptions33.setCheckGlobalThisLevel(checkLevel59);
        compilerOptions33.coalesceVariableNames = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy63 = compilerOptions33.variableRenaming;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy63);
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(errorFormat29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy63 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy63.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        java.util.Set<java.lang.String> strSet6 = node4.getDirectives();
        boolean boolean7 = node4.isInstanceOf();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.empty();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        int int14 = node12.getIntProp(100);
        com.google.javascript.rhino.InputId inputId15 = node12.getInputId();
        int int16 = node12.getCharno();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        java.lang.Object obj22 = node20.getProp(0);
        com.google.javascript.rhino.Node node23 = node20.removeChildren();
        node20.setWasEmptyNode(false);
        boolean boolean26 = node20.isHook();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(8, node4, node8, node12, node20, (int) (byte) -1, 44);
        node12.setVarArgs(false);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(inputId15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        boolean boolean12 = compilerOptions0.removeUnusedVars;
        compilerOptions0.locale = "()";
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.brokenClosureRequiresLevel;
        java.lang.String str16 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "()" + "'", str16.equals("()"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback38);
        boolean boolean40 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState41 = compiler1.getState();
        com.google.javascript.jscomp.JSModule jSModule42 = null;
        try {
            java.lang.String[] strArray43 = compiler1.toSourceArray(jSModule42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(intermediateState41);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromInputStream("module$goog.exportProperty", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray4 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.generatePseudoNames;
        compilerOptions5.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.generatePseudoNames;
        compilerOptions9.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions9.checkRequires;
        compilerOptions5.checkProvides = checkLevel13;
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = null;
        compilerOptions5.setWarningsGuard(composeWarningsGuard15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.generatePseudoNames;
        compilerOptions19.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.checkRequires;
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet28 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet28, strArray27);
        compilerOptions19.setIdGenerators((java.util.Set<java.lang.String>) strSet28);
        compilerOptions17.setStripTypes((java.util.Set<java.lang.String>) strSet28);
        compilerOptions17.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat34 = compilerOptions17.errorFormat;
        compilerOptions5.setErrorFormat(errorFormat34);
        compilerOptions5.setProtectHiddenSideEffects(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean39 = compilerOptions38.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean41 = compilerOptions40.generatePseudoNames;
        compilerOptions40.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions40.checkRequires;
        java.lang.String[] strArray48 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet49 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet49, strArray48);
        compilerOptions40.setIdGenerators((java.util.Set<java.lang.String>) strSet49);
        compilerOptions38.setStripTypes((java.util.Set<java.lang.String>) strSet49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean55 = compilerOptions54.generatePseudoNames;
        compilerOptions54.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        compilerOptions53.checkGlobalNamesLevel = checkLevel58;
        compilerOptions38.checkUnreachableCode = checkLevel58;
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean62 = compilerOptions61.generatePseudoNames;
        boolean boolean63 = compilerOptions61.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel64 = compilerOptions61.checkUnreachableCode;
        compilerOptions38.setCheckGlobalThisLevel(checkLevel64);
        compilerOptions38.coalesceVariableNames = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy68 = compilerOptions38.variableRenaming;
        compilerOptions5.setVariableRenaming(variableRenamingPolicy68);
        compilerOptions0.setVariableRenaming(variableRenamingPolicy68);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean72 = compilerOptions71.generatePseudoNames;
        compilerOptions71.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions71.checkRequires;
        java.lang.String[] strArray79 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet80 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet80, strArray79);
        compilerOptions71.setIdGenerators((java.util.Set<java.lang.String>) strSet80);
        com.google.javascript.jscomp.CompilerOptions compilerOptions83 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean84 = compilerOptions83.generatePseudoNames;
        compilerOptions83.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions87 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean88 = compilerOptions87.generatePseudoNames;
        compilerOptions87.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel91 = compilerOptions87.checkRequires;
        compilerOptions83.checkProvides = checkLevel91;
        compilerOptions71.checkRequires = checkLevel91;
        java.lang.String str94 = compilerOptions71.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode95 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        compilerOptions71.setTracer(tracerMode95);
        compilerOptions0.setTracer(tracerMode95);
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(errorFormat34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy68 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy68.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + checkLevel91 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel91.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertTrue("'" + tracerMode95 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode95.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isTrue();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.generatePseudoNames;
        compilerOptions6.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkRequires;
        compilerOptions2.checkProvides = checkLevel10;
        compilerOptions2.optimizeParameters = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions2.setTracer(tracerMode14);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean18 = closureCodingConvention16.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions2.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList22);
        boolean boolean25 = node24.isTry();
        com.google.javascript.rhino.Node node26 = node20.srcref(node24);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean31 = node30.isTry();
        java.util.Set<java.lang.String> strSet32 = node30.getDirectives();
        boolean boolean33 = node30.isWhile();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.newNode(node30, nodeArray34);
        java.lang.String str36 = closureCodingConvention16.extractClassNameIfRequire(node20, node30);
        try {
            com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.regexp(node0, node30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(strSet32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str36);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "PARAM_LIST");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        boolean boolean8 = node7.isLabelName();
        node7.putBooleanProp(40, false);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        compilerOptions0.setOptimizeArgumentsArray(true);
        compilerOptions0.setAliasStringsBlacklist("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.setProcessCommonJSModules(false);
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.aggressiveVarCheck;
        byte[] byteArray15 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.generatePseudoNames;
        compilerOptions20.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.checkRequires;
        compilerOptions16.checkProvides = checkLevel24;
        compilerOptions16.optimizeParameters = true;
        compilerOptions16.removeUnusedPrototypeProperties = true;
        java.lang.String str30 = compilerOptions16.aliasStringsBlacklist;
        java.lang.String str31 = compilerOptions16.renamePrefix;
        com.google.javascript.jscomp.CompilerOptions.Reach reach32 = com.google.javascript.jscomp.CompilerOptions.Reach.NONE;
        compilerOptions16.setInlineVariables(reach32);
        compilerOptions0.setRemoveUnusedVariable(reach32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + reach32 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.NONE + "'", reach32.equals(com.google.javascript.jscomp.CompilerOptions.Reach.NONE));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile2 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList4);
        boolean boolean7 = node6.isTry();
        java.util.Set<java.lang.String> strSet8 = node6.getDirectives();
        boolean boolean9 = node6.isInstanceOf();
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean13 = diagnosticGroup11.matches(diagnosticType12);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node10, diagnosticType12, strArray15);
        java.util.Set<java.lang.String> strSet17 = node10.getDirectives();
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.returnNode(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile2);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNull(strSet17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.optimizeParameters = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode12 = null;
        compilerOptions0.setTracer(tracerMode12);
        compilerOptions0.prettyPrint = true;
        compilerOptions0.setOptimizeCalls(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setCollapseProperties(false);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray5 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard6 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray5);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard6);
        compilerOptions0.coalesceVariableNames = false;
        org.junit.Assert.assertNotNull(warningsGuardArray5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1, node5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str13 = jSSourceFile11.getLine((int) '#');
        jSSourceFile11.clearCachedSource();
        node5.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile11);
        boolean boolean16 = diagnosticType0.equals((java.lang.Object) node5);
        boolean boolean17 = node5.wasEmptyNode();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        java.util.Set<java.lang.String> strSet12 = node10.getDirectives();
        boolean boolean13 = node10.isWith();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList15 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList15, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList15);
        node4.addChildAfter(node10, node17);
        com.google.javascript.rhino.Node node19 = node4.getLastChild();
        boolean boolean20 = node4.isNumber();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.recordFunctionInformation = true;
        compilerOptions0.closurePass = true;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str10 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray5 = compilerOptions4.inputPropertyMapSerialized;
        compilerOptions4.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions4.sourceMapLocationMappings;
        compilerOptions0.sourceMapLocationMappings = locationMappingList8;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.inputDelimiter = "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n";
        compilerOptions0.setExportTestFunctions(true);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertNotNull(locationMappingList8);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions0.setTracer(tracerMode14);
        compilerOptions0.setExportTestFunctions(false);
        compilerOptions0.setExportTestFunctions(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile6 = node4.getStaticSourceFile();
        boolean boolean7 = node4.isNot();
        boolean boolean8 = node0.isEquivalentToTyped(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        boolean boolean15 = node14.isParamList();
        boolean boolean16 = node14.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile17 = node14.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId18 = null;
        node14.setInputId(inputId18);
        boolean boolean20 = closureCodingConvention10.isOptionalParameter(node14);
        boolean boolean21 = detailLevel9.apply(node14);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList23 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList23, nodeArray22);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList23);
        boolean boolean26 = node25.isTry();
        java.util.Set<java.lang.String> strSet27 = node25.getDirectives();
        boolean boolean28 = node25.isWhile();
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.newNode(node25, nodeArray29);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList(nodeArray29);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.newNode(node14, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.call(node0, nodeArray29);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(staticSourceFile6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(staticSourceFile17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(strSet27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType6 = null;
        closureCodingConvention0.applySubclassRelationship(functionType4, functionType5, subclassType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        java.lang.String str13 = node8.checkTreeEquals(node12);
        boolean boolean14 = node12.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList16);
        java.lang.Object obj20 = node18.getProp(0);
        java.lang.String str21 = node18.getQualifiedName();
        node12.addChildrenToFront(node18);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node24 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = closureCodingConvention23.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean31 = node30.isParamList();
        boolean boolean32 = node30.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile33 = node30.getStaticSourceFile();
        java.lang.String str34 = closureCodingConvention23.extractClassNameIfRequire(node26, node30);
        node12.addChildrenToBack(node26);
        try {
            boolean boolean36 = closureCodingConvention0.isPropertyTestFunction(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str13.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(delegateRelationship25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(staticSourceFile33);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker38 = null;
        compiler1.tracker = performanceTracker38;
        java.util.logging.Logger logger40 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager41 = new com.google.javascript.jscomp.LoggerErrorManager(logger40);
        loggerErrorManager41.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray43 = loggerErrorManager41.getErrors();
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager41);
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean46 = compilerOptions45.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean48 = compilerOptions47.generatePseudoNames;
        compilerOptions47.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions47.checkRequires;
        java.lang.String[] strArray55 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet56 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet56, strArray55);
        compilerOptions47.setIdGenerators((java.util.Set<java.lang.String>) strSet56);
        compilerOptions45.setStripTypes((java.util.Set<java.lang.String>) strSet56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean62 = compilerOptions61.generatePseudoNames;
        compilerOptions61.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel65 = compilerOptions61.checkRequires;
        compilerOptions60.checkGlobalNamesLevel = checkLevel65;
        compilerOptions45.checkUnreachableCode = checkLevel65;
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean69 = compilerOptions68.generatePseudoNames;
        boolean boolean70 = compilerOptions68.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel71 = compilerOptions68.checkUnreachableCode;
        compilerOptions45.setCheckGlobalThisLevel(checkLevel71);
        com.google.javascript.jscomp.CompilerOptions compilerOptions73 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean74 = compilerOptions73.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions75 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean76 = compilerOptions75.generatePseudoNames;
        compilerOptions75.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel79 = compilerOptions75.checkRequires;
        java.lang.String[] strArray83 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet84 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean85 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet84, strArray83);
        compilerOptions75.setIdGenerators((java.util.Set<java.lang.String>) strSet84);
        compilerOptions73.setStripTypes((java.util.Set<java.lang.String>) strSet84);
        compilerOptions73.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat90 = compilerOptions73.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy91 = compilerOptions73.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel92 = compilerOptions73.checkRequires;
        compilerOptions45.checkMissingReturn = checkLevel92;
        com.google.javascript.jscomp.JSError jSError94 = null;
        try {
            loggerErrorManager41.report(checkLevel92, jSError94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(jSErrorArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + checkLevel71 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel71.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + checkLevel79 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel79.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(errorFormat90);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy91 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy91.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel92 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel92.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        compilerOptions0.setSkipAllPasses(false);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap5 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setDefineToDoubleLiteral("", 1.0d);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray13 = compilerOptions9.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.generatePseudoNames;
        compilerOptions14.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions14.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap19 = null;
        compilerOptions14.setCssRenamingMap(cssRenamingMap19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.generatePseudoNames;
        compilerOptions21.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions21.checkRequires;
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        compilerOptions21.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        compilerOptions14.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet30);
        compilerOptions9.stripNamePrefixes = strSet30;
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertNotNull(strMap5);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode6 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions0.setLanguageIn(languageMode6);
        boolean boolean8 = compilerOptions0.optimizeReturns;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.defaultLevel;
        java.lang.String[] strArray14 = null;
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", (int) (byte) -1, 0, diagnosticType12, strArray14);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = jSError15.level;
        compilerOptions0.aggressiveVarCheck = checkLevel16;
        boolean boolean18 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode6.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node3.siblings();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node3.new FileLevelJsDocBuilder();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertNotNull(nodeIterable6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
        boolean boolean2 = sideEffectFlags0.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.inlineVariables = false;
        boolean boolean8 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = null;
        compilerOptions0.setErrorFormat(errorFormat9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode6 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions0.setLanguageIn(languageMode6);
        boolean boolean8 = compilerOptions0.optimizeReturns;
        boolean boolean9 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.removeUnusedLocalVars = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode6.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback38);
        boolean boolean40 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.ErrorManager errorManager41 = compiler1.getErrorManager();
        compiler1.reportCodeChange();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(errorManager41);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        java.lang.String str6 = node3.getQualifiedName();
        boolean boolean7 = node3.isNumber();
        boolean boolean8 = node3.isSyntheticBlock();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.setOptimizeCalls(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions5.checkMissingGetCssNameLevel;
        compilerOptions5.setIgnoreCajaProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.generatePseudoNames;
        compilerOptions11.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.generatePseudoNames;
        compilerOptions15.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        compilerOptions11.checkProvides = checkLevel19;
        compilerOptions5.checkGlobalThisLevel = checkLevel19;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel19;
        boolean boolean23 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.generateExports = true;
        compilerOptions0.smartNameRemoval = true;
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType15 = null;
        closureCodingConvention0.applySubclassRelationship(functionType13, functionType14, subclassType15);
        boolean boolean18 = closureCodingConvention0.isPrivate("module$Unknown class name");
        boolean boolean20 = closureCodingConvention0.isConstant("");
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str6 = jSSourceFile4.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 1, node12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str20 = jSSourceFile18.getLine((int) '#');
        jSSourceFile18.clearCachedSource();
        node12.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str27 = jSSourceFile25.getLine((int) '#');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile25 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.generatePseudoNames;
        boolean boolean31 = compilerOptions29.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions29.checkUnreachableCode;
        compilerOptions29.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode35 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions29.setLanguageIn(languageMode35);
        compiler1.init(jSSourceFileArray7, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig39 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions38);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig39);
        com.google.javascript.jscomp.JSError[] jSErrorArray41 = compiler1.getWarnings();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode35.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(jSErrorArray41);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        boolean boolean1 = node0.hasChildren();
        node0.setOptionalArg(true);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(30, 49, 31);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.voidNode(node7);
        com.google.javascript.rhino.Node node9 = node0.srcrefTree(node7);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable10 = node9.children();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeIterable10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        boolean boolean6 = node3.isAdd();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile15 = node12.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId16 = null;
        node12.setInputId(inputId16);
        boolean boolean18 = closureCodingConvention8.isOptionalParameter(node12);
        boolean boolean19 = detailLevel7.apply(node12);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isTry();
        java.util.Set<java.lang.String> strSet25 = node23.getDirectives();
        boolean boolean26 = node23.isWhile();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.newNode(node23, nodeArray27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList(nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.newNode(node12, nodeArray27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.newNode(node3, nodeArray27);
        com.google.javascript.rhino.InputId inputId32 = node31.getInputId();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(staticSourceFile15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(strSet25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(inputId32);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        byte[] byteArray8 = compilerOptions4.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions4.checkProvides;
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList12);
        boolean boolean15 = node14.isParamList();
        boolean boolean16 = node14.isNull();
        com.google.javascript.rhino.jstype.JSType jSType17 = node14.getJSType();
        com.google.javascript.rhino.Node node18 = node14.getLastSibling();
        com.google.javascript.rhino.Node node19 = node14.getParent();
        boolean boolean20 = node14.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node14, diagnosticType21, strArray27);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = jSError28.level;
        int int30 = jSError28.lineNumber;
        loggerErrorManager2.report(checkLevel9, jSError28);
        boolean boolean32 = diagnosticGroup0.matches(jSError28);
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean35 = compilerOptions34.generatePseudoNames;
        compilerOptions34.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions34.checkRequires;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel38);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler40 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback41 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal42 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler40, callback41);
        java.lang.String str43 = nodeTraversal42.getSourceName();
        com.google.javascript.rhino.Node node44 = nodeTraversal42.getEnclosingFunction();
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList46 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList46, nodeArray45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList46);
        boolean boolean49 = node48.isTypeOf();
        boolean boolean50 = node48.isTypeOf();
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.DiagnosticType.error("", "goog.exportProperty");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList58 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList58, nodeArray57);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList58);
        boolean boolean61 = node60.isTry();
        java.util.Set<java.lang.String> strSet62 = node60.getDirectives();
        boolean boolean63 = node60.isInstanceOf();
        com.google.javascript.rhino.Node node64 = node55.clonePropsFrom(node60);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup65 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean67 = diagnosticGroup65.matches(diagnosticType66);
        java.lang.String[] strArray69 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node64, diagnosticType66, strArray69);
        com.google.javascript.jscomp.JSError jSError71 = nodeTraversal42.makeError(node48, diagnosticType53, strArray69);
        com.google.javascript.jscomp.CheckLevel checkLevel72 = diagnosticGroupWarningsGuard39.level(jSError71);
        com.google.javascript.rhino.Node[] nodeArray74 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList75 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean76 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList75, nodeArray74);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList75);
        boolean boolean78 = node77.isParamList();
        boolean boolean79 = node77.isNull();
        com.google.javascript.rhino.jstype.JSType jSType80 = node77.getJSType();
        com.google.javascript.rhino.Node node81 = node77.getLastSibling();
        com.google.javascript.rhino.Node node82 = node77.getParent();
        boolean boolean83 = node77.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType84 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray90 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError91 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node77, diagnosticType84, strArray90);
        com.google.javascript.jscomp.CheckLevel checkLevel92 = jSError91.level;
        int int93 = jSError91.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel94 = jSError91.level;
        com.google.javascript.jscomp.CheckLevel checkLevel95 = diagnosticGroupWarningsGuard39.level(jSError91);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(strSet62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(diagnosticGroup65);
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(strArray69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNull(checkLevel72);
        org.junit.Assert.assertNotNull(nodeArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNull(node82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(diagnosticType84);
        org.junit.Assert.assertNotNull(strArray90);
        org.junit.Assert.assertNotNull(jSError91);
        org.junit.Assert.assertTrue("'" + checkLevel92 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel92.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertTrue("'" + checkLevel94 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel94.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(checkLevel95);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("goog.abstractMethod", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.exportProperty", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.foldConstants = true;
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile8 = jsAst7.getSourceFile();
        sourceFile8.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(sourceFile8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node0);
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        int int12 = node10.getIntProp(100);
        com.google.javascript.rhino.InputId inputId13 = node10.getInputId();
        int int14 = node10.getCharno();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.tryCatch(node0, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(inputId13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.removeDeadCode = true;
        boolean boolean14 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean15 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        java.lang.String str6 = node1.checkTreeEquals(node5);
        boolean boolean7 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        java.lang.String str14 = node11.getQualifiedName();
        node5.addChildrenToFront(node11);
        boolean boolean16 = node5.isEmpty();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile22 = node20.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable23 = node20.siblings();
        com.google.javascript.rhino.InputId inputId24 = node20.getInputId();
        boolean boolean25 = node20.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(51, node5, node20);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable27 = node20.getAncestors();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str6.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(staticSourceFile22);
        org.junit.Assert.assertNotNull(nodeIterable23);
        org.junit.Assert.assertNull(inputId24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(ancestorIterable27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = node0.srcref(node4);
        int int8 = node4.getIntProp(31);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        java.lang.String str6 = node1.checkTreeEquals(node5);
        boolean boolean7 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList9);
        java.lang.Object obj13 = node11.getProp(0);
        java.lang.String str14 = node11.getQualifiedName();
        node5.addChildrenToFront(node11);
        boolean boolean16 = node5.isEmpty();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile22 = node20.getStaticSourceFile();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable23 = node20.siblings();
        com.google.javascript.rhino.InputId inputId24 = node20.getInputId();
        boolean boolean25 = node20.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(51, node5, node20);
        com.google.javascript.rhino.Node node27 = node5.removeChildren();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str6.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(staticSourceFile22);
        org.junit.Assert.assertNotNull(nodeIterable23);
        org.junit.Assert.assertNull(inputId24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setShadowVariables(false);
        boolean boolean4 = compilerOptions0.collapseProperties;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap5 = compilerOptions0.getTweakReplacements();
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strMap5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        node1.setSourceEncodedPositionForTree(37);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        java.lang.String[] strArray5 = new java.lang.String[] { "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet6);
        boolean boolean9 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.setColorizeErrorOutput(false);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList12 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setRemoveUnusedLocalVars(true);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(locationMappingList12);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        java.lang.String str5 = node0.checkTreeEquals(node4);
        boolean boolean6 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        java.lang.Object obj12 = node10.getProp(0);
        java.lang.String str13 = node10.getQualifiedName();
        node4.addChildrenToFront(node10);
        boolean boolean15 = node4.isEmpty();
        boolean boolean16 = node4.isDelProp();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str5.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList4 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setMarkNoSideEffectCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setTweakToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "Unknown class name");
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setComputeFunctionSideEffects(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingList4);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList28);
        boolean boolean32 = closureCodingConvention0.isPrototypeAlias(node31);
        java.lang.String str33 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean35 = closureCodingConvention0.isExported("module$module$()");
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.exportProperty" + "'", str33.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        boolean boolean12 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setManageClosureDependencies(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.generatePseudoNames;
        compilerOptions16.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.checkRequires;
        compilerOptions15.checkGlobalNamesLevel = checkLevel20;
        compilerOptions0.checkUnreachableCode = checkLevel20;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray24 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray24);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = new com.google.javascript.jscomp.DiagnosticGroup("module$goog.exportProperty", diagnosticGroupArray24);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean29 = compilerOptions28.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean31 = compilerOptions30.generatePseudoNames;
        compilerOptions30.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions30.checkRequires;
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet39 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet39, strArray38);
        compilerOptions30.setIdGenerators((java.util.Set<java.lang.String>) strSet39);
        compilerOptions28.setStripTypes((java.util.Set<java.lang.String>) strSet39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean45 = compilerOptions44.generatePseudoNames;
        compilerOptions44.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions44.checkRequires;
        compilerOptions43.checkGlobalNamesLevel = checkLevel48;
        compilerOptions28.checkUnreachableCode = checkLevel48;
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.generatePseudoNames;
        boolean boolean53 = compilerOptions51.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions51.checkUnreachableCode;
        compilerOptions28.setCheckGlobalThisLevel(checkLevel54);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard56 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup27, checkLevel54);
        compilerOptions0.setWarningLevel(diagnosticGroup26, checkLevel54);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroupArray24);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isParamList();
        boolean boolean5 = node3.isNull();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        boolean boolean8 = node7.isBreak();
        boolean boolean9 = node7.isCase();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setSpecializeInitialModule(false);
        boolean boolean6 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.generatePseudoNames;
        compilerOptions3.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions3.checkRequires;
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet12 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet12, strArray11);
        compilerOptions3.setIdGenerators((java.util.Set<java.lang.String>) strSet12);
        compilerOptions1.setStripTypes((java.util.Set<java.lang.String>) strSet12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.generatePseudoNames;
        compilerOptions17.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions17.checkRequires;
        compilerOptions16.checkGlobalNamesLevel = checkLevel21;
        compilerOptions1.checkUnreachableCode = checkLevel21;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.generatePseudoNames;
        boolean boolean26 = compilerOptions24.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions24.checkUnreachableCode;
        compilerOptions1.setCheckGlobalThisLevel(checkLevel27);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard29 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel27);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup30;
        boolean boolean32 = diagnosticGroupWarningsGuard29.disables(diagnosticGroup30);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList3);
        boolean boolean6 = node5.isParamList();
        boolean boolean7 = node5.isNull();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 1, node5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str13 = jSSourceFile11.getLine((int) '#');
        jSSourceFile11.clearCachedSource();
        node5.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile11);
        boolean boolean16 = diagnosticType0.equals((java.lang.Object) node5);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isTry();
        java.util.Set<java.lang.String> strSet22 = node20.getDirectives();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray24 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList25 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList25, nodeArray24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList25);
        java.lang.String str28 = node23.checkTreeEquals(node27);
        boolean boolean29 = node27.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList31 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList31, nodeArray30);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList31);
        java.lang.Object obj35 = node33.getProp(0);
        java.lang.String str36 = node33.getQualifiedName();
        node27.addChildrenToFront(node33);
        com.google.javascript.rhino.Node node38 = node20.srcref(node27);
        try {
            com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.tryCatch(node5, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str28.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(nodeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node0.isEquivalentToTyped(node4);
        boolean boolean7 = node4.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList2);
        boolean boolean5 = node4.isParamList();
        boolean boolean6 = node4.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node4.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId8 = null;
        node4.setInputId(inputId8);
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList14);
        boolean boolean17 = node16.isParamList();
        boolean boolean18 = node16.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile19 = node16.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId20 = null;
        node16.setInputId(inputId20);
        boolean boolean22 = closureCodingConvention12.isOptionalParameter(node16);
        boolean boolean23 = detailLevel11.apply(node16);
        boolean boolean24 = closureCodingConvention0.isPrototypeAlias(node16);
        boolean boolean26 = closureCodingConvention0.isValidEnumKey("()");
        java.lang.String str27 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str28 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(staticSourceFile7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(staticSourceFile19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.abstractMethod" + "'", str27.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportSymbol" + "'", str28.equals("goog.exportSymbol"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        byte[] byteArray1 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setSourceMapOutputPath("hi!");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler4 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineLocalVariables(true);
        compilerOptions0.setCollapseObjectLiterals(true);
        compilerOptions0.ambiguateProperties = true;
        boolean boolean11 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertNull(byteArray1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile4.clearCachedSource();
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile4);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        try {
            java.lang.String str8 = compiler1.toSource(jSModule7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap5);
        compilerOptions0.setAliasStringsBlacklist("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler9 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setAppNameStr("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(aliasTransformationHandler9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList6);
        boolean boolean9 = node8.isTypeOf();
        boolean boolean10 = node8.isTypeOf();
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("", "goog.exportProperty");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile16 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node15);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isTry();
        java.util.Set<java.lang.String> strSet22 = node20.getDirectives();
        boolean boolean23 = node20.isInstanceOf();
        com.google.javascript.rhino.Node node24 = node15.clonePropsFrom(node20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean27 = diagnosticGroup25.matches(diagnosticType26);
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", node24, diagnosticType26, strArray29);
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node8, diagnosticType13, strArray29);
        int int32 = nodeTraversal2.getLineNumber();
        java.lang.String str33 = nodeTraversal2.getSourceName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(staticSourceFile16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node3.getStaticSourceFile();
        int int6 = node3.getCharno();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList8);
        boolean boolean11 = node10.isTry();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile12 = node10.getStaticSourceFile();
        boolean boolean13 = node10.isNot();
        boolean boolean14 = node10.isBreak();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        boolean boolean21 = node20.isParamList();
        boolean boolean22 = node20.isNull();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 1, node20);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node25 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention24.getDelegateRelationship(node25);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList29 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList29, nodeArray28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList29);
        boolean boolean32 = node31.isParamList();
        boolean boolean33 = node31.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile34 = node31.getStaticSourceFile();
        java.lang.String str35 = closureCodingConvention24.extractClassNameIfRequire(node27, node31);
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList37 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList37, nodeArray36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList37);
        boolean boolean40 = node39.isParamList();
        boolean boolean41 = node39.isNull();
        com.google.javascript.rhino.jstype.JSType jSType42 = node39.getJSType();
        node31.addChildrenToBack(node39);
        java.lang.String str44 = closureCodingConvention15.extractClassNameIfProvide(node20, node39);
        try {
            node3.replaceChild(node10, node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(staticSourceFile12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(staticSourceFile34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.number((double) 49);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        jSSourceFile2.clearCachedSource();
        java.lang.String str4 = jSSourceFile2.getCode();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        int int6 = compilerInput5.getNumLines();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.generatePseudoNames;
        compilerOptions4.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.optimizeParameters = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode12 = null;
        compilerOptions0.setTracer(tracerMode12);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean16 = closureCodingConvention14.isPrivate("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList20);
        boolean boolean23 = node22.isTry();
        com.google.javascript.rhino.Node node24 = node18.srcref(node22);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList26 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList26, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList26);
        boolean boolean29 = node28.isTry();
        java.util.Set<java.lang.String> strSet30 = node28.getDirectives();
        boolean boolean31 = node28.isWhile();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.newNode(node28, nodeArray32);
        java.lang.String str34 = closureCodingConvention14.extractClassNameIfRequire(node18, node28);
        boolean boolean35 = node28.isWhile();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        boolean boolean4 = node3.hasMoreThanOneChild();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler5 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler5, callback6);
        java.lang.String str8 = nodeTraversal7.getSourceName();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList10);
        boolean boolean13 = node12.isParamList();
        boolean boolean14 = node12.isScript();
        com.google.javascript.rhino.Node node15 = node12.getFirstChild();
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions17.checkMissingGetCssNameLevel;
        diagnosticType16.level = checkLevel20;
        com.google.javascript.jscomp.SourceAst sourceAst22 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(sourceAst22, "", true);
        com.google.javascript.jscomp.JSModule jSModule26 = compilerInput25.getModule();
        com.google.javascript.jscomp.JSModule jSModule27 = null;
        compilerInput25.setModule(jSModule27);
        boolean boolean29 = diagnosticType16.equals((java.lang.Object) compilerInput25);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList32 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList32, nodeArray31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList32);
        boolean boolean35 = node34.isParamList();
        boolean boolean36 = node34.isNull();
        com.google.javascript.rhino.jstype.JSType jSType37 = node34.getJSType();
        com.google.javascript.rhino.Node node38 = node34.getLastSibling();
        com.google.javascript.rhino.Node node39 = node34.getParent();
        boolean boolean40 = node34.isNull();
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray47 = new java.lang.String[] { "()", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n", "", "module$Unknown class name", "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("module$Unknown class name", node34, diagnosticType41, strArray47);
        com.google.javascript.jscomp.JSError jSError49 = nodeTraversal7.makeError(node12, diagnosticType16, strArray47);
        try {
            com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.tryFinally(node3, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(jSModule26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError49);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.generatePseudoNames;
        compilerOptions2.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions2.checkRequires;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions2.setIdGenerators((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.setAliasKeywords(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy19 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy19.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship2 = closureCodingConvention0.getDelegateRelationship(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList5);
        boolean boolean8 = node7.isParamList();
        boolean boolean9 = node7.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile10 = node7.getStaticSourceFile();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire(node3, node7);
        boolean boolean12 = node3.isOr();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.not(node3);
        try {
            int int15 = node13.getExistingIntProp(16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 16");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(staticSourceFile10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = jSSourceFile2.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("", "goog.abstractMethod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$" + "'", str2.equals("module$"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "Unknown class name";
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.generatePseudoNames;
        compilerOptions7.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap12 = null;
        compilerOptions7.setCssRenamingMap(cssRenamingMap12);
        compilerOptions7.setTweakToBooleanLiteral("module$Unknown class name", true);
        boolean boolean17 = compilerOptions7.checkSymbols;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel18 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList21);
        boolean boolean24 = node23.isParamList();
        boolean boolean25 = node23.isNull();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile26 = node23.getStaticSourceFile();
        com.google.javascript.rhino.InputId inputId27 = null;
        node23.setInputId(inputId27);
        boolean boolean29 = closureCodingConvention19.isOptionalParameter(node23);
        boolean boolean30 = detailLevel18.apply(node23);
        compilerOptions7.setSourceMapDetailLevel(detailLevel18);
        compilerOptions0.setSourceMapDetailLevel(detailLevel18);
        compilerOptions0.setAcceptConstKeyword(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean36 = compilerOptions35.generatePseudoNames;
        compilerOptions35.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions35.checkRequires;
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" };
        java.util.LinkedHashSet<java.lang.String> strSet44 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet44, strArray43);
        compilerOptions35.setIdGenerators((java.util.Set<java.lang.String>) strSet44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean48 = compilerOptions47.generatePseudoNames;
        compilerOptions47.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.generatePseudoNames;
        compilerOptions51.checkTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions51.checkRequires;
        compilerOptions47.checkProvides = checkLevel55;
        compilerOptions35.checkRequires = checkLevel55;
        compilerOptions0.setAggressiveVarCheck(checkLevel55);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(detailLevel18);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(staticSourceFile26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) '#');
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.rhino.InputId inputId8 = compilerInput6.getInputId();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertNotNull(inputId8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList1 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList1, nodeArray0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList1);
        java.lang.Object obj5 = node3.getProp(0);
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList11 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList11, nodeArray10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList11);
        java.lang.String str14 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node16 = node3.copyInformationFromForTree(node9);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList18 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList18, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList18);
        int int22 = node20.getIntProp(100);
        com.google.javascript.rhino.Node node23 = node16.useSourceInfoIfMissingFromForTree(node20);
        java.lang.String str24 = node20.toString();
        boolean boolean25 = node20.isGetterDef();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n" + "'", str14.equals("Node tree inequality:\nTree1:\nCONTINUE\n\n\nTree2:\nPARAM_LIST\n\n\nSubtree1: CONTINUE\n\n\nSubtree2: PARAM_LIST\n"));
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PARAM_LIST" + "'", str24.equals("PARAM_LIST"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }
}

