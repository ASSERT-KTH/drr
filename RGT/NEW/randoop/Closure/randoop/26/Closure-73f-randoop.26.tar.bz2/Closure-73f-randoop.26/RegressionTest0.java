import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        java.lang.String[] strArray3 = null;
        try {
            com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make("hi!", node1, diagnosticType2, strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray1 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0 };
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticTypeArray1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray1 = new java.lang.String[] {};
        try {
            com.google.javascript.jscomp.JSError jSError2 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test005");
//        try {
//            com.google.javascript.rhino.Context.reportError("", "", 10, "hi!", 49);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (#10)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("hi!", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            java.lang.String str3 = defaultCodingConvention0.extractClassNameIfProvide(node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("", "", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        try {
            com.google.javascript.rhino.Node node4 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) -1, node11);
        try {
            com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1), node5, node12, (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        try {
            java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.getMessage1("language version", (java.lang.Object) node6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder5.append("language version");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        try {
            node5.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node13.getJsDocBuilderForNode();
        try {
            node6.removeChild(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        try {
            java.io.Reader reader3 = jSSourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        boolean boolean6 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) -1, node11);
        node11.setCharno((int) (byte) 10);
        try {
            node5.addChildrenToFront(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        try {
            com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 1, node1, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        node13.setType(0);
        try {
            int int35 = node13.getExistingIntProp(25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        java.lang.Appendable appendable9 = null;
        try {
            node6.appendStringTree(appendable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        try {
            boolean boolean15 = defaultCodingConvention0.isOptionalParameter(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        int int8 = ecmaError6.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            loggerErrorManager1.println(checkLevel2, jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (-1), 41, 0);
        try {
            node3.setSideEffectFlags(41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0, 31, (int) (short) 100);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        try {
            context0.setLanguageVersion((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        boolean boolean19 = node13.isNoSideEffectsCall();
        try {
            node13.setSideEffectFlags(14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "()");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.util.Collection<java.lang.String> strCollection4 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("<No stack trace available>", "", "", "NUMBER 1.0 0");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <No stack trace available>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("NUMBER 1.0 0", "", (int) (short) 10, "", 49);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: NUMBER 1.0 0 (#10)");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        boolean boolean14 = node11.isOptionalArg();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean26 = node25.wasEmptyNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean32 = node31.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = node25.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) -1, node47);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(15, node33, node37, node42, node48, 10, 49);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean58 = node57.wasEmptyNode();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean64 = node63.wasEmptyNode();
        com.google.javascript.rhino.Node node65 = node57.copyInformationFromForTree(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node((int) (byte) -1, node79);
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node(15, node65, node69, node74, node80, 10, 49);
        com.google.javascript.rhino.Node node84 = node80.getLastSibling();
        try {
            com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((int) '#', node11, node19, node42, node80, 13, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node84);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        node13.setType(0);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean46 = node45.wasEmptyNode();
        com.google.javascript.rhino.Node node47 = node39.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (byte) -1, node61);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(15, node47, node51, node56, node62, 10, 49);
        try {
            node13.addChildrenToFront(node47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("hi!", "language version", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup1;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        boolean boolean6 = diagnosticGroup1.matches(diagnosticType5);
//        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean12 = node11.wasEmptyNode();
//        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean18 = node17.wasEmptyNode();
//        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
//        try {
//            java.lang.String str20 = com.google.javascript.rhino.ScriptRuntime.getMessage2("NUMBER 1.0 0", (java.lang.Object) boolean6, (java.lang.Object) node17);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property NUMBER 1.0 0");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup1);
//        org.junit.Assert.assertNotNull(diagnosticType5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(node11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(node19);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("()", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray5 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList6 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList6, dependencyInfoArray5);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies8 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(dependencyInfoArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Context context33 = new com.google.javascript.rhino.Context();
        java.lang.Object obj34 = context33.getDebuggerContextData();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean41 = node40.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean47 = node46.wasEmptyNode();
        com.google.javascript.rhino.Node node48 = node40.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) -1, node62);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(15, node48, node52, node57, node63, 10, 49);
        context33.seal((java.lang.Object) node48);
        try {
            com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(23, node32, node48, 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node22.detachFromParent();
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        node32.setJSType(jSType33);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        java.util.logging.Logger logger7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.parsing.ParserRunner.parse("language version", "hi!", config5, errorReporter6, logger7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType1, functionType2, objectType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        node13.setType(0);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable34 = node13.siblings();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeIterable34);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        try {
            java.lang.String str3 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.lang.String str4 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.sourceName();
        java.lang.String str8 = ecmaError6.getErrorMessage();
        try {
            ecmaError6.initLineSource("language version");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        try {
            context0.setLanguageVersion(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler6 = null;
        try {
            com.google.javascript.rhino.Node node7 = compilerInput3.getAstRoot(abstractCompiler6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        com.google.javascript.rhino.Node node38 = node28.detachFromParent();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean50 = node49.wasEmptyNode();
        com.google.javascript.rhino.Node node51 = node43.copyInformationFromForTree(node49);
        node51.addSuppression("()");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (byte) -1, node58);
        boolean boolean60 = node59.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, node28, node51, node59, 5, 8);
        try {
            node4.addChildrenToBack(node51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Object obj0 = null;
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray8 = new java.lang.String[] { "NUMBER 1.0 0", "null", ": " };
        try {
            com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("()", 1, 34, checkLevel3, diagnosticType4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String str3 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NUMBER 1.0 0" + "'", str3.equals("NUMBER 1.0 0"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("null", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        java.lang.Throwable[] throwableArray19 = runtimeException18.getSuppressed();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        com.google.javascript.rhino.Context context38 = new com.google.javascript.rhino.Context();
        java.lang.Object obj39 = context38.getDebuggerContextData();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean46 = node45.wasEmptyNode();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean52 = node51.wasEmptyNode();
        com.google.javascript.rhino.Node node53 = node45.copyInformationFromForTree(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (byte) -1, node67);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(15, node53, node57, node62, node68, 10, 49);
        context38.seal((java.lang.Object) node53);
        try {
            context0.removeThreadLocal((java.lang.Object) node53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("language version", (int) (short) 10, 10);
        try {
            boolean boolean5 = closureCodingConvention0.isPropertyTestFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        try {
            boolean boolean7 = closureCodingConvention0.isPropertyTestFunction(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator3);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset6);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile11, jSSourceFile15 };
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset18);
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator21);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset24);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator31);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile22, jSSourceFile25, jSSourceFile29, jSSourceFile32 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = null;
        try {
            com.google.javascript.jscomp.Result result35 = compiler1.compile(jSSourceFileArray16, jSSourceFileArray33, compilerOptions34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str13 = jSSourceFile10.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region15 = jSSourceFile10.getRegion((int) ' ');
        com.google.javascript.jscomp.SourceFile.Generator generator17 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator17);
        java.nio.charset.Charset charset20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset20);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.nio.charset.Charset charset26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset26);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
        java.lang.String str30 = jSSourceFile27.getLine((int) (byte) 0);
        com.google.javascript.jscomp.SourceFile.Generator generator32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile18, jSSourceFile21, jSSourceFile24, jSSourceFile27, jSSourceFile33, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.nio.charset.Charset charset45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset45);
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46);
        java.nio.charset.Charset charset49 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset49);
        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile50);
        java.nio.charset.Charset charset53 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset53);
        com.google.javascript.jscomp.CompilerInput compilerInput55 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile54);
        java.lang.String str57 = jSSourceFile54.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region59 = jSSourceFile54.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray60 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile46, jSSourceFile50, jSSourceFile54 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList61 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList61, jSSourceFileArray60);
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = null;
        try {
            compiler2.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList61, compilerOptions63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(region15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNull(region59);
        org.junit.Assert.assertNotNull(jSSourceFileArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a type name", "null", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        int int19 = node5.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            java.lang.String str6 = compiler2.toSource(jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = null;
        try {
            compiler1.setState(intermediateState2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset8);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList11, jSSourceFileArray10);
        com.google.javascript.jscomp.JSModule[] jSModuleArray13 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList14, jSModuleArray13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = null;
        try {
            com.google.javascript.jscomp.Result result17 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList11, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList14, compilerOptions16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSModuleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator9);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version", charset15);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version", charset18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset24);
        java.nio.charset.Charset charset27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset27);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile13, jSSourceFile16, jSSourceFile19, jSSourceFile22, jSSourceFile25, jSSourceFile28 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList31 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList31, jSSourceFileArray30);
        com.google.javascript.jscomp.JSModule[] jSModuleArray33 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList34 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList34, jSModuleArray33);
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = null;
        try {
            compiler2.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList31, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList34, compilerOptions36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jSModuleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("NUMBER 1.0 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NUMBER 1.0 0" + "'", str1.equals("NUMBER 1.0 0"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        int int6 = diagnosticType2.compareTo(diagnosticType5);
        java.lang.String str7 = diagnosticType5.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "language version: language version" + "'", str7.equals("language version: language version"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str8 = jSSourceFile7.getOriginalPath();
        try {
            compilerInput4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "language version" + "'", str8.equals("language version"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("hi!", "language version");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = null;
        try {
            com.google.javascript.jscomp.Result result12 = compiler2.compile(jSSourceFile7, jSSourceFile10, compilerOptions11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        node9.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = node9.getLastSibling();
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        context0.seal((java.lang.Object) node14);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter17 = context0.setErrorReporter(errorReporter16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        try {
            node5.addChildrenToFront(node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        java.lang.String str7 = jSSourceFile4.getLine((int) (byte) 0);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str13 = jSSourceFile10.getLine((int) (byte) 0);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset15);
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator18);
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator21);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile10, jSSourceFile16, jSSourceFile19, jSSourceFile22 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray24 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = null;
        try {
            com.google.javascript.jscomp.Result result26 = compiler1.compile(jSSourceFileArray23, jSSourceFileArray24, compilerOptions25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        boolean boolean14 = detailLevel0.apply(node5);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getEnclosingFunction();
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        node8.putProp((int) (short) 0, (java.lang.Object) (byte) 100);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags17 = new com.google.javascript.rhino.Node.SideEffectFlags(49);
        try {
            node8.setSideEffectFlags(sideEffectFlags17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node3, callback4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder2 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            compiler1.toSource(codeBuilder2, (int) (byte) 1, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str5 = jSSourceFile2.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region7 = jSSourceFile2.getRegion((int) ' ');
        jSSourceFile2.setOriginalPath("goog.abstractMethod");
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(region7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray8 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType7, strArray8);
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel10 = compiler1.getErrorLevel(jSError9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("<No stack trace available>", "goog.abstractMethod", (int) (byte) 0, "", 29);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        node14.setType((int) (byte) 10);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention35 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        boolean boolean42 = node41.isOnlyModifiesThisCall();
        boolean boolean43 = defaultCodingConvention35.isPropertyTestFunction(node41);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal44 = null;
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean50 = node49.wasEmptyNode();
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast51 = defaultCodingConvention35.getObjectLiteralCast(nodeTraversal44, node49);
        node14.addChildToFront(node49);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention53 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (byte) -1, node58);
        boolean boolean60 = node59.isOnlyModifiesThisCall();
        boolean boolean61 = defaultCodingConvention53.isPropertyTestFunction(node59);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node64 = node59.copyInformationFromForTree(node63);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean74 = node73.wasEmptyNode();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean80 = node79.wasEmptyNode();
        com.google.javascript.rhino.Node node81 = node73.copyInformationFromForTree(node79);
        boolean boolean82 = node79.isOptionalArg();
        com.google.javascript.rhino.Node node83 = node79.cloneTree();
        boolean boolean84 = node83.isVarArgs();
        try {
            com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(5, node14, node63, node68, node83, 42, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(objectLiteralCast51);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        java.lang.String str7 = jSSourceFile4.getLine((int) (byte) 0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray9 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = null;
        try {
            com.google.javascript.jscomp.Result result11 = compiler1.compile(jSSourceFileArray8, jSModuleArray9, compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNotNull(jSModuleArray9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        boolean boolean2 = sideEffectFlags0.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.JSModule jSModule0 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.rhino.Node[] nodeArray5 = null;
        try {
            nodeTraversal2.traverseRoots(nodeArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("language version", "RETURN 0\n");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eof" + "'", str1.equals("eof"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset7);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        java.lang.String str11 = jSSourceFile8.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region13 = jSSourceFile8.getRegion((int) ' ');
        com.google.javascript.jscomp.JSModule[] jSModuleArray14 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = null;
        try {
            com.google.javascript.jscomp.Result result16 = compiler2.compile(jSSourceFile8, jSModuleArray14, compilerOptions15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(region13);
        org.junit.Assert.assertNotNull(jSModuleArray14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        com.google.javascript.rhino.Node node34 = node24.detachFromParent();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean46 = node45.wasEmptyNode();
        com.google.javascript.rhino.Node node47 = node39.copyInformationFromForTree(node45);
        node47.addSuppression("()");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (byte) -1, node54);
        boolean boolean56 = node55.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(0, node24, node47, node55, 5, 8);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(18, node59, 41, 9);
        com.google.javascript.rhino.JSDocInfo jSDocInfo63 = node62.getJSDocInfo();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(jSDocInfo63);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(4, 0, 1);
        java.lang.String str4 = node3.toStringTree();
        try {
            java.lang.String str5 = node3.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: RETURN 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RETURN 0\n" + "'", str4.equals("RETURN 0\n"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        java.lang.Object obj35 = null;
        try {
            context0.putThreadLocal(obj35, (java.lang.Object) 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = null;
        try {
            compiler1.initOptions(compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
        try {
            boolean boolean6 = compiler2.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray10 = null;
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType9, strArray10);
        try {
            java.lang.String str12 = lightweightMessageFormatter3.formatWarning(jSError11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(jSError11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray9 = null;
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType8, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray17 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType16, strArray17);
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType8, strArray17);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel21, "<No stack trace available>");
        com.google.javascript.jscomp.ErrorFormat errorFormat24 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream25 = null;
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler(printStream25);
        com.google.javascript.jscomp.MessageFormatter messageFormatter28 = errorFormat24.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler26, true);
        try {
            java.lang.String str29 = jSError19.format(checkLevel21, messageFormatter28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(errorFormat24);
        org.junit.Assert.assertNotNull(messageFormatter28);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("language version", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(15, node33);
        com.google.javascript.rhino.JSDocInfo jSDocInfo35 = null;
        node33.setJSDocInfo(jSDocInfo35);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        compilerInput3.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        compiler2.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        java.lang.String str14 = jSSourceFile11.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region16 = jSSourceFile11.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
        try {
            com.google.javascript.jscomp.Result result21 = compiler2.compile(jSSourceFile8, jSSourceFileArray19, compilerOptions20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(region16);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFileArray19);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType3, functionType4, objectType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        boolean boolean6 = node5.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) -1, node12);
        boolean boolean14 = node13.isOnlyModifiesThisCall();
        boolean boolean15 = defaultCodingConvention7.isPropertyTestFunction(node13);
        com.google.javascript.rhino.Node node16 = node5.copyInformationFrom(node13);
        try {
            node5.setDouble((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ERROR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.EcmaError ecmaError19 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int20 = ecmaError19.columnNumber();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) "hi!", (java.lang.Object) ecmaError19);
        int int22 = ecmaError19.getLineNumber();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(ecmaError19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        try {
            java.lang.String[] strArray4 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        java.nio.charset.Charset charset6 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset6);
//        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
//        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator13);
//        java.nio.charset.Charset charset16 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset16);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile11, jSSourceFile14, jSSourceFile17 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
//        try {
//            com.google.javascript.jscomp.Result result21 = compiler0.compile(jSSourceFileArray18, jSModuleArray19, compilerOptions20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNotNull(jSSourceFile17);
//        org.junit.Assert.assertNotNull(jSSourceFileArray18);
//        org.junit.Assert.assertNotNull(jSModuleArray19);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        compiler2.reportCodeChange();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = compiler2.newExternInput("RETURN 0\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType6);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray7 = null;
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType6, strArray7);
        int int9 = diagnosticType0.compareTo(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-34) + "'", int9 == (-34));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        int int4 = nodeTraversal2.getLineNumber();
        try {
            com.google.javascript.rhino.Node node5 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "goog.abstractMethod");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        java.nio.charset.Charset charset14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset14);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        java.lang.String str18 = jSSourceFile15.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region20 = jSSourceFile15.getRegion((int) ' ');
        jSSourceFile15.setOriginalPath("goog.abstractMethod");
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile8, jSSourceFile11, jSSourceFile15, jSSourceFile25 };
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version", charset28);
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray34 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile29, jSSourceFile32 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = null;
        try {
            com.google.javascript.jscomp.Result result36 = compiler1.compile(jSSourceFileArray26, jSSourceFileArray34, compilerOptions35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(region20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFileArray34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        java.lang.String str33 = closureCodingConvention12.extractClassNameIfProvide(node17, node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship34 = defaultCodingConvention0.getClassesDefinedByCall(node17);
        try {
            com.google.javascript.rhino.Node node36 = node17.getChildAtIndex(120);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(subclassRelationship34);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node22.cloneTree();
        com.google.javascript.rhino.Node node33 = node22.removeFirstChild();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str41 = node37.toString(true, false, true);
        try {
            com.google.javascript.rhino.Node node42 = node33.getChildBefore(node37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "NUMBER 1.0 0" + "'", str41.equals("NUMBER 1.0 0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError(": ", ": ");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        lightweightMessageFormatter3.setColorize(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray12 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType11, strArray12);
        try {
            java.lang.String str14 = lightweightMessageFormatter3.formatWarning(jSError13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        try {
//            compiler0.rebuildInputsFromModules();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            int int2 = compiler1.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node22.cloneTree();
        try {
            double double33 = node32.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF  0 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        boolean boolean14 = node11.isOptionalArg();
        com.google.javascript.rhino.Node node15 = node11.cloneTree();
        boolean boolean16 = node15.isVarArgs();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) -1, node22);
        node22.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        node30.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node34 = node30.getLastSibling();
        java.lang.RuntimeException runtimeException35 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node22, (java.lang.Object) node30);
        boolean boolean37 = node22.getBooleanProp((int) '4');
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) -1, node43);
        node43.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (byte) -1, node51);
        node51.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node55 = node51.getLastSibling();
        java.lang.RuntimeException runtimeException56 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node43, (java.lang.Object) node51);
        try {
            com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) 'a', node15, node22, node43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(runtimeException35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(runtimeException56);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags20 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags20.clearAllFlags();
        int int22 = sideEffectFlags20.valueOf();
        try {
            node5.setSideEffectFlags(sideEffectFlags20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        node9.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = node9.getLastSibling();
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        context0.seal((java.lang.Object) node14);
        boolean boolean17 = context0.isActivationNeeded("");
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter19 = context0.setErrorReporter(errorReporter18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
//        java.nio.charset.Charset charset11 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset11);
//        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
//        java.lang.String str15 = jSSourceFile12.getLine((int) (byte) 0);
//        java.nio.charset.Charset charset17 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset17);
//        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18);
//        java.lang.String str21 = jSSourceFile18.getLine((int) (byte) 0);
//        java.nio.charset.Charset charset23 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset23);
//        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile24);
//        java.lang.String str27 = jSSourceFile24.getLine((int) (byte) 0);
//        com.google.javascript.jscomp.Region region29 = jSSourceFile24.getRegion((int) ' ');
//        jSSourceFile24.clearCachedSource();
//        java.nio.charset.Charset charset32 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset32);
//        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
//        java.lang.String str36 = jSSourceFile33.getLine((int) (byte) 0);
//        com.google.javascript.jscomp.Region region38 = jSSourceFile33.getRegion((int) ' ');
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version: language version");
//        java.nio.charset.Charset charset42 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset42);
//        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile43);
//        java.lang.String str46 = jSSourceFile43.getLine((int) (byte) 0);
//        com.google.javascript.jscomp.Region region48 = jSSourceFile43.getRegion((int) ' ');
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version: language version");
//        java.nio.charset.Charset charset52 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
//        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile53);
//        java.lang.String str56 = jSSourceFile53.getLine((int) (byte) 0);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray57 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9, jSSourceFile12, jSSourceFile18, jSSourceFile24, jSSourceFile33, jSSourceFile40, jSSourceFile43, jSSourceFile50, jSSourceFile53 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList58 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList58, jSSourceFileArray57);
//        java.nio.charset.Charset charset61 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset61);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile64 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray65 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile62, jSSourceFile64 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList66 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean67 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList66, jSSourceFileArray65);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = null;
//        try {
//            compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList58, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList66, compilerOptions68);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(jSSourceFile9);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(jSSourceFile24);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNull(region29);
//        org.junit.Assert.assertNotNull(jSSourceFile33);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertNull(region38);
//        org.junit.Assert.assertNotNull(jSSourceFile40);
//        org.junit.Assert.assertNotNull(jSSourceFile43);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertNull(region48);
//        org.junit.Assert.assertNotNull(jSSourceFile50);
//        org.junit.Assert.assertNotNull(jSSourceFile53);
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertNotNull(jSSourceFileArray57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(jSSourceFile62);
//        org.junit.Assert.assertNotNull(jSSourceFile64);
//        org.junit.Assert.assertNotNull(jSSourceFileArray65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType5, strArray6);
        java.text.MessageFormat messageFormat8 = diagnosticType5.format;
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertNotNull(messageFormat8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("eof", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList7 = null;
//        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions9.moveFunctionDeclarations = false;
//        try {
//            compiler0.init(jSSourceFileList7, jSSourceFileList8, compilerOptions9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType24 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType22, functionType23, objectType24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(1);
        sideEffectFlags1.setAllFlags();
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType29, strArray30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray38 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType37, strArray38);
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType29, strArray38);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("language version: language version", node6, diagnosticType20, strArray38);
        try {
            node6.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        boolean boolean24 = defaultCodingConvention0.isSuperClassReference("language version");
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder5.append("Not declared as a type name");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        boolean boolean6 = node4.isOptionalArg();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node9 = node5.getLastSibling();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        node9.putProp((int) (short) 0, (java.lang.Object) (byte) 100);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node9 };
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(1, nodeArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        java.lang.String str2 = codeBuilder0.toString();
        int int3 = codeBuilder0.getLength();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        boolean boolean24 = node16.getBooleanProp(36);
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
//        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable32 = node28.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor33 = ancestorIterable32.iterator();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(ancestorIterable32);
        org.junit.Assert.assertNotNull(nodeItor33);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        boolean boolean6 = node4.hasOneChild();
        java.lang.String str7 = node4.toString();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "EOF  0" + "'", str7.equals("EOF  0"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        node12.addSuppression("()");
        com.google.javascript.rhino.Node node15 = node12.cloneTree();
        com.google.javascript.rhino.jstype.JSType jSType16 = node12.getJSType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.Scope scope5 = compiler2.getTopScope();
        try {
            int int6 = compiler2.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(scope5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Named type with empty name component)" + "'", str1.equals("(Named type with empty name component)"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        boolean boolean15 = node14.isVarArgs();
        node14.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean24 = node23.wasEmptyNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean30 = node29.wasEmptyNode();
        com.google.javascript.rhino.Node node31 = node23.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (byte) -1, node45);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(15, node31, node35, node40, node46, 10, 49);
        node31.setType((int) (byte) 10);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention52 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) -1, node57);
        boolean boolean59 = node58.isOnlyModifiesThisCall();
        boolean boolean60 = defaultCodingConvention52.isPropertyTestFunction(node58);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal61 = null;
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean67 = node66.wasEmptyNode();
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast68 = defaultCodingConvention52.getObjectLiteralCast(nodeTraversal61, node66);
        node31.addChildToFront(node66);
        com.google.javascript.rhino.Node node70 = node66.cloneNode();
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean76 = node75.wasEmptyNode();
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean82 = node81.wasEmptyNode();
        com.google.javascript.rhino.Node node83 = node75.copyInformationFromForTree(node81);
        try {
            node14.addChildAfter(node66, node83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(objectLiteralCast68);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(node83);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        boolean boolean19 = node17.hasOneChild();
        java.util.List<java.lang.String> strList20 = defaultCodingConvention0.identifyTypeDeclarationCall(node17);
        try {
            int int22 = node17.getExistingIntProp((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(strList20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        context0.setCompileFunctionsWithDynamicScope(false);
        org.junit.Assert.assertNull(obj1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions1.checkMethods;
        compilerOptions1.inlineLocalFunctions = false;
        compilerOptions1.closurePass = true;
        java.util.Set<java.lang.String> strSet9 = compilerOptions1.stripNameSuffixes;
        java.lang.String str10 = compilerOptions1.syntheticBlockEndMarker;
        try {
            context0.unseal((java.lang.Object) str10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.enableRuntimeTypeCheck("null");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            com.google.javascript.rhino.Context.reportError("NUMBER 1.0 0", "EOF  0", 4095, "EOF  0", 0);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: NUMBER 1.0 0 (EOF  0#4095)");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider5 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter7 = errorFormat0.toFormatter(sourceExcerptProvider5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel2 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel2;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        node17.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node17);
        java.lang.Appendable appendable22 = null;
        try {
            node10.appendStringTree(appendable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream1 = null;
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
//        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset8 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset8);
//        com.google.javascript.rhino.Node node10 = compiler6.parse(jSSourceFile9);
//        boolean boolean11 = compiler6.hasErrors();
//        compiler6.reportCodeChange();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        java.lang.String[] strArray22 = null;
//        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType21, strArray22);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
//        java.lang.String[] strArray30 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType29, strArray30);
//        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType21, strArray30);
//        com.google.javascript.jscomp.CheckLevel checkLevel33 = compiler6.getErrorLevel(jSError32);
//        try {
//            com.google.javascript.jscomp.CheckLevel checkLevel34 = compiler2.getErrorLevel(jSError32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertNotNull(messageFormatter4);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(jSSourceFile9);
//        org.junit.Assert.assertNull(node10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(diagnosticType21);
//        org.junit.Assert.assertNotNull(jSError23);
//        org.junit.Assert.assertNotNull(diagnosticType29);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(jSError31);
//        org.junit.Assert.assertNotNull(jSError32);
//        org.junit.Assert.assertNull(checkLevel33);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a type name", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 36, (-34), 44);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        com.google.javascript.rhino.Node node19 = node13.getLastChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertNull(node19);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.EcmaError ecmaError19 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int20 = ecmaError19.columnNumber();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) "hi!", (java.lang.Object) ecmaError19);
        try {
            ecmaError19.initColumnNumber(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(ecmaError19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertNotNull(runtimeException21);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray10 = null;
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType9, strArray10);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel13, "<No stack trace available>");
        diagnosticType9.level = checkLevel13;
        compilerOptions2.checkProvides = checkLevel13;
        compilerOptions2.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions2.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel22, "<No stack trace available>");
        java.lang.String[] strArray29 = new java.lang.String[] { "(Named type with empty name component)", "language version", "NUMBER 1.0 0", "window" };
        try {
            com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("com.google.javascript.rhino.EcmaError: : ", node1, checkLevel20, diagnosticType24, strArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray29);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        boolean boolean19 = node13.isNoSideEffectsCall();
        node13.setOptionalArg(false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node4.setJSType(jSType6);
        boolean boolean8 = node4.isQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.crossModuleMethodMotion = false;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder12 = node11.getJsDocBuilderForNode();
        int int13 = node11.getChildCount();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node26 = node18.copyInformationFromForTree(node24);
        java.lang.String str27 = closureCodingConvention6.extractClassNameIfProvide(node11, node26);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType30 = null;
        closureCodingConvention6.applySubclassRelationship(functionType28, functionType29, subclassType30);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = null;
        com.google.javascript.jscomp.Scope scope33 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention34 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) -1, node39);
        boolean boolean41 = node40.isOnlyModifiesThisCall();
        boolean boolean42 = defaultCodingConvention34.isPropertyTestFunction(node40);
        com.google.javascript.rhino.Node node43 = null;
        java.lang.String str44 = defaultCodingConvention34.getSingletonGetterClassName(node43);
        boolean boolean46 = defaultCodingConvention34.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = null;
        com.google.javascript.jscomp.Scope scope48 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray49 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList50 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList50, objectTypeArray49);
        defaultCodingConvention34.defineDelegateProxyPrototypeProperties(jSTypeRegistry47, scope48, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList50);
        closureCodingConvention6.defineDelegateProxyPrototypeProperties(jSTypeRegistry32, scope33, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList50);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention6);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags2.clearSideEffectFlags();
        sideEffectFlags2.clearSideEffectFlags();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) -1, node10);
        boolean boolean12 = node11.isOnlyModifiesThisCall();
        boolean boolean13 = defaultCodingConvention5.isPropertyTestFunction(node11);
        com.google.javascript.rhino.Node node14 = null;
        java.lang.String str15 = defaultCodingConvention5.getSingletonGetterClassName(node14);
        java.lang.String str16 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention17 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder23 = node22.getJsDocBuilderForNode();
        int int24 = node22.getChildCount();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean30 = node29.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean36 = node35.wasEmptyNode();
        com.google.javascript.rhino.Node node37 = node29.copyInformationFromForTree(node35);
        java.lang.String str38 = closureCodingConvention17.extractClassNameIfProvide(node22, node37);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship39 = defaultCodingConvention5.getClassesDefinedByCall(node22);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder46 = node45.getJsDocBuilderForNode();
        int int47 = node45.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray54 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType53, strArray54);
        java.lang.String[] strArray56 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node45, diagnosticType53, strArray56);
        try {
            java.lang.String str58 = com.google.javascript.rhino.ScriptRuntime.getMessage3("null", (java.lang.Object) sideEffectFlags2, (java.lang.Object) subclassRelationship39, (java.lang.Object) "RETURN 0\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property null");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNull(subclassRelationship39);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(jSError57);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Named type with empty name component", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.SourceFile sourceFile0 = null;
        try {
            com.google.javascript.jscomp.JsAst jsAst1 = new com.google.javascript.jscomp.JsAst(sourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("(Named type with empty name component)");
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.getFirstChild();
        node10.putIntProp(31, 4095);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "", "NUMBER 1.0 0");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        try {
            com.google.javascript.jscomp.JSModule jSModule3 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput3 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 13);
        node1.detachChildren();
        org.junit.Assert.assertNotNull(node1);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        com.google.javascript.jscomp.Scope scope5 = compiler0.getTopScope();
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertNull(scope5);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        com.google.javascript.jscomp.JsAst jsAst38 = new com.google.javascript.jscomp.JsAst(sourceFile36);
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst38, false);
        com.google.javascript.jscomp.SourceFile.Generator generator42 = null;
        com.google.javascript.jscomp.SourceFile sourceFile43 = com.google.javascript.jscomp.SourceFile.fromGenerator("NUMBER 1.0 0", generator42);
        try {
            jsAst38.setSourceFile(sourceFile43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(sourceFile43);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        java.util.Locale locale12 = null;
        java.util.Locale locale13 = context0.setLocale(locale12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter15 = context0.setErrorReporter(errorReporter14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(locale13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(15, node33);
        boolean boolean35 = node34.isVarArgs();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("window", "goog.abstractMethod", "", "Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property window");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        java.lang.String[] strArray12 = null;
//        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType11, strArray12);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
//        java.lang.String[] strArray20 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType19, strArray20);
//        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType11, strArray20);
//        boolean boolean23 = diagnosticGroup0.matches(diagnosticType11);
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticType11);
//        org.junit.Assert.assertNotNull(jSError13);
//        org.junit.Assert.assertNotNull(diagnosticType19);
//        org.junit.Assert.assertNotNull(strArray20);
//        org.junit.Assert.assertNotNull(jSError21);
//        org.junit.Assert.assertNotNull(jSError22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node41 = node33.copyInformationFromForTree(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) -1, node55);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(15, node41, node45, node50, node56, 10, 49);
        com.google.javascript.rhino.Node node60 = node50.detachFromParent();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean66 = node65.wasEmptyNode();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean72 = node71.wasEmptyNode();
        com.google.javascript.rhino.Node node73 = node65.copyInformationFromForTree(node71);
        node73.addSuppression("()");
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node((int) (byte) -1, node80);
        boolean boolean82 = node81.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(0, node50, node73, node81, 5, 8);
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(18, node85, 41, 9);
        java.lang.String str89 = closureCodingConvention0.getSingletonGetterClassName(node85);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(str89);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray10 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType9, strArray10);
        try {
            java.lang.String str12 = lightweightMessageFormatter3.formatError(jSError11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = null;
        try {
            nodeTraversal2.traverse(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkControlStructures = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        java.lang.String str5 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray6 = null;
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType5, strArray6);
        boolean boolean9 = jSError7.equals((java.lang.Object) "<No stack trace available>");
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        int int2 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        compiler2.reportCodeChange();
        try {
            compiler2.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.skipAllCompilerPasses();
        java.lang.String str10 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        java.lang.String str23 = defaultCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags1.clearAllFlags();
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        node9.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = node9.getLastSibling();
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        context0.seal((java.lang.Object) node14);
        try {
            context0.setGeneratingSource(false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((-1.0d), 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getDelegateSuperclassName();
        java.lang.String str2 = defaultCodingConvention0.getExportSymbolFunction();
        java.lang.String str3 = defaultCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        lightweightMessageFormatter3.setColorize(false);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter3, logger6);
        int int8 = loggerErrorManager7.getWarningCount();
        loggerErrorManager7.setTypedPercent((double) 27);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean51 = node50.wasEmptyNode();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean57 = node56.wasEmptyNode();
        com.google.javascript.rhino.Node node58 = node50.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) (byte) -1, node72);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(15, node58, node62, node67, node73, 10, 49);
        com.google.javascript.rhino.Node node77 = node73.getLastSibling();
        com.google.javascript.rhino.Node node78 = node77.getLastChild();
        boolean boolean79 = closureCodingConvention0.isOptionalParameter(node78);
        boolean boolean81 = closureCodingConvention0.isSuperClassReference("hi!");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("-1", "", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        boolean boolean5 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node9 = node5.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = null;
        node9.setJSDocInfo(jSDocInfo10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(140, "com.google.javascript.rhino.EcmaError: : ");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean21 = node20.wasEmptyNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean27 = node26.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = node20.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) -1, node42);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(15, node28, node32, node37, node43, 10, 49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean53 = node52.wasEmptyNode();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean59 = node58.wasEmptyNode();
        com.google.javascript.rhino.Node node60 = node52.copyInformationFromForTree(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (byte) -1, node74);
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node(15, node60, node64, node69, node75, 10, 49);
        boolean boolean79 = node46.hasChild(node69);
        int int80 = node69.getSourcePosition();
        com.google.javascript.rhino.Node node81 = null;
        try {
            com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node((int) (short) -1, node9, node14, node69, node81, 34, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 100 + "'", int80 == 100);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker7 = null;
//        compiler0.tracker = performanceTracker7;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = null;
//        try {
//            com.google.javascript.rhino.Node node10 = compiler0.parse(jSSourceFile9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.String str2 = sourceFile1.toString();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "()" + "'", str2.equals("()"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        try {
            com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        boolean boolean2 = compilerOptions0.checkControlStructures;
        compilerOptions0.inputDelimiter = "-1";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        loggerErrorManager1.setTypedPercent((double) 'a');
        int int5 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray14 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType13, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node5, diagnosticType13, strArray16);
        java.lang.String str18 = jSError17.sourceName;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RETURN 0\n" + "'", str18.equals("RETURN 0\n"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            com.google.javascript.rhino.Context.reportWarning("Named type with empty name component", "", 44, "window", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions0.checkRequires = checkLevel11;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Context context1 = new com.google.javascript.rhino.Context();
        java.lang.Object obj2 = context1.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) -1, node7);
        boolean boolean9 = node8.isOnlyModifiesThisCall();
        context1.putThreadLocal((java.lang.Object) boolean9, (java.lang.Object) 'a');
        int int12 = context1.getInstructionObserverThreshold();
        java.util.Locale locale13 = null;
        java.util.Locale locale14 = context1.setLocale(locale13);
        try {
            java.lang.String str15 = com.google.javascript.rhino.ScriptRuntime.getMessage1(": ", (java.lang.Object) locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property : ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(locale14);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        compiler2.reportCodeChange();
        try {
            com.google.javascript.jscomp.Region region8 = compiler2.getSourceRegion("<No stack trace available>", 36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.error("language version", "NUMBER 1.0 0");
//        boolean boolean4 = diagnosticGroup0.matches(diagnosticType3);
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean3 = compilerOptions0.checkTypes;
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean5 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean50 = node49.wasEmptyNode();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean56 = node55.wasEmptyNode();
        com.google.javascript.rhino.Node node57 = node49.copyInformationFromForTree(node55);
        boolean boolean58 = node55.isOptionalArg();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection59 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node55);
        try {
            java.util.List<java.lang.String> strList60 = closureCodingConvention0.identifyTypeDeclarationCall(node55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(nodeCollection59);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup8;
        boolean boolean10 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
        java.lang.String str11 = diagnosticGroupWarningsGuard7.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DiagnosticGroup<internetExplorerChecks>(ERROR)" + "'", str11.equals("DiagnosticGroup<internetExplorerChecks>(ERROR)"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node11 = node6.copyInformationFromForTree(node10);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean14 = closureCodingConvention12.isPrivate("NUMBER 1.0 0");
        java.lang.String str15 = closureCodingConvention12.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention16 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) -1, node21);
        boolean boolean23 = node22.isOnlyModifiesThisCall();
        boolean boolean24 = defaultCodingConvention16.isPropertyTestFunction(node22);
        com.google.javascript.rhino.Node node25 = null;
        java.lang.String str26 = defaultCodingConvention16.getSingletonGetterClassName(node25);
        boolean boolean28 = defaultCodingConvention16.isSuperClassReference("hi!");
        java.lang.String str29 = defaultCodingConvention16.getExportPropertyFunction();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean35 = node34.wasEmptyNode();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean41 = node40.wasEmptyNode();
        com.google.javascript.rhino.Node node42 = node34.copyInformationFromForTree(node40);
        boolean boolean43 = node40.isOptionalArg();
        com.google.javascript.rhino.Node node44 = node40.cloneTree();
        java.lang.String str45 = defaultCodingConvention16.identifyTypeDefAssign(node44);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = closureCodingConvention12.getDelegateRelationship(node44);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention47 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean49 = closureCodingConvention47.isPrivate("NUMBER 1.0 0");
        java.lang.String str50 = closureCodingConvention47.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention51 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (byte) -1, node56);
        boolean boolean58 = node57.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention59 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (byte) -1, node64);
        boolean boolean66 = node65.isOnlyModifiesThisCall();
        boolean boolean67 = defaultCodingConvention59.isPropertyTestFunction(node65);
        com.google.javascript.rhino.Node node68 = node57.copyInformationFrom(node65);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship69 = closureCodingConvention51.getClassesDefinedByCall(node65);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str74 = closureCodingConvention47.extractClassNameIfProvide(node65, node73);
        boolean boolean75 = node44.isEquivalentTo(node73);
        java.lang.String str76 = node11.checkTreeEquals(node73);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(delegateRelationship46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "goog.abstractMethod" + "'", str50.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(subclassRelationship69);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n" + "'", str76.equals("Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n"));
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup8;
//        boolean boolean12 = composeWarningsGuard7.enables(diagnosticGroup8);
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray13 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup8 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = new com.google.javascript.jscomp.DiagnosticGroup("(Named type with empty name component)", diagnosticGroupArray13);
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup14;
//        org.junit.Assert.assertNotNull(diagnosticGroup1);
//        org.junit.Assert.assertNotNull(diagnosticGroup2);
//        org.junit.Assert.assertNotNull(diagnosticGroup3);
//        org.junit.Assert.assertNotNull(warningsGuardArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray13);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean17 = node16.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = node10.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) -1, node32);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(15, node18, node22, node27, node33, 10, 49);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.rhino.Node node39 = node38.removeChildren();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean51 = node50.wasEmptyNode();
        com.google.javascript.rhino.Node node52 = node44.copyInformationFromForTree(node50);
        boolean boolean53 = node50.isOptionalArg();
        try {
            com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(0, node4, node33, node38, node50, 0, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        compiler0.disableThreads();
//        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator7);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.ErrorFormat errorFormat12 = compilerOptions11.errorFormat;
//        compilerOptions11.gatherCssNames = false;
//        try {
//            compiler0.init(jSSourceFileArray9, jSModuleArray10, compilerOptions11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertNotNull(jSSourceFile8);
//        org.junit.Assert.assertNotNull(jSSourceFileArray9);
//        org.junit.Assert.assertNotNull(errorFormat12);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node13 = node12.getParent();
        try {
            boolean boolean14 = node13.isLocalResultCall();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        com.google.javascript.rhino.Node node65 = node31.getParent();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(node65);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("error reporter", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions22.checkMethods;
        compilerOptions22.inlineLocalFunctions = false;
        compilerOptions22.closurePass = true;
        java.util.Set<java.lang.String> strSet30 = compilerOptions22.stripNameSuffixes;
        node5.setDirectives(strSet30);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet30);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions19.checkMethods;
        compilerOptions19.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy25 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy26 = null;
        compilerOptions19.setRenamingPolicy(variableRenamingPolicy25, propertyRenamingPolicy26);
        boolean boolean28 = compilerOptions19.crossModuleMethodMotion;
        java.lang.String str29 = compilerOptions19.appNameStr;
        java.util.Set<java.lang.String> strSet30 = compilerOptions19.stripNamePrefixes;
        compilerOptions0.stripTypePrefixes = strSet30;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy25.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(strSet30);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        java.lang.String str10 = compilerOptions0.appNameStr;
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripNamePrefixes;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap12 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap12;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet11);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker7 = null;
//        compiler0.tracker = performanceTracker7;
//        try {
//            compiler0.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        compilerOptions0.inferTypesInGlobalScope = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.Node node22 = node20.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = null;
        try {
            node22.setJSDocInfo(jSDocInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.aggressiveVarCheck;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        boolean boolean12 = context0.isGeneratingDebug();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.ErrorManager errorManager7 = compiler0.getErrorManager();
//        boolean boolean8 = compiler0.acceptEcmaScript5();
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(errorManager7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        java.util.Locale locale12 = null;
        java.util.Locale locale13 = context0.setLocale(locale12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(locale13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        java.lang.Appendable appendable6 = null;
        try {
            node4.appendStringTree(appendable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter14 = context0.setErrorReporter(errorReporter13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        java.lang.String str33 = closureCodingConvention12.extractClassNameIfProvide(node17, node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship34 = defaultCodingConvention0.getClassesDefinedByCall(node17);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean42 = node41.wasEmptyNode();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean48 = node47.wasEmptyNode();
        com.google.javascript.rhino.Node node49 = node41.copyInformationFromForTree(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (byte) -1, node63);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(15, node49, node53, node58, node64, 10, 49);
        com.google.javascript.rhino.Node node68 = node58.detachFromParent();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean74 = node73.wasEmptyNode();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean80 = node79.wasEmptyNode();
        com.google.javascript.rhino.Node node81 = node73.copyInformationFromForTree(node79);
        node81.addSuppression("()");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node((int) (byte) -1, node88);
        boolean boolean90 = node89.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node93 = new com.google.javascript.rhino.Node(0, node58, node81, node89, 5, 8);
        node17.addChildToFront(node93);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(subclassRelationship34);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
//        compilerInput3.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
//        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
//        compilerInput9.clearAst();
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
//        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
//        boolean boolean16 = compiler11.hasErrors();
//        compiler11.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
//        compiler11.tracker = performanceTracker18;
//        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
//        try {
//            java.lang.String str21 = compilerInput9.getPathRelativeToClosureBase();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(jSModule6);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.lang.String str2 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("eof");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(eof)" + "'", str1.equals("(eof)"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags1.clearSideEffectFlags();
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node11 = node6.copyInformationFromForTree(node10);
        boolean boolean12 = node10.hasSideEffects();
        com.google.javascript.rhino.Node node13 = node10.getNext();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        boolean boolean8 = composeWarningsGuard3.enables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup4;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions13.checkMethods;
        compilerOptions13.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = null;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy19, propertyRenamingPolicy20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node54 = node44.cloneTree();
        com.google.javascript.rhino.Node node55 = node44.removeFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType56 = node44.getJSType();
        context0.putThreadLocal((java.lang.Object) compilerOptions13, (java.lang.Object) node44);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) -1, node62);
        node62.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node66 = node62.getLastSibling();
        int int67 = node62.getType();
        com.google.javascript.rhino.Node node68 = null;
        try {
            node44.replaceChildAfter(node62, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 39 + "'", int67 == 39);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        try {
            com.google.javascript.rhino.Node node6 = node4.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node9 = node5.getLastSibling();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) -1, node14);
        node14.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node18 = node14.getLastSibling();
        com.google.javascript.rhino.Node node19 = node18.cloneTree();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        node32.addSuppression("()");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean46 = node45.wasEmptyNode();
        com.google.javascript.rhino.Node node47 = node39.copyInformationFromForTree(node45);
        node47.setType(3);
        try {
            com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(15, node5, node19, node32, node47, 41, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
//        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
//        java.lang.String str13 = compiler6.toSource();
//        try {
//            compiler6.normalize();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertNotNull(jSErrorArray12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
//        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
//        java.lang.String str13 = compiler6.toSource();
//        java.nio.charset.Charset charset15 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
//        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
//        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream19 = null;
//        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
//        com.google.javascript.rhino.Node node23 = compiler20.getRoot();
//        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
//        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler20.getMessages();
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState26 = compiler20.getState();
//        compiler6.setState(intermediateState26);
//        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
//        com.google.javascript.jscomp.ErrorManager errorManager29 = compiler6.getErrorManager();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertNotNull(jSErrorArray12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile16);
//        org.junit.Assert.assertNotNull(errorFormat18);
//        org.junit.Assert.assertNotNull(messageFormatter22);
//        org.junit.Assert.assertNull(node23);
//        org.junit.Assert.assertNotNull(jSErrorArray25);
//        org.junit.Assert.assertNotNull(intermediateState26);
//        org.junit.Assert.assertNotNull(errorManager29);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        lightweightMessageFormatter3.setColorize(false);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter3, logger6);
        com.google.javascript.jscomp.JSError jSError8 = null;
        try {
            java.lang.String str9 = lightweightMessageFormatter3.formatWarning(jSError8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection14 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node10);
        try {
            node10.setSideEffectFlags(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeCollection14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        boolean boolean10 = node9.isOnlyModifiesThisCall();
        boolean boolean11 = defaultCodingConvention3.isPropertyTestFunction(node9);
        com.google.javascript.rhino.Node node12 = null;
        java.lang.String str13 = defaultCodingConvention3.getSingletonGetterClassName(node12);
        boolean boolean15 = defaultCodingConvention3.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node20.getJsDocBuilderForNode();
        boolean boolean22 = node20.hasOneChild();
        java.util.List<java.lang.String> strList23 = defaultCodingConvention3.identifyTypeDeclarationCall(node20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup24;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup24;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean28 = compilerOptions27.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray35 = null;
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType34, strArray35);
        com.google.javascript.jscomp.CheckLevel checkLevel38 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel38, "<No stack trace available>");
        diagnosticType34.level = checkLevel38;
        compilerOptions27.checkProvides = checkLevel38;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions27.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard44 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup24, checkLevel43);
        try {
            java.lang.String str45 = com.google.javascript.rhino.ScriptRuntime.getMessage4("window", (java.lang.Object) "RETURN 0\n", (java.lang.Object) 0, (java.lang.Object) node20, (java.lang.Object) diagnosticGroup24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property window");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(strList23);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = node38.copyInformationFromForTree(node44);
        node46.addSuppression("()");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        boolean boolean55 = node54.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, node23, node46, node54, 5, 8);
        com.google.javascript.rhino.Node node59 = node46.getFirstChild();
        int int60 = node46.getLineno();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.syntheticBlockEndMarker = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        int int2 = context0.getLanguageVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean10 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkSymbols = false;
        boolean boolean9 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("()", "goog.abstractMethod", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat1 = diagnosticType0.format;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(messageFormat1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) ancestorIterable2);
        org.junit.Assert.assertNotNull(ancestorIterable2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripTypes = strSet2;
        compilerOptions0.setLooseTypes(false);
        compilerOptions0.setDefineToDoubleLiteral("goog.exportProperty", (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing12 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        compilerOptions0.setTweakProcessing(tweakProcessing12);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing12 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing12.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        int int8 = ecmaError6.getLineNumber();
        java.lang.String str9 = ecmaError6.sourceName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        com.google.javascript.jscomp.JSModule jSModule5 = null;
//        try {
//            java.lang.String[] strArray6 = compiler0.toSourceArray(jSModule5);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray12 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup11 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray12);
        java.lang.Object obj14 = context0.getThreadLocal((java.lang.Object) diagnosticGroupArray12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray12);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroupArray12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        boolean boolean19 = node17.hasOneChild();
        java.util.List<java.lang.String> strList20 = defaultCodingConvention0.identifyTypeDeclarationCall(node17);
        com.google.javascript.rhino.Node node21 = node17.getLastChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(strList20);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        compiler2.reportCodeChange();
        try {
            java.lang.String[] strArray6 = compiler2.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        double double3 = loggerErrorManager1.getTypedPercent();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = closureCodingConvention0.getClassesDefinedByCall(node14);
        boolean boolean20 = closureCodingConvention0.isPrivate("window");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node26 = node24.getAncestor(9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) -1, node32);
        boolean boolean34 = node33.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention35 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        boolean boolean42 = node41.isOnlyModifiesThisCall();
        boolean boolean43 = defaultCodingConvention35.isPropertyTestFunction(node41);
        com.google.javascript.rhino.Node node44 = node33.copyInformationFrom(node41);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship45 = closureCodingConvention27.getClassesDefinedByCall(node41);
        com.google.javascript.rhino.Node node46 = node41.getLastChild();
        java.lang.String str47 = closureCodingConvention0.extractClassNameIfProvide(node24, node41);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        try {
            node41.removeChild(node51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(subclassRelationship45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(node51);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        java.lang.String str13 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node26 = node18.copyInformationFromForTree(node24);
        boolean boolean27 = node24.isOptionalArg();
        com.google.javascript.rhino.Node node28 = node24.cloneTree();
        java.lang.String str29 = defaultCodingConvention0.identifyTypeDefAssign(node28);
        boolean boolean31 = defaultCodingConvention0.isConstant("EOF  0");
        java.lang.String str32 = defaultCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = jSSourceFile2.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "language version" + "'", str3.equals("language version"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "language version" + "'", str6.equals("language version"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node13 = null;
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        node18.setVarArgs(false);
        try {
            node10.addChildAfter(node13, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        java.lang.String str5 = nodeTraversal2.getSourceName();
        int int6 = nodeTraversal2.getLineNumber();
        com.google.javascript.rhino.Node node7 = nodeTraversal2.getEnclosingFunction();
        java.util.List<com.google.javascript.rhino.Node> nodeList8 = null;
        try {
            nodeTraversal2.traverseRoots(nodeList8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard3 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup6;
        try {
            boolean boolean8 = diagnosticGroupWarningsGuard3.enables(diagnosticGroup6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.messageBundle = messageBundle5;
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker7 = null;
//        compiler0.tracker = performanceTracker7;
//        com.google.javascript.jscomp.JSModule jSModule9 = null;
//        try {
//            java.lang.String str10 = compiler0.toSource(jSModule9);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node28.getLastSibling();
        com.google.javascript.rhino.Node node33 = null;
        com.google.javascript.rhino.Node node34 = null;
        try {
            node28.replaceChild(node33, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        boolean boolean65 = node54.hasChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        java.util.logging.Logger logger7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.parsing.ParserRunner.parse("RETURN 0\n", "Named type with empty name component", config5, errorReporter6, logger7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean15 = node14.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean21 = node20.wasEmptyNode();
        com.google.javascript.rhino.Node node22 = node14.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) -1, node36);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(15, node22, node26, node31, node37, 10, 49);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = node22.children();
        com.google.javascript.rhino.Node node43 = node22.getAncestor(15);
        try {
            boolean boolean44 = defaultCodingConvention0.isVarArgsParameter(node43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNull(node43);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        java.lang.String str5 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable8 = node7.getAncestors();
        try {
            nodeTraversal2.traverse(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.checkTypes = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler18 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("(Named type with empty name component)", "(Named type with empty name component)", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("()", "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        java.lang.String str17 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) boolean16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "false" + "'", str17.equals("false"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        boolean boolean4 = closureCodingConvention0.isPrivate("");
        boolean boolean6 = closureCodingConvention0.isPrivate("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        boolean boolean6 = node4.hasOneChild();
        int int8 = node4.getIntProp((-1));
        java.lang.Appendable appendable9 = null;
        try {
            node4.appendStringTree(appendable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
//        compilerInput3.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
//        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
//        compilerInput9.clearAst();
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
//        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
//        boolean boolean16 = compiler11.hasErrors();
//        compiler11.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
//        compiler11.tracker = performanceTracker18;
//        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
//        com.google.javascript.rhino.Node node21 = compiler11.getRoot();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(jSModule6);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(node21);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(16, "NUMBER 1.0 0");
        node2.setType((int) (short) 100);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format6 = compilerOptions0.sourceMapFormat;
        boolean boolean7 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 22");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = null;
        try {
            compiler0.setState(intermediateState1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean21 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions13.checkMethods;
        compilerOptions13.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = null;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy19, propertyRenamingPolicy20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node54 = node44.cloneTree();
        com.google.javascript.rhino.Node node55 = node44.removeFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType56 = node44.getJSType();
        context0.putThreadLocal((java.lang.Object) compilerOptions13, (java.lang.Object) node44);
        java.lang.String str58 = compilerOptions13.aliasableGlobals;
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Object obj0 = null;
        java.lang.Object obj1 = null;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError(obj0, obj1);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.labelRenaming = false;
        compilerOptions0.nameReferenceGraphPath = "hi!";
        compilerOptions0.setSummaryDetailLevel((int) (byte) 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj5 = context0.getThreadLocal((java.lang.Object) tweakProcessing4);
        boolean boolean6 = context0.isGeneratingDebugChanged();
        boolean boolean7 = context0.isGeneratingDebugChanged();
        int int8 = context0.getLanguageVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention12 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        boolean boolean19 = node18.isOnlyModifiesThisCall();
        boolean boolean20 = defaultCodingConvention12.isPropertyTestFunction(node18);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node18);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = closureCodingConvention4.getClassesDefinedByCall(node18);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node18, node26);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = null;
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node41 = node33.copyInformationFromForTree(node39);
        node41.addSuppression("()");
        com.google.javascript.rhino.Node node44 = node41.cloneTree();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast45 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal28, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        java.lang.String str5 = composeWarningsGuard3.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup6 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
        boolean boolean9 = composeWarningsGuard3.enables(diagnosticGroup8);
        java.lang.String str10 = composeWarningsGuard3.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        int int13 = context0.getLanguageVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        boolean boolean19 = node13.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node20 = node13.getLastSibling();
        com.google.javascript.rhino.Node node21 = node20.getNext();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        java.lang.String str23 = defaultCodingConvention0.getGlobalObject();
        boolean boolean25 = defaultCodingConvention0.isConstant("language version: language version");
        java.lang.String str26 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) boolean25);
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "window" + "'", str23.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "false" + "'", str26.equals("false"));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean2 = compilerOptions1.moveFunctionDeclarations;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        java.lang.String[] strArray9 = null;
//        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType8, strArray9);
//        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel12, "<No stack trace available>");
//        diagnosticType8.level = checkLevel12;
//        compilerOptions1.checkProvides = checkLevel12;
//        boolean boolean17 = compilerOptions1.removeEmptyFunctions;
//        compilerOptions1.checkEs5Strict = false;
//        boolean boolean20 = compilerOptions1.checkUnusedPropertiesEarly;
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node26.getJsDocBuilderForNode();
//        int int28 = node26.getChildCount();
//        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean34 = node33.wasEmptyNode();
//        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean40 = node39.wasEmptyNode();
//        com.google.javascript.rhino.Node node41 = node33.copyInformationFromForTree(node39);
//        java.lang.String str42 = closureCodingConvention21.extractClassNameIfProvide(node26, node41);
//        java.nio.charset.Charset charset44 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset44);
//        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45);
//        com.google.javascript.jscomp.ErrorManager errorManager47 = null;
//        compilerInput46.setErrorManager(errorManager47);
//        com.google.javascript.jscomp.JSModule jSModule49 = compilerInput46.getModule();
//        com.google.javascript.jscomp.CompilerInput compilerInput52 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput46, "", false);
//        compilerInput52.clearAst();
//        com.google.javascript.jscomp.Compiler compiler54 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset56 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset56);
//        com.google.javascript.rhino.Node node58 = compiler54.parse(jSSourceFile57);
//        boolean boolean59 = compiler54.hasErrors();
//        compiler54.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker61 = null;
//        compiler54.tracker = performanceTracker61;
//        compilerInput52.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler54);
//        try {
//            java.lang.String str64 = com.google.javascript.rhino.ScriptRuntime.getMessage3("", (java.lang.Object) boolean20, (java.lang.Object) node26, (java.lang.Object) compilerInput52);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(diagnosticType8);
//        org.junit.Assert.assertNotNull(jSError10);
//        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(node41);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertNotNull(jSSourceFile45);
//        org.junit.Assert.assertNull(jSModule49);
//        org.junit.Assert.assertNotNull(jSSourceFile57);
//        org.junit.Assert.assertNull(node58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.nameReferenceGraphPath = "error reporter";
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        boolean boolean8 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler2.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        try {
            boolean boolean6 = compiler2.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(messageFormatter5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.Node node22 = node20.getLastChild();
        try {
            node22.setSideEffectFlags(48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags6 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags6.clearAllFlags();
        boolean boolean8 = sideEffectFlags6.areAllFlagsSet();
        java.lang.Object obj9 = null;
        try {
            context0.putThreadLocal((java.lang.Object) boolean8, obj9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions13.checkMethods;
        compilerOptions13.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = null;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy19, propertyRenamingPolicy20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node54 = node44.cloneTree();
        com.google.javascript.rhino.Node node55 = node44.removeFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType56 = node44.getJSType();
        context0.putThreadLocal((java.lang.Object) compilerOptions13, (java.lang.Object) node44);
        boolean boolean58 = context0.isSealed();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node5 = null;
        try {
            com.google.javascript.rhino.Node node6 = node4.copyInformationFrom(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        node15.setType((int) (byte) 10);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention36 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) -1, node41);
        boolean boolean43 = node42.isOnlyModifiesThisCall();
        boolean boolean44 = defaultCodingConvention36.isPropertyTestFunction(node42);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal45 = null;
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean51 = node50.wasEmptyNode();
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast52 = defaultCodingConvention36.getObjectLiteralCast(nodeTraversal45, node50);
        node15.addChildToFront(node50);
        com.google.javascript.rhino.Node node54 = node50.cloneNode();
        try {
            com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, node1, node54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(objectLiteralCast52);
        org.junit.Assert.assertNotNull(node54);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(49);
        boolean boolean2 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setMutatesThis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node11 = node6.copyInformationFromForTree(node10);
        try {
            java.lang.String str12 = node10.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 23.0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        java.lang.Class<?> wildcardClass38 = sourceFile36.getClass();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkTypes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        int int32 = node17.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setTweakToStringLiteral("-1", "(Named type with empty name component)");
        compilerOptions0.closurePass = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        try {
            com.google.javascript.rhino.Context.reportWarning("false");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        int int17 = ecmaError14.getLineNumber();
        java.lang.String str18 = ecmaError14.lineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.nameReferenceGraphPath = "error reporter";
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
        java.lang.String str11 = compilerInput3.getLine(41);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(2, "Unknown class name");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.checkEs5Strict = false;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.nameReferenceReportPath = "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        java.lang.String str33 = closureCodingConvention12.extractClassNameIfProvide(node17, node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship34 = defaultCodingConvention0.getClassesDefinedByCall(node17);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) -1, node39);
        node39.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node43 = node39.getLastSibling();
        java.util.List<java.lang.String> strList44 = defaultCodingConvention0.identifyTypeDeclarationCall(node43);
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType47 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType48 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType49 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType45, objectType46, objectType47, functionType48, functionType49);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(subclassRelationship34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(strList44);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        int int17 = ecmaError6.lineNumber();
        int int18 = ecmaError6.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
//        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
//        java.lang.String str13 = compiler6.toSource();
//        java.nio.charset.Charset charset15 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
//        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
//        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream19 = null;
//        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
//        com.google.javascript.rhino.Node node23 = compiler20.getRoot();
//        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
//        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler20.getMessages();
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState26 = compiler20.getState();
//        compiler6.setState(intermediateState26);
//        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
//        int int29 = compiler6.getWarningCount();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertNotNull(jSErrorArray12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile16);
//        org.junit.Assert.assertNotNull(errorFormat18);
//        org.junit.Assert.assertNotNull(messageFormatter22);
//        org.junit.Assert.assertNull(node23);
//        org.junit.Assert.assertNotNull(jSErrorArray25);
//        org.junit.Assert.assertNotNull(intermediateState26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions4.inlineLocalFunctions = false;
        compilerOptions4.closurePass = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripNameSuffixes;
        java.lang.String str13 = compilerOptions4.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions14.errorFormat;
        java.lang.String[] strArray19 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions14.stripNamePrefixes = strSet20;
        compilerOptions4.aliasableStrings = strSet20;
        compilerOptions0.stripTypes = strSet20;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
        compilerOptions0.checkUndefinedProperties = checkLevel25;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean29 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        boolean boolean6 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.checkMissingGetCssNameBlacklist = "NUMBER 1.0 0";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = node28.getJSDocInfo();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSDocInfo32);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        java.lang.String[] strArray16 = null;
//        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType15, strArray16);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
//        java.lang.String[] strArray24 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType23, strArray24);
//        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType15, strArray24);
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = compiler0.getErrorLevel(jSError26);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        int int34 = diagnosticType30.compareTo(diagnosticType33);
//        com.google.javascript.jscomp.CheckLevel checkLevel36 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel36, "<No stack trace available>");
//        diagnosticType30.level = checkLevel36;
//        java.io.PrintStream printStream40 = null;
//        com.google.javascript.jscomp.Compiler compiler41 = new com.google.javascript.jscomp.Compiler(printStream40);
//        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt42 = null;
//        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter43 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler41, sourceExcerpt42);
//        lightweightMessageFormatter43.setColorize(false);
//        try {
//            java.lang.String str46 = jSError26.format(checkLevel36, (com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(diagnosticType15);
//        org.junit.Assert.assertNotNull(jSError17);
//        org.junit.Assert.assertNotNull(diagnosticType23);
//        org.junit.Assert.assertNotNull(strArray24);
//        org.junit.Assert.assertNotNull(jSError25);
//        org.junit.Assert.assertNotNull(jSError26);
//        org.junit.Assert.assertNull(checkLevel27);
//        org.junit.Assert.assertNotNull(diagnosticType30);
//        org.junit.Assert.assertNotNull(diagnosticType33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType38);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        java.lang.String str19 = runtimeException18.toString();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: Cannot set property \"NUMBER 52.0 0\" of false to \"NUMBER 52.0 0\"" + "'", str19.equals("com.google.javascript.rhino.EcmaError: TypeError: Cannot set property \"NUMBER 52.0 0\" of false to \"NUMBER 52.0 0\""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean5 = tweakProcessing4.isOn();
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.lineLengthThreshold(1);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean51 = node50.wasEmptyNode();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean57 = node56.wasEmptyNode();
        com.google.javascript.rhino.Node node58 = node50.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) (byte) -1, node72);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(15, node58, node62, node67, node73, 10, 49);
        com.google.javascript.rhino.Node node77 = node73.getLastSibling();
        com.google.javascript.rhino.Node node78 = node77.getLastChild();
        boolean boolean79 = closureCodingConvention0.isOptionalParameter(node78);
        com.google.javascript.rhino.Node node80 = node78.removeFirstChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(node80);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean51 = node50.wasEmptyNode();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean57 = node56.wasEmptyNode();
        com.google.javascript.rhino.Node node58 = node50.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) (byte) -1, node72);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(15, node58, node62, node67, node73, 10, 49);
        com.google.javascript.rhino.Node node77 = node73.getLastSibling();
        com.google.javascript.rhino.Node node78 = node77.getLastChild();
        boolean boolean79 = closureCodingConvention0.isOptionalParameter(node78);
        com.google.javascript.rhino.Node node80 = node78.cloneNode();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node80);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(4, 0, 1);
        java.lang.String str4 = node3.toStringTree();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean17 = node16.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = node10.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) -1, node32);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(15, node18, node22, node27, node33, 10, 49);
        com.google.javascript.rhino.Node node37 = node27.cloneTree();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention38 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node39 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship40 = defaultCodingConvention38.getClassesDefinedByCall(node39);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean47 = node46.wasEmptyNode();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean53 = node52.wasEmptyNode();
        com.google.javascript.rhino.Node node54 = node46.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((int) (byte) -1, node68);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(15, node54, node58, node63, node69, 10, 49);
        node54.setType(0);
        java.lang.String str75 = defaultCodingConvention38.getSingletonGetterClassName(node54);
        try {
            node3.addChildBefore(node37, node54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RETURN 0\n" + "'", str4.equals("RETURN 0\n"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(subclassRelationship40);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(str75);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        boolean boolean4 = closureCodingConvention0.isPrivate("");
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean21 = node20.wasEmptyNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean27 = node26.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = node20.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) -1, node42);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(15, node28, node32, node37, node43, 10, 49);
        java.lang.String str47 = closureCodingConvention7.extractClassNameIfRequire(node14, node43);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship48 = closureCodingConvention0.getClassesDefinedByCall(node43);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(subclassRelationship48);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = node38.copyInformationFromForTree(node44);
        node46.addSuppression("()");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        boolean boolean55 = node54.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, node23, node46, node54, 5, 8);
        com.google.javascript.rhino.Node node59 = node46.getFirstChild();
        try {
            node59.setVarArgs(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(node59);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean10 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) -1, node20);
        boolean boolean22 = node21.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention23 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        boolean boolean30 = node29.isOnlyModifiesThisCall();
        boolean boolean31 = defaultCodingConvention23.isPropertyTestFunction(node29);
        com.google.javascript.rhino.Node node32 = node21.copyInformationFrom(node29);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = closureCodingConvention15.getClassesDefinedByCall(node29);
        com.google.javascript.rhino.Node node34 = node29.getLastChild();
        boolean boolean35 = node14.isEquivalentTo(node29);
        java.util.Set<java.lang.String> strSet36 = null;
        node14.setDirectives(strSet36);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(subclassRelationship33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        try {
            node54.setSideEffectFlags(35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        java.lang.String str19 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.rewriteFunctionExpressions = false;
        boolean boolean22 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        boolean boolean12 = defaultCodingConvention4.isPropertyTestFunction(node10);
        com.google.javascript.rhino.Node node13 = null;
        java.lang.String str14 = defaultCodingConvention4.getSingletonGetterClassName(node13);
        boolean boolean16 = defaultCodingConvention4.isSuperClassReference("hi!");
        java.lang.String str17 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        boolean boolean31 = node28.isOptionalArg();
        com.google.javascript.rhino.Node node32 = node28.cloneTree();
        java.lang.String str33 = defaultCodingConvention4.identifyTypeDefAssign(node32);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention0.getDelegateRelationship(node32);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention35 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean37 = closureCodingConvention35.isPrivate("NUMBER 1.0 0");
        java.lang.String str38 = closureCodingConvention35.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention39 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (byte) -1, node44);
        boolean boolean46 = node45.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention47 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) -1, node52);
        boolean boolean54 = node53.isOnlyModifiesThisCall();
        boolean boolean55 = defaultCodingConvention47.isPropertyTestFunction(node53);
        com.google.javascript.rhino.Node node56 = node45.copyInformationFrom(node53);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship57 = closureCodingConvention39.getClassesDefinedByCall(node53);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str62 = closureCodingConvention35.extractClassNameIfProvide(node53, node61);
        boolean boolean63 = node32.isEquivalentTo(node61);
        node32.setOptionalArg(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "goog.abstractMethod" + "'", str38.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(subclassRelationship57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
//        compilerInput3.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
//        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
//        compilerInput9.clearAst();
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
//        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
//        boolean boolean16 = compiler11.hasErrors();
//        compiler11.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
//        compiler11.tracker = performanceTracker18;
//        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version: language version");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.ErrorFormat errorFormat25 = compilerOptions24.errorFormat;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy26 = compilerOptions24.variableRenaming;
//        boolean boolean27 = compilerOptions24.removeEmptyFunctions;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions28.moveFunctionDeclarations = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions28.checkMethods;
//        compilerOptions28.inlineLocalFunctions = false;
//        compilerOptions28.closurePass = true;
//        java.util.Set<java.lang.String> strSet36 = compilerOptions28.stripNameSuffixes;
//        java.lang.String str37 = compilerOptions28.syntheticBlockEndMarker;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.ErrorFormat errorFormat39 = compilerOptions38.errorFormat;
//        java.lang.String[] strArray43 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
//        java.util.LinkedHashSet<java.lang.String> strSet44 = new java.util.LinkedHashSet<java.lang.String>();
//        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet44, strArray43);
//        compilerOptions38.stripNamePrefixes = strSet44;
//        compilerOptions28.aliasableStrings = strSet44;
//        compilerOptions24.setIdGenerators((java.util.Set<java.lang.String>) strSet44);
//        try {
//            com.google.javascript.jscomp.Result result49 = compiler11.compile(jSSourceFile21, jSSourceFile23, compilerOptions24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(jSModule6);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(jSSourceFile23);
//        org.junit.Assert.assertNotNull(errorFormat25);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy26 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy26.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(strSet36);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNotNull(errorFormat39);
//        org.junit.Assert.assertNotNull(strArray43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup8;
//        boolean boolean12 = composeWarningsGuard7.enables(diagnosticGroup8);
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray13 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup8 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = new com.google.javascript.jscomp.DiagnosticGroup("(Named type with empty name component)", diagnosticGroupArray13);
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup14;
//        org.junit.Assert.assertNotNull(diagnosticGroup1);
//        org.junit.Assert.assertNotNull(diagnosticGroup2);
//        org.junit.Assert.assertNotNull(diagnosticGroup3);
//        org.junit.Assert.assertNotNull(warningsGuardArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray13);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        node18.setJSType(jSType20);
        try {
            com.google.javascript.rhino.Node node22 = node10.getChildBefore(node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        boolean boolean10 = defaultCodingConvention0.isExported("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node15.getJsDocBuilderForNode();
        int int17 = node15.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType18 = node15.getJSType();
        java.util.List<java.lang.String> strList19 = defaultCodingConvention0.identifyTypeDeclarationCall(node15);
        boolean boolean21 = defaultCodingConvention0.isExported("RETURN 0\n");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNull(strList19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean8 = compilerOptions0.removeUnusedVars;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing9 = compilerOptions0.getTweakProcessing();
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing9.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        compilerOptions0.instrumentationTemplate = "// Input %num%";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node4.siblings();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeIterable5);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        java.lang.String str13 = defaultCodingConvention0.getExportPropertyFunction();
        boolean boolean15 = defaultCodingConvention0.isExported("language version");
        boolean boolean17 = defaultCodingConvention0.isValidEnumKey("Unknown class name");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.Object obj5 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable38 = node34.getAncestors();
        java.lang.RuntimeException runtimeException39 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, obj5, (java.lang.Object) node34);
        boolean boolean40 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(ancestorIterable38);
        org.junit.Assert.assertNotNull(runtimeException39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler2.tracker;
        try {
            boolean boolean7 = compiler2.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj5 = context0.getThreadLocal((java.lang.Object) tweakProcessing4);
        boolean boolean6 = tweakProcessing4.isOn();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }
}

