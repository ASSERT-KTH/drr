import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler18 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(aliasTransformationHandler18);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.EcmaError ecmaError19 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int20 = ecmaError19.columnNumber();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) "hi!", (java.lang.Object) ecmaError19);
        java.lang.String str22 = ecmaError19.lineSource();
        int int23 = ecmaError19.lineNumber();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(ecmaError19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.closurePass = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertNotNull(errorFormat1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("NUMBER 1.0 0", "Not declared as a type name", 0, "", 5);
        int int6 = evaluatorException5.lineNumber();
        java.lang.Class<?> wildcardClass7 = evaluatorException5.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        boolean boolean14 = context0.isActivationNeeded("NUMBER 1.0 0: <No stack trace available>");
        com.google.javascript.rhino.Context context15 = com.google.javascript.rhino.Context.enter(context0);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(context15);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        compilerInput3.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning(": ", ": ");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray9 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType8, strArray9);
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray9);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(jSError11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        node5.setLineno((int) 'a');
        node5.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        java.lang.String str19 = compilerOptions0.locale;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy20;
        compilerOptions0.lineLengthThreshold(45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy20 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy20.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        compilerOptions0.tightenTypes = true;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setRemoveClosureAsserts(true);
        compilerOptions0.computeFunctionSideEffects = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        boolean boolean8 = compilerOptions0.reserveRawExports;
        java.util.Set<java.lang.String> strSet9 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState12 = compiler6.getState();
//        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler6.getSourceMap();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertNotNull(intermediateState12);
//        org.junit.Assert.assertNull(sourceMap13);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.reserveRawExports = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("(Named type with empty name component)", "hi!", "or");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        boolean boolean10 = defaultCodingConvention0.isExported("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node15.getJsDocBuilderForNode();
        int int17 = node15.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType18 = node15.getJSType();
        java.util.List<java.lang.String> strList19 = defaultCodingConvention0.identifyTypeDeclarationCall(node15);
        node15.setCharno(36);
        java.lang.Appendable appendable22 = null;
        try {
            node15.appendStringTree(appendable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNull(strList19);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(27);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
//        compilerInput3.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
//        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
//        compilerInput9.clearAst();
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
//        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
//        boolean boolean16 = compiler11.hasErrors();
//        compiler11.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
//        compiler11.tracker = performanceTracker18;
//        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
//        compiler11.disableThreads();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(jSModule6);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("(eof)", "", 34);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.setRemoveClosureAsserts(false);
//        compilerOptions0.disableRuntimeTypeCheck();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
//        boolean boolean7 = compilerOptions4.removeEmptyFunctions;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions8.moveFunctionDeclarations = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
//        compilerOptions8.inlineLocalFunctions = false;
//        compilerOptions8.closurePass = true;
//        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
//        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
//        java.lang.String[] strArray23 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
//        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
//        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
//        compilerOptions18.stripNamePrefixes = strSet24;
//        compilerOptions8.aliasableStrings = strSet24;
//        compilerOptions4.stripTypes = strSet24;
//        compilerOptions0.stripTypePrefixes = strSet24;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup30;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup30;
//        com.google.javascript.jscomp.CheckLevel checkLevel34 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel34, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard37 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup30, checkLevel34);
//        java.lang.RuntimeException runtimeException38 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) checkLevel34);
//        compilerOptions0.checkShadowVars = checkLevel34;
//        org.junit.Assert.assertNotNull(errorFormat5);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(strSet16);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(errorFormat19);
//        org.junit.Assert.assertNotNull(strArray23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNull(diagnosticGroup30);
//        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType36);
//        org.junit.Assert.assertNotNull(runtimeException38);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean10 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkUndefinedProperties;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.inferTypesInGlobalScope;
        compilerOptions13.setColorizeErrorOutput(false);
        boolean boolean17 = compilerOptions13.generateExports;
        boolean boolean18 = compilerOptions13.generatePseudoNames;
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions13.errorFormat = errorFormat19;
        compilerOptions0.errorFormat = errorFormat19;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(errorFormat19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions0.checkShadowVars = checkLevel7;
        compilerOptions0.aliasStringsBlacklist = "Named type with empty name component";
        compilerOptions0.checkCaja = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        java.lang.String str23 = defaultCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean30 = node29.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean36 = node35.wasEmptyNode();
        com.google.javascript.rhino.Node node37 = node29.copyInformationFromForTree(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (byte) -1, node51);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(15, node37, node41, node46, node52, 10, 49);
        node37.setType(0);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship58 = defaultCodingConvention0.getClassesDefinedByCall(node37);
        com.google.javascript.rhino.Node node59 = node37.removeFirstChild();
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "window" + "'", str23.equals("window"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(subclassRelationship58);
        org.junit.Assert.assertNull(node59);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        compilerOptions0.setDefineToBooleanLiteral("EOF  0", true);
        compilerOptions0.optimizeCalls = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        java.lang.String str17 = ecmaError14.toString();
        int int18 = ecmaError14.lineNumber();
        java.lang.String str19 = ecmaError14.getName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str17.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        boolean boolean12 = defaultCodingConvention4.isPropertyTestFunction(node10);
        com.google.javascript.rhino.Node node13 = null;
        java.lang.String str14 = defaultCodingConvention4.getSingletonGetterClassName(node13);
        boolean boolean16 = defaultCodingConvention4.isSuperClassReference("hi!");
        java.lang.String str17 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        boolean boolean31 = node28.isOptionalArg();
        com.google.javascript.rhino.Node node32 = node28.cloneTree();
        java.lang.String str33 = defaultCodingConvention4.identifyTypeDefAssign(node32);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention0.getDelegateRelationship(node32);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection35 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        node40.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node44 = node40.getLastSibling();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node40.getJsDocBuilderForNode();
        boolean boolean46 = closureCodingConvention0.isOptionalParameter(node40);
        boolean boolean47 = node40.isQuotedString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        boolean boolean9 = defaultCodingConvention1.isPropertyTestFunction(node7);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(29, node7);
        java.util.Set<java.lang.String> strSet11 = node7.getDirectives();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(strSet11);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test030");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup8;
//        boolean boolean10 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
//        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node16.getJsDocBuilderForNode();
//        int int18 = node16.getChildCount();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
//        java.lang.String[] strArray25 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType24, strArray25);
//        java.lang.String[] strArray27 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node16, diagnosticType24, strArray27);
//        int int29 = jSError28.lineNumber;
//        int int30 = jSError28.getCharno();
//        try {
//            com.google.javascript.jscomp.CheckLevel checkLevel31 = diagnosticGroupWarningsGuard7.level(jSError28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(diagnosticType24);
//        org.junit.Assert.assertNotNull(strArray25);
//        org.junit.Assert.assertNotNull(jSError26);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertNotNull(jSError28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        java.nio.charset.Charset charset12 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
//        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
//        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
//        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
//        jSSourceFile13.clearCachedSource();
//        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
//        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput22, "NUMBER 1.0 0: <No stack trace available>", true);
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSSourceFile13);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNull(region18);
//        org.junit.Assert.assertNull(node20);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        boolean boolean2 = compilerOptions0.checkControlStructures;
        compilerOptions0.printInputDelimiter = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean6 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        java.lang.String str38 = sourceFile36.toString();
        sourceFile36.setOriginalPath("1b");
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "()" + "'", str38.equals("()"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        boolean boolean9 = node8.hasSideEffects();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions4.inlineLocalFunctions = false;
        compilerOptions4.closurePass = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripNameSuffixes;
        java.lang.String str13 = compilerOptions4.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions14.errorFormat;
        java.lang.String[] strArray19 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions14.stripNamePrefixes = strSet20;
        compilerOptions4.aliasableStrings = strSet20;
        compilerOptions0.stripTypes = strSet20;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
        compilerOptions0.checkUndefinedProperties = checkLevel25;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean29 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean31 = compilerOptions30.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray38 = null;
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType37, strArray38);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel41, "<No stack trace available>");
        diagnosticType37.level = checkLevel41;
        compilerOptions30.checkProvides = checkLevel41;
        compilerOptions30.setCollapsePropertiesOnExternTypes(false);
        compilerOptions30.setShadowVariables(true);
        compilerOptions30.reserveRawExports = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode52 = compilerOptions30.tracer;
        compilerOptions0.tracer = tracerMode52;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertTrue("'" + tracerMode52 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode52.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.ambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean7 = node6.wasEmptyNode();
//        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean13 = node12.wasEmptyNode();
//        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
//        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
//        node14.setType((int) (byte) 10);
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention35 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
//        boolean boolean42 = node41.isOnlyModifiesThisCall();
//        boolean boolean43 = defaultCodingConvention35.isPropertyTestFunction(node41);
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal44 = null;
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean50 = node49.wasEmptyNode();
//        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast51 = defaultCodingConvention35.getObjectLiteralCast(nodeTraversal44, node49);
//        node14.addChildToFront(node49);
//        com.google.javascript.rhino.Node node53 = node49.cloneNode();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup54 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup54;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup54;
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel58, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard61 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup54, checkLevel58);
//        java.lang.RuntimeException runtimeException62 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) checkLevel58);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        java.lang.String[] strArray66 = null;
//        com.google.javascript.jscomp.JSError jSError67 = com.google.javascript.jscomp.JSError.make("error reporter", node53, checkLevel58, diagnosticType65, strArray66);
//        com.google.javascript.jscomp.CheckLevel checkLevel68 = diagnosticType65.level;
//        org.junit.Assert.assertNotNull(node6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(node12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(node14);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertNotNull(node40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNull(objectLiteralCast51);
//        org.junit.Assert.assertNotNull(node53);
//        org.junit.Assert.assertNull(diagnosticGroup54);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType60);
//        org.junit.Assert.assertNotNull(runtimeException62);
//        org.junit.Assert.assertNotNull(diagnosticType65);
//        org.junit.Assert.assertNotNull(jSError67);
//        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
//        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
//        try {
//            com.google.javascript.jscomp.Region region15 = compiler6.getSourceRegion("@IMPLEMENTATION.VERSION@", 13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertNotNull(jSErrorArray12);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        boolean boolean5 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.inlineLocalVariables = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions0.checkMethods = checkLevel8;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap1 = compilerOptions0.getTweakReplacements();
        java.lang.String str2 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNotNull(strMap1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 23);
        boolean boolean6 = context0.hasCompileFunctionsWithDynamicScope();
        int int7 = context0.getInstructionObserverThreshold();
        boolean boolean8 = context0.isGeneratingSource();
        boolean boolean10 = context0.isActivationNeeded("<No stack trace available>");
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        boolean boolean49 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        boolean boolean51 = closureCodingConvention0.isConstantKey("false");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) 13);
        java.lang.String str54 = closureCodingConvention0.identifyTypeDefAssign(node53);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(str54);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
//        boolean boolean7 = node6.isOnlyModifiesThisCall();
//        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
//        com.google.javascript.rhino.Node node9 = null;
//        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
//        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
//        com.google.javascript.rhino.EcmaError ecmaError19 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
//        int int20 = ecmaError19.columnNumber();
//        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) "hi!", (java.lang.Object) ecmaError19);
//        java.lang.String str22 = ecmaError19.lineSource();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup23;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup23;
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel27, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel27);
//        java.lang.RuntimeException runtimeException31 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) checkLevel27);
//        ecmaError19.addSuppressed((java.lang.Throwable) runtimeException31);
//        java.lang.String str33 = ecmaError19.toString();
//        java.lang.String str34 = ecmaError19.details();
//        org.junit.Assert.assertNotNull(node5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(ecmaError19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
//        org.junit.Assert.assertNotNull(runtimeException21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
//        org.junit.Assert.assertNull(diagnosticGroup23);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType29);
//        org.junit.Assert.assertNotNull(runtimeException31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str33.equals("com.google.javascript.rhino.EcmaError: : "));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + ": " + "'", str34.equals(": "));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("eof", "window");
        java.lang.String str3 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eof" + "'", str3.equals("eof"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        node8.putProp((int) (short) 0, (java.lang.Object) (byte) 100);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) -1, node20);
        node20.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node24 = node20.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = null;
        node24.setJSDocInfo(jSDocInfo25);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean33 = node32.wasEmptyNode();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node40 = node32.copyInformationFromForTree(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (byte) -1, node54);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(15, node40, node44, node49, node55, 10, 49);
        com.google.javascript.rhino.Node node59 = node58.cloneNode();
        node58.putIntProp(47, 15);
        java.lang.String str63 = node24.checkTreeEquals(node58);
        boolean boolean64 = node58.isUnscopedQualifiedName();
        boolean boolean65 = node8.isEquivalentToTyped(node58);
        try {
            node58.setString(": ");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: LE 10 [directives: 15] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n" + "'", str63.equals("Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        node54.setSourcePositionForTree((-34));
        com.google.javascript.rhino.Node node67 = node54.cloneTree();
        node67.detachChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        java.nio.charset.Charset charset12 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
//        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
//        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
//        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
//        jSSourceFile13.clearCachedSource();
//        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
//        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
//        java.lang.Object[] objArray23 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
//        java.lang.Object obj24 = null;
//        java.lang.RuntimeException runtimeException25 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) jSSourceFile13, (java.lang.Object) objArray23, obj24);
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSSourceFile13);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNull(region18);
//        org.junit.Assert.assertNull(node20);
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertNotNull(runtimeException25);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference(": ");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler6 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler6, callback7);
        boolean boolean9 = nodeTraversal8.hasScope();
        int int10 = nodeTraversal8.getLineNumber();
        com.google.javascript.jscomp.Compiler compiler11 = nodeTraversal8.getCompiler();
        com.google.javascript.jscomp.Scope scope12 = nodeTraversal8.getScope();
        com.google.javascript.rhino.Node node13 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast14 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal8, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(compiler11);
        org.junit.Assert.assertNull(scope12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        com.google.javascript.rhino.Context context6 = new com.google.javascript.rhino.Context();
        java.lang.Object obj7 = context6.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context6, (long) (short) 10);
        int int10 = context6.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) -1, node15);
        node15.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node19 = node15.getLastSibling();
        com.google.javascript.rhino.Node node20 = node19.cloneTree();
        context6.seal((java.lang.Object) node20);
        com.google.javascript.rhino.jstype.JSType jSType22 = node20.getJSType();
        boolean boolean23 = node20.isVarArgs();
        boolean boolean24 = node4.hasChild(node20);
        java.lang.Appendable appendable25 = null;
        try {
            node20.appendStringTree(appendable25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("NUMBER 52.0 0", "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", 30);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(49);
        sideEffectFlags1.setMutatesThis();
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        boolean boolean49 = closureCodingConvention0.isValidEnumKey("()");
        java.lang.String str50 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) -1, node55);
        boolean boolean57 = node56.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention58 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (byte) -1, node63);
        boolean boolean65 = node64.isOnlyModifiesThisCall();
        boolean boolean66 = defaultCodingConvention58.isPropertyTestFunction(node64);
        com.google.javascript.rhino.Node node67 = node56.copyInformationFrom(node64);
        boolean boolean68 = node67.hasMoreThanOneChild();
        java.util.List<java.lang.String> strList69 = closureCodingConvention0.identifyTypeDeclarationCall(node67);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection70 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "goog.exportProperty" + "'", str50.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(strList69);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection70);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions0.checkRequires = checkLevel11;
        compilerOptions0.moveFunctionDeclarations = true;
        byte[] byteArray15 = compilerOptions0.inputPropertyMapSerialized;
        boolean boolean16 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.checkProvides = checkLevel12;
        compilerOptions0.collapseAnonymousFunctions = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.markAsCompiled = true;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray26 = null;
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType25, strArray26);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel29, "<No stack trace available>");
        diagnosticType25.level = checkLevel29;
        compilerOptions18.checkProvides = checkLevel29;
        compilerOptions18.setCollapsePropertiesOnExternTypes(false);
        boolean boolean36 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat38 = compilerOptions37.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy39 = compilerOptions37.variableRenaming;
        java.lang.String str40 = compilerOptions37.jsOutputFile;
        compilerOptions37.crossModuleCodeMotion = true;
        boolean boolean43 = compilerOptions37.extractPrototypeMemberDeclarations;
        compilerOptions37.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions37.checkGlobalNamesLevel;
        compilerOptions18.checkProvides = checkLevel46;
        compilerOptions0.reportMissingOverride = checkLevel46;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(errorFormat38);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy39 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy39.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test062");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        compiler0.disableThreads();
//        com.google.javascript.jscomp.SourceMap sourceMap6 = compiler0.getSourceMap();
//        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback7);
//        java.lang.String str9 = nodeTraversal8.getSourceName();
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertNull(sourceMap6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        boolean boolean17 = compilerOptions0.gatherCssNames;
        boolean boolean18 = compilerOptions0.checkSuspiciousCode;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        compiler0.disableThreads();
//        int int6 = compiler0.getErrorCount();
//        int int7 = compiler0.getErrorCount();
//        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
//        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        node1.setLineno(5);
        org.junit.Assert.assertNotNull(ancestorIterable2);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        boolean boolean5 = compiler0.hasErrors();
//        compiler0.reportCodeChange();
//        com.google.javascript.jscomp.ErrorManager errorManager7 = compiler0.getErrorManager();
//        int int8 = compiler0.getWarningCount();
//        try {
//            com.google.javascript.jscomp.CompilerInput compilerInput10 = compiler0.newExternInput("goog.exportProperty");
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(errorManager7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        java.lang.String str5 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node6 = nodeTraversal2.getCurrentNode();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = null;
        com.google.javascript.jscomp.Scope scope14 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray15 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16, objectTypeArray15);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry13, scope14, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16);
        boolean boolean20 = defaultCodingConvention0.isPrivate("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "EOF ", 2, 26);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(objectTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkRequires;
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node5 = node3.getAncestor(9);
        boolean boolean6 = node3.wasEmptyNode();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean20 = node19.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = node13.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) -1, node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(15, node21, node25, node30, node36, 10, 49);
        java.lang.String str40 = closureCodingConvention0.extractClassNameIfRequire(node7, node36);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString(140, "com.google.javascript.rhino.EcmaError: : ");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (byte) -1, node48);
        node48.setCharno((int) (byte) 10);
        java.lang.String str52 = closureCodingConvention0.extractClassNameIfRequire(node43, node48);
        boolean boolean54 = closureCodingConvention0.isConstant("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node13.children();
        com.google.javascript.rhino.Node node34 = node13.getAncestor(15);
        try {
            com.google.javascript.rhino.Node node35 = node34.getFirstChild();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertNull(node34);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
//        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
//        compiler0.disableThreads();
//        int int6 = compiler0.getErrorCount();
//        java.nio.charset.Charset charset8 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset8);
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
//        com.google.javascript.jscomp.ErrorFormat errorFormat11 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream12 = null;
//        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat11.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, true);
//        com.google.javascript.rhino.Node node16 = compiler13.getRoot();
//        compilerInput10.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
//        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler13.getMessages();
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState19 = compiler13.getState();
//        compiler0.setState(intermediateState19);
//        com.google.javascript.jscomp.Region region23 = compiler0.getSourceRegion("com.google.javascript.rhino.EcmaError: null: language version", 0);
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertNull(node4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(jSSourceFile9);
//        org.junit.Assert.assertNotNull(errorFormat11);
//        org.junit.Assert.assertNotNull(messageFormatter15);
//        org.junit.Assert.assertNull(node16);
//        org.junit.Assert.assertNotNull(jSErrorArray18);
//        org.junit.Assert.assertNotNull(intermediateState19);
//        org.junit.Assert.assertNull(region23);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getLanguageVersion();
        boolean boolean3 = context0.isActivationNeeded("(eof)");
        int int4 = context0.getLanguageVersion();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(48);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        compilerOptions0.removeEmptyFunctions = false;
        boolean boolean11 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        boolean boolean6 = compilerOptions0.aliasExternals;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions7.getTweakReplacements();
        boolean boolean9 = compilerOptions7.checkSymbols;
        compilerOptions7.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.inferTypesInGlobalScope;
        boolean boolean14 = compilerOptions12.crossModuleMethodMotion;
        boolean boolean15 = compilerOptions12.checkTypes;
        compilerOptions12.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler18 = compilerOptions12.getAliasTransformationHandler();
        compilerOptions7.setAliasTransformationHandler(aliasTransformationHandler18);
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler18);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        boolean boolean6 = node4.hasOneChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = node4.getJSDocInfo();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSDocInfo7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
        boolean boolean7 = compilerOptions4.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions8.inlineLocalFunctions = false;
        compilerOptions8.closurePass = true;
        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
        java.lang.String[] strArray23 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions18.stripNamePrefixes = strSet24;
        compilerOptions8.aliasableStrings = strSet24;
        compilerOptions4.stripTypes = strSet24;
        compilerOptions0.stripTypePrefixes = strSet24;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap30 = compilerOptions0.getTweakReplacements();
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strMap30);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkSymbols = false;
        compilerOptions0.closurePass = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap11 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strMap11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.decomposeExpressions;
        compilerOptions0.checkTypedPropertyCalls = true;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", 46, (-3));
        java.lang.String str8 = node4.toString(false, false, false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n" + "'", str8.equals("EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean35 = node34.wasEmptyNode();
        com.google.javascript.rhino.Node node36 = node28.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (byte) -1, node50);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(15, node36, node40, node45, node51, 10, 49);
        java.util.List<java.lang.String> strList55 = defaultCodingConvention0.identifyTypeDeclarationCall(node51);
        boolean boolean56 = node51.isUnscopedQualifiedName();
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(strList55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        node17.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node17);
        node17.setSourcePositionForTree(27);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version: language version");
        jSSourceFile1.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.Object obj5 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable38 = node34.getAncestors();
        java.lang.RuntimeException runtimeException39 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, obj5, (java.lang.Object) node34);
        compilerOptions0.optimizeCalls = true;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy42 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy42;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(ancestorIterable38);
        org.junit.Assert.assertNotNull(runtimeException39);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy42 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy42.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean7 = node6.wasEmptyNode();
//        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean13 = node12.wasEmptyNode();
//        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
//        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
//        node14.setType((int) (byte) 10);
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention35 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
//        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
//        boolean boolean42 = node41.isOnlyModifiesThisCall();
//        boolean boolean43 = defaultCodingConvention35.isPropertyTestFunction(node41);
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal44 = null;
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
//        boolean boolean50 = node49.wasEmptyNode();
//        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast51 = defaultCodingConvention35.getObjectLiteralCast(nodeTraversal44, node49);
//        node14.addChildToFront(node49);
//        com.google.javascript.rhino.Node node53 = node49.cloneNode();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup54 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup54;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup54;
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel58, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard61 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup54, checkLevel58);
//        java.lang.RuntimeException runtimeException62 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) checkLevel58);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
//        java.lang.String[] strArray66 = null;
//        com.google.javascript.jscomp.JSError jSError67 = com.google.javascript.jscomp.JSError.make("error reporter", node53, checkLevel58, diagnosticType65, strArray66);
//        int int68 = node53.getCharno();
//        org.junit.Assert.assertNotNull(node6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(node12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(node14);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertNotNull(node40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNull(objectLiteralCast51);
//        org.junit.Assert.assertNotNull(node53);
//        org.junit.Assert.assertNull(diagnosticGroup54);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType60);
//        org.junit.Assert.assertNotNull(runtimeException62);
//        org.junit.Assert.assertNotNull(diagnosticType65);
//        org.junit.Assert.assertNotNull(jSError67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
//        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
//        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
//        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
//        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) ' ');
//        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable15 = node14.getAncestors();
//        com.google.javascript.rhino.Node node16 = node14.cloneTree();
//        com.google.javascript.jscomp.NodeTraversal.Callback callback17 = null;
//        try {
//            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler6, node16, callback17);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertNotNull(jSErrorArray12);
//        org.junit.Assert.assertNotNull(ancestorIterable15);
//        org.junit.Assert.assertNotNull(node16);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        boolean boolean9 = defaultCodingConvention1.isPropertyTestFunction(node7);
        com.google.javascript.rhino.Node node10 = null;
        java.lang.String str11 = defaultCodingConvention1.getSingletonGetterClassName(node10);
        boolean boolean13 = defaultCodingConvention1.isSuperClassReference("hi!");
        java.lang.String str14 = defaultCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean20 = node19.wasEmptyNode();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean26 = node25.wasEmptyNode();
        com.google.javascript.rhino.Node node27 = node19.copyInformationFromForTree(node25);
        boolean boolean28 = node25.isOptionalArg();
        com.google.javascript.rhino.Node node29 = node25.cloneTree();
        java.lang.String str30 = defaultCodingConvention1.identifyTypeDefAssign(node29);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder38 = node37.getJsDocBuilderForNode();
        int int39 = node37.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray46 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType45, strArray46);
        java.lang.String[] strArray48 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node37, diagnosticType45, strArray48);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection50 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node37);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(31, node37, node54, node58, 18, 120);
        com.google.javascript.rhino.Node node62 = node29.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean68 = node67.wasEmptyNode();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean74 = node73.wasEmptyNode();
        com.google.javascript.rhino.Node node75 = node67.copyInformationFromForTree(node73);
        boolean boolean76 = node73.isOptionalArg();
        com.google.javascript.rhino.Node node77 = node73.cloneTree();
        boolean boolean78 = node77.isVarArgs();
        java.util.Set<java.lang.String> strSet79 = node77.getDirectives();
        try {
            com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(0, node37, node77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(nodeCollection50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(strSet79);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        java.lang.Object obj8 = compilerOptions0.clone();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        compilerOptions0.setShadowVariables(false);
        compilerOptions0.setLooseTypes(true);
        boolean boolean23 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setTweakToStringLiteral("-1", "(Named type with empty name component)");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) -1, node15);
        boolean boolean17 = node16.isOnlyModifiesThisCall();
        boolean boolean18 = defaultCodingConvention10.isPropertyTestFunction(node16);
        com.google.javascript.rhino.Node node19 = null;
        java.lang.String str20 = defaultCodingConvention10.getSingletonGetterClassName(node19);
        java.lang.String str21 = defaultCodingConvention10.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder28 = node27.getJsDocBuilderForNode();
        int int29 = node27.getChildCount();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean35 = node34.wasEmptyNode();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean41 = node40.wasEmptyNode();
        com.google.javascript.rhino.Node node42 = node34.copyInformationFromForTree(node40);
        java.lang.String str43 = closureCodingConvention22.extractClassNameIfProvide(node27, node42);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = defaultCodingConvention10.getClassesDefinedByCall(node27);
        java.lang.String str45 = defaultCodingConvention10.getExportPropertyFunction();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention10);
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.specializeInitialModule = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions19.checkMethods;
        compilerOptions19.inlineLocalFunctions = false;
        compilerOptions19.closurePass = true;
        compilerOptions19.strictMessageReplacement = false;
        boolean boolean29 = compilerOptions19.extractPrototypeMemberDeclarations;
        compilerOptions19.aliasKeywords = false;
        byte[] byteArray33 = new byte[] { (byte) 100 };
        compilerOptions19.inputPropertyMapSerialized = byteArray33;
        compilerOptions0.inputPropertyMapSerialized = byteArray33;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(byteArray33);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("Unknown class name", '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        boolean boolean15 = node14.isVarArgs();
        boolean boolean16 = node14.isOptionalArg();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node14.new FileLevelJsDocBuilder();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("goog.abstractMethod", "<No stack trace available>");
        java.lang.String str3 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        int int6 = node4.getCharno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions7.checkMethods;
        compilerOptions7.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = null;
        compilerOptions7.setRenamingPolicy(variableRenamingPolicy13, propertyRenamingPolicy14);
        boolean boolean16 = compilerOptions7.crossModuleMethodMotion;
        java.lang.String str17 = compilerOptions7.appNameStr;
        java.util.Set<java.lang.String> strSet18 = compilerOptions7.stripNamePrefixes;
        compilerOptions0.stripNamePrefixes = strSet18;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strSet18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError(": ", "hi!");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node9 = node5.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = null;
        node9.setJSDocInfo(jSDocInfo10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean24 = node23.wasEmptyNode();
        com.google.javascript.rhino.Node node25 = node17.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) -1, node39);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(15, node25, node29, node34, node40, 10, 49);
        com.google.javascript.rhino.Node node44 = node43.cloneNode();
        node43.putIntProp(47, 15);
        java.lang.String str48 = node9.checkTreeEquals(node43);
        try {
            java.lang.String str50 = com.google.javascript.rhino.ScriptRuntime.getMessage2("-1", (java.lang.Object) node9, (java.lang.Object) "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property -1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n" + "'", str48.equals("Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean18 = compilerOptions0.strictMessageReplacement;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) -1, node25);
        boolean boolean27 = node26.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = node26.copyInformationFrom(node34);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship38 = closureCodingConvention20.getClassesDefinedByCall(node34);
        boolean boolean40 = closureCodingConvention20.isPrivate("window");
        boolean boolean42 = closureCodingConvention20.isConstantKey("hi!");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention20);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection44 = closureCodingConvention20.getAssertionFunctions();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean52 = node51.wasEmptyNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean58 = node57.wasEmptyNode();
        com.google.javascript.rhino.Node node59 = node51.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) (byte) -1, node73);
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node(15, node59, node63, node68, node74, 10, 49);
        com.google.javascript.rhino.Node node78 = node68.detachFromParent();
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(39, node68);
        int int80 = node68.getCharno();
        try {
            boolean boolean81 = closureCodingConvention20.isPropertyTestFunction(node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(subclassRelationship38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection44);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 100 + "'", int80 == 100);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        java.util.Locale locale12 = null;
        java.util.Locale locale13 = context0.setLocale(locale12);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions16.checkMethods;
        compilerOptions16.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy23 = null;
        compilerOptions16.setRenamingPolicy(variableRenamingPolicy22, propertyRenamingPolicy23);
        boolean boolean25 = compilerOptions16.crossModuleMethodMotion;
        java.lang.Object obj26 = context0.getThreadLocal((java.lang.Object) compilerOptions16);
        boolean boolean27 = compilerOptions16.ideMode;
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy22.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
//        compilerInput3.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
//        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
//        compilerInput9.clearAst();
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
//        java.nio.charset.Charset charset13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
//        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
//        boolean boolean16 = compiler11.hasErrors();
//        compiler11.reportCodeChange();
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
//        compiler11.tracker = performanceTracker18;
//        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
//        com.google.javascript.jscomp.SourceAst sourceAst21 = compilerInput9.getSourceAst();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(jSModule6);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(sourceAst21);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing3 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        boolean boolean6 = compilerOptions0.markAsCompiled;
        compilerOptions0.inferTypesInGlobalScope = true;
        org.junit.Assert.assertTrue("'" + tweakProcessing3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing3.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(150);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        boolean boolean19 = compilerOptions0.closurePass;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.String str22 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.syntheticBlockEndMarker = "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nGT NUMBER 1.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: GT NUMBER 1.0 0\n";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions18.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel21 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions18.sourceMapDetailLevel = detailLevel21;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.checkRequires;
        compilerOptions0.checkMethods = checkLevel23;
        java.lang.String str25 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel21);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.collapseAnonymousFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkUndefinedProperties;
        boolean boolean6 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.setOutputCharset("Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n");
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = compilerOptions0.getTweakProcessing();
        compilerOptions0.disambiguateProperties = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions7.errorFormat;
        compilerOptions7.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing11 = compilerOptions7.getTweakProcessing();
        compilerOptions7.disambiguateProperties = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setRemoveClosureAsserts(false);
        compilerOptions14.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy20 = compilerOptions18.variableRenaming;
        boolean boolean21 = compilerOptions18.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions22.checkMethods;
        compilerOptions22.inlineLocalFunctions = false;
        compilerOptions22.closurePass = true;
        java.util.Set<java.lang.String> strSet30 = compilerOptions22.stripNameSuffixes;
        java.lang.String str31 = compilerOptions22.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat33 = compilerOptions32.errorFormat;
        java.lang.String[] strArray37 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet38 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet38, strArray37);
        compilerOptions32.stripNamePrefixes = strSet38;
        compilerOptions22.aliasableStrings = strSet38;
        compilerOptions18.stripTypes = strSet38;
        compilerOptions14.stripTypePrefixes = strSet38;
        compilerOptions7.stripNamePrefixes = strSet38;
        compilerOptions0.stripTypePrefixes = strSet38;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertTrue("'" + tweakProcessing11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing11.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy20 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy20.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(errorFormat33);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset7);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, true);
        com.google.javascript.rhino.Node node15 = compiler12.getRoot();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        java.lang.String str22 = jSSourceFile19.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region24 = jSSourceFile19.getRegion((int) ' ');
        jSSourceFile19.clearCachedSource();
        com.google.javascript.rhino.Node node26 = compiler12.parse(jSSourceFile19);
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset29);
        com.google.javascript.rhino.Node node31 = compiler27.parse(jSSourceFile30);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        java.lang.String str37 = jSSourceFile34.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region39 = jSSourceFile34.getRegion((int) ' ');
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str45 = jSSourceFile42.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region47 = jSSourceFile42.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile30, jSSourceFile34, jSSourceFile42, jSSourceFile49 };
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile53);
        java.lang.String str56 = jSSourceFile53.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region58 = jSSourceFile53.getRegion((int) ' ');
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.inferTypesInGlobalScope;
        boolean boolean65 = compilerOptions63.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result66 = compiler2.compile(jSSourceFileArray50, jSSourceFileArray62, compilerOptions63);
        compilerOptions63.specializeInitialModule = true;
        compilerOptions63.removeEmptyFunctions = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy71 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions63.propertyRenaming = propertyRenamingPolicy71;
        boolean boolean73 = compilerOptions63.groupVariableDeclarations;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(region39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(region47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(region58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(result66);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy71 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy71.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.collapseAnonymousFunctions = false;
        compilerOptions0.setSummaryDetailLevel((int) 'a');
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.flowSensitiveInlineVariables = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean10 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.aliasKeywords = false;
        byte[] byteArray14 = new byte[] { (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray14;
        java.lang.String str16 = compilerOptions0.reportPath;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str7 = node3.toString(true, false, true);
        java.lang.Class<?> wildcardClass8 = node3.getClass();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "NUMBER 1.0 0" + "'", str7.equals("NUMBER 1.0 0"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("eof", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        java.lang.String str33 = closureCodingConvention12.extractClassNameIfProvide(node17, node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship34 = defaultCodingConvention0.getClassesDefinedByCall(node17);
        com.google.javascript.rhino.jstype.ObjectType objectType35 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType36 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType38 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType35, objectType36, objectType37, functionType38, functionType39);
        java.lang.String str41 = defaultCodingConvention0.getAbstractMethodName();
        boolean boolean43 = defaultCodingConvention0.isPrivate("// Input %num%");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(subclassRelationship34);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, false);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config3);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType6);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions0.sourceMapDetailLevel;
        java.lang.String str10 = compilerOptions0.reportPath;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.jsOutputFile = "EOF  0 [jsdoc_info: JSDocInfo]\n";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "eof", 160);
        java.lang.Throwable[] throwableArray4 = evaluatorException3.getSuppressed();
        java.lang.String str5 = evaluatorException3.lineSource();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        boolean boolean11 = compiler6.acceptConstKeyword();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
        boolean boolean7 = compilerOptions4.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions8.inlineLocalFunctions = false;
        compilerOptions8.closurePass = true;
        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
        java.lang.String[] strArray23 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions18.stripNamePrefixes = strSet24;
        compilerOptions8.aliasableStrings = strSet24;
        compilerOptions4.stripTypes = strSet24;
        compilerOptions0.stripTypePrefixes = strSet24;
        compilerOptions0.setLooseTypes(false);
        boolean boolean32 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention12 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        boolean boolean19 = node18.isOnlyModifiesThisCall();
        boolean boolean20 = defaultCodingConvention12.isPropertyTestFunction(node18);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node18);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = closureCodingConvention4.getClassesDefinedByCall(node18);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node18, node26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = null;
        node26.setJSDocInfo(jSDocInfo28);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        int int37 = diagnosticType33.compareTo(diagnosticType36);
        node26.putProp((int) (byte) 0, (java.lang.Object) diagnosticType36);
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticType36.level;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        java.lang.String str13 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean20 = node19.wasEmptyNode();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean26 = node25.wasEmptyNode();
        com.google.javascript.rhino.Node node27 = node19.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) -1, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(15, node27, node31, node36, node42, 10, 49);
        com.google.javascript.rhino.Node node46 = node42.getLastSibling();
        boolean boolean47 = node46.isOptionalArg();
        boolean boolean48 = defaultCodingConvention0.isPropertyTestFunction(node46);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        int int8 = node6.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray15 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType14, strArray15);
        java.lang.String[] strArray17 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node6, diagnosticType14, strArray17);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection19 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node6);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(31, node6, node23, node27, 18, 120);
        boolean boolean31 = node6.hasSideEffects();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(nodeCollection19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.lineBreak = false;
        boolean boolean8 = compilerOptions0.aliasAllStrings;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean10 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        boolean boolean19 = compilerOptions0.checkCaja;
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean21 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.locale = "<No stack trace available>";
        compilerOptions0.setAcceptConstKeyword(true);
        boolean boolean11 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        boolean boolean19 = compilerOptions0.closurePass;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.String str22 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray16 = null;
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType15, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType23, strArray24);
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compiler0.getErrorLevel(jSError26);
        com.google.javascript.jscomp.CodingConvention codingConvention28 = compiler0.getCodingConvention();
        com.google.javascript.jscomp.JSModule jSModule29 = null;
        try {
            java.lang.String[] strArray30 = compiler0.toSourceArray(jSModule29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(codingConvention28);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("EOF ", "@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler4 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler4, callback5);
        boolean boolean7 = nodeTraversal6.hasScope();
        int int8 = nodeTraversal6.getLineNumber();
        java.lang.String str9 = nodeTraversal6.getSourceName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) -1, node15);
        boolean boolean17 = node16.isOnlyModifiesThisCall();
        boolean boolean18 = defaultCodingConvention10.isPropertyTestFunction(node16);
        com.google.javascript.rhino.Node node19 = null;
        java.lang.String str20 = defaultCodingConvention10.getSingletonGetterClassName(node19);
        java.lang.String str21 = defaultCodingConvention10.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention10, "null", 34, (int) ' ');
        com.google.javascript.rhino.Node node26 = node25.getLastChild();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast27 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal6, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(node26);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray14 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType13, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node5, diagnosticType13, strArray16);
        int int18 = jSError17.lineNumber;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = jSError17.getType();
        java.lang.String str20 = jSError17.sourceName;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RETURN 0\n" + "'", str20.equals("RETURN 0\n"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing20 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray27 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType26, strArray27);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = jSError28.level;
        compilerOptions0.reportMissingOverride = checkLevel29;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + tweakProcessing20 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing20.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        boolean boolean13 = compiler6.isTypeCheckingEnabled();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt14 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter15 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, sourceExcerpt14);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        java.io.FilenameFilter filenameFilter8 = null;
        java.lang.String str9 = ecmaError6.getScriptStackTrace(filenameFilter8);
        int int10 = ecmaError6.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.strictMessageReplacement = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "";
        compilerOptions0.jsOutputFile = "NUMBER 1.0 0: <No stack trace available>";
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.checkMissingGetCssNameBlacklist = "@IMPLEMENTATION.VERSION@";
        compilerOptions0.setPropertyAffinity(false);
        compilerOptions0.reserveRawExports = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions0.checkRequires = checkLevel11;
        boolean boolean13 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String str14 = compilerOptions0.appNameStr;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        int int6 = node4.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        boolean boolean8 = node4.hasChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions0.sourceMapDetailLevel;
        java.lang.String str10 = compilerOptions0.reportPath;
        compilerOptions0.locale = "()";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.Region region6 = compilerInput3.getRegion(3);
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        java.lang.String str12 = jSSourceFile9.getLine((int) (byte) 0);
        jSSourceFile9.clearCachedSource();
        compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) (-1L), (int) 'a');
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 97.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        boolean boolean12 = compilerOptions0.printInputDelimiter;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("NUMBER 1.0 0", "Not declared as a type name", 0, "", 5);
        java.lang.String str6 = evaluatorException5.getScriptStackTrace();
        int int7 = evaluatorException5.lineNumber();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        lightweightMessageFormatter3.setColorize(false);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter3, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = loggerErrorManager7.getWarnings();
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions10.checkMethods;
        compilerOptions10.inlineLocalFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format16 = compilerOptions10.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format16;
        boolean boolean18 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        boolean boolean4 = closureCodingConvention0.isPrivate("");
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(16, "NUMBER 1.0 0");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node15.getJsDocBuilderForNode();
        int int17 = node15.getChildCount();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        java.lang.String str31 = closureCodingConvention10.extractClassNameIfProvide(node15, node30);
        boolean boolean32 = node30.hasOneChild();
        java.lang.String str33 = closureCodingConvention0.extractClassNameIfProvide(node9, node30);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection34 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(nodeCollection34);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("com.google.javascript.rhino.EcmaError: : ", (int) ' ', 150);
        com.google.javascript.rhino.Node node4 = node3.getLastChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean16 = node15.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean22 = node21.wasEmptyNode();
        com.google.javascript.rhino.Node node23 = node15.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) -1, node37);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(15, node23, node27, node32, node38, 10, 49);
        com.google.javascript.rhino.Node node42 = node38.getLastSibling();
        boolean boolean43 = detailLevel9.apply(node38);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention44 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        boolean boolean51 = node50.isOnlyModifiesThisCall();
        boolean boolean52 = defaultCodingConvention44.isPropertyTestFunction(node50);
        com.google.javascript.rhino.Node node53 = null;
        java.lang.String str54 = defaultCodingConvention44.getSingletonGetterClassName(node53);
        boolean boolean56 = defaultCodingConvention44.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder62 = node61.getJsDocBuilderForNode();
        boolean boolean63 = node61.hasOneChild();
        java.util.List<java.lang.String> strList64 = defaultCodingConvention44.identifyTypeDeclarationCall(node61);
        boolean boolean65 = detailLevel9.apply(node61);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder73 = node72.getJsDocBuilderForNode();
        int int74 = node72.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray81 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError82 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType80, strArray81);
        java.lang.String[] strArray83 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node72, diagnosticType80, strArray83);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection85 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node72);
        com.google.javascript.rhino.Node node89 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node93 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node96 = new com.google.javascript.rhino.Node(31, node72, node89, node93, 18, 120);
        boolean boolean97 = detailLevel9.apply(node96);
        int int99 = node96.getIntProp(0);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(strList64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertNotNull(jSError82);
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertNotNull(jSError84);
        org.junit.Assert.assertNotNull(nodeCollection85);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 0 + "'", int99 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        int int8 = ecmaError6.getColumnNumber();
        java.lang.String str9 = ecmaError6.getName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.optimizeArgumentsArray = false;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard5 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray4);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard5);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node31.cloneNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean35 = closureCodingConvention33.isPrivate("NUMBER 1.0 0");
        java.lang.String str36 = closureCodingConvention33.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention37 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) -1, node42);
        boolean boolean44 = node43.isOnlyModifiesThisCall();
        boolean boolean45 = defaultCodingConvention37.isPropertyTestFunction(node43);
        com.google.javascript.rhino.Node node46 = null;
        java.lang.String str47 = defaultCodingConvention37.getSingletonGetterClassName(node46);
        boolean boolean49 = defaultCodingConvention37.isSuperClassReference("hi!");
        java.lang.String str50 = defaultCodingConvention37.getExportPropertyFunction();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean56 = node55.wasEmptyNode();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean62 = node61.wasEmptyNode();
        com.google.javascript.rhino.Node node63 = node55.copyInformationFromForTree(node61);
        boolean boolean64 = node61.isOptionalArg();
        com.google.javascript.rhino.Node node65 = node61.cloneTree();
        java.lang.String str66 = defaultCodingConvention37.identifyTypeDefAssign(node65);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship67 = closureCodingConvention33.getDelegateRelationship(node65);
        com.google.javascript.rhino.Context context68 = new com.google.javascript.rhino.Context();
        java.lang.Object obj69 = context68.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context68, (long) (short) 10);
        int int72 = context68.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) (byte) -1, node77);
        node77.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node81 = node77.getLastSibling();
        com.google.javascript.rhino.Node node82 = node81.cloneTree();
        context68.seal((java.lang.Object) node82);
        com.google.javascript.rhino.jstype.JSType jSType84 = node82.getJSType();
        boolean boolean85 = node82.isVarArgs();
        node31.addChildAfter(node65, node82);
        com.google.javascript.rhino.Node node87 = node65.getFirstChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "goog.abstractMethod" + "'", str36.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNull(delegateRelationship67);
        org.junit.Assert.assertNull(obj69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNull(jSType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(node87);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        com.google.javascript.rhino.Node node23 = compiler20.getRoot();
        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler20.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState26 = compiler20.getState();
        compiler6.setState(intermediateState26);
        boolean boolean28 = compiler6.isTypeCheckingEnabled();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(intermediateState26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.Object obj5 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable38 = node34.getAncestors();
        java.lang.RuntimeException runtimeException39 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, obj5, (java.lang.Object) node34);
        compilerOptions0.optimizeCalls = true;
        java.lang.String str42 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(ancestorIterable38);
        org.junit.Assert.assertNotNull(runtimeException39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "// Input %num%" + "'", str42.equals("// Input %num%"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString(": ", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention12 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        boolean boolean19 = node18.isOnlyModifiesThisCall();
        boolean boolean20 = defaultCodingConvention12.isPropertyTestFunction(node18);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node18);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = closureCodingConvention4.getClassesDefinedByCall(node18);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node18, node26);
        com.google.javascript.rhino.Node node28 = node18.getNext();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(node28);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        compilerOptions0.aliasStringsBlacklist = "RETURN 0\n";
        boolean boolean22 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        compilerOptions0.optimizeCalls = false;
        com.google.javascript.jscomp.SourceMap.Format format8 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.sourceMapFormat = format8;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(format8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap1 = compilerOptions0.getTweakReplacements();
        boolean boolean2 = compilerOptions0.checkSymbols;
        compilerOptions0.checkTypedPropertyCalls = true;
        compilerOptions0.ambiguateProperties = false;
        org.junit.Assert.assertNotNull(strMap1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setTweakToStringLiteral("-1", "(Named type with empty name component)");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) -1, node15);
        boolean boolean17 = node16.isOnlyModifiesThisCall();
        boolean boolean18 = defaultCodingConvention10.isPropertyTestFunction(node16);
        com.google.javascript.rhino.Node node19 = null;
        java.lang.String str20 = defaultCodingConvention10.getSingletonGetterClassName(node19);
        java.lang.String str21 = defaultCodingConvention10.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder28 = node27.getJsDocBuilderForNode();
        int int29 = node27.getChildCount();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean35 = node34.wasEmptyNode();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean41 = node40.wasEmptyNode();
        com.google.javascript.rhino.Node node42 = node34.copyInformationFromForTree(node40);
        java.lang.String str43 = closureCodingConvention22.extractClassNameIfProvide(node27, node42);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = defaultCodingConvention10.getClassesDefinedByCall(node27);
        java.lang.String str45 = defaultCodingConvention10.getExportPropertyFunction();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention10);
        compilerOptions0.tightenTypes = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        boolean boolean9 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, true);
        java.lang.String str25 = jSSourceFile13.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        int int17 = ecmaError6.lineNumber();
        java.lang.Throwable[] throwableArray18 = ecmaError6.getSuppressed();
        java.io.FilenameFilter filenameFilter19 = null;
        java.lang.String str20 = ecmaError6.getScriptStackTrace(filenameFilter19);
        int int21 = ecmaError6.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "<No stack trace available>" + "'", str20.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        com.google.javascript.rhino.Node node23 = compiler20.getRoot();
        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler20.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState26 = compiler20.getState();
        compiler6.setState(intermediateState26);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker29 = null;
        compiler6.tracker = performanceTracker29;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput32 = compiler6.newExternInput("(eof)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(intermediateState26);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.crossModuleMethodMotion = false;
        compilerOptions0.setSummaryDetailLevel((-2));
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertNotNull(errorFormat1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean20 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.syntheticBlockEndMarker = "Unknown class name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("(eof)");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.debugFunctionSideEffectsPath = "-1";
        compilerOptions0.setChainCalls(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.collapseAnonymousFunctions = false;
        compilerOptions0.setSummaryDetailLevel((int) 'a');
        compilerOptions0.skipAllCompilerPasses();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions8.inlineLocalFunctions = false;
        compilerOptions8.closurePass = true;
        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
        compilerOptions0.aliasableStrings = strSet16;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkUndefinedProperties;
        boolean boolean12 = compilerOptions0.optimizeParameters;
        compilerOptions0.allowLegacyJsMessages = false;
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode1, true);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        compilerOptions0.inferTypesInGlobalScope = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 34, 45, 0);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str5 = compilerInput3.getLine((-1));
        java.lang.String str7 = compilerInput3.getLine(48);
        try {
            java.util.Collection<java.lang.String> strCollection8 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        java.lang.String str11 = ecmaError6.lineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        java.lang.String str1 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        compilerOptions0.enableRuntimeTypeCheck("eof");
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.lineLengthThreshold(27);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        java.lang.Object obj8 = compilerOptions0.clone();
        boolean boolean9 = compilerOptions0.checkTypes;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripTypes = strSet2;
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkUndefinedProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions7.checkMethods;
        compilerOptions7.inlineLocalFunctions = false;
        compilerOptions7.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions15.checkMethods;
        compilerOptions7.checkRequires = checkLevel18;
        compilerOptions7.moveFunctionDeclarations = true;
        java.lang.String[] strArray58 = new java.lang.String[] { "null", "error reporter", "// Input %num%", "RETURN 0\n", "language version", "// Input %num%", "(Named type with empty name component)", "goog.abstractMethod", "goog.abstractMethod", "()", "EOF  0", "-1", "Not declared as a type name", "<No stack trace available>", "null", "@IMPLEMENTATION.VERSION@", "Named type with empty name component", "EOF  0 [jsdoc_info: JSDocInfo]\n", "com.google.javascript.rhino.EcmaError: : ", "Named type with empty name component", "(eof)", "DiagnosticGroup<internetExplorerChecks>(ERROR)", "NUMBER 1.0 0", "goog.abstractMethod", "com.google.javascript.rhino.EcmaError: : ", "com.google.javascript.rhino.EcmaError: TypeError: Cannot set property \"NUMBER 52.0 0\" of false to \"NUMBER 52.0 0\"", "RETURN 0\n", "window", "@IMPLEMENTATION.VERSION@", "Unknown class name", "goog.exportSymbol", "or", "language version: language version", "()", "com.google.javascript.rhino.EcmaError: null: language version", "false" };
        java.util.LinkedHashSet<java.lang.String> strSet59 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet59, strArray58);
        compilerOptions7.stripNamePrefixes = strSet59;
        compilerOptions0.stripTypePrefixes = strSet59;
        boolean boolean63 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        try {
            ecmaError6.initSourceName("error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("Unknown class name", "NUMBER 1.0 0: <No stack trace available>");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.moveFunctionDeclarations;
        compilerOptions18.removeUnusedLocalVars = false;
        compilerOptions18.recordFunctionInformation = true;
        java.lang.String str24 = compilerOptions18.nameReferenceReportPath;
        compilerOptions18.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.checkRequires;
        compilerOptions0.checkShadowVars = checkLevel27;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 120);
        int int4 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            compiler5.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) errorFormat0);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("ERROR 2");
        ecmaError1.initLineNumber(49);
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.children();
        boolean boolean6 = node3.getBooleanProp((int) (byte) 0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        boolean boolean10 = defaultCodingConvention0.isExported("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node15.getJsDocBuilderForNode();
        int int17 = node15.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType18 = node15.getJSType();
        java.util.List<java.lang.String> strList19 = defaultCodingConvention0.identifyTypeDeclarationCall(node15);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean26 = node25.wasEmptyNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean32 = node31.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = node25.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) -1, node47);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(15, node33, node37, node42, node48, 10, 49);
        int int52 = node42.getLineno();
        com.google.javascript.rhino.Node node53 = node42.detachFromParent();
        int int55 = node53.getIntProp(43);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean61 = node60.wasEmptyNode();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean67 = node66.wasEmptyNode();
        com.google.javascript.rhino.Node node68 = node60.copyInformationFromForTree(node66);
        boolean boolean69 = node66.isOptionalArg();
        com.google.javascript.rhino.Node node70 = node66.cloneTree();
        boolean boolean71 = node70.isVarArgs();
        com.google.javascript.rhino.Node node72 = node70.getLastSibling();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean80 = node79.wasEmptyNode();
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean86 = node85.wasEmptyNode();
        com.google.javascript.rhino.Node node87 = node79.copyInformationFromForTree(node85);
        com.google.javascript.rhino.Node node88 = node87.getParent();
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node((-1), node87, 2, 0);
        node70.putProp((int) (byte) 100, (java.lang.Object) node87);
        try {
            node15.replaceChildAfter(node53, node87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNull(strList19);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNull(node88);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        boolean boolean19 = compilerOptions0.closurePass;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.String str22 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.allowLegacyJsMessages = false;
        compilerOptions0.enableRuntimeTypeCheck("NUMBER 1.0 0: <No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        java.lang.String str8 = ecmaError6.lineSource();
        java.lang.String str9 = ecmaError6.getName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node22.cloneTree();
        com.google.javascript.rhino.Node node33 = node22.removeFirstChild();
        try {
            com.google.javascript.rhino.Node node34 = node33.cloneNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node33);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        boolean boolean20 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(4, 0, 1);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean7 = closureCodingConvention5.isPrivate("NUMBER 1.0 0");
        java.lang.String str8 = closureCodingConvention5.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) -1, node14);
        boolean boolean16 = node15.isOnlyModifiesThisCall();
        boolean boolean17 = defaultCodingConvention9.isPropertyTestFunction(node15);
        com.google.javascript.rhino.Node node18 = null;
        java.lang.String str19 = defaultCodingConvention9.getSingletonGetterClassName(node18);
        boolean boolean21 = defaultCodingConvention9.isSuperClassReference("hi!");
        java.lang.String str22 = defaultCodingConvention9.getExportPropertyFunction();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        boolean boolean36 = node33.isOptionalArg();
        com.google.javascript.rhino.Node node37 = node33.cloneTree();
        java.lang.String str38 = defaultCodingConvention9.identifyTypeDefAssign(node37);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship39 = closureCodingConvention5.getDelegateRelationship(node37);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention40 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean42 = closureCodingConvention40.isPrivate("NUMBER 1.0 0");
        java.lang.String str43 = closureCodingConvention40.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention44 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        boolean boolean51 = node50.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention52 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) -1, node57);
        boolean boolean59 = node58.isOnlyModifiesThisCall();
        boolean boolean60 = defaultCodingConvention52.isPropertyTestFunction(node58);
        com.google.javascript.rhino.Node node61 = node50.copyInformationFrom(node58);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship62 = closureCodingConvention44.getClassesDefinedByCall(node58);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str67 = closureCodingConvention40.extractClassNameIfProvide(node58, node66);
        boolean boolean68 = node37.isEquivalentTo(node66);
        java.lang.String str69 = closureCodingConvention0.extractClassNameIfProvide(node4, node37);
        boolean boolean71 = closureCodingConvention0.isExported("EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.abstractMethod" + "'", str8.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNull(delegateRelationship39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "goog.abstractMethod" + "'", str43.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(subclassRelationship62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.removeTryCatchFinally = true;
        java.lang.String[] strArray37 = new java.lang.String[] { "eof", ": ", "ERROR 2", "false", "1b", "language version: language version", "NUMBER 1.0 0: <No stack trace available>", "EOF  0 [jsdoc_info: JSDocInfo]\n", "DiagnosticGroup<internetExplorerChecks>(ERROR)", "Unknown class name", "DiagnosticGroup<internetExplorerChecks>(ERROR)", "1b", "goog.exportSymbol", "goog.abstractMethod", "@IMPLEMENTATION.VERSION@", "<No stack trace available>", "com.google.javascript.rhino.EcmaError: null: language version", "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n", "-1", "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "", "<No stack trace available>", ": ", "RETURN 0\n", "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n", "goog.exportProperty", "RETURN 0\n", "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n", "Named type with empty name component", "(eof)", "EOF " };
        java.util.ArrayList<java.lang.String> strList38 = new java.util.ArrayList<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList38, strArray37);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        java.lang.Class<?> wildcardClass5 = compilerOptions0.getClass();
        compilerOptions0.setRemoveAbstractMethods(false);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test207");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.cloneTree();
        java.lang.String str34 = defaultCodingConvention0.getSingletonGetterClassName(node33);
        com.google.javascript.rhino.Node node35 = null;
        try {
            node33.addChildToFront(node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap12 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap12;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        byte[] byteArray19 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.aliasableGlobals = "@IMPLEMENTATION.VERSION@";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(byteArray19);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkSymbols = false;
        java.lang.String str9 = compilerOptions0.locale;
        compilerOptions0.setTweakToBooleanLiteral("()", false);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.reportMissingOverride = checkLevel11;
        boolean boolean16 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("goog.exportProperty", "", "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot set property \"NUMBER 52.0 0\" of false to \"NUMBER 52.0 0\"");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        boolean boolean2 = compilerOptions0.checkControlStructures;
        compilerOptions0.printInputDelimiter = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        node9.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = node9.getLastSibling();
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        context0.seal((java.lang.Object) node14);
        boolean boolean16 = node14.isQuotedString();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        java.lang.String str6 = compiler0.toSource();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean5 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = compilerOptions6.errorFormat;
        java.lang.String[] strArray11 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet12 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet12, strArray11);
        compilerOptions6.stripNamePrefixes = strSet12;
        compilerOptions6.removeUnusedVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions6.checkUndefinedProperties;
        compilerOptions0.checkShadowVars = checkLevel17;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(errorFormat7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        boolean boolean17 = compilerOptions0.gatherCssNames;
        boolean boolean18 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.setPropertyAffinity(true);
        compilerOptions0.setDefineToNumberLiteral("// Input %num%", 49);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.Object obj5 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable38 = node34.getAncestors();
        java.lang.RuntimeException runtimeException39 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, obj5, (java.lang.Object) node34);
        boolean boolean40 = compilerOptions0.inlineFunctions;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(ancestorIterable38);
        org.junit.Assert.assertNotNull(runtimeException39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "Not declared as a type name");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean3 = compilerOptions0.checkTypes;
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        java.lang.String[] strArray21 = new java.lang.String[] { "goog.abstractMethod", "false", "ERROR 2", "RETURN 0\n", "eof", "EOF  0", "goog.abstractMethod", "<No stack trace available>", "Not declared as a type name", "Not declared as a type name", "(Named type with empty name component)", "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n", "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "goog.exportSymbol" };
        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        com.google.javascript.rhino.Context.checkLanguageVersion(120);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(110, nodeArray1);
        org.junit.Assert.assertNotNull(nodeArray1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        java.lang.String str9 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        compilerOptions0.unaliasableGlobals = "()";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("null", "goog.abstractMethod", (-34), "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", 49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -34");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node28.getLastSibling();
        node28.setVarArgs(true);
        boolean boolean35 = node28.hasOneChild();
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions36.setRemoveClosureAsserts(false);
        compilerOptions36.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat41 = compilerOptions40.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy42 = compilerOptions40.variableRenaming;
        boolean boolean43 = compilerOptions40.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel47 = compilerOptions44.checkMethods;
        compilerOptions44.inlineLocalFunctions = false;
        compilerOptions44.closurePass = true;
        java.util.Set<java.lang.String> strSet52 = compilerOptions44.stripNameSuffixes;
        java.lang.String str53 = compilerOptions44.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat55 = compilerOptions54.errorFormat;
        java.lang.String[] strArray59 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet60 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet60, strArray59);
        compilerOptions54.stripNamePrefixes = strSet60;
        compilerOptions44.aliasableStrings = strSet60;
        compilerOptions40.stripTypes = strSet60;
        compilerOptions36.stripTypePrefixes = strSet60;
        node28.setDirectives((java.util.Set<java.lang.String>) strSet60);
        com.google.javascript.rhino.Node node67 = node28.getFirstChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(errorFormat41);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy42 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy42.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet52);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(errorFormat55);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean20 = node19.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = node13.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) -1, node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(15, node21, node25, node30, node36, 10, 49);
        java.lang.String str40 = closureCodingConvention0.extractClassNameIfRequire(node7, node36);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString(140, "com.google.javascript.rhino.EcmaError: : ");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (byte) -1, node48);
        node48.setCharno((int) (byte) 10);
        java.lang.String str52 = closureCodingConvention0.extractClassNameIfRequire(node43, node48);
        com.google.javascript.rhino.jstype.FunctionType functionType53 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType54 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType55 = null;
        closureCodingConvention0.applySubclassRelationship(functionType53, functionType54, subclassType55);
        com.google.javascript.rhino.jstype.FunctionType functionType57 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType58 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType59 = null;
        closureCodingConvention0.applySubclassRelationship(functionType57, functionType58, subclassType59);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap1 = compilerOptions0.getTweakReplacements();
        boolean boolean2 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertNotNull(strMap1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.checkTypedPropertyCalls = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        boolean boolean9 = defaultCodingConvention1.isPropertyTestFunction(node7);
        com.google.javascript.rhino.Node node10 = null;
        java.lang.String str11 = defaultCodingConvention1.getSingletonGetterClassName(node10);
        boolean boolean13 = defaultCodingConvention1.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node18.getJsDocBuilderForNode();
        boolean boolean20 = node18.hasOneChild();
        java.util.List<java.lang.String> strList21 = defaultCodingConvention1.identifyTypeDeclarationCall(node18);
        com.google.javascript.rhino.Node node23 = node18.getAncestor(10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet26 = null;
        compilerOptions24.stripTypes = strSet26;
        compilerOptions24.setLooseTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions24.checkUndefinedProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean32 = compilerOptions31.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray39 = null;
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType38, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel42 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel42, "<No stack trace available>");
        diagnosticType38.level = checkLevel42;
        compilerOptions31.checkProvides = checkLevel42;
        boolean boolean47 = compilerOptions31.removeEmptyFunctions;
        compilerOptions31.disambiguateProperties = false;
        java.lang.String str50 = compilerOptions31.sourceMapOutputPath;
        compilerOptions31.strictMessageReplacement = true;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions31.reportMissingOverride;
        compilerOptions24.checkUnreachableCode = checkLevel53;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler55 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback56 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal57 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler55, callback56);
        boolean boolean58 = nodeTraversal57.hasScope();
        int int59 = nodeTraversal57.getLineNumber();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention60 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) (byte) -1, node65);
        boolean boolean67 = node66.isOnlyModifiesThisCall();
        boolean boolean68 = defaultCodingConvention60.isPropertyTestFunction(node66);
        boolean boolean70 = defaultCodingConvention60.isExported("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder76 = node75.getJsDocBuilderForNode();
        int int77 = node75.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType78 = node75.getJSType();
        java.util.List<java.lang.String> strList79 = defaultCodingConvention60.identifyTypeDeclarationCall(node75);
        com.google.javascript.jscomp.DiagnosticType diagnosticType85 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray86 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError87 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType85, strArray86);
        java.lang.String[] strArray88 = null;
        com.google.javascript.jscomp.JSError jSError89 = nodeTraversal57.makeError(node75, diagnosticType85, strArray88);
        java.lang.String[] strArray90 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError91 = com.google.javascript.jscomp.JSError.make("hi!", node18, checkLevel53, diagnosticType85, strArray90);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(strList21);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNull(jSType78);
        org.junit.Assert.assertNull(strList79);
        org.junit.Assert.assertNotNull(diagnosticType85);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertNotNull(jSError87);
        org.junit.Assert.assertNotNull(jSError89);
        org.junit.Assert.assertNotNull(strArray90);
        org.junit.Assert.assertNotNull(jSError91);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkTypes;
        boolean boolean5 = compilerOptions0.lineBreak;
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.syntheticBlockEndMarker = "(eof)";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean20 = compilerOptions0.decomposeExpressions;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.aliasStringsBlacklist = "Unknown class name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test236");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("goog.exportSymbol", "(eof)", 9, "eof", 31);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportSymbol ((eof)#9)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("RETURN 0\n");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions2.checkMethods;
        compilerOptions2.inlineLocalFunctions = false;
        compilerOptions2.inputDelimiter = "(Named type with empty name component)";
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions2.checkUnreachableCode;
        compilerOptions0.checkProvides = checkLevel10;
        java.lang.String str12 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "// Input %num%" + "'", str12.equals("// Input %num%"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        java.lang.String str6 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.nameReferenceReportPath = "language version";
        compilerOptions0.removeDeadCode = true;
        java.lang.String str24 = compilerOptions0.reportPath;
        compilerOptions0.setPropertyAffinity(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        boolean boolean15 = node14.isVarArgs();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable16 = node14.siblings();
        node14.removeProp(150);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(nodeIterable16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat11 = compilerOptions10.errorFormat;
        java.lang.String[] strArray15 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions10.stripNamePrefixes = strSet16;
        compilerOptions0.aliasableStrings = strSet16;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.inputDelimiter = "null";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(errorFormat11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset5);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = errorFormat8.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        com.google.javascript.rhino.Node node13 = compiler10.getRoot();
        compilerInput7.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = compiler10.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler10.getMessages();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder24 = node23.getJsDocBuilderForNode();
        int int25 = node23.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray32 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType31, strArray32);
        java.lang.String[] strArray34 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node23, diagnosticType31, strArray34);
        int int36 = jSError35.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compiler10.getErrorLevel(jSError35);
        boolean boolean38 = compiler10.hasErrors();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertNotNull(messageFormatter12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(checkLevel37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test245");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        java.lang.String str4 = composeWarningsGuard3.toString();
//        java.lang.String str5 = composeWarningsGuard3.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup6 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
//        boolean boolean9 = composeWarningsGuard3.enables(diagnosticGroup8);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
//        boolean boolean11 = composeWarningsGuard3.enables(diagnosticGroup10);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
//        java.lang.String str16 = composeWarningsGuard15.toString();
//        java.lang.String str17 = composeWarningsGuard15.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray19 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup18 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray19);
//        boolean boolean21 = composeWarningsGuard15.enables(diagnosticGroup20);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
//        boolean boolean23 = composeWarningsGuard15.enables(diagnosticGroup22);
//        boolean boolean24 = composeWarningsGuard3.enables(diagnosticGroup22);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticGroup6);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNull(diagnosticGroup10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticGroup18);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(diagnosticGroup22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("ERROR 2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR 2" + "'", str1.equals("ERROR 2"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripTypes = strSet2;
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions6.brokenClosureRequiresLevel;
        compilerOptions0.checkRequires = checkLevel8;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.collapseAnonymousFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkUndefinedProperties;
        boolean boolean6 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions7.checkMethods;
        compilerOptions7.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = null;
        compilerOptions7.setRenamingPolicy(variableRenamingPolicy13, propertyRenamingPolicy14);
        java.util.Set<java.lang.String> strSet16 = compilerOptions7.stripTypePrefixes;
        compilerOptions0.stripTypePrefixes = strSet16;
        compilerOptions0.inlineLocalVariables = false;
        boolean boolean20 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        loggerErrorManager4.generateReport();
        loggerErrorManager4.setTypedPercent((double) 'a');
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.moveFunctionDeclarations;
        compilerOptions8.removeUnusedLocalVars = false;
        compilerOptions8.recordFunctionInformation = true;
        java.lang.String str14 = compilerOptions8.nameReferenceReportPath;
        compilerOptions8.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkRequires;
        com.google.javascript.jscomp.JSError jSError18 = null;
        loggerErrorManager4.println(checkLevel17, jSError18);
        diagnosticType2.level = checkLevel17;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        com.google.javascript.jscomp.ErrorFormat errorFormat3 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream4 = null;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler(printStream4);
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = errorFormat3.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, true);
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler5.getErrorManager();
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.ErrorFormat errorFormat13 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat13.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, true);
        com.google.javascript.rhino.Node node18 = compiler15.getRoot();
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
        java.nio.charset.Charset charset21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset21);
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22);
        java.lang.String str25 = jSSourceFile22.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region27 = jSSourceFile22.getRegion((int) ' ');
        jSSourceFile22.clearCachedSource();
        com.google.javascript.rhino.Node node29 = compiler15.parse(jSSourceFile22);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset32);
        com.google.javascript.rhino.Node node34 = compiler30.parse(jSSourceFile33);
        java.nio.charset.Charset charset36 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset36);
        com.google.javascript.jscomp.CompilerInput compilerInput38 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37);
        java.lang.String str40 = jSSourceFile37.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region42 = jSSourceFile37.getRegion((int) ' ');
        java.nio.charset.Charset charset44 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset44);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45);
        java.lang.String str48 = jSSourceFile45.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region50 = jSSourceFile45.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray53 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile22, jSSourceFile33, jSSourceFile37, jSSourceFile45, jSSourceFile52 };
        java.nio.charset.Charset charset55 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset55);
        com.google.javascript.jscomp.CompilerInput compilerInput57 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile56);
        java.lang.String str59 = jSSourceFile56.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region61 = jSSourceFile56.getRegion((int) ' ');
        java.nio.charset.Charset charset63 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile64 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset63);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray65 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile56, jSSourceFile64 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean67 = compilerOptions66.inferTypesInGlobalScope;
        boolean boolean68 = compilerOptions66.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result69 = compiler5.compile(jSSourceFileArray53, jSSourceFileArray65, compilerOptions66);
        compilerOptions66.setManageClosureDependencies(false);
        compilerOptions66.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions74.setRemoveClosureAsserts(false);
        compilerOptions74.removeTryCatchFinally = false;
        boolean boolean79 = compilerOptions74.checkControlStructures;
        com.google.javascript.jscomp.CheckLevel checkLevel80 = compilerOptions74.checkFunctions;
        compilerOptions66.checkRequires = checkLevel80;
        compilerOptions0.checkFunctions = checkLevel80;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(errorFormat3);
        org.junit.Assert.assertNotNull(messageFormatter7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(errorFormat13);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(region27);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(region42);
        org.junit.Assert.assertNotNull(jSSourceFile45);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(region50);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(jSSourceFileArray53);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNull(region61);
        org.junit.Assert.assertNotNull(jSSourceFile64);
        org.junit.Assert.assertNotNull(jSSourceFileArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(result69);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + checkLevel80 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel80.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.renamePrefix = "";
        compilerOptions0.setProcessObjectPropertyString(true);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) -1, node14);
        boolean boolean16 = node15.isOnlyModifiesThisCall();
        boolean boolean17 = defaultCodingConvention9.isPropertyTestFunction(node15);
        com.google.javascript.rhino.Node node18 = node7.copyInformationFrom(node15);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship19 = closureCodingConvention1.getClassesDefinedByCall(node15);
        boolean boolean21 = closureCodingConvention1.isPrivate("window");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean60 = node59.wasEmptyNode();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean66 = node65.wasEmptyNode();
        com.google.javascript.rhino.Node node67 = node59.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (byte) -1, node81);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(15, node67, node71, node76, node82, 10, 49);
        boolean boolean86 = node53.hasChild(node76);
        java.util.List<java.lang.String> strList87 = closureCodingConvention1.identifyTypeDeclarationCall(node53);
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(23, node53);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(subclassRelationship19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNull(strList87);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.clearSideEffectFlags();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        boolean boolean14 = node11.isOptionalArg();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection15 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node11);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, node11);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(nodeCollection15);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("@IMPLEMENTATION.VERSION@", "com.google.javascript.rhino.EcmaError: null: language version", "-1");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        compilerOptions0.inlineLocalFunctions = true;
        boolean boolean13 = compilerOptions0.strictMessageReplacement;
        boolean boolean14 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(13);
        sideEffectFlags1.setMutatesGlobalState();
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean5 = compilerOptions0.checkControlStructures;
        compilerOptions0.inferTypesInGlobalScope = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.collapseAnonymousFunctions = true;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str12 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.ParserRunner.parse("EOF  0 [jsdoc_info: JSDocInfo]\n", "false", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions18.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel21 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions18.sourceMapDetailLevel = detailLevel21;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.checkRequires;
        compilerOptions0.checkMethods = checkLevel23;
        boolean boolean25 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.setRemoveAbstractMethods(false);
        byte[] byteArray28 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig29 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel21);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(byteArray28);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkTypes;
        boolean boolean5 = compilerOptions0.lineBreak;
        boolean boolean6 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = compilerOptions0.getTweakProcessing();
        compilerOptions0.disambiguateProperties = false;
        boolean boolean7 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.checkDuplicateMessages = false;
        java.lang.String str10 = compilerOptions0.locale;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.setTweakToDoubleLiteral("// Input %num%", (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "or", (int) (short) 1, "", (int) '#');
        try {
            evaluatorException5.initSourceName("EOF ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        int int8 = node4.getType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39 + "'", int8 == 39);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        boolean boolean6 = compiler0.hasErrors();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        com.google.javascript.jscomp.ErrorFormat errorFormat11 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat11.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, true);
        com.google.javascript.rhino.Node node16 = compiler13.getRoot();
        compilerInput10.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler13.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler13.getMessages();
        java.lang.String str20 = compiler13.toSource();
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset22);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23);
        com.google.javascript.jscomp.ErrorFormat errorFormat25 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        com.google.javascript.jscomp.MessageFormatter messageFormatter29 = errorFormat25.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler27, true);
        com.google.javascript.rhino.Node node30 = compiler27.getRoot();
        compilerInput24.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler27);
        com.google.javascript.jscomp.JSError[] jSErrorArray32 = compiler27.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState33 = compiler27.getState();
        compiler13.setState(intermediateState33);
        compiler0.setState(intermediateState33);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(errorFormat11);
        org.junit.Assert.assertNotNull(messageFormatter15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(errorFormat25);
        org.junit.Assert.assertNotNull(messageFormatter29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(jSErrorArray32);
        org.junit.Assert.assertNotNull(intermediateState33);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder13 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder13.append("goog.exportSymbol");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        boolean boolean15 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.locale = "language version: language version";
        compilerOptions0.aliasExternals = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.inputDelimiter = "(Named type with empty name component)";
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        com.google.javascript.jscomp.Scope scope6 = compiler0.getTopScope();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(scope6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.removeEmptyFunctions = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.moveFunctionDeclarations;
        compilerOptions21.removeUnusedLocalVars = false;
        compilerOptions21.recordFunctionInformation = true;
        java.lang.String str27 = compilerOptions21.nameReferenceReportPath;
        compilerOptions21.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions21.checkRequires;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel30;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.ErrorManager errorManager7 = compiler0.getErrorManager();
        int int8 = compiler0.getWarningCount();
        boolean boolean9 = compiler0.hasErrors();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(errorManager7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        boolean boolean9 = defaultCodingConvention1.isPropertyTestFunction(node7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node12 = node7.copyInformationFromForTree(node11);
        node12.setType((int) (short) -1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("error reporter", "com.google.javascript.rhino.EcmaError: null: language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType23, strArray24);
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("// Input %num%", node12, diagnosticType17, strArray24);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(jSError26);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions3.checkMethods;
        compilerOptions3.inlineLocalFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions3.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format9;
        java.lang.String str11 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
        java.lang.String str7 = compilerOptions4.jsOutputFile;
        compilerOptions4.crossModuleCodeMotion = true;
        boolean boolean10 = compilerOptions4.extractPrototypeMemberDeclarations;
        byte[] byteArray11 = compilerOptions4.inputVariableMapSerialized;
        java.lang.Object obj12 = compilerOptions4.clone();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions4.brokenClosureRequiresLevel;
        compilerOptions0.checkFunctions = checkLevel13;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing15 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean16 = tweakProcessing15.isOn();
        compilerOptions0.setTweakProcessing(tweakProcessing15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(byteArray11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + tweakProcessing15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing15.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions0.checkShadowVars = checkLevel7;
        boolean boolean9 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String[] strArray24 = new java.lang.String[] { "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nGT NUMBER 1.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: GT NUMBER 1.0 0\n", "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "(eof)", "goog.abstractMethod", "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "", "NUMBER 1.0 0", "DiagnosticGroup<internetExplorerChecks>(ERROR)", "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "Not declared as a type name", "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "(eof)", "ERROR 2", "ERROR 2" };
        java.util.ArrayList<java.lang.String> strList25 = new java.util.ArrayList<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList25, strArray24);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList25);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        loggerErrorManager1.setTypedPercent((double) 'a');
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.moveFunctionDeclarations;
        compilerOptions5.removeUnusedLocalVars = false;
        compilerOptions5.recordFunctionInformation = true;
        java.lang.String str11 = compilerOptions5.nameReferenceReportPath;
        compilerOptions5.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions5.checkRequires;
        com.google.javascript.jscomp.JSError jSError15 = null;
        loggerErrorManager1.println(checkLevel14, jSError15);
        int int17 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj5 = context0.getThreadLocal((java.lang.Object) tweakProcessing4);
        boolean boolean6 = context0.isGeneratingDebugChanged();
        boolean boolean7 = context0.isGeneratingDebugChanged();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = context0.getErrorReporter();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        context0.seal((java.lang.Object) diagnosticGroup9);
        long long11 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean12 = context0.hasCompileFunctionsWithDynamicScope();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(errorReporter8);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        java.lang.String str11 = ecmaError6.getName();
        java.lang.String str12 = ecmaError6.sourceName();
        java.lang.String str13 = ecmaError6.sourceName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
        java.lang.String str10 = compilerInput9.getName();
        com.google.javascript.jscomp.Region region12 = compilerInput9.getRegion(39);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNull(region12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean18 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.setPropertyAffinity(false);
        compilerOptions0.rewriteFunctionExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        boolean boolean14 = context0.isActivationNeeded("NUMBER 1.0 0: <No stack trace available>");
        com.google.javascript.rhino.Context context15 = new com.google.javascript.rhino.Context();
        java.lang.Object obj16 = context15.getDebuggerContextData();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) -1, node21);
        boolean boolean23 = node22.isOnlyModifiesThisCall();
        context15.putThreadLocal((java.lang.Object) boolean23, (java.lang.Object) 'a');
        int int26 = context15.getInstructionObserverThreshold();
        java.util.Locale locale27 = null;
        java.util.Locale locale28 = context15.setLocale(locale27);
        boolean boolean29 = context15.isSealed();
        com.google.javascript.rhino.Context context30 = new com.google.javascript.rhino.Context();
        java.lang.Object obj31 = context30.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context30, (long) (short) 10);
        int int34 = context30.getInstructionObserverThreshold();
        java.util.Locale locale35 = context30.getLocale();
        java.util.Locale locale36 = context15.setLocale(locale35);
        java.util.Locale locale37 = context0.setLocale(locale36);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(locale28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertNull(locale36);
        org.junit.Assert.assertNull(locale37);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.debugFunctionSideEffectsPath = "-1";
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.smartNameRemoval = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "EOF Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", "language version");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        int int32 = node22.getLineno();
        com.google.javascript.rhino.Node node33 = node22.detachFromParent();
        node33.setString("or");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = node38.copyInformationFromForTree(node44);
        node46.addSuppression("()");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        boolean boolean55 = node54.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, node23, node46, node54, 5, 8);
        boolean boolean59 = node54.hasChildren();
        boolean boolean60 = node54.hasSideEffects();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(": ");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset5);
        com.google.javascript.rhino.Node node7 = compiler3.parse(jSSourceFile6);
        com.google.javascript.rhino.Node node8 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler3);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        loggerErrorManager10.setTypedPercent((double) 120);
        int int13 = loggerErrorManager10.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = loggerErrorManager10.getWarnings();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.rhino.Node node17 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler16);
        jsAst2.clearAst();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean10 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str5 = compilerInput3.getLine((-1));
        java.lang.String str7 = compilerInput3.getLine(48);
        com.google.javascript.jscomp.SourceAst sourceAst8 = compilerInput3.getSourceAst();
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.ErrorManager errorManager13 = null;
        compilerInput12.setErrorManager(errorManager13);
        com.google.javascript.jscomp.JSModule jSModule15 = compilerInput12.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput12, "", false);
        compilerInput18.clearAst();
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset22);
        com.google.javascript.rhino.Node node24 = compiler20.parse(jSSourceFile23);
        boolean boolean25 = compiler20.hasErrors();
        compiler20.reportCodeChange();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker27 = null;
        compiler20.tracker = performanceTracker27;
        compilerInput18.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
        com.google.javascript.jscomp.SourceAst sourceAst30 = compilerInput18.getSourceAst();
        java.nio.charset.Charset charset32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset32);
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        com.google.javascript.jscomp.ErrorManager errorManager35 = null;
        compilerInput34.setErrorManager(errorManager35);
        com.google.javascript.jscomp.JSModule jSModule37 = compilerInput34.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput34, "", false);
        compilerInput40.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile42 = compilerInput40.getSourceFile();
        com.google.javascript.jscomp.SourceAst sourceAst43 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(sourceAst43, "", false);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray47 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3, compilerInput18, compilerInput40, compilerInput46 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList48 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList48, dependencyInfoArray47);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies50 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(sourceAst8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(jSModule15);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(sourceAst30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNull(jSModule37);
        org.junit.Assert.assertNotNull(sourceFile42);
        org.junit.Assert.assertNotNull(dependencyInfoArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        node54.setSourcePositionForTree((-34));
        int int67 = node54.getCharno();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 4062 + "'", int67 == 4062);
    }
}

