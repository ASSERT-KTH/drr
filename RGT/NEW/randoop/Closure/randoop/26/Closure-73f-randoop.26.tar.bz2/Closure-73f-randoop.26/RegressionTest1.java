import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        com.google.javascript.jscomp.JsAst jsAst38 = new com.google.javascript.jscomp.JsAst(sourceFile36);
        com.google.javascript.jscomp.SourceFile.Generator generator40 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("window", generator40);
        try {
            jsAst38.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(jSSourceFile41);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("window", generator2);
        jSSourceFile3.clearCachedSource();
        try {
            com.google.javascript.rhino.Node node5 = compiler0.parse(jSSourceFile3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        node6.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) -1, node14);
        node14.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node18 = node14.getLastSibling();
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node6, (java.lang.Object) node14);
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(120, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(runtimeException19);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        boolean boolean15 = node14.isVarArgs();
        com.google.javascript.rhino.Node node16 = node14.getLastSibling();
        node16.putBooleanProp((int) (short) -1, false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 23);
        boolean boolean6 = context0.hasCompileFunctionsWithDynamicScope();
        int int7 = context0.getInstructionObserverThreshold();
        int int8 = context0.getOptimizationLevel();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        java.lang.String str13 = defaultCodingConvention0.getExportPropertyFunction();
        boolean boolean15 = defaultCodingConvention0.isExported("language version");
        boolean boolean17 = defaultCodingConvention0.isValidEnumKey("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean24 = node23.wasEmptyNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean30 = node29.wasEmptyNode();
        com.google.javascript.rhino.Node node31 = node23.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (byte) -1, node45);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(15, node31, node35, node40, node46, 10, 49);
        node31.setType((int) (byte) 10);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention52 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) -1, node57);
        boolean boolean59 = node58.isOnlyModifiesThisCall();
        boolean boolean60 = defaultCodingConvention52.isPropertyTestFunction(node58);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal61 = null;
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean67 = node66.wasEmptyNode();
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast68 = defaultCodingConvention52.getObjectLiteralCast(nodeTraversal61, node66);
        node31.addChildToFront(node66);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable70 = node66.siblings();
        java.lang.String str71 = defaultCodingConvention0.identifyTypeDefAssign(node66);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(objectLiteralCast68);
        org.junit.Assert.assertNotNull(nodeIterable70);
        org.junit.Assert.assertNull(str71);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.generatePseudoNames = true;
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        java.lang.String str3 = jSSourceFile2.toString();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.debugFunctionSideEffectsPath = "(Named type with empty name component)";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(byteArray7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        boolean boolean5 = diagnosticGroup0.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        int int4 = nodeTraversal2.getLineNumber();
        com.google.javascript.jscomp.Compiler compiler5 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) -1, node10);
        node10.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node14 = node10.getLastSibling();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = null;
        java.lang.String[] strArray19 = new java.lang.String[] { "language version: language version", "Not declared as a type name", "language version: language version" };
        try {
            nodeTraversal2.report(node10, diagnosticType15, strArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(compiler5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(strArray19);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        boolean boolean12 = defaultCodingConvention4.isPropertyTestFunction(node10);
        com.google.javascript.rhino.Node node13 = null;
        java.lang.String str14 = defaultCodingConvention4.getSingletonGetterClassName(node13);
        boolean boolean16 = defaultCodingConvention4.isSuperClassReference("hi!");
        java.lang.String str17 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        boolean boolean31 = node28.isOptionalArg();
        com.google.javascript.rhino.Node node32 = node28.cloneTree();
        java.lang.String str33 = defaultCodingConvention4.identifyTypeDefAssign(node32);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention0.getDelegateRelationship(node32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType36 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType37 = null;
        closureCodingConvention0.applySubclassRelationship(functionType35, functionType36, subclassType37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean50 = node49.wasEmptyNode();
        com.google.javascript.rhino.Node node51 = node43.copyInformationFromForTree(node49);
        boolean boolean52 = closureCodingConvention0.isVarArgsParameter(node51);
        node51.setType(19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler2.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            java.lang.String[] strArray7 = compiler2.toSourceArray(jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(messageFormatter5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType5, strArray6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = jSError7.getType();
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertNotNull(diagnosticType8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean18 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = compilerOptions0.getTweakProcessing();
        java.util.List<java.lang.String> strList5 = null;
        try {
            compilerOptions0.setManageClosureDependencies(strList5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        java.lang.String str11 = ecmaError6.getName();
        java.lang.String str12 = ecmaError6.sourceName();
        try {
            ecmaError6.initSourceName("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "or" + "'", str1.equals("or"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput15 = compiler6.getInput("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node11 = node6.copyInformationFromForTree(node10);
        node6.setType(0);
        java.lang.String str14 = node6.getQualifiedName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.specializeInitialModule = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("window", "(Named type with empty name component)");
        java.io.Reader reader3 = sourceFile2.getCodeReader();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(reader3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.strictMessageReplacement = true;
        java.lang.String str22 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean51 = node50.wasEmptyNode();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean57 = node56.wasEmptyNode();
        com.google.javascript.rhino.Node node58 = node50.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) (byte) -1, node72);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(15, node58, node62, node67, node73, 10, 49);
        com.google.javascript.rhino.Node node77 = node73.getLastSibling();
        com.google.javascript.rhino.Node node78 = node77.getLastChild();
        boolean boolean79 = closureCodingConvention0.isOptionalParameter(node78);
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node86 = new com.google.javascript.rhino.Node((int) (byte) -1, node85);
        node85.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node93 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node94 = new com.google.javascript.rhino.Node((int) (byte) -1, node93);
        node93.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node97 = node93.getLastSibling();
        java.lang.RuntimeException runtimeException98 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node85, (java.lang.Object) node93);
        try {
            java.util.List<java.lang.String> strList99 = closureCodingConvention0.identifyTypeDeclarationCall(node93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(node97);
        org.junit.Assert.assertNotNull(runtimeException98);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(": ");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset5);
        com.google.javascript.rhino.Node node7 = compiler3.parse(jSSourceFile6);
        com.google.javascript.rhino.Node node8 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler3);
        com.google.javascript.jscomp.Result result9 = compiler3.getResult();
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.ErrorFormat errorFormat14 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream15 = null;
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler(printStream15);
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = errorFormat14.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler16, true);
        com.google.javascript.rhino.Node node19 = compiler16.getRoot();
        compilerInput13.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler16);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler16.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray22 = compiler16.getMessages();
        java.lang.String str23 = compiler16.toSource();
        java.nio.charset.Charset charset25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset25);
        com.google.javascript.jscomp.CompilerInput compilerInput27 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile26);
        com.google.javascript.jscomp.ErrorFormat errorFormat28 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream29 = null;
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler(printStream29);
        com.google.javascript.jscomp.MessageFormatter messageFormatter32 = errorFormat28.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler30, true);
        com.google.javascript.rhino.Node node33 = compiler30.getRoot();
        compilerInput27.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler30);
        com.google.javascript.jscomp.JSError[] jSErrorArray35 = compiler30.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState36 = compiler30.getState();
        compiler16.setState(intermediateState36);
        compiler3.setState(intermediateState36);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(result9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(errorFormat14);
        org.junit.Assert.assertNotNull(messageFormatter18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(jSErrorArray21);
        org.junit.Assert.assertNotNull(jSErrorArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(errorFormat28);
        org.junit.Assert.assertNotNull(messageFormatter32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNotNull(jSErrorArray35);
        org.junit.Assert.assertNotNull(intermediateState36);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.checkProvides = checkLevel12;
        java.lang.String str14 = compilerOptions0.inputDelimiter;
        boolean boolean15 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "// Input %num%" + "'", str14.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("error reporter", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor3 = ancestorIterable2.iterator();
        org.junit.Assert.assertNotNull(ancestorIterable2);
        org.junit.Assert.assertNotNull(nodeItor3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        try {
            ecmaError6.initLineSource("(Named type with empty name component)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        node12.addSuppression("()");
        com.google.javascript.rhino.Node node15 = node12.cloneTree();
        java.lang.String str16 = node15.toStringTree();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EOF  0 [jsdoc_info: JSDocInfo]\n" + "'", str16.equals("EOF  0 [jsdoc_info: JSDocInfo]\n"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("Unknown class name", checkLevel1, "EOF  0");
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        boolean boolean10 = defaultCodingConvention0.isExported("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean17 = node16.wasEmptyNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node24 = node16.copyInformationFromForTree(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(15, node24, node28, node33, node39, 10, 49);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean49 = node48.wasEmptyNode();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean55 = node54.wasEmptyNode();
        com.google.javascript.rhino.Node node56 = node48.copyInformationFromForTree(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (byte) -1, node70);
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node(15, node56, node60, node65, node71, 10, 49);
        boolean boolean75 = node42.hasChild(node65);
        int int76 = node65.getSourcePosition();
        java.util.List<java.lang.String> strList77 = defaultCodingConvention0.identifyTypeDeclarationCall(node65);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 100 + "'", int76 == 100);
        org.junit.Assert.assertNull(strList77);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripTypes = strSet2;
        compilerOptions0.removeUnusedLocalVars = true;
        compilerOptions0.checkSymbols = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("null");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean3 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        boolean boolean6 = node5.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) -1, node12);
        boolean boolean14 = node13.isOnlyModifiesThisCall();
        boolean boolean15 = defaultCodingConvention7.isPropertyTestFunction(node13);
        com.google.javascript.rhino.Node node16 = node5.copyInformationFrom(node13);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention18 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean20 = closureCodingConvention18.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean32 = node31.wasEmptyNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node39 = node31.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(15, node39, node43, node48, node54, 10, 49);
        java.lang.String str58 = closureCodingConvention18.extractClassNameIfRequire(node25, node54);
        try {
            node16.addChildrenToFront(node54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "Unknown class name", "<No stack trace available>", 5, "RETURN 0\n", 110);
        try {
            ecmaError6.initSourceName("false");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        com.google.javascript.jscomp.SourceMap sourceMap6 = compiler0.getSourceMap();
        java.lang.Class<?> wildcardClass7 = compiler0.getClass();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(sourceMap6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("com.google.javascript.rhino.EcmaError: TypeError: Cannot set property \"NUMBER 52.0 0\" of false to \"NUMBER 52.0 0\"");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean50 = closureCodingConvention48.isPrivate("NUMBER 1.0 0");
        java.lang.String str51 = closureCodingConvention48.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention52 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) -1, node57);
        boolean boolean59 = node58.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention60 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) (byte) -1, node65);
        boolean boolean67 = node66.isOnlyModifiesThisCall();
        boolean boolean68 = defaultCodingConvention60.isPropertyTestFunction(node66);
        com.google.javascript.rhino.Node node69 = node58.copyInformationFrom(node66);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship70 = closureCodingConvention52.getClassesDefinedByCall(node66);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str75 = closureCodingConvention48.extractClassNameIfProvide(node66, node74);
        java.lang.String str76 = closureCodingConvention0.getSingletonGetterClassName(node66);
        com.google.javascript.rhino.Node node77 = null;
        boolean boolean78 = closureCodingConvention0.isVarArgsParameter(node77);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "goog.abstractMethod" + "'", str51.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNull(subclassRelationship70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray14 = null;
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType13, strArray14);
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel17, "<No stack trace available>");
        diagnosticType13.level = checkLevel17;
        compilerOptions6.checkProvides = checkLevel17;
        compilerOptions6.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions6.aggressiveVarCheck;
        boolean boolean25 = compilerOptions6.closurePass;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig26 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions6);
        compiler2.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig26);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        boolean boolean6 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.inferTypesInGlobalScope;
        boolean boolean5 = compilerOptions3.crossModuleMethodMotion;
        compilerOptions3.collapseAnonymousFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions3.checkUndefinedProperties;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = null;
        java.lang.String[] strArray14 = new java.lang.String[] { "eof", "or", "RETURN 0\n", "()" };
        try {
            com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("false", 24, 29, checkLevel8, diagnosticType9, strArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.rhino.Node node3 = compiler1.getRoot();
        try {
            compiler1.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertNull(node3);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup8;
//        boolean boolean10 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup8;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertNull(diagnosticGroup8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions4.inlineLocalFunctions = false;
        compilerOptions4.closurePass = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripNameSuffixes;
        java.lang.String str13 = compilerOptions4.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions14.errorFormat;
        java.lang.String[] strArray19 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions14.stripNamePrefixes = strSet20;
        compilerOptions4.aliasableStrings = strSet20;
        compilerOptions0.stripTypes = strSet20;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
        compilerOptions0.checkUndefinedProperties = checkLevel25;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.aliasExternals = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = null;
        com.google.javascript.jscomp.Scope scope14 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray15 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16, objectTypeArray15);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry13, scope14, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16);
        boolean boolean20 = defaultCodingConvention0.isPrivate("");
        java.lang.String str21 = defaultCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(objectTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        node8.putProp((int) (short) 0, (java.lang.Object) (byte) 100);
        com.google.javascript.rhino.Node node16 = null;
        try {
            node8.addChildrenToFront(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = closureCodingConvention0.getClassesDefinedByCall(node14);
        boolean boolean20 = closureCodingConvention0.isPrivate("window");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node26 = node24.getAncestor(9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) -1, node32);
        boolean boolean34 = node33.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention35 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        boolean boolean42 = node41.isOnlyModifiesThisCall();
        boolean boolean43 = defaultCodingConvention35.isPropertyTestFunction(node41);
        com.google.javascript.rhino.Node node44 = node33.copyInformationFrom(node41);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship45 = closureCodingConvention27.getClassesDefinedByCall(node41);
        com.google.javascript.rhino.Node node46 = node41.getLastChild();
        java.lang.String str47 = closureCodingConvention0.extractClassNameIfProvide(node24, node41);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection48 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(subclassRelationship45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection48);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions19.checkMethods;
        compilerOptions19.inlineLocalFunctions = false;
        compilerOptions19.closurePass = true;
        java.util.Set<java.lang.String> strSet27 = compilerOptions19.stripNameSuffixes;
        java.lang.String str28 = compilerOptions19.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat30 = compilerOptions29.errorFormat;
        java.lang.String[] strArray34 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet35 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet35, strArray34);
        compilerOptions29.stripNamePrefixes = strSet35;
        compilerOptions19.aliasableStrings = strSet35;
        compilerOptions0.stripNameSuffixes = strSet35;
        compilerOptions0.unaliasableGlobals = "window";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(errorFormat30);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        java.lang.String str33 = closureCodingConvention12.extractClassNameIfProvide(node17, node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship34 = defaultCodingConvention0.getClassesDefinedByCall(node17);
        java.lang.String str35 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node36 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship37 = defaultCodingConvention0.getClassesDefinedByCall(node36);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(subclassRelationship34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(subclassRelationship37);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(": ");
        try {
            java.io.Reader reader2 = sourceFile1.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: :  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node5 = node3.getAncestor(9);
        try {
            node5.setType((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        boolean boolean19 = node13.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node20 = node13.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo21 = null;
        node13.setJSDocInfo(jSDocInfo21);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        java.lang.String str19 = compilerOptions0.instrumentationTemplate;
        boolean boolean20 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            com.google.javascript.rhino.Context.reportWarning("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        boolean boolean6 = node5.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) -1, node12);
        boolean boolean14 = node13.isOnlyModifiesThisCall();
        boolean boolean15 = defaultCodingConvention7.isPropertyTestFunction(node13);
        com.google.javascript.rhino.Node node16 = node5.copyInformationFrom(node13);
        try {
            int int18 = node5.getExistingIntProp(28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("NUMBER 1.0 0", generator1);
        java.lang.String str3 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NUMBER 1.0 0" + "'", str3.equals("NUMBER 1.0 0"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray16 = null;
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType15, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType23, strArray24);
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compiler0.getErrorLevel(jSError26);
        com.google.javascript.jscomp.CodingConvention codingConvention28 = compiler0.getCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node41 = node33.copyInformationFromForTree(node39);
        boolean boolean42 = node39.isOptionalArg();
        com.google.javascript.rhino.Node node43 = node39.cloneTree();
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newExpr(node39);
        com.google.javascript.jscomp.NodeTraversal.Callback callback45 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node44, callback45);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(codingConvention28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        java.lang.String str6 = compiler2.toSource();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        boolean boolean12 = compilerOptions0.printInputDelimiter;
        compilerOptions0.setTweakToStringLiteral("language version", "com.google.javascript.rhino.EcmaError: : ");
        boolean boolean16 = compilerOptions0.convertToDottedProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = compilerOptions17.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions17.variableRenaming;
        boolean boolean20 = compilerOptions17.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions21.checkMethods;
        compilerOptions21.inlineLocalFunctions = false;
        compilerOptions21.closurePass = true;
        java.util.Set<java.lang.String> strSet29 = compilerOptions21.stripNameSuffixes;
        java.lang.String str30 = compilerOptions21.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat32 = compilerOptions31.errorFormat;
        java.lang.String[] strArray36 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        compilerOptions31.stripNamePrefixes = strSet37;
        compilerOptions21.aliasableStrings = strSet37;
        compilerOptions17.setIdGenerators((java.util.Set<java.lang.String>) strSet37);
        compilerOptions0.stripNamePrefixes = strSet37;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(errorFormat32);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean50 = closureCodingConvention48.isPrivate("NUMBER 1.0 0");
        java.lang.String str51 = closureCodingConvention48.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention52 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) -1, node57);
        boolean boolean59 = node58.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention60 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) (byte) -1, node65);
        boolean boolean67 = node66.isOnlyModifiesThisCall();
        boolean boolean68 = defaultCodingConvention60.isPropertyTestFunction(node66);
        com.google.javascript.rhino.Node node69 = node58.copyInformationFrom(node66);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship70 = closureCodingConvention52.getClassesDefinedByCall(node66);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str75 = closureCodingConvention48.extractClassNameIfProvide(node66, node74);
        java.lang.String str76 = closureCodingConvention0.getSingletonGetterClassName(node66);
        com.google.javascript.rhino.jstype.FunctionType functionType77 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType77, functionType78, objectType79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "goog.abstractMethod" + "'", str51.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNull(subclassRelationship70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(str76);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.labelRenaming = false;
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkControlStructures = false;
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.optimizeArgumentsArray = false;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.rewriteFunctionExpressions = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray17 = null;
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType16, strArray17);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel20, "<No stack trace available>");
        diagnosticType16.level = checkLevel20;
        compilerOptions9.checkProvides = checkLevel20;
        compilerOptions9.setCollapsePropertiesOnExternTypes(false);
        compilerOptions9.setShadowVariables(true);
        compilerOptions9.reserveRawExports = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode31 = compilerOptions9.tracer;
        compilerOptions0.tracer = tracerMode31;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + tracerMode31 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode31.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean5 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset7);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, true);
        com.google.javascript.rhino.Node node15 = compiler12.getRoot();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        java.lang.String str22 = jSSourceFile19.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region24 = jSSourceFile19.getRegion((int) ' ');
        jSSourceFile19.clearCachedSource();
        com.google.javascript.rhino.Node node26 = compiler12.parse(jSSourceFile19);
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset29);
        com.google.javascript.rhino.Node node31 = compiler27.parse(jSSourceFile30);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        java.lang.String str37 = jSSourceFile34.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region39 = jSSourceFile34.getRegion((int) ' ');
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str45 = jSSourceFile42.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region47 = jSSourceFile42.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile30, jSSourceFile34, jSSourceFile42, jSSourceFile49 };
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile53);
        java.lang.String str56 = jSSourceFile53.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region58 = jSSourceFile53.getRegion((int) ' ');
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.inferTypesInGlobalScope;
        boolean boolean65 = compilerOptions63.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result66 = compiler2.compile(jSSourceFileArray50, jSSourceFileArray62, compilerOptions63);
        compilerOptions63.locale = "(Named type with empty name component)";
        compilerOptions63.computeFunctionSideEffects = false;
        boolean boolean71 = compilerOptions63.prettyPrint;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(region39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(region47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(region58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(result66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap1 = compilerOptions0.getTweakReplacements();
        boolean boolean2 = compilerOptions0.checkSymbols;
        compilerOptions0.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.inferTypesInGlobalScope;
        boolean boolean7 = compilerOptions5.crossModuleMethodMotion;
        boolean boolean8 = compilerOptions5.checkTypes;
        compilerOptions5.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions5.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler11);
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition14 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation15 = aliasTransformationHandler11.logAliasTransformation("NUMBER 1.0 0", aliasTransformationSourcePosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strMap1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Named type with empty name component");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        node10.setString("");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean10 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Named type with empty name component");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.Context context1 = new com.google.javascript.rhino.Context();
        java.lang.Object obj2 = context1.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, (long) (short) 10);
        int int5 = context1.getInstructionObserverThreshold();
        java.util.Locale locale6 = context1.getLocale();
        java.util.Locale locale7 = context0.setLocale(locale6);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNull(locale7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        compilerOptions0.setDefineToBooleanLiteral("EOF  0", true);
        boolean boolean15 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = compilerOptions0.getTweakProcessing();
        boolean boolean5 = compilerOptions0.ideMode;
        boolean boolean6 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean7 = compilerOptions0.lineBreak;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.jscomp.ErrorManager errorManager9 = compiler6.getErrorManager();
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.ErrorFormat errorFormat14 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream15 = null;
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler(printStream15);
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = errorFormat14.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler16, true);
        com.google.javascript.rhino.Node node19 = compiler16.getRoot();
        compilerInput13.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler16);
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset22);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23);
        java.lang.String str26 = jSSourceFile23.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region28 = jSSourceFile23.getRegion((int) ' ');
        jSSourceFile23.clearCachedSource();
        com.google.javascript.rhino.Node node30 = compiler16.parse(jSSourceFile23);
        com.google.javascript.jscomp.Compiler compiler31 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset33);
        com.google.javascript.rhino.Node node35 = compiler31.parse(jSSourceFile34);
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset37);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38);
        java.lang.String str41 = jSSourceFile38.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region43 = jSSourceFile38.getRegion((int) ' ');
        java.nio.charset.Charset charset45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset45);
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46);
        java.lang.String str49 = jSSourceFile46.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region51 = jSSourceFile46.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray54 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile34, jSSourceFile38, jSSourceFile46, jSSourceFile53 };
        java.nio.charset.Charset charset56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset56);
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        java.lang.String str60 = jSSourceFile57.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region62 = jSSourceFile57.getRegion((int) ' ');
        java.nio.charset.Charset charset64 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset64);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray66 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile57, jSSourceFile65 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean68 = compilerOptions67.inferTypesInGlobalScope;
        boolean boolean69 = compilerOptions67.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result70 = compiler6.compile(jSSourceFileArray54, jSSourceFileArray66, compilerOptions67);
        com.google.javascript.jscomp.JSModule[] jSModuleArray71 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean73 = compilerOptions72.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType79 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray80 = null;
        com.google.javascript.jscomp.JSError jSError81 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType79, strArray80);
        com.google.javascript.jscomp.CheckLevel checkLevel83 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType85 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel83, "<No stack trace available>");
        diagnosticType79.level = checkLevel83;
        compilerOptions72.checkProvides = checkLevel83;
        com.google.javascript.jscomp.CheckLevel checkLevel88 = compilerOptions72.checkMissingGetCssNameLevel;
        compilerOptions72.inferTypesInGlobalScope = false;
        java.lang.String str91 = compilerOptions72.locale;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy92 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions72.propertyRenaming = propertyRenamingPolicy92;
        com.google.javascript.jscomp.Result result94 = compiler1.compile(jSSourceFileArray54, jSModuleArray71, compilerOptions72);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(errorManager9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(errorFormat14);
        org.junit.Assert.assertNotNull(messageFormatter18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(region28);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(region43);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNull(region51);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFileArray54);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNull(region62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(jSSourceFileArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(result70);
        org.junit.Assert.assertNotNull(jSModuleArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(diagnosticType79);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType85);
        org.junit.Assert.assertTrue("'" + checkLevel88 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel88.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str91);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy92 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy92.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result94);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        try {
            ecmaError6.initColumnNumber(19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (-1L));
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean46 = node45.wasEmptyNode();
        com.google.javascript.rhino.Node node47 = node39.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (byte) -1, node61);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(15, node47, node51, node56, node62, 10, 49);
        node47.setType(0);
        try {
            node1.addChildBefore(node15, node47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node has siblings.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker7 = null;
        compiler0.tracker = performanceTracker7;
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler0.getWarnings();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(jSErrorArray9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        com.google.javascript.rhino.Context context5 = new com.google.javascript.rhino.Context();
        java.lang.Object obj6 = context5.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context5, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing9 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj10 = context5.getThreadLocal((java.lang.Object) tweakProcessing9);
        compilerOptions0.setTweakProcessing(tweakProcessing9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + tweakProcessing9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing9.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(": ");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset5);
        com.google.javascript.rhino.Node node7 = compiler3.parse(jSSourceFile6);
        com.google.javascript.rhino.Node node8 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler3);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.ErrorManager errorManager13 = null;
        compilerInput12.setErrorManager(errorManager13);
        com.google.javascript.jscomp.JSModule jSModule15 = compilerInput12.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput12, "", false);
        compilerInput18.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile20 = compilerInput18.getSourceFile();
        try {
            jsAst2.setSourceFile(sourceFile20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(jSModule15);
        org.junit.Assert.assertNotNull(sourceFile20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = closureCodingConvention0.getClassesDefinedByCall(node14);
        boolean boolean20 = closureCodingConvention0.isPrivate("window");
        boolean boolean22 = closureCodingConvention0.isConstantKey("hi!");
        boolean boolean24 = closureCodingConvention0.isConstantKey("");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        com.google.javascript.jscomp.JsAst jsAst38 = new com.google.javascript.jscomp.JsAst(sourceFile36);
        try {
            java.io.Reader reader39 = sourceFile36.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: () (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.inlineLocalFunctions = false;
        boolean boolean21 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        java.lang.String str5 = defaultCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "window" + "'", str5.equals("window"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", (int) (byte) 1, "", 48);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = evaluatorException5.getScriptStackTrace(filenameFilter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray12 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup11 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray12);
        java.lang.Object obj14 = context0.getThreadLocal((java.lang.Object) diagnosticGroupArray12);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroupArray12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        compilerOptions0.markAsCompiled = true;
        java.util.Set<java.lang.String> strSet14 = compilerOptions0.stripTypes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet14);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        boolean boolean12 = context0.isGeneratingDebugChanged();
        com.google.javascript.rhino.Context context13 = new com.google.javascript.rhino.Context();
        java.lang.Object obj14 = context13.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context13, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context13, (long) 23);
        java.util.Locale locale19 = context13.getLocale();
        java.util.Locale locale20 = context0.setLocale(locale19);
        java.util.Locale locale21 = context0.getLocale();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNull(locale20);
        org.junit.Assert.assertNotNull(locale21);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions4.inlineLocalFunctions = false;
        compilerOptions4.closurePass = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripNameSuffixes;
        java.lang.String str13 = compilerOptions4.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions14.errorFormat;
        java.lang.String[] strArray19 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions14.stripNamePrefixes = strSet20;
        compilerOptions4.aliasableStrings = strSet20;
        compilerOptions0.stripTypes = strSet20;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
        compilerOptions0.checkUndefinedProperties = checkLevel25;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node14 = node13.getParent();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-1), node13, 2, 0);
        java.lang.String str18 = node17.toString();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR 2" + "'", str18.equals("ERROR 2"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.strictMessageReplacement = true;
        compilerOptions0.checkTypedPropertyCalls = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkSymbols = false;
        compilerOptions0.closurePass = true;
        boolean boolean11 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.unaliasableGlobals = "null";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.debugFunctionSideEffectsPath = "-1";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy22 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy22;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy22.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean4 = compilerOptions0.generateExports;
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        boolean boolean6 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean4 = compilerOptions0.generateExports;
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        compilerOptions0.syntheticBlockStartMarker = "<No stack trace available>";
        compilerOptions0.skipAllCompilerPasses();
        java.lang.String str9 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset24);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.ErrorFormat errorFormat27 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat27.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler29, true);
        com.google.javascript.rhino.Node node32 = compiler29.getRoot();
        compilerInput26.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
        com.google.javascript.jscomp.JSError[] jSErrorArray34 = compiler29.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray35 = compiler29.getMessages();
        java.lang.String str36 = compiler29.toSource();
        compilerInput22.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
        java.lang.String str38 = compilerInput22.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(errorFormat27);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNotNull(jSErrorArray34);
        org.junit.Assert.assertNotNull(jSErrorArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        java.lang.String str17 = ecmaError14.toString();
        java.lang.String str18 = ecmaError14.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str17.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean5 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig7 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.sourceName();
        java.lang.Throwable[] throwableArray8 = ecmaError6.getSuppressed();
        java.lang.String str9 = ecmaError6.getName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        java.lang.String str17 = ecmaError14.toString();
        java.lang.Throwable[] throwableArray18 = ecmaError14.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str17.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
        compilerInput9.clearAst();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
        boolean boolean16 = compiler11.hasErrors();
        compiler11.reportCodeChange();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
        compiler11.tracker = performanceTracker18;
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = null;
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset24);
        com.google.javascript.rhino.Node node26 = compiler22.parse(jSSourceFile25);
        compiler22.disableThreads();
        int int28 = compiler22.getErrorCount();
        java.nio.charset.Charset charset30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset30);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31);
        java.lang.String str34 = jSSourceFile31.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region36 = jSSourceFile31.getRegion((int) ' ');
        java.nio.charset.Charset charset38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset38);
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
        com.google.javascript.jscomp.ErrorFormat errorFormat41 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream42 = null;
        com.google.javascript.jscomp.Compiler compiler43 = new com.google.javascript.jscomp.Compiler(printStream42);
        com.google.javascript.jscomp.MessageFormatter messageFormatter45 = errorFormat41.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler43, true);
        com.google.javascript.rhino.Node node46 = compiler43.getRoot();
        compilerInput40.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler43);
        java.nio.charset.Charset charset49 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset49);
        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile50);
        java.lang.String str53 = jSSourceFile50.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region55 = jSSourceFile50.getRegion((int) ' ');
        jSSourceFile50.clearCachedSource();
        com.google.javascript.rhino.Node node57 = compiler43.parse(jSSourceFile50);
        java.nio.charset.Charset charset59 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset59);
        com.google.javascript.jscomp.CompilerInput compilerInput61 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60);
        java.lang.String str63 = jSSourceFile60.getLine((int) (byte) 0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str67 = jSSourceFile66.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput69 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile66, false);
        java.lang.String str70 = jSSourceFile66.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray71 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile50, jSSourceFile60, jSSourceFile66 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions72.setRemoveClosureAsserts(false);
        compilerOptions72.disableRuntimeTypeCheck();
        boolean boolean76 = compilerOptions72.inlineAnonymousFunctionExpressions;
        boolean boolean77 = compilerOptions72.inlineConstantVars;
        com.google.javascript.jscomp.Result result78 = compiler22.compile(jSSourceFile31, jSSourceFileArray71, compilerOptions72);
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat80 = compilerOptions79.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy81 = compilerOptions79.variableRenaming;
        java.lang.String str82 = compilerOptions79.jsOutputFile;
        compilerOptions79.crossModuleCodeMotion = true;
        boolean boolean85 = compilerOptions79.extractPrototypeMemberDeclarations;
        try {
            com.google.javascript.jscomp.Result result86 = compiler11.compile(jSSourceFileArray21, jSSourceFileArray71, compilerOptions79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(region36);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(errorFormat41);
        org.junit.Assert.assertNotNull(messageFormatter45);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNull(region55);
        org.junit.Assert.assertNull(node57);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "language version" + "'", str67.equals("language version"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "language version" + "'", str70.equals("language version"));
        org.junit.Assert.assertNotNull(jSSourceFileArray71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(result78);
        org.junit.Assert.assertNotNull(errorFormat80);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy81 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy81.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "" + "'", str82.equals(""));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str5 = compilerInput3.getLine((-1));
        java.lang.String str7 = compilerInput3.getLine(48);
        com.google.javascript.jscomp.SourceAst sourceAst8 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(sourceAst8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getLanguageVersion();
        java.lang.String str5 = context0.getImplementationVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        boolean boolean19 = node13.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node20 = node13.getLastSibling();
        node20.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.specializeInitialModule = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.checkEs5Strict = false;
        java.lang.String str6 = compilerOptions0.renamePrefix;
        compilerOptions0.instrumentForCoverageOnly = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setChainCalls(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        boolean boolean8 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.Context.checkOptimizationLevel(6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.Context.checkOptimizationLevel(0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(errorManager4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        boolean boolean18 = node17.isQuotedString();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) -1, node46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(15, node32, node36, node41, node47, 10, 49);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (byte) -1, node56);
        node56.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (byte) -1, node64);
        node64.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node68 = node64.getLastSibling();
        java.lang.RuntimeException runtimeException69 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node56, (java.lang.Object) node64);
        boolean boolean70 = node64.isNoSideEffectsCall();
        boolean boolean71 = node64.isLocalResultCall();
        try {
            com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node(9, node17, node47, node64, 47, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(runtimeException69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        boolean boolean14 = context0.isActivationNeeded("NUMBER 1.0 0: <No stack trace available>");
        context0.removeActivationName("");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.cloneTree();
        java.lang.String str34 = defaultCodingConvention0.getSingletonGetterClassName(node33);
        com.google.javascript.rhino.Node node35 = node33.removeFirstChild();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(node35);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        com.google.javascript.jscomp.SourceMap sourceMap6 = compiler0.getSourceMap();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("Unknown class name", charset8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str13 = jSSourceFile12.getOriginalPath();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = null;
        try {
            com.google.javascript.jscomp.Result result15 = compiler0.compile(jSSourceFile9, jSSourceFile12, compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(sourceMap6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "language version" + "'", str13.equals("language version"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        java.util.Locale locale12 = null;
        java.util.Locale locale13 = context0.setLocale(locale12);
        boolean boolean14 = context0.isSealed();
        int int15 = context0.getLanguageVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph3.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean3 = compilerOptions0.checkTypes;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.reportPath = "NUMBER 1.0 0";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        int int8 = node6.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray15 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType14, strArray15);
        java.lang.String[] strArray17 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node6, diagnosticType14, strArray17);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection19 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node6);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(31, node6, node23, node27, 18, 120);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean37 = node36.wasEmptyNode();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean43 = node42.wasEmptyNode();
        com.google.javascript.rhino.Node node44 = node36.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (byte) -1, node58);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(15, node44, node48, node53, node59, 10, 49);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean69 = node68.wasEmptyNode();
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean75 = node74.wasEmptyNode();
        com.google.javascript.rhino.Node node76 = node68.copyInformationFromForTree(node74);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node90 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node((int) (byte) -1, node90);
        com.google.javascript.rhino.Node node94 = new com.google.javascript.rhino.Node(15, node76, node80, node85, node91, 10, 49);
        boolean boolean95 = node62.hasChild(node85);
        com.google.javascript.rhino.Node node96 = node6.copyInformationFrom(node62);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(nodeCollection19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(node96);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        boolean boolean5 = compilerOptions0.gatherCssNames;
        boolean boolean6 = compilerOptions0.prettyPrint;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap7 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap7;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        boolean boolean19 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(detailLevel20);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        try {
            compiler0.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 120);
        int int4 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            boolean boolean6 = compiler5.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "hi!", "@IMPLEMENTATION.VERSION@", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        com.google.javascript.rhino.Node node14 = compiler6.getRoot();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 23);
        java.util.Locale locale6 = context0.getLocale();
        boolean boolean7 = context0.hasCompileFunctionsWithDynamicScope();
        int int8 = context0.getLanguageVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("NUMBER 1.0 0", "Not declared as a type name", 0, "", 5);
        java.lang.String str6 = evaluatorException5.sourceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkUndefinedProperties;
        boolean boolean12 = compilerOptions0.optimizeParameters;
        compilerOptions0.instrumentForCoverage = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap15 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = compilerOptions16.errorFormat;
        java.lang.String[] strArray21 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        compilerOptions16.stripNamePrefixes = strSet22;
        compilerOptions0.stripNamePrefixes = strSet22;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap15);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(1);
        sideEffectFlags1.setReturnsTainted();
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
        try {
            java.lang.String str23 = compilerInput22.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node22.cloneTree();
        boolean boolean33 = node32.isVarArgs();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        com.google.javascript.jscomp.JSModule jSModule21 = null;
        try {
            java.lang.String str22 = compiler6.toSource(jSModule21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        java.lang.String str8 = ecmaError6.lineSource();
        java.lang.String str9 = ecmaError6.details();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ": " + "'", str9.equals(": "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.checkProvides = checkLevel12;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        int int11 = ecmaError6.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        boolean boolean12 = compilerOptions0.printInputDelimiter;
        compilerOptions0.setTweakToStringLiteral("language version", "com.google.javascript.rhino.EcmaError: : ");
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset7);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, true);
        com.google.javascript.rhino.Node node15 = compiler12.getRoot();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        java.lang.String str22 = jSSourceFile19.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region24 = jSSourceFile19.getRegion((int) ' ');
        jSSourceFile19.clearCachedSource();
        com.google.javascript.rhino.Node node26 = compiler12.parse(jSSourceFile19);
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset29);
        com.google.javascript.rhino.Node node31 = compiler27.parse(jSSourceFile30);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        java.lang.String str37 = jSSourceFile34.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region39 = jSSourceFile34.getRegion((int) ' ');
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str45 = jSSourceFile42.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region47 = jSSourceFile42.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile30, jSSourceFile34, jSSourceFile42, jSSourceFile49 };
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile53);
        java.lang.String str56 = jSSourceFile53.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region58 = jSSourceFile53.getRegion((int) ' ');
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.inferTypesInGlobalScope;
        boolean boolean65 = compilerOptions63.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result66 = compiler2.compile(jSSourceFileArray50, jSSourceFileArray62, compilerOptions63);
        compilerOptions63.setManageClosureDependencies(false);
        compilerOptions63.deadAssignmentElimination = true;
        compilerOptions63.setCollapsePropertiesOnExternTypes(false);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(region39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(region47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(region58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(result66);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = compilerOptions6.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = compilerOptions6.variableRenaming;
        java.lang.String str9 = compilerOptions6.jsOutputFile;
        compilerOptions6.crossModuleCodeMotion = true;
        boolean boolean12 = compilerOptions6.extractPrototypeMemberDeclarations;
        compilerOptions6.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions6.checkGlobalNamesLevel;
        compilerOptions0.checkMethods = checkLevel15;
        compilerOptions0.exportTestFunctions = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(errorFormat7);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        boolean boolean12 = context0.isGeneratingDebugChanged();
        com.google.javascript.rhino.Context context13 = new com.google.javascript.rhino.Context();
        java.lang.Object obj14 = context13.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context13, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context13, (long) 23);
        java.util.Locale locale19 = context13.getLocale();
        java.util.Locale locale20 = context0.setLocale(locale19);
        int int21 = context0.getLanguageVersion();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNull(locale20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        node54.setSourcePositionForTree((-34));
        com.google.javascript.rhino.Node node67 = node54.cloneTree();
        try {
            double double68 = node54.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF  1048575 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        try {
            boolean boolean3 = compiler1.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        com.google.javascript.jscomp.MessageBundle messageBundle19 = null;
        compilerOptions0.messageBundle = messageBundle19;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "NUMBER 1.0 0: <No stack trace available>", "Not declared as a type name", 49, "@IMPLEMENTATION.VERSION@", 0);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        com.google.javascript.jscomp.CodingConvention codingConvention21 = compiler6.getCodingConvention();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(codingConvention21);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean5 = tweakProcessing4.isOn();
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        int int4 = nodeTraversal2.getLineNumber();
        int int5 = nodeTraversal2.getLineNumber();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset5);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = errorFormat8.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        com.google.javascript.rhino.Node node13 = compiler10.getRoot();
        compilerInput7.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = compiler10.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler10.getMessages();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder24 = node23.getJsDocBuilderForNode();
        int int25 = node23.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray32 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType31, strArray32);
        java.lang.String[] strArray34 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node23, diagnosticType31, strArray34);
        int int36 = jSError35.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compiler10.getErrorLevel(jSError35);
        com.google.javascript.jscomp.JSModule jSModule38 = null;
        try {
            java.lang.String str39 = compiler10.toSource(jSModule38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertNotNull(messageFormatter12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(checkLevel37);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj5 = context0.getThreadLocal((java.lang.Object) tweakProcessing4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        try {
            java.io.Reader reader2 = jSSourceFile1.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        compilerOptions0.aliasableGlobals = "NUMBER 1.0 0: <No stack trace available>";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        boolean boolean5 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.inlineLocalVariables = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setRemoveClosureAsserts(false);
        compilerOptions8.disableRuntimeTypeCheck();
        boolean boolean12 = compilerOptions8.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkFunctions;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel13;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) '#', ": ");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean10 = node9.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean16 = node15.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = node9.copyInformationFromForTree(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) -1, node31);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(15, node17, node21, node26, node32, 10, 49);
        com.google.javascript.rhino.Node node36 = node26.detachFromParent();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node36);
        node2.addChildToBack(node37);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.setDefineToStringLiteral("eof", "// Input %num%");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard3 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel2);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
//        try {
//            boolean boolean5 = diagnosticGroupWarningsGuard3.disables(diagnosticGroup4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap5 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertNotNull(strMap5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        org.junit.Assert.assertNotNull(jSErrorArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        java.lang.String str11 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean31 = node30.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = node24.copyInformationFromForTree(node30);
        java.lang.String str33 = closureCodingConvention12.extractClassNameIfProvide(node17, node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship34 = defaultCodingConvention0.getClassesDefinedByCall(node17);
        java.lang.String str35 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType38 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType36, objectType37, objectType38, functionType39, functionType40);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(subclassRelationship34);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        lightweightMessageFormatter3.setColorize(true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        boolean boolean19 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.aliasAllStrings = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = node38.copyInformationFromForTree(node44);
        node46.addSuppression("()");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        boolean boolean55 = node54.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, node23, node46, node54, 5, 8);
        com.google.javascript.rhino.Node node59 = node46.getFirstChild();
        try {
            com.google.javascript.rhino.Node node60 = node59.removeChildren();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(node59);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.devirtualizePrototypeMethods = true;
        boolean boolean8 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(": ");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.lang.String str4 = sourceFile1.getLine(11);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        boolean boolean17 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("error reporter");
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: error reporter");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Object obj1 = null;
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags2.clearSideEffectFlags();
        sideEffectFlags2.setAllFlags();
        sideEffectFlags2.clearSideEffectFlags();
        try {
            java.lang.String str6 = com.google.javascript.rhino.ScriptRuntime.getMessage2("window", obj1, (java.lang.Object) sideEffectFlags2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property window");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("NUMBER 1.0 0: <No stack trace available>", "RETURN 0\n", 18);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripTypes = strSet2;
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkUndefinedProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray15 = null;
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType14, strArray15);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel18, "<No stack trace available>");
        diagnosticType14.level = checkLevel18;
        compilerOptions7.checkProvides = checkLevel18;
        boolean boolean23 = compilerOptions7.removeEmptyFunctions;
        compilerOptions7.disambiguateProperties = false;
        java.lang.String str26 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.strictMessageReplacement = true;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkUnreachableCode = checkLevel29;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy31 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray32 = anonymousFunctionNamingPolicy31.getReservedCharacters();
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy31;
        java.lang.String str34 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy31 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy31.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray32);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertNotNull(errorFormat1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("goog.exportProperty", "(eof)", "", 34, "hi!", (int) (byte) 1);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter12 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
        java.util.logging.Logger logger13 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager14 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter12, logger13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray24 = null;
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType23, strArray24);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray32 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType31, strArray32);
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType23, strArray32);
        try {
            java.lang.String str35 = lightweightMessageFormatter12.formatError(jSError34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(jSError34);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.lang.String str11 = compilerInput3.getName();
        java.util.Collection<java.lang.String> strCollection12 = compilerInput3.getProvides();
        try {
            java.lang.String str13 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strCollection12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("or");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeEmptyFunctions = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.lineSource();
        com.google.javascript.rhino.EcmaError ecmaError14 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str15 = ecmaError14.lineSource();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError14);
        int int17 = ecmaError6.lineNumber();
        java.lang.Throwable[] throwableArray18 = ecmaError6.getSuppressed();
        java.lang.String str19 = ecmaError6.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(ecmaError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "<No stack trace available>" + "'", str19.equals("<No stack trace available>"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        boolean boolean20 = compilerOptions0.inlineAnonymousFunctionExpressions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.moveFunctionDeclarations;
        compilerOptions21.removeUnusedLocalVars = false;
        compilerOptions21.recordFunctionInformation = true;
        java.lang.String str27 = compilerOptions21.nameReferenceReportPath;
        compilerOptions21.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions21.checkRequires;
        compilerOptions0.checkUndefinedProperties = checkLevel30;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        boolean boolean6 = node5.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) -1, node12);
        boolean boolean14 = node13.isOnlyModifiesThisCall();
        boolean boolean15 = defaultCodingConvention7.isPropertyTestFunction(node13);
        com.google.javascript.rhino.Node node16 = node5.copyInformationFrom(node13);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node13.getJsDocBuilderForNode();
        node13.setLineno(0);
        java.lang.String str20 = node13.getQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("NUMBER 1.0 0: <No stack trace available>", ": ", "");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        java.lang.String str23 = defaultCodingConvention0.getGlobalObject();
        boolean boolean25 = defaultCodingConvention0.isValidEnumKey("// Input %num%");
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "window" + "'", str23.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        java.lang.String str5 = nodeTraversal2.getSourceName();
        boolean boolean6 = nodeTraversal2.hasScope();
        com.google.javascript.rhino.Node node7 = nodeTraversal2.getEnclosingFunction();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        boolean boolean12 = defaultCodingConvention4.isPropertyTestFunction(node10);
        com.google.javascript.rhino.Node node13 = null;
        java.lang.String str14 = defaultCodingConvention4.getSingletonGetterClassName(node13);
        boolean boolean16 = defaultCodingConvention4.isSuperClassReference("hi!");
        java.lang.String str17 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        boolean boolean31 = node28.isOptionalArg();
        com.google.javascript.rhino.Node node32 = node28.cloneTree();
        java.lang.String str33 = defaultCodingConvention4.identifyTypeDefAssign(node32);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention0.getDelegateRelationship(node32);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection35 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        node40.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node44 = node40.getLastSibling();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node40.getJsDocBuilderForNode();
        boolean boolean46 = closureCodingConvention0.isOptionalParameter(node40);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean52 = node51.wasEmptyNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean58 = node57.wasEmptyNode();
        com.google.javascript.rhino.Node node59 = node51.copyInformationFromForTree(node57);
        boolean boolean60 = node57.isOptionalArg();
        com.google.javascript.rhino.Node node61 = node57.getFirstChild();
        try {
            java.lang.String str62 = closureCodingConvention0.getSingletonGetterClassName(node57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(node61);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.sourceName();
        java.io.FilenameFilter filenameFilter8 = null;
        java.lang.String str9 = ecmaError6.getScriptStackTrace(filenameFilter8);
        try {
            ecmaError6.initColumnNumber(43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        node17.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node17);
        java.lang.Object obj23 = node21.getProp(47);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.ParserRunner.parse("com.google.javascript.rhino.EcmaError: null: language version", "", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray9 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray9);
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup10;
        try {
            boolean boolean12 = diagnosticGroupWarningsGuard7.enables(diagnosticGroup10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroupArray9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) '#', ": ");
        boolean boolean4 = node2.getBooleanProp(16);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean18 = compilerOptions0.strictMessageReplacement;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) -1, node25);
        boolean boolean27 = node26.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = node26.copyInformationFrom(node34);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship38 = closureCodingConvention20.getClassesDefinedByCall(node34);
        boolean boolean40 = closureCodingConvention20.isPrivate("window");
        boolean boolean42 = closureCodingConvention20.isConstantKey("hi!");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention20);
        java.lang.String str44 = closureCodingConvention20.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(subclassRelationship38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "goog.abstractMethod" + "'", str44.equals("goog.abstractMethod"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        boolean boolean2 = compilerOptions0.checkControlStructures;
        compilerOptions0.printInputDelimiter = false;
        boolean boolean5 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean20 = compilerOptions0.decomposeExpressions;
        compilerOptions0.setProcessObjectPropertyString(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap23 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(cssRenamingMap23);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel4, "<No stack trace available>");
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup8;
//        boolean boolean10 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup8;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertNull(diagnosticGroup8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        boolean boolean15 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.locale = "language version: language version";
        compilerOptions0.setManageClosureDependencies(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        boolean boolean36 = node33.isOptionalArg();
        com.google.javascript.rhino.Node node37 = node33.cloneTree();
        boolean boolean38 = node37.isVarArgs();
        com.google.javascript.rhino.Node node39 = node37.getLastSibling();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship40 = defaultCodingConvention0.getDelegateRelationship(node39);
        boolean boolean43 = defaultCodingConvention0.isExported("", false);
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(delegateRelationship40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.inputDelimiter = "(Named type with empty name component)";
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node11 = node6.copyInformationFromForTree(node10);
        boolean boolean12 = node10.hasSideEffects();
        java.lang.Appendable appendable13 = null;
        try {
            node10.appendStringTree(appendable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.checkProvides = checkLevel12;
        java.util.Set<java.lang.String> strSet14 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(strSet14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.inlineVariables = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions7.errorFormat;
        java.lang.String[] strArray12 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        compilerOptions7.stripNamePrefixes = strSet13;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = compilerOptions7.sourceMapDetailLevel;
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (byte) -1, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(15, node30, node34, node39, node45, 10, 49);
        com.google.javascript.rhino.Node node49 = node45.getLastSibling();
        boolean boolean50 = detailLevel16.apply(node45);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention51 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (byte) -1, node56);
        boolean boolean58 = node57.isOnlyModifiesThisCall();
        boolean boolean59 = defaultCodingConvention51.isPropertyTestFunction(node57);
        com.google.javascript.rhino.Node node60 = null;
        java.lang.String str61 = defaultCodingConvention51.getSingletonGetterClassName(node60);
        boolean boolean63 = defaultCodingConvention51.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder69 = node68.getJsDocBuilderForNode();
        boolean boolean70 = node68.hasOneChild();
        java.util.List<java.lang.String> strList71 = defaultCodingConvention51.identifyTypeDeclarationCall(node68);
        boolean boolean72 = detailLevel16.apply(node68);
        compilerOptions0.sourceMapDetailLevel = detailLevel16;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(detailLevel16);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(strList71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        com.google.javascript.rhino.Node node3 = node1.cloneTree();
        boolean boolean4 = node3.hasOneChild();
        com.google.javascript.rhino.Node node5 = node3.getParent();
        org.junit.Assert.assertNotNull(ancestorIterable2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean5 = tweakProcessing4.isOn();
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        compilerOptions0.setGenerateExports(false);
        java.lang.Object obj9 = compilerOptions0.clone();
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        node5.setLineno((int) 'a');
        com.google.javascript.rhino.Node node24 = null;
        try {
            node5.addChildToFront(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        int int11 = context0.getInstructionObserverThreshold();
        java.util.Locale locale12 = null;
        java.util.Locale locale13 = context0.setLocale(locale12);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 48);
        boolean boolean17 = context0.isActivationNeeded("");
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        boolean boolean4 = compilerOptions0.ideMode;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.enableRuntimeTypeCheck("EOF  0");
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions0.checkShadowVars = checkLevel7;
        compilerOptions0.aliasStringsBlacklist = "Named type with empty name component";
        compilerOptions0.instrumentForCoverageOnly = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = compilerOptions6.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = compilerOptions6.variableRenaming;
        java.lang.String str9 = compilerOptions6.jsOutputFile;
        compilerOptions6.crossModuleCodeMotion = true;
        boolean boolean12 = compilerOptions6.extractPrototypeMemberDeclarations;
        compilerOptions6.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions6.checkGlobalNamesLevel;
        compilerOptions0.checkMethods = checkLevel15;
        compilerOptions0.lineLengthThreshold(27);
        compilerOptions0.collapseVariableDeclarations = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(errorFormat7);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset7);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, true);
        com.google.javascript.rhino.Node node15 = compiler12.getRoot();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        java.lang.String str22 = jSSourceFile19.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region24 = jSSourceFile19.getRegion((int) ' ');
        jSSourceFile19.clearCachedSource();
        com.google.javascript.rhino.Node node26 = compiler12.parse(jSSourceFile19);
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset29);
        com.google.javascript.rhino.Node node31 = compiler27.parse(jSSourceFile30);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        java.lang.String str37 = jSSourceFile34.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region39 = jSSourceFile34.getRegion((int) ' ');
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str45 = jSSourceFile42.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region47 = jSSourceFile42.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile30, jSSourceFile34, jSSourceFile42, jSSourceFile49 };
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile53);
        java.lang.String str56 = jSSourceFile53.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region58 = jSSourceFile53.getRegion((int) ' ');
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.inferTypesInGlobalScope;
        boolean boolean65 = compilerOptions63.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result66 = compiler2.compile(jSSourceFileArray50, jSSourceFileArray62, compilerOptions63);
        compilerOptions63.setManageClosureDependencies(false);
        compilerOptions63.flowSensitiveInlineVariables = true;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(region39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(region47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(region58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(result66);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        boolean boolean23 = node16.isQualifiedName();
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str5 = compilerInput3.getLine((-1));
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "goog.abstractMethod", false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = node38.copyInformationFromForTree(node44);
        node46.addSuppression("()");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        boolean boolean55 = node54.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, node23, node46, node54, 5, 8);
        com.google.javascript.rhino.Node node60 = node54.getAncestor(9);
        boolean boolean61 = node54.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.Object obj5 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(15, node19, node23, node28, node34, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable38 = node34.getAncestors();
        java.lang.RuntimeException runtimeException39 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, obj5, (java.lang.Object) node34);
        boolean boolean40 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(ancestorIterable38);
        org.junit.Assert.assertNotNull(runtimeException39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        boolean boolean6 = compiler2.isIdeMode();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        try {
            java.lang.String str8 = compiler2.toSource(jSModule7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("or", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        compiler6.reportCodeChange();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean50 = closureCodingConvention48.isPrivate("NUMBER 1.0 0");
        java.lang.String str51 = closureCodingConvention48.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention52 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) -1, node57);
        boolean boolean59 = node58.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention60 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) (byte) -1, node65);
        boolean boolean67 = node66.isOnlyModifiesThisCall();
        boolean boolean68 = defaultCodingConvention60.isPropertyTestFunction(node66);
        com.google.javascript.rhino.Node node69 = node58.copyInformationFrom(node66);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship70 = closureCodingConvention52.getClassesDefinedByCall(node66);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str75 = closureCodingConvention48.extractClassNameIfProvide(node66, node74);
        java.lang.String str76 = closureCodingConvention0.getSingletonGetterClassName(node66);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention77 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) (byte) -1, node82);
        boolean boolean84 = node83.isOnlyModifiesThisCall();
        boolean boolean85 = defaultCodingConvention77.isPropertyTestFunction(node83);
        com.google.javascript.rhino.Node node86 = null;
        java.lang.String str87 = defaultCodingConvention77.getSingletonGetterClassName(node86);
        java.lang.String str88 = defaultCodingConvention77.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node92 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention77, "null", 34, (int) ' ');
        try {
            boolean boolean93 = closureCodingConvention0.isPropertyTestFunction(node92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "goog.abstractMethod" + "'", str51.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNull(subclassRelationship70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(str87);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(node92);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection14 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node10);
        int int15 = node10.getType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeCollection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = null;
        com.google.javascript.jscomp.Scope scope14 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray15 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16, objectTypeArray15);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry13, scope14, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16);
        boolean boolean21 = defaultCodingConvention0.isExported("error reporter", false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        boolean boolean29 = node28.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention30 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) -1, node35);
        boolean boolean37 = node36.isOnlyModifiesThisCall();
        boolean boolean38 = defaultCodingConvention30.isPropertyTestFunction(node36);
        com.google.javascript.rhino.Node node39 = node28.copyInformationFrom(node36);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship40 = closureCodingConvention22.getClassesDefinedByCall(node36);
        boolean boolean42 = closureCodingConvention22.isPrivate("window");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node48 = node46.getAncestor(9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention49 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (byte) -1, node54);
        boolean boolean56 = node55.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention57 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) -1, node62);
        boolean boolean64 = node63.isOnlyModifiesThisCall();
        boolean boolean65 = defaultCodingConvention57.isPropertyTestFunction(node63);
        com.google.javascript.rhino.Node node66 = node55.copyInformationFrom(node63);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship67 = closureCodingConvention49.getClassesDefinedByCall(node63);
        com.google.javascript.rhino.Node node68 = node63.getLastChild();
        java.lang.String str69 = closureCodingConvention22.extractClassNameIfProvide(node46, node63);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((int) (byte) -1, node75);
        node75.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node((int) (byte) -1, node83);
        node83.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node87 = node83.getLastSibling();
        java.lang.RuntimeException runtimeException88 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node75, (java.lang.Object) node83);
        boolean boolean89 = node83.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node90 = node83.getLastSibling();
        try {
            java.lang.String str91 = defaultCodingConvention0.extractClassNameIfProvide(node63, node90);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(objectTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(subclassRelationship40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(node48);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(subclassRelationship67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(runtimeException88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(node90);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        java.lang.String str19 = compilerOptions0.instrumentationTemplate;
        boolean boolean20 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) -1, node20);
        boolean boolean22 = node21.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention23 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        boolean boolean30 = node29.isOnlyModifiesThisCall();
        boolean boolean31 = defaultCodingConvention23.isPropertyTestFunction(node29);
        com.google.javascript.rhino.Node node32 = node21.copyInformationFrom(node29);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = closureCodingConvention15.getClassesDefinedByCall(node29);
        com.google.javascript.rhino.Node node34 = node29.getLastChild();
        boolean boolean35 = node14.isEquivalentTo(node29);
        com.google.javascript.rhino.Node node36 = node29.removeChildren();
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        node36.setJSType(jSType37);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(subclassRelationship33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags1.clearSideEffectFlags();
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setReturnsTainted();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.details();
        java.lang.String str11 = ecmaError6.getName();
        java.lang.String str12 = ecmaError6.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getLanguageVersion();
        com.google.javascript.rhino.EcmaError ecmaError11 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int12 = ecmaError11.columnNumber();
        java.lang.String str13 = ecmaError11.getLineSource();
        java.lang.String str14 = ecmaError11.getSourceName();
        try {
            context0.unseal((java.lang.Object) ecmaError11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(ecmaError11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("null", "language version");
        java.lang.String str3 = ecmaError2.toString();
        int int4 = ecmaError2.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: null: language version" + "'", str3.equals("com.google.javascript.rhino.EcmaError: null: language version"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset24);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.ErrorFormat errorFormat27 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat27.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler29, true);
        com.google.javascript.rhino.Node node32 = compiler29.getRoot();
        compilerInput26.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
        com.google.javascript.jscomp.JSError[] jSErrorArray34 = compiler29.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray35 = compiler29.getMessages();
        java.lang.String str36 = compiler29.toSource();
        compilerInput22.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
        com.google.javascript.jscomp.Result result38 = compiler29.getResult();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(errorFormat27);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNotNull(jSErrorArray34);
        org.junit.Assert.assertNotNull(jSErrorArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(result38);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.ErrorFormat errorFormat6 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat6.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler8, true);
        com.google.javascript.rhino.Node node11 = compiler8.getRoot();
        compilerInput5.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler8);
        int int13 = compiler8.getErrorCount();
        compiler8.reportCodeChange();
        try {
            context0.unseal((java.lang.Object) compiler8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(errorFormat6);
        org.junit.Assert.assertNotNull(messageFormatter10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("ERROR 2");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 120);
        int int4 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        double double6 = loggerErrorManager1.getTypedPercent();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 120.0d + "'", double6 == 120.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean16 = node15.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean22 = node21.wasEmptyNode();
        com.google.javascript.rhino.Node node23 = node15.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        node28.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node32 = node21.copyInformationFrom(node28);
        node21.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node35 = null;
        try {
            node8.replaceChildAfter(node21, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nLE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: LE 10 [directives: 15]\n    EOF  0\n    NUMBER 52.0 0\n    EOF  0\n    ERROR\n        NUMBER 52.0 0\n");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        try {
            int int4 = diagnosticType2.compareTo(diagnosticType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        com.google.javascript.rhino.Node node45 = com.google.javascript.jscomp.NodeUtil.newExpr(node42);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        int int6 = node4.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        int int8 = node4.getLineno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        try {
            com.google.javascript.rhino.Context.reportWarning("com.google.javascript.rhino.EcmaError: TypeError: Cannot set property \"NUMBER 52.0 0\" of false to \"NUMBER 52.0 0\"", "NUMBER 1.0 0: <No stack trace available>", 0, "language version: language version", 9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean18 = compilerOptions0.strictMessageReplacement;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) -1, node25);
        boolean boolean27 = node26.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = node26.copyInformationFrom(node34);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship38 = closureCodingConvention20.getClassesDefinedByCall(node34);
        boolean boolean40 = closureCodingConvention20.isPrivate("window");
        boolean boolean42 = closureCodingConvention20.isConstantKey("hi!");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention20);
        boolean boolean45 = closureCodingConvention20.isConstant("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(subclassRelationship38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        boolean boolean14 = context0.isActivationNeeded("NUMBER 1.0 0: <No stack trace available>");
        context0.removeActivationName("");
        context0.setCompileFunctionsWithDynamicScope(true);
        context0.setGeneratingSource(true);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) -1, node31);
        node31.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) -1, node39);
        node39.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node43 = node39.getLastSibling();
        java.lang.RuntimeException runtimeException44 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node31, (java.lang.Object) node39);
        boolean boolean45 = node39.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node46 = node39.getLastSibling();
        java.lang.String str47 = closureCodingConvention0.identifyTypeDefAssign(node46);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(runtimeException44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        boolean boolean24 = defaultCodingConvention0.isConstant("Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n");
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        boolean boolean12 = compilerOptions0.printInputDelimiter;
        compilerOptions0.setTweakToStringLiteral("language version", "com.google.javascript.rhino.EcmaError: : ");
        boolean boolean16 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt2 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt2);
        lightweightMessageFormatter3.setColorize(false);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter3, logger6);
        int int8 = loggerErrorManager7.getWarningCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setRemoveClosureAsserts(false);
        compilerOptions9.disableRuntimeTypeCheck();
        boolean boolean13 = compilerOptions9.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.checkFunctions;
        com.google.javascript.jscomp.JSError jSError15 = null;
        try {
            loggerErrorManager7.report(checkLevel14, jSError15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        boolean boolean20 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        compilerOptions0.reportMissingOverride = checkLevel21;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        boolean boolean10 = node9.isOnlyModifiesThisCall();
        boolean boolean11 = defaultCodingConvention3.isPropertyTestFunction(node9);
        com.google.javascript.rhino.Node node12 = null;
        java.lang.String str13 = defaultCodingConvention3.getSingletonGetterClassName(node12);
        boolean boolean15 = defaultCodingConvention3.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node20.getJsDocBuilderForNode();
        boolean boolean22 = node20.hasOneChild();
        java.util.List<java.lang.String> strList23 = defaultCodingConvention3.identifyTypeDeclarationCall(node20);
        com.google.javascript.rhino.Node node25 = node20.getAncestor(10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat27 = compilerOptions26.errorFormat;
        compilerOptions26.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions26.checkFunctions;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray32 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup31 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup33 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray32);
        java.lang.String str34 = diagnosticGroup33.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel36 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.make("Unknown class name", checkLevel36, "EOF  0");
        boolean boolean39 = diagnosticGroup33.matches(diagnosticType38);
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray46 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType45, strArray46);
        try {
            com.google.javascript.jscomp.JSError jSError48 = nodeTraversal2.makeError(node25, checkLevel30, diagnosticType38, strArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(strList23);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertNotNull(errorFormat27);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroupArray32);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions6.checkMethods;
        compilerOptions6.inlineLocalFunctions = false;
        compilerOptions6.closurePass = true;
        java.util.Set<java.lang.String> strSet14 = compilerOptions6.stripNameSuffixes;
        java.lang.String str15 = compilerOptions6.syntheticBlockEndMarker;
        compilerOptions6.deadAssignmentElimination = true;
        boolean boolean18 = compilerOptions6.printInputDelimiter;
        compilerOptions6.setTweakToStringLiteral("language version", "com.google.javascript.rhino.EcmaError: : ");
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions6.checkGlobalNamesLevel;
        compilerOptions0.reportMissingOverride = checkLevel22;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (-1L));
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean9 = node8.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean15 = node14.wasEmptyNode();
        com.google.javascript.rhino.Node node16 = node8.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(15, node16, node20, node25, node31, 10, 49);
        com.google.javascript.rhino.Node node35 = node25.detachFromParent();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(39, node25);
        int int37 = node25.getCharno();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable42 = node41.children();
        try {
            node1.addChildAfter(node25, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeIterable42);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.debugFunctionSideEffectsPath = "// Input %num%";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions0.checkRequires = checkLevel11;
        boolean boolean13 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy14 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy14;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy14 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy14.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = closureCodingConvention0.getClassesDefinedByCall(node14);
        boolean boolean20 = closureCodingConvention0.isPrivate("window");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node26 = node24.getAncestor(9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) -1, node32);
        boolean boolean34 = node33.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention35 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        boolean boolean42 = node41.isOnlyModifiesThisCall();
        boolean boolean43 = defaultCodingConvention35.isPropertyTestFunction(node41);
        com.google.javascript.rhino.Node node44 = node33.copyInformationFrom(node41);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship45 = closureCodingConvention27.getClassesDefinedByCall(node41);
        com.google.javascript.rhino.Node node46 = node41.getLastChild();
        java.lang.String str47 = closureCodingConvention0.extractClassNameIfProvide(node24, node41);
        int int48 = node24.getChildCount();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(subclassRelationship45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions13.checkMethods;
        compilerOptions13.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = null;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy19, propertyRenamingPolicy20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node54 = node44.cloneTree();
        com.google.javascript.rhino.Node node55 = node44.removeFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType56 = node44.getJSType();
        context0.putThreadLocal((java.lang.Object) compilerOptions13, (java.lang.Object) node44);
        compilerOptions13.setRemoveClosureAsserts(true);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(jSType56);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str7 = ecmaError6.sourceName();
        java.lang.Throwable[] throwableArray8 = ecmaError6.getSuppressed();
        try {
            ecmaError6.initColumnNumber(18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("com.google.javascript.rhino.EcmaError: : ", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        byte[] byteArray19 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.recordFunctionInformation = false;
        java.lang.String str22 = compilerOptions0.appNameStr;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(byteArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions18.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel21 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions18.sourceMapDetailLevel = detailLevel21;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.checkRequires;
        compilerOptions0.checkMethods = checkLevel23;
        boolean boolean25 = compilerOptions0.instrumentForCoverageOnly;
        java.lang.String str26 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel21);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions18.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel21 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions18.sourceMapDetailLevel = detailLevel21;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.checkRequires;
        compilerOptions0.checkMethods = checkLevel23;
        boolean boolean25 = compilerOptions0.instrumentForCoverageOnly;
        boolean boolean26 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel21);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean24 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
        org.junit.Assert.assertNull(context0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        loggerErrorManager1.setTypedPercent((double) 'a');
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.moveFunctionDeclarations;
        compilerOptions5.removeUnusedLocalVars = false;
        compilerOptions5.recordFunctionInformation = true;
        java.lang.String str11 = compilerOptions5.nameReferenceReportPath;
        compilerOptions5.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions5.checkRequires;
        com.google.javascript.jscomp.JSError jSError15 = null;
        loggerErrorManager1.println(checkLevel14, jSError15);
        loggerErrorManager1.setTypedPercent((double) (short) 0);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSErrorArray19);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setReturnsTainted();
        boolean boolean3 = sideEffectFlags0.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
        boolean boolean7 = compilerOptions4.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions8.inlineLocalFunctions = false;
        compilerOptions8.closurePass = true;
        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
        java.lang.String[] strArray23 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions18.stripNamePrefixes = strSet24;
        compilerOptions8.aliasableStrings = strSet24;
        compilerOptions4.stripTypes = strSet24;
        compilerOptions0.stripTypePrefixes = strSet24;
        compilerOptions0.setLooseTypes(false);
        boolean boolean32 = compilerOptions0.inlineGetters;
        compilerOptions0.debugFunctionSideEffectsPath = "";
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        boolean boolean2 = compilerOptions0.checkControlStructures;
        java.lang.String str3 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        int int65 = node54.getSourcePosition();
        node54.detachChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        boolean boolean4 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler2.getErrorManager();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset7);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, true);
        com.google.javascript.rhino.Node node15 = compiler12.getRoot();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        java.lang.String str22 = jSSourceFile19.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region24 = jSSourceFile19.getRegion((int) ' ');
        jSSourceFile19.clearCachedSource();
        com.google.javascript.rhino.Node node26 = compiler12.parse(jSSourceFile19);
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset29);
        com.google.javascript.rhino.Node node31 = compiler27.parse(jSSourceFile30);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        java.lang.String str37 = jSSourceFile34.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region39 = jSSourceFile34.getRegion((int) ' ');
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str45 = jSSourceFile42.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region47 = jSSourceFile42.getRegion((int) ' ');
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile30, jSSourceFile34, jSSourceFile42, jSSourceFile49 };
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile53);
        java.lang.String str56 = jSSourceFile53.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region58 = jSSourceFile53.getRegion((int) ' ');
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.inferTypesInGlobalScope;
        boolean boolean65 = compilerOptions63.crossModuleMethodMotion;
        com.google.javascript.jscomp.Result result66 = compiler2.compile(jSSourceFileArray50, jSSourceFileArray62, compilerOptions63);
        try {
            java.lang.String[] strArray67 = compiler2.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.RuntimeException: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(region39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(region47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(region58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(result66);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(15, node33);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean41 = node40.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean47 = node46.wasEmptyNode();
        com.google.javascript.rhino.Node node48 = node40.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) -1, node62);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(15, node48, node52, node57, node63, 10, 49);
        com.google.javascript.rhino.Node node67 = node57.cloneTree();
        com.google.javascript.rhino.Node node68 = node57.removeFirstChild();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder74 = node73.getJsDocBuilderForNode();
        com.google.javascript.rhino.Context context75 = new com.google.javascript.rhino.Context();
        java.lang.Object obj76 = context75.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context75, (long) (short) 10);
        int int79 = context75.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) (byte) -1, node84);
        node84.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node88 = node84.getLastSibling();
        com.google.javascript.rhino.Node node89 = node88.cloneTree();
        context75.seal((java.lang.Object) node89);
        com.google.javascript.rhino.jstype.JSType jSType91 = node89.getJSType();
        boolean boolean92 = node89.isVarArgs();
        boolean boolean93 = node73.hasChild(node89);
        try {
            node33.addChildAfter(node57, node89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node has siblings.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder74);
        org.junit.Assert.assertNull(obj76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: null: language version");
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1(": ", "error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property : ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        boolean boolean45 = node42.isLocalResultCall();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.renamePrefix = "";
        compilerOptions0.setChainCalls(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.markAsCompiled = true;
        compilerOptions0.removeEmptyFunctions = true;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig7 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        node17.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node21 = node17.getLastSibling();
        int int22 = node17.getType();
        node17.setDouble((double) (byte) 0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention25 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        boolean boolean33 = defaultCodingConvention25.isPropertyTestFunction(node31);
        com.google.javascript.rhino.Node node34 = null;
        java.lang.String str35 = defaultCodingConvention25.getSingletonGetterClassName(node34);
        java.lang.String str36 = defaultCodingConvention25.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention25, "null", 34, (int) ' ');
        try {
            node10.addChildBefore(node17, node40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39 + "'", int22 == 39);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(node40);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        boolean boolean2 = compilerOptions0.checkControlStructures;
        compilerOptions0.printInputDelimiter = true;
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(codingConvention5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str16 = jSSourceFile13.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region18 = jSSourceFile13.getRegion((int) ' ');
        jSSourceFile13.clearCachedSource();
        com.google.javascript.rhino.Node node20 = compiler6.parse(jSSourceFile13);
        java.lang.String str21 = compiler6.getAstDotGraph();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.labelRenaming = true;
        compilerOptions0.syntheticBlockEndMarker = "DiagnosticGroup<internetExplorerChecks>(ERROR)";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        com.google.javascript.jscomp.JsAst jsAst38 = new com.google.javascript.jscomp.JsAst(sourceFile36);
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst38, false);
        jsAst38.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile42 = jsAst38.getSourceFile();
        java.lang.String str43 = sourceFile42.getName();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(sourceFile42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "()" + "'", str43.equals("()"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean20 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) '#', ": ");
        boolean boolean3 = node2.hasChildren();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        boolean boolean4 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        try {
            compiler0.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        int int4 = nodeTraversal2.getLineNumber();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) -1, node10);
        boolean boolean12 = node11.isOnlyModifiesThisCall();
        boolean boolean13 = defaultCodingConvention5.isPropertyTestFunction(node11);
        boolean boolean15 = defaultCodingConvention5.isExported("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node20.getJsDocBuilderForNode();
        int int22 = node20.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType23 = node20.getJSType();
        java.util.List<java.lang.String> strList24 = defaultCodingConvention5.identifyTypeDeclarationCall(node20);
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType30, strArray31);
        java.lang.String[] strArray33 = null;
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal2.makeError(node20, diagnosticType30, strArray33);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean41 = node40.wasEmptyNode();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean47 = node46.wasEmptyNode();
        com.google.javascript.rhino.Node node48 = node40.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) -1, node62);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(15, node48, node52, node57, node63, 10, 49);
        com.google.javascript.rhino.Node node67 = node63.getLastSibling();
        boolean boolean68 = node67.isOptionalArg();
        boolean boolean69 = jSError34.equals((java.lang.Object) boolean68);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = jSError34.level;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNull(strList24);
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + checkLevel70 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel70.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.checkSymbols = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String str4 = compiler1.getSourceLine("or", 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.recordFunctionInformation = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = compilerOptions6.errorFormat;
        compilerOptions0.errorFormat = errorFormat7;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(errorFormat7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.debugFunctionSideEffectsPath = "-1";
        com.google.javascript.jscomp.CheckLevel checkLevel23 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.make("Unknown class name", checkLevel23, "EOF  0");
        compilerOptions0.checkUndefinedProperties = checkLevel23;
        boolean boolean27 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        int int19 = node17.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray26 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType25, strArray26);
        java.lang.String[] strArray28 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node17, diagnosticType25, strArray28);
        int int30 = jSError29.lineNumber;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = jSError29.getType();
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compiler6.getErrorLevel(jSError29);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNull(checkLevel32);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler48 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback49 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal50 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler48, callback49);
        boolean boolean51 = nodeTraversal50.hasScope();
        com.google.javascript.jscomp.Scope scope52 = nodeTraversal50.getScope();
        java.lang.String str53 = nodeTraversal50.getSourceName();
        int int54 = nodeTraversal50.getLineNumber();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean61 = node60.wasEmptyNode();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean67 = node66.wasEmptyNode();
        com.google.javascript.rhino.Node node68 = node60.copyInformationFromForTree(node66);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) (byte) -1, node82);
        com.google.javascript.rhino.Node node86 = new com.google.javascript.rhino.Node(15, node68, node72, node77, node83, 10, 49);
        com.google.javascript.rhino.Node node87 = node77.detachFromParent();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast88 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal50, node87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(scope52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node87);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("goog.exportProperty", "language version: language version", 0, "com.google.javascript.rhino.EcmaError: : ", 14);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportProperty");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 23);
        java.util.Locale locale6 = context0.getLocale();
        context0.removeActivationName("EOF  0");
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(locale6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean3 = compilerOptions0.gatherCssNames;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray9 = null;
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType8, strArray9);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel12, "<No stack trace available>");
        diagnosticType8.level = checkLevel12;
        compilerOptions1.checkProvides = checkLevel12;
        context0.seal((java.lang.Object) checkLevel12);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = context0.getErrorReporter();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNull(errorReporter18);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.checkProvides = checkLevel12;
        boolean boolean14 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.deadAssignmentElimination = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        java.lang.String str13 = defaultCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean25 = node24.wasEmptyNode();
        com.google.javascript.rhino.Node node26 = node18.copyInformationFromForTree(node24);
        boolean boolean27 = node24.isOptionalArg();
        com.google.javascript.rhino.Node node28 = node24.cloneTree();
        java.lang.String str29 = defaultCodingConvention0.identifyTypeDefAssign(node28);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention30 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) -1, node35);
        boolean boolean37 = node36.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention38 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) -1, node43);
        boolean boolean45 = node44.isOnlyModifiesThisCall();
        boolean boolean46 = defaultCodingConvention38.isPropertyTestFunction(node44);
        com.google.javascript.rhino.Node node47 = node36.copyInformationFrom(node44);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship48 = closureCodingConvention30.getClassesDefinedByCall(node44);
        com.google.javascript.rhino.Node node49 = node44.getLastChild();
        com.google.javascript.rhino.Node node50 = null;
        try {
            node28.replaceChildAfter(node44, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(subclassRelationship48);
        org.junit.Assert.assertNotNull(node49);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        int int6 = compiler0.getErrorCount();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        java.lang.String str12 = jSSourceFile9.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region14 = jSSourceFile9.getRegion((int) ' ');
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset16);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17);
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream20 = null;
        com.google.javascript.jscomp.Compiler compiler21 = new com.google.javascript.jscomp.Compiler(printStream20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = errorFormat19.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler21, true);
        com.google.javascript.rhino.Node node24 = compiler21.getRoot();
        compilerInput18.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler21);
        java.nio.charset.Charset charset27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset27);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        java.lang.String str31 = jSSourceFile28.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region33 = jSSourceFile28.getRegion((int) ' ');
        jSSourceFile28.clearCachedSource();
        com.google.javascript.rhino.Node node35 = compiler21.parse(jSSourceFile28);
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset37);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38);
        java.lang.String str41 = jSSourceFile38.getLine((int) (byte) 0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str45 = jSSourceFile44.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
        java.lang.String str48 = jSSourceFile44.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray49 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile28, jSSourceFile38, jSSourceFile44 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions50.setRemoveClosureAsserts(false);
        compilerOptions50.disableRuntimeTypeCheck();
        boolean boolean54 = compilerOptions50.inlineAnonymousFunctionExpressions;
        boolean boolean55 = compilerOptions50.inlineConstantVars;
        com.google.javascript.jscomp.Result result56 = compiler0.compile(jSSourceFile9, jSSourceFileArray49, compilerOptions50);
        com.google.javascript.jscomp.CheckLevel checkLevel57 = null;
        compilerOptions50.checkRequires = checkLevel57;
        byte[] byteArray59 = compilerOptions50.inputVariableMapSerialized;
        compilerOptions50.setGenerateExports(false);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(region14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(messageFormatter23);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(region33);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "language version" + "'", str45.equals("language version"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "language version" + "'", str48.equals("language version"));
        org.junit.Assert.assertNotNull(jSSourceFileArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(result56);
        org.junit.Assert.assertNull(byteArray59);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        boolean boolean46 = closureCodingConvention0.isPrivate("RETURN 0\n");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean54 = node53.wasEmptyNode();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean60 = node59.wasEmptyNode();
        com.google.javascript.rhino.Node node61 = node53.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((int) (byte) -1, node75);
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(15, node61, node65, node70, node76, 10, 49);
        com.google.javascript.rhino.Node node80 = node70.detachFromParent();
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(15, node80);
        java.lang.String str82 = closureCodingConvention0.identifyTypeDefAssign(node81);
        boolean boolean84 = closureCodingConvention0.isConstantKey("<No stack trace available>");
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(25, 2, 110);
        try {
            java.util.List<java.lang.String> strList89 = closureCodingConvention0.identifyTypeDeclarationCall(node88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable32 = node28.getAncestors();
        boolean boolean33 = node28.hasChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(ancestorIterable32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 45");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
        boolean boolean7 = compilerOptions4.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions8.inlineLocalFunctions = false;
        compilerOptions8.closurePass = true;
        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
        java.lang.String[] strArray23 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions18.stripNamePrefixes = strSet24;
        compilerOptions8.aliasableStrings = strSet24;
        compilerOptions4.stripTypes = strSet24;
        compilerOptions0.stripTypePrefixes = strSet24;
        compilerOptions0.setLooseTypes(false);
        java.util.Set<java.lang.String> strSet32 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strSet32);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.removeEmptyFunctions = true;
        com.google.javascript.jscomp.MessageBundle messageBundle21 = null;
        compilerOptions0.messageBundle = messageBundle21;
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.Object obj2 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.inferTypesInGlobalScope;
        boolean boolean5 = compilerOptions3.crossModuleMethodMotion;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions6.getTweakReplacements();
        boolean boolean8 = compilerOptions6.checkSymbols;
        compilerOptions6.inputDelimiter = "language version";
        boolean boolean11 = compilerOptions6.specializeInitialModule;
        try {
            java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.getMessage4("()", (java.lang.Object) "window", obj2, (java.lang.Object) boolean5, (java.lang.Object) boolean11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.collapseAnonymousFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap1 = compilerOptions0.getTweakReplacements();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap2 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap2;
        org.junit.Assert.assertNotNull(strMap1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getDelegateSuperclassName();
        java.lang.String str2 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = null;
        try {
            boolean boolean4 = defaultCodingConvention0.isVarArgsParameter(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        compilerOptions0.tightenTypes = true;
        compilerOptions0.setChainCalls(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getTweakReplacements();
        compilerOptions0.syntheticBlockStartMarker = "language version: language version";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strMap7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean19 = compilerOptions0.extractPrototypeMemberDeclarations;
        java.lang.String str20 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        boolean boolean49 = closureCodingConvention0.isValidEnumKey("()");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler50 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback51 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal52 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler50, callback51);
        boolean boolean53 = nodeTraversal52.hasScope();
        com.google.javascript.jscomp.Scope scope54 = nodeTraversal52.getScope();
        java.lang.String str55 = nodeTraversal52.getSourceName();
        int int56 = nodeTraversal52.getLineNumber();
        com.google.javascript.rhino.Node node57 = nodeTraversal52.getEnclosingFunction();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder64 = node63.getJsDocBuilderForNode();
        int int65 = node63.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray72 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType71, strArray72);
        java.lang.String[] strArray74 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node63, diagnosticType71, strArray74);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast76 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal52, node63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(scope54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(node57);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertNotNull(jSError75);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat20 = compilerOptions19.errorFormat;
        compilerOptions19.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing23 = compilerOptions19.getTweakProcessing();
        compilerOptions19.disambiguateProperties = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setRemoveClosureAsserts(false);
        compilerOptions26.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat31 = compilerOptions30.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy32 = compilerOptions30.variableRenaming;
        boolean boolean33 = compilerOptions30.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions34.checkMethods;
        compilerOptions34.inlineLocalFunctions = false;
        compilerOptions34.closurePass = true;
        java.util.Set<java.lang.String> strSet42 = compilerOptions34.stripNameSuffixes;
        java.lang.String str43 = compilerOptions34.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat45 = compilerOptions44.errorFormat;
        java.lang.String[] strArray49 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet50 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet50, strArray49);
        compilerOptions44.stripNamePrefixes = strSet50;
        compilerOptions34.aliasableStrings = strSet50;
        compilerOptions30.stripTypes = strSet50;
        compilerOptions26.stripTypePrefixes = strSet50;
        compilerOptions19.stripNamePrefixes = strSet50;
        compilerOptions0.stripTypePrefixes = strSet50;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(errorFormat20);
        org.junit.Assert.assertTrue("'" + tweakProcessing23 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing23.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(errorFormat31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy32.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(errorFormat45);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        int int6 = compiler0.getErrorCount();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        com.google.javascript.jscomp.ErrorFormat errorFormat11 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat11.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, true);
        com.google.javascript.rhino.Node node16 = compiler13.getRoot();
        compilerInput10.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler13.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState19 = compiler13.getState();
        compiler0.setState(intermediateState19);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = compiler0.getTypeRegistry();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt22);
        boolean boolean24 = compiler0.isTypeCheckingEnabled();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(errorFormat11);
        org.junit.Assert.assertNotNull(messageFormatter15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNotNull(intermediateState19);
        org.junit.Assert.assertNotNull(jSTypeRegistry21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        boolean boolean14 = context0.isActivationNeeded("NUMBER 1.0 0: <No stack trace available>");
        context0.setCompileFunctionsWithDynamicScope(true);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version: language version");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, true);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        compilerInput3.setModule(jSModule4);
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel4 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.collapseVariableDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(detailLevel4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.collapseAnonymousFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkUndefinedProperties;
        boolean boolean6 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.debugFunctionSideEffectsPath = "goog.abstractMethod";
        compilerOptions0.appNameStr = "// Input %num%";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean12 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkShadowVars;
        compilerOptions0.smartNameRemoval = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        com.google.javascript.rhino.Node node23 = compiler20.getRoot();
        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler20.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState26 = compiler20.getState();
        compiler6.setState(intermediateState26);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
        java.lang.String str31 = compiler6.getSourceLine("null", 0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(intermediateState26);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj5 = context0.getThreadLocal((java.lang.Object) tweakProcessing4);
        boolean boolean6 = context0.isGeneratingDebugChanged();
        boolean boolean7 = context0.isGeneratingDebugChanged();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = context0.getErrorReporter();
        boolean boolean9 = context0.isGeneratingDebug();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(errorReporter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing20 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray27 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType26, strArray27);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = jSError28.level;
        compilerOptions0.reportMissingOverride = checkLevel29;
        boolean boolean31 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + tweakProcessing20 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing20.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        boolean boolean15 = node14.isOnlyModifiesThisCall();
        boolean boolean16 = defaultCodingConvention8.isPropertyTestFunction(node14);
        com.google.javascript.rhino.Node node17 = node6.copyInformationFrom(node14);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = closureCodingConvention0.getClassesDefinedByCall(node14);
        com.google.javascript.rhino.Node node19 = node14.getLastChild();
        java.lang.String str20 = node19.getQualifiedName();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(16, "NUMBER 1.0 0");
        java.lang.String str24 = node19.checkTreeEquals(node23);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nGT NUMBER 1.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: GT NUMBER 1.0 0\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nGT NUMBER 1.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: GT NUMBER 1.0 0\n"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        java.lang.String str5 = nodeTraversal2.getSourceName();
        int int6 = nodeTraversal2.getLineNumber();
        com.google.javascript.jscomp.Scope scope7 = nodeTraversal2.getScope();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean10 = closureCodingConvention8.isPrivate("NUMBER 1.0 0");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean22 = node21.wasEmptyNode();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node29 = node21.copyInformationFromForTree(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) -1, node43);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(15, node29, node33, node38, node44, 10, 49);
        java.lang.String str48 = closureCodingConvention8.extractClassNameIfRequire(node15, node44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean50 = compilerOptions49.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet51 = null;
        compilerOptions49.stripTypes = strSet51;
        compilerOptions49.setLooseTypes(false);
        com.google.javascript.rhino.Context context55 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.CompilerOptions compilerOptions56 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean57 = compilerOptions56.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray64 = null;
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType63, strArray64);
        com.google.javascript.jscomp.CheckLevel checkLevel67 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel67, "<No stack trace available>");
        diagnosticType63.level = checkLevel67;
        compilerOptions56.checkProvides = checkLevel67;
        context55.seal((java.lang.Object) checkLevel67);
        compilerOptions49.reportMissingOverride = checkLevel67;
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = null;
        java.lang.String[] strArray75 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        try {
            com.google.javascript.jscomp.JSError jSError76 = nodeTraversal2.makeError(node44, checkLevel67, diagnosticType74, strArray75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(scope7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType69);
        org.junit.Assert.assertNotNull(strArray75);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = null;
        com.google.javascript.jscomp.Scope scope27 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = null;
        java.lang.String str38 = defaultCodingConvention28.getSingletonGetterClassName(node37);
        boolean boolean40 = defaultCodingConvention28.isSuperClassReference("hi!");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = null;
        com.google.javascript.jscomp.Scope scope42 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray43 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44, objectTypeArray43);
        defaultCodingConvention28.defineDelegateProxyPrototypeProperties(jSTypeRegistry41, scope42, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry26, scope27, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList44);
        boolean boolean49 = closureCodingConvention0.isValidEnumKey("()");
        boolean boolean51 = closureCodingConvention0.isValidEnumKey("Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (byte) -1, node56);
        node56.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node60 = node56.getLastSibling();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        node60.putProp((int) (short) 0, (java.lang.Object) (byte) 100);
        try {
            boolean boolean68 = closureCodingConvention0.isPropertyTestFunction(node60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(objectTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node66);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        com.google.javascript.rhino.Node node6 = node5.getLastChild();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) -1, node12);
        boolean boolean14 = node13.isOnlyModifiesThisCall();
        boolean boolean15 = defaultCodingConvention7.isPropertyTestFunction(node13);
        com.google.javascript.rhino.Node node16 = null;
        java.lang.String str17 = defaultCodingConvention7.getSingletonGetterClassName(node16);
        boolean boolean19 = defaultCodingConvention7.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder25 = node24.getJsDocBuilderForNode();
        boolean boolean26 = node24.hasOneChild();
        java.util.List<java.lang.String> strList27 = defaultCodingConvention7.identifyTypeDeclarationCall(node24);
        com.google.javascript.rhino.Node node29 = node24.getAncestor(10);
        try {
            node6.addChildToBack(node29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(strList27);
        org.junit.Assert.assertNull(node29);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = compilerOptions0.propertyRenaming;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.labelRenaming = false;
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.appNameStr = "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n";
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        com.google.javascript.rhino.Context context7 = new com.google.javascript.rhino.Context();
        java.lang.Object obj8 = context7.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context7, (long) (short) 10);
        int int11 = context7.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        com.google.javascript.rhino.Node node21 = node20.cloneTree();
        context7.seal((java.lang.Object) node21);
        node21.addSuppression("()");
        java.lang.RuntimeException runtimeException25 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) (byte) -1, (java.lang.Object) "()");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean32 = node31.wasEmptyNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node39 = node31.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node53);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(15, node39, node43, node48, node54, 10, 49);
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray64 = null;
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType63, strArray64);
        com.google.javascript.jscomp.CheckLevel checkLevel67 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel67, "<No stack trace available>");
        diagnosticType63.level = checkLevel67;
        try {
            java.lang.String str71 = com.google.javascript.rhino.ScriptRuntime.getMessage3("language version: language version", (java.lang.Object) "()", (java.lang.Object) node43, (java.lang.Object) checkLevel67);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version: language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(runtimeException25);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType69);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions10.checkMethods;
        compilerOptions10.inlineLocalFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format16 = compilerOptions10.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format16;
        boolean boolean18 = compilerOptions0.labelRenaming;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.exportTestFunctions = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap1 = compilerOptions0.getTweakReplacements();
        boolean boolean2 = compilerOptions0.checkSymbols;
        compilerOptions0.inputDelimiter = "language version";
        compilerOptions0.rewriteFunctionExpressions = false;
        org.junit.Assert.assertNotNull(strMap1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        boolean boolean15 = node14.isVarArgs();
        com.google.javascript.rhino.Node node16 = node14.getLastSibling();
        com.google.javascript.rhino.Node node17 = node16.cloneNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        context0.seal((java.lang.Object) "goog.abstractMethod");
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        node13.setType((int) (byte) 10);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention34 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) -1, node39);
        boolean boolean41 = node40.isOnlyModifiesThisCall();
        boolean boolean42 = defaultCodingConvention34.isPropertyTestFunction(node40);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal43 = null;
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean49 = node48.wasEmptyNode();
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast50 = defaultCodingConvention34.getObjectLiteralCast(nodeTraversal43, node48);
        node13.addChildToFront(node48);
        node48.setOptionalArg(true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(objectLiteralCast50);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions0.checkRequires = checkLevel11;
        java.lang.String str13 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy12 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy12.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = compilerOptions4.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions4.variableRenaming;
        boolean boolean7 = compilerOptions4.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions8.inlineLocalFunctions = false;
        compilerOptions8.closurePass = true;
        java.util.Set<java.lang.String> strSet16 = compilerOptions8.stripNameSuffixes;
        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = compilerOptions18.errorFormat;
        java.lang.String[] strArray23 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions18.stripNamePrefixes = strSet24;
        compilerOptions8.aliasableStrings = strSet24;
        compilerOptions4.stripTypes = strSet24;
        compilerOptions0.stripTypePrefixes = strSet24;
        compilerOptions0.setLooseTypes(false);
        boolean boolean32 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.markAsCompiled = true;
        java.util.Set<java.lang.String> strSet5 = null;
        compilerOptions0.aliasableStrings = strSet5;
        compilerOptions0.strictMessageReplacement = false;
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention12 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        boolean boolean19 = node18.isOnlyModifiesThisCall();
        boolean boolean20 = defaultCodingConvention12.isPropertyTestFunction(node18);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node18);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = closureCodingConvention4.getClassesDefinedByCall(node18);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node18, node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean33 = node32.wasEmptyNode();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean39 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node40 = node32.copyInformationFromForTree(node38);
        boolean boolean41 = node38.isOptionalArg();
        com.google.javascript.rhino.Node node42 = node38.cloneTree();
        boolean boolean43 = node42.isVarArgs();
        com.google.javascript.rhino.Node node44 = node42.getLastSibling();
        boolean boolean45 = closureCodingConvention0.isVarArgsParameter(node44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray6 = null;
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType5, strArray6);
        java.lang.Object obj8 = null;
        boolean boolean9 = jSError7.equals(obj8);
        java.lang.String str10 = jSError7.sourceName;
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Not declared as a type name" + "'", str10.equals("Not declared as a type name"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType5, strArray6);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType5.level;
        java.lang.String str9 = diagnosticType5.toString();
        java.lang.String[] strArray10 = null;
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray10);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "NUMBER 1.0 0: <No stack trace available>" + "'", str9.equals("NUMBER 1.0 0: <No stack trace available>"));
        org.junit.Assert.assertNotNull(jSError11);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions10.checkMethods;
        compilerOptions10.inlineLocalFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format16 = compilerOptions10.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format16;
        boolean boolean18 = compilerOptions0.labelRenaming;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.labelRenaming = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = compilerOptions0.getTweakProcessing();
        compilerOptions0.disambiguateProperties = false;
        boolean boolean7 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean14 = compilerOptions0.checkEs5Strict;
        compilerOptions0.checkTypes = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 23);
        com.google.javascript.rhino.Node node11 = node6.copyInformationFromForTree(node10);
        boolean boolean12 = node10.hasSideEffects();
        boolean boolean13 = node10.hasOneChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 23);
        boolean boolean6 = context0.hasCompileFunctionsWithDynamicScope();
        int int7 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Context context8 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean9 = context0.isGeneratingSource();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(context8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean3 = compilerOptions0.checkTypes;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.unaliasableGlobals = "language version";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        int int4 = context0.getLanguageVersion();
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray14 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType13, strArray14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        int int17 = diagnosticType13.compareTo(diagnosticType16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType26, strArray27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray35 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType34, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType26, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("ERROR 2", 29, 36, diagnosticType13, strArray35);
        context0.removeThreadLocal((java.lang.Object) diagnosticType13);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean8 = node7.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean14 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = node7.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) -1, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(15, node15, node19, node24, node30, 10, 49);
        context0.seal((java.lang.Object) node15);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("()");
        java.lang.Object obj37 = context0.getThreadLocal((java.lang.Object) sourceFile36);
        com.google.javascript.jscomp.JsAst jsAst38 = new com.google.javascript.jscomp.JsAst(sourceFile36);
        jsAst38.clearAst();
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst38, false);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        java.lang.String str23 = node16.toString();
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "NUMBER 52.0 0" + "'", str23.equals("NUMBER 52.0 0"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean7 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions13.checkMethods;
        compilerOptions13.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = null;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy19, propertyRenamingPolicy20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node54 = node44.cloneTree();
        com.google.javascript.rhino.Node node55 = node44.removeFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType56 = node44.getJSType();
        context0.putThreadLocal((java.lang.Object) compilerOptions13, (java.lang.Object) node44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean59 = compilerOptions58.moveFunctionDeclarations;
        compilerOptions58.removeUnusedLocalVars = false;
        compilerOptions58.recordFunctionInformation = true;
        java.lang.String str64 = compilerOptions58.nameReferenceReportPath;
        compilerOptions58.checkSymbols = false;
        context0.seal((java.lang.Object) false);
        try {
            context0.removeActivationName("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str64);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.setAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("eof");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToDoubleLiteral("RETURN 0\n", (double) (short) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions10.checkMethods;
        compilerOptions10.inlineLocalFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format16 = compilerOptions10.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format16;
        boolean boolean18 = compilerOptions0.labelRenaming;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(runtimeException21);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray11 = null;
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType10, strArray11);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel14, "<No stack trace available>");
        diagnosticType10.level = checkLevel14;
        compilerOptions3.checkProvides = checkLevel14;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray29 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType28, strArray29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray37 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType36, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("EOF  0", 34, 10, diagnosticType28, strArray37);
        try {
            com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("()", (int) (byte) 10, (int) '#', checkLevel14, diagnosticType19, strArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        java.lang.String str2 = codeBuilder0.toString();
        java.lang.String str3 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.checkProvides = checkLevel12;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler14 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler14);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(": ");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset5);
        com.google.javascript.rhino.Node node7 = compiler3.parse(jSSourceFile6);
        com.google.javascript.rhino.Node node8 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler3);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler3.getWarnings();
        boolean boolean10 = compiler3.acceptEcmaScript5();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput12 = compiler3.getInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test398");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("goog.exportProperty");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportProperty");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node31.cloneNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean35 = closureCodingConvention33.isPrivate("NUMBER 1.0 0");
        java.lang.String str36 = closureCodingConvention33.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention37 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) -1, node42);
        boolean boolean44 = node43.isOnlyModifiesThisCall();
        boolean boolean45 = defaultCodingConvention37.isPropertyTestFunction(node43);
        com.google.javascript.rhino.Node node46 = null;
        java.lang.String str47 = defaultCodingConvention37.getSingletonGetterClassName(node46);
        boolean boolean49 = defaultCodingConvention37.isSuperClassReference("hi!");
        java.lang.String str50 = defaultCodingConvention37.getExportPropertyFunction();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean56 = node55.wasEmptyNode();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean62 = node61.wasEmptyNode();
        com.google.javascript.rhino.Node node63 = node55.copyInformationFromForTree(node61);
        boolean boolean64 = node61.isOptionalArg();
        com.google.javascript.rhino.Node node65 = node61.cloneTree();
        java.lang.String str66 = defaultCodingConvention37.identifyTypeDefAssign(node65);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship67 = closureCodingConvention33.getDelegateRelationship(node65);
        com.google.javascript.rhino.Context context68 = new com.google.javascript.rhino.Context();
        java.lang.Object obj69 = context68.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context68, (long) (short) 10);
        int int72 = context68.getInstructionObserverThreshold();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) (byte) -1, node77);
        node77.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node81 = node77.getLastSibling();
        com.google.javascript.rhino.Node node82 = node81.cloneTree();
        context68.seal((java.lang.Object) node82);
        com.google.javascript.rhino.jstype.JSType jSType84 = node82.getJSType();
        boolean boolean85 = node82.isVarArgs();
        node31.addChildAfter(node65, node82);
        java.lang.Appendable appendable87 = null;
        try {
            node82.appendStringTree(appendable87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "goog.abstractMethod" + "'", str36.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNull(delegateRelationship67);
        org.junit.Assert.assertNull(obj69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNull(jSType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(49);
        boolean boolean2 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.setMutatesGlobalState();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        java.lang.String str4 = composeWarningsGuard3.toString();
//        java.lang.String str5 = composeWarningsGuard3.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup6 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
//        boolean boolean9 = composeWarningsGuard3.enables(diagnosticGroup8);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
//        boolean boolean11 = composeWarningsGuard3.enables(diagnosticGroup10);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
//        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup12;
//        java.lang.String str14 = diagnosticGroup12.toString();
//        boolean boolean15 = composeWarningsGuard3.enables(diagnosticGroup12);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticGroup6);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNull(diagnosticGroup10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy6, propertyRenamingPolicy7);
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        java.lang.String str10 = compilerOptions0.appNameStr;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig11 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean12 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        java.lang.String str26 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "goog.exportSymbol" + "'", str26.equals("goog.exportSymbol"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        java.lang.Object obj8 = compilerOptions0.clone();
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.inputDelimiter = "(Named type with empty name component)";
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkUnreachableCode;
        boolean boolean9 = compilerOptions0.checkEs5Strict;
        compilerOptions0.collapseAnonymousFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.reserveRawExports = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.inferTypesInGlobalScope;
        boolean boolean9 = compilerOptions7.crossModuleMethodMotion;
        boolean boolean10 = compilerOptions7.checkTypes;
        compilerOptions7.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler13 = compilerOptions7.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler13);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler13);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
        compilerInput9.clearAst();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset13);
        com.google.javascript.rhino.Node node15 = compiler11.parse(jSSourceFile14);
        boolean boolean16 = compiler11.hasErrors();
        compiler11.reportCodeChange();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
        compiler11.tracker = performanceTracker18;
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler11.getWarnings();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jSErrorArray21);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions0.sourceMapDetailLevel;
        java.lang.String str10 = compilerOptions0.reportPath;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        compilerOptions0.inlineLocalFunctions = true;
        boolean boolean13 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.renamePrefix = "goog.abstractMethod";
        compilerOptions0.nameReferenceGraphPath = "goog.abstractMethod";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = defaultCodingConvention0.getClassesDefinedByCall(node1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) -1, node8);
        node8.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, node16);
        node16.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node8, (java.lang.Object) node16);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship22 = defaultCodingConvention0.getClassesDefinedByCall(node16);
        java.lang.String str23 = defaultCodingConvention0.getGlobalObject();
        boolean boolean25 = defaultCodingConvention0.isConstant("language version: language version");
        com.google.javascript.rhino.Context context26 = new com.google.javascript.rhino.Context();
        java.lang.Object obj27 = context26.getDebuggerContextData();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean40 = node39.wasEmptyNode();
        com.google.javascript.rhino.Node node41 = node33.copyInformationFromForTree(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) -1, node55);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(15, node41, node45, node50, node56, 10, 49);
        context26.seal((java.lang.Object) node41);
        java.lang.String str61 = defaultCodingConvention0.identifyTypeDefAssign(node41);
        com.google.javascript.rhino.Node node62 = node41.removeChildren();
        org.junit.Assert.assertNull(subclassRelationship2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNull(subclassRelationship22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "window" + "'", str23.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNull(node62);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        compiler0.disableThreads();
        int int6 = compiler0.getErrorCount();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        java.lang.String str12 = jSSourceFile9.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region14 = jSSourceFile9.getRegion((int) ' ');
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset16);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17);
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream20 = null;
        com.google.javascript.jscomp.Compiler compiler21 = new com.google.javascript.jscomp.Compiler(printStream20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = errorFormat19.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler21, true);
        com.google.javascript.rhino.Node node24 = compiler21.getRoot();
        compilerInput18.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler21);
        java.nio.charset.Charset charset27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset27);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        java.lang.String str31 = jSSourceFile28.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region33 = jSSourceFile28.getRegion((int) ' ');
        jSSourceFile28.clearCachedSource();
        com.google.javascript.rhino.Node node35 = compiler21.parse(jSSourceFile28);
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset37);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38);
        java.lang.String str41 = jSSourceFile38.getLine((int) (byte) 0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str45 = jSSourceFile44.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
        java.lang.String str48 = jSSourceFile44.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray49 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile28, jSSourceFile38, jSSourceFile44 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions50.setRemoveClosureAsserts(false);
        compilerOptions50.disableRuntimeTypeCheck();
        boolean boolean54 = compilerOptions50.inlineAnonymousFunctionExpressions;
        boolean boolean55 = compilerOptions50.inlineConstantVars;
        com.google.javascript.jscomp.Result result56 = compiler0.compile(jSSourceFile9, jSSourceFileArray49, compilerOptions50);
        com.google.javascript.jscomp.CheckLevel checkLevel57 = null;
        compilerOptions50.checkRequires = checkLevel57;
        byte[] byteArray59 = compilerOptions50.inputVariableMapSerialized;
        compilerOptions50.syntheticBlockEndMarker = "(eof)";
        java.lang.Object obj62 = compilerOptions50.clone();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(region14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNotNull(messageFormatter23);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(region33);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "language version" + "'", str45.equals("language version"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "language version" + "'", str48.equals("language version"));
        org.junit.Assert.assertNotNull(jSSourceFileArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(result56);
        org.junit.Assert.assertNull(byteArray59);
        org.junit.Assert.assertNotNull(obj62);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset5);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = errorFormat8.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, true);
        com.google.javascript.rhino.Node node13 = compiler10.getRoot();
        compilerInput7.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.JSError[] jSErrorArray15 = compiler10.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler10.getMessages();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.Result result18 = compiler10.getResult();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput20 = compiler10.getInput("EOF  0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertNotNull(messageFormatter12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(jSErrorArray15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        int int7 = node5.getChildCount();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.rhino.Node node20 = node12.copyInformationFromForTree(node18);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node5, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) -1, node30);
        boolean boolean32 = node31.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        boolean boolean40 = node39.isOnlyModifiesThisCall();
        boolean boolean41 = defaultCodingConvention33.isPropertyTestFunction(node39);
        com.google.javascript.rhino.Node node42 = node31.copyInformationFrom(node39);
        boolean boolean43 = node42.hasMoreThanOneChild();
        boolean boolean44 = closureCodingConvention0.isVarArgsParameter(node42);
        boolean boolean46 = closureCodingConvention0.isPrivate("RETURN 0\n");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean54 = node53.wasEmptyNode();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean60 = node59.wasEmptyNode();
        com.google.javascript.rhino.Node node61 = node53.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((int) (byte) -1, node75);
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(15, node61, node65, node70, node76, 10, 49);
        com.google.javascript.rhino.Node node80 = node70.detachFromParent();
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(15, node80);
        java.lang.String str82 = closureCodingConvention0.identifyTypeDefAssign(node81);
        boolean boolean84 = closureCodingConvention0.isConstantKey("<No stack trace available>");
        java.lang.String str85 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "goog.abstractMethod" + "'", str85.equals("goog.abstractMethod"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.smartNameRemoval = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions6.checkMethods;
        compilerOptions6.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat13 = compilerOptions12.errorFormat;
        compilerOptions12.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions16.checkMethods;
        compilerOptions12.checkShadowVars = checkLevel19;
        compilerOptions6.reportMissingOverride = checkLevel19;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat13);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean2 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean3 = compilerOptions0.checkTypes;
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean7 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        compilerOptions0.inlineVariables = true;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        boolean boolean9 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray16 = null;
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType15, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType23, strArray24);
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compiler0.getErrorLevel(jSError26);
        com.google.javascript.jscomp.CodingConvention codingConvention28 = compiler0.getCodingConvention();
        boolean boolean29 = compiler0.acceptEcmaScript5();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(codingConvention28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.lineBreak = false;
        boolean boolean8 = compilerOptions0.aliasAllStrings;
        boolean boolean9 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        boolean boolean13 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        java.lang.String str18 = node14.toString(false, false, false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EOF " + "'", str18.equals("EOF "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        compilerOptions0.aliasStringsBlacklist = "RETURN 0\n";
        boolean boolean22 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        boolean boolean6 = node4.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean18 = node17.wasEmptyNode();
        com.google.javascript.rhino.Node node19 = node11.copyInformationFromForTree(node17);
        boolean boolean20 = node17.isOptionalArg();
        com.google.javascript.rhino.Node node21 = node17.cloneTree();
        boolean boolean22 = node21.isVarArgs();
        com.google.javascript.rhino.Node node23 = node21.getLastSibling();
        java.lang.String str24 = node4.checkTreeEquals(node21);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.rhino.Node node9 = compiler6.getRoot();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler6.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = compiler6.getMessages();
        java.lang.String str13 = compiler6.toSource();
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        com.google.javascript.rhino.Node node23 = compiler20.getRoot();
        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler20.getMessages();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState26 = compiler20.getState();
        compiler6.setState(intermediateState26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset30);
        com.google.javascript.rhino.Node node32 = compiler28.parse(jSSourceFile31);
        compiler28.disableThreads();
        int int34 = compiler28.getErrorCount();
        java.nio.charset.Charset charset36 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset36);
        com.google.javascript.jscomp.CompilerInput compilerInput38 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37);
        java.lang.String str40 = jSSourceFile37.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region42 = jSSourceFile37.getRegion((int) ' ');
        java.nio.charset.Charset charset44 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset44);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45);
        com.google.javascript.jscomp.ErrorFormat errorFormat47 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream48 = null;
        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler(printStream48);
        com.google.javascript.jscomp.MessageFormatter messageFormatter51 = errorFormat47.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler49, true);
        com.google.javascript.rhino.Node node52 = compiler49.getRoot();
        compilerInput46.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler49);
        java.nio.charset.Charset charset55 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset55);
        com.google.javascript.jscomp.CompilerInput compilerInput57 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile56);
        java.lang.String str59 = jSSourceFile56.getLine((int) (byte) 0);
        com.google.javascript.jscomp.Region region61 = jSSourceFile56.getRegion((int) ' ');
        jSSourceFile56.clearCachedSource();
        com.google.javascript.rhino.Node node63 = compiler49.parse(jSSourceFile56);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset65);
        com.google.javascript.jscomp.CompilerInput compilerInput67 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile66);
        java.lang.String str69 = jSSourceFile66.getLine((int) (byte) 0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "()");
        java.lang.String str73 = jSSourceFile72.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput75 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile72, false);
        java.lang.String str76 = jSSourceFile72.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray77 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile56, jSSourceFile66, jSSourceFile72 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions78.setRemoveClosureAsserts(false);
        compilerOptions78.disableRuntimeTypeCheck();
        boolean boolean82 = compilerOptions78.inlineAnonymousFunctionExpressions;
        boolean boolean83 = compilerOptions78.inlineConstantVars;
        com.google.javascript.jscomp.Result result84 = compiler28.compile(jSSourceFile37, jSSourceFileArray77, compilerOptions78);
        com.google.javascript.jscomp.CompilerInput compilerInput85 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37);
        com.google.javascript.jscomp.JSModule jSModule86 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray87 = new com.google.javascript.jscomp.JSModule[] { jSModule86 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions88 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions88.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel91 = compilerOptions88.checkMethods;
        compilerOptions88.inlineLocalFunctions = false;
        compilerOptions88.devirtualizePrototypeMethods = true;
        java.util.Set<java.lang.String> strSet96 = compilerOptions88.stripTypePrefixes;
        try {
            com.google.javascript.jscomp.Result result97 = compiler6.compile(jSSourceFile37, jSModuleArray87, compilerOptions88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSErrorArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(intermediateState26);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(region42);
        org.junit.Assert.assertNotNull(jSSourceFile45);
        org.junit.Assert.assertNotNull(errorFormat47);
        org.junit.Assert.assertNotNull(messageFormatter51);
        org.junit.Assert.assertNull(node52);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNull(region61);
        org.junit.Assert.assertNull(node63);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "language version" + "'", str73.equals("language version"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "language version" + "'", str76.equals("language version"));
        org.junit.Assert.assertNotNull(jSSourceFileArray77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertNotNull(jSModuleArray87);
        org.junit.Assert.assertTrue("'" + checkLevel91 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel91.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet96);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.checkMethods;
        compilerOptions0.checkRequires = checkLevel11;
        boolean boolean13 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node7.getJsDocBuilderForNode();
        int int9 = node7.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType15, strArray16);
        java.lang.String[] strArray18 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node7, diagnosticType15, strArray18);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection20 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node7);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(31, node7, node24, node28, 18, 120);
        try {
            com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(46, node28, (int) '4', (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(nodeCollection20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        boolean boolean12 = defaultCodingConvention4.isPropertyTestFunction(node10);
        com.google.javascript.rhino.Node node13 = null;
        java.lang.String str14 = defaultCodingConvention4.getSingletonGetterClassName(node13);
        boolean boolean16 = defaultCodingConvention4.isSuperClassReference("hi!");
        java.lang.String str17 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        boolean boolean31 = node28.isOptionalArg();
        com.google.javascript.rhino.Node node32 = node28.cloneTree();
        java.lang.String str33 = defaultCodingConvention4.identifyTypeDefAssign(node32);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention0.getDelegateRelationship(node32);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection35 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) -1, node40);
        node40.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node44 = node40.getLastSibling();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node40.getJsDocBuilderForNode();
        boolean boolean46 = closureCodingConvention0.isOptionalParameter(node40);
        boolean boolean48 = closureCodingConvention0.isValidEnumKey("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.labelRenaming = false;
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        boolean boolean9 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 120);
        int int4 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = compilerOptions6.errorFormat;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray14 = null;
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType13, strArray14);
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel17, "<No stack trace available>");
        diagnosticType13.level = checkLevel17;
        compilerOptions6.reportMissingOverride = checkLevel17;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        boolean boolean29 = node28.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention30 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) -1, node35);
        boolean boolean37 = node36.isOnlyModifiesThisCall();
        boolean boolean38 = defaultCodingConvention30.isPropertyTestFunction(node36);
        com.google.javascript.rhino.Node node39 = node28.copyInformationFrom(node36);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray52 = null;
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType51, strArray52);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray60 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType59, strArray60);
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("hi!", (int) 'a', 31, diagnosticType51, strArray60);
        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make("language version: language version", node28, diagnosticType42, strArray60);
        try {
            loggerErrorManager1.println(checkLevel17, jSError63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(errorFormat7);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNotNull(jSError63);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("NUMBER 1.0 0", charset2);
        com.google.javascript.rhino.Node node4 = compiler0.parse(jSSourceFile3);
        boolean boolean5 = compiler0.hasErrors();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getErrors();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        node5.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) -1, node13);
        node13.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node17 = node13.getLastSibling();
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node5, (java.lang.Object) node13);
        try {
            node5.setSideEffectFlags(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException18);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) -1);
        sideEffectFlags1.clearSideEffectFlags();
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setThrows();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.ErrorManager errorManager4 = null;
        compilerInput3.setErrorManager(errorManager4);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceAst6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 120);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler8 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler8, callback9);
        boolean boolean11 = nodeTraversal10.hasScope();
        int int12 = nodeTraversal10.getLineNumber();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) -1, node18);
        boolean boolean20 = node19.isOnlyModifiesThisCall();
        boolean boolean21 = defaultCodingConvention13.isPropertyTestFunction(node19);
        boolean boolean23 = defaultCodingConvention13.isExported("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node28.getJsDocBuilderForNode();
        int int30 = node28.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType31 = node28.getJSType();
        java.util.List<java.lang.String> strList32 = defaultCodingConvention13.identifyTypeDeclarationCall(node28);
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray39 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType38, strArray39);
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = nodeTraversal10.makeError(node28, diagnosticType38, strArray41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray49 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType48, strArray49);
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("EOF  0 [jsdoc_info: JSDocInfo]\n", 11, (int) (byte) -1, diagnosticType38, strArray49);
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel52 = compiler4.getErrorLevel(jSError51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertNull(strList32);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(jSError51);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        byte[] byteArray19 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(byteArray19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler2.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, sourceExcerpt7);
        com.google.javascript.jscomp.SourceAst sourceAst9 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceAst9, "", false);
        java.nio.charset.Charset charset14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset14);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream18 = null;
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler(printStream18);
        com.google.javascript.jscomp.MessageFormatter messageFormatter21 = errorFormat17.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler19, true);
        com.google.javascript.rhino.Node node22 = compiler19.getRoot();
        compilerInput16.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler19);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = compiler19.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = compiler19.getMessages();
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler19);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder33 = node32.getJsDocBuilderForNode();
        int int34 = node32.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.DiagnosticType.disabled("NUMBER 1.0 0", "<No stack trace available>");
        java.lang.String[] strArray41 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("NUMBER 1.0 0", 34, (int) (short) 100, diagnosticType40, strArray41);
        java.lang.String[] strArray43 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError44 = com.google.javascript.jscomp.JSError.make("RETURN 0\n", node32, diagnosticType40, strArray43);
        int int45 = jSError44.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compiler19.getErrorLevel(jSError44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean48 = compilerOptions47.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray55 = null;
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType54, strArray55);
        com.google.javascript.jscomp.CheckLevel checkLevel58 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel58, "<No stack trace available>");
        diagnosticType54.level = checkLevel58;
        compilerOptions47.checkProvides = checkLevel58;
        compilerOptions47.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel65 = compilerOptions47.aggressiveVarCheck;
        java.io.PrintStream printStream66 = null;
        com.google.javascript.jscomp.Compiler compiler67 = new com.google.javascript.jscomp.Compiler(printStream66);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt68 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter69 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler67, sourceExcerpt68);
        lightweightMessageFormatter69.setColorize(false);
        lightweightMessageFormatter69.setColorize(false);
        java.lang.String str74 = jSError44.format(checkLevel65, (com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter69);
        try {
            java.lang.String str75 = lightweightMessageFormatter8.formatWarning(jSError44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertNotNull(messageFormatter21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jSError44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(checkLevel46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str74);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("(Named type with empty name component)", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions4.inlineLocalFunctions = false;
        compilerOptions4.closurePass = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripNameSuffixes;
        java.lang.String str13 = compilerOptions4.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions14.errorFormat;
        java.lang.String[] strArray19 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions14.stripNamePrefixes = strSet20;
        compilerOptions4.aliasableStrings = strSet20;
        compilerOptions0.stripTypes = strSet20;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
        compilerOptions0.checkUndefinedProperties = checkLevel25;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean29 = compilerOptions0.inlineConstantVars;
        compilerOptions0.aliasStringsBlacklist = "@IMPLEMENTATION.VERSION@";
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        java.lang.Object obj5 = context0.getThreadLocal((java.lang.Object) tweakProcessing4);
        int int6 = context0.getInstructionObserverThreshold();
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertTrue("'" + tweakProcessing4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing4.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripTypes = strSet2;
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(format4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.checkMethods;
        compilerOptions4.inlineLocalFunctions = false;
        compilerOptions4.closurePass = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripNameSuffixes;
        java.lang.String str13 = compilerOptions4.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions14.errorFormat;
        java.lang.String[] strArray19 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions14.stripNamePrefixes = strSet20;
        compilerOptions4.aliasableStrings = strSet20;
        compilerOptions0.stripTypes = strSet20;
        compilerOptions0.syntheticBlockEndMarker = "goog.abstractMethod";
        compilerOptions0.checkSuspiciousCode = false;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        try {
            java.lang.String str3 = diagnosticGroup0.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.disambiguateProperties = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions6.getTweakReplacements();
        boolean boolean8 = compilerOptions6.checkSymbols;
        compilerOptions6.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.inferTypesInGlobalScope;
        boolean boolean13 = compilerOptions11.crossModuleMethodMotion;
        boolean boolean14 = compilerOptions11.checkTypes;
        compilerOptions11.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler17 = compilerOptions11.getAliasTransformationHandler();
        compilerOptions6.setAliasTransformationHandler(aliasTransformationHandler17);
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler17);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler17);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.setOutputCharset("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        java.lang.String[] strArray5 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "null", "RETURN 0\n" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNamePrefixes = strSet6;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(44, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean18 = compilerOptions0.strictMessageReplacement;
        boolean boolean19 = compilerOptions0.markAsCompiled;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) -1, node25);
        boolean boolean27 = node26.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) -1, node33);
        boolean boolean35 = node34.isOnlyModifiesThisCall();
        boolean boolean36 = defaultCodingConvention28.isPropertyTestFunction(node34);
        com.google.javascript.rhino.Node node37 = node26.copyInformationFrom(node34);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship38 = closureCodingConvention20.getClassesDefinedByCall(node34);
        boolean boolean40 = closureCodingConvention20.isPrivate("window");
        boolean boolean42 = closureCodingConvention20.isConstantKey("hi!");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention20);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection44 = closureCodingConvention20.getAssertionFunctions();
        java.lang.String str45 = closureCodingConvention20.getExportPropertyFunction();
        java.lang.String str46 = closureCodingConvention20.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(subclassRelationship38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "goog.exportProperty" + "'", str45.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "goog.exportProperty" + "'", str46.equals("goog.exportProperty"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = compilerOptions0.customPasses;
        compilerOptions0.setTweakToDoubleLiteral("", 0.0d);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray9 = null;
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType8, strArray9);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel12, "<No stack trace available>");
        diagnosticType8.level = checkLevel12;
        java.lang.String[] strArray16 = null;
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("language version: language version", (int) 'a', (int) (byte) 100, diagnosticType8, strArray16);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(jSError17);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("EOF  0", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        boolean boolean17 = compilerOptions0.gatherCssNames;
        compilerOptions0.smartNameRemoval = false;
        boolean boolean20 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        compilerOptions0.instrumentForCoverageOnly = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.jscomp.Scope scope5 = compiler2.getTopScope();
        com.google.javascript.rhino.Node node6 = compiler2.getRoot();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(scope5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) str4);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(runtimeException5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.labelRenaming = false;
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkRequires;
        compilerOptions0.collapseAnonymousFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "Node tree inequality:\nTree1:\nERROR\n    NUMBER 52.0\n\n\nTree2:\nNUMBER 1.0 0\n\n\nSubtree1: ERROR\n    NUMBER 52.0\n\n\nSubtree2: NUMBER 1.0 0\n", 46, (-3));
        java.lang.Class<?> wildcardClass5 = node4.getClass();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        boolean boolean8 = composeWarningsGuard3.enables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup4;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 10.0f, (int) (byte) -1, (-3));
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        byte[] byteArray19 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions0.reportUnknownTypes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(byteArray19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        boolean boolean17 = compilerOptions0.gatherCssNames;
        compilerOptions0.removeUnusedLocalVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy20 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy21 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy20, propertyRenamingPolicy21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy20 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy20.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node32 = node31.cloneNode();
        node31.putIntProp(47, 15);
        boolean boolean36 = node31.isQuotedString();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("NUMBER 1.0 0");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) -1, node9);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        boolean boolean12 = defaultCodingConvention4.isPropertyTestFunction(node10);
        com.google.javascript.rhino.Node node13 = null;
        java.lang.String str14 = defaultCodingConvention4.getSingletonGetterClassName(node13);
        boolean boolean16 = defaultCodingConvention4.isSuperClassReference("hi!");
        java.lang.String str17 = defaultCodingConvention4.getExportPropertyFunction();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean29 = node28.wasEmptyNode();
        com.google.javascript.rhino.Node node30 = node22.copyInformationFromForTree(node28);
        boolean boolean31 = node28.isOptionalArg();
        com.google.javascript.rhino.Node node32 = node28.cloneTree();
        java.lang.String str33 = defaultCodingConvention4.identifyTypeDefAssign(node32);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = closureCodingConvention0.getDelegateRelationship(node32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType36 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType37 = null;
        closureCodingConvention0.applySubclassRelationship(functionType35, functionType36, subclassType37);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (byte) -1, node44);
        node44.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) -1, node52);
        node52.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node56 = node52.getLastSibling();
        java.lang.RuntimeException runtimeException57 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) node44, (java.lang.Object) node52);
        boolean boolean59 = node44.getBooleanProp((int) '4');
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention60 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean62 = closureCodingConvention60.isPrivate("NUMBER 1.0 0");
        java.lang.String str63 = closureCodingConvention60.getAbstractMethodName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention64 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (byte) -1, node69);
        boolean boolean71 = node70.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention72 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) (byte) -1, node77);
        boolean boolean79 = node78.isOnlyModifiesThisCall();
        boolean boolean80 = defaultCodingConvention72.isPropertyTestFunction(node78);
        com.google.javascript.rhino.Node node81 = node70.copyInformationFrom(node78);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship82 = closureCodingConvention64.getClassesDefinedByCall(node78);
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, 0, 0);
        java.lang.String str87 = closureCodingConvention60.extractClassNameIfProvide(node78, node86);
        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = null;
        node86.setJSDocInfo(jSDocInfo88);
        java.lang.String str90 = closureCodingConvention0.extractClassNameIfRequire(node44, node86);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(runtimeException57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "goog.abstractMethod" + "'", str63.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNull(subclassRelationship82);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNull(str87);
        org.junit.Assert.assertNull(str90);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.checkEs5Strict = false;
        boolean boolean19 = compilerOptions0.generatePseudoNames;
        compilerOptions0.labelRenaming = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean12 = node11.wasEmptyNode();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) -1, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(15, node13, node17, node22, node28, 10, 49);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean38 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean44 = node43.wasEmptyNode();
        com.google.javascript.rhino.Node node45 = node37.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) -1, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(15, node45, node49, node54, node60, 10, 49);
        boolean boolean64 = node31.hasChild(node54);
        node54.setCharno(19);
        java.lang.String str70 = node54.toString(true, true, false);
        java.lang.String str74 = node54.toString(false, false, true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "EOF  0" + "'", str70.equals("EOF  0"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "EOF " + "'", str74.equals("EOF "));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node13 = node12.getParent();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = null;
        node12.setJSDocInfo(jSDocInfo14);
        java.lang.String str16 = node12.toString();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EOF  0" + "'", str16.equals("EOF  0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean4 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setShadowVariables(true);
        byte[] byteArray20 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNull(byteArray20);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 36, 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1b" + "'", str2.equals("1b"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean4 = compilerOptions0.generateExports;
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        compilerOptions0.syntheticBlockStartMarker = "<No stack trace available>";
        compilerOptions0.skipAllCompilerPasses();
        java.lang.String str9 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.enableRuntimeTypeCheck("eof");
        compilerOptions0.checkMissingGetCssNameBlacklist = "-1";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        java.lang.String str18 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler2.tracker;
        try {
            compiler2.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.Object obj1 = context0.getDebuggerContextData();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        context0.putThreadLocal((java.lang.Object) boolean8, (java.lang.Object) 'a');
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions13.checkMethods;
        compilerOptions13.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = null;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy19, propertyRenamingPolicy20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) -1, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(15, node35, node39, node44, node50, 10, 49);
        com.google.javascript.rhino.Node node54 = node44.cloneTree();
        com.google.javascript.rhino.Node node55 = node44.removeFirstChild();
        com.google.javascript.rhino.jstype.JSType jSType56 = node44.getJSType();
        context0.putThreadLocal((java.lang.Object) compilerOptions13, (java.lang.Object) node44);
        java.lang.String str58 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) context0);
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(jSType56);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = node6.copyInformationFromForTree(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) -1, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(15, node14, node18, node23, node29, 10, 49);
        com.google.javascript.rhino.Node node33 = node23.detachFromParent();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(39, node23);
        java.lang.String str35 = node23.getString();
        com.google.javascript.rhino.Node node36 = node23.removeFirstChild();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNull(node36);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) -1, node5);
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        boolean boolean8 = defaultCodingConvention0.isPropertyTestFunction(node6);
        com.google.javascript.rhino.Node node9 = null;
        java.lang.String str10 = defaultCodingConvention0.getSingletonGetterClassName(node9);
        boolean boolean12 = defaultCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node17.getJsDocBuilderForNode();
        boolean boolean19 = node17.hasOneChild();
        java.util.List<java.lang.String> strList20 = defaultCodingConvention0.identifyTypeDeclarationCall(node17);
        com.google.javascript.rhino.Node node21 = node17.getNext();
        try {
            node21.setVarArgs(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(strList20);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("language version", "or", "(Named type with empty name component)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = compilerOptions0.errorFormat;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(15, (-34), 43);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        boolean boolean8 = composeWarningsGuard3.enables(diagnosticGroup4);
        java.lang.String str9 = composeWarningsGuard3.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup10;
        try {
            boolean boolean12 = composeWarningsGuard3.disables(diagnosticGroup10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(diagnosticGroup10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing3 = compilerOptions0.getTweakProcessing();
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + tweakProcessing3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing3.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        int int7 = ecmaError6.columnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        com.google.javascript.rhino.EcmaError ecmaError16 = com.google.javascript.rhino.ScriptRuntime.constructError("", "", "", 0, "hi!", 5);
        java.lang.String str17 = ecmaError16.sourceName();
        java.lang.String str18 = ecmaError16.getErrorMessage();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError16);
        java.lang.String str20 = ecmaError6.details();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertNotNull(ecmaError16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + ": " + "'", str20.equals(": "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) -1, node6);
        boolean boolean8 = node7.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) -1, node14);
        boolean boolean16 = node15.isOnlyModifiesThisCall();
        boolean boolean17 = defaultCodingConvention9.isPropertyTestFunction(node15);
        com.google.javascript.rhino.Node node18 = node7.copyInformationFrom(node15);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship19 = closureCodingConvention1.getClassesDefinedByCall(node15);
        com.google.javascript.rhino.Node node20 = node15.getLastChild();
        java.lang.String str21 = node20.getQualifiedName();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean34 = node33.wasEmptyNode();
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node36 = node35.getParent();
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((-1), node35, 2, 0);
        java.lang.String str40 = node39.toString();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean47 = node46.wasEmptyNode();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean53 = node52.wasEmptyNode();
        com.google.javascript.rhino.Node node54 = node46.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node55 = node54.getParent();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((-1), node54, 2, 0);
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node20, node39, node54 };
        try {
            com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(130, nodeArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(subclassRelationship19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ERROR 2" + "'", str40.equals("ERROR 2"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNotNull(nodeArray59);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.nameReferenceReportPath = "language version";
        compilerOptions0.removeDeadCode = true;
        java.lang.String str24 = compilerOptions0.reportPath;
        java.lang.String str25 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions0.checkProvides;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "// Input %num%" + "'", str25.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean17 = node16.wasEmptyNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean23 = node22.wasEmptyNode();
        com.google.javascript.rhino.Node node24 = node16.copyInformationFromForTree(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) -1, node38);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(15, node24, node28, node33, node39, 10, 49);
        node24.setType((int) (byte) 10);
        boolean boolean45 = node8.isEquivalentTo(node24);
        com.google.javascript.rhino.Node node46 = node24.removeFirstChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(node46);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean5 = node4.wasEmptyNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, (int) (byte) 100);
        boolean boolean11 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = node4.copyInformationFromForTree(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) -1, node17);
        node17.setCharno((int) (byte) 10);
        com.google.javascript.rhino.Node node21 = node10.copyInformationFrom(node17);
        node10.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions24.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel27 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions24.sourceMapDetailLevel = detailLevel27;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.checkRequires;
        compilerOptions24.setProcessObjectPropertyString(true);
        compilerOptions24.unaliasableGlobals = "goog.exportSymbol";
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions34.checkMethods;
        compilerOptions34.inlineLocalFunctions = false;
        java.lang.RuntimeException runtimeException40 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) false, (java.lang.Object) compilerOptions24, (java.lang.Object) compilerOptions34);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel27);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException40);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        java.lang.String str5 = nodeTraversal2.getSourceName();
        boolean boolean6 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, true);
        com.google.javascript.rhino.Node node5 = compiler2.getRoot();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler2.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, sourceExcerpt7);
        try {
            compiler2.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) '4', (int) (byte) 0, (int) '#');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) -1, node4);
        node4.setCharno((int) (byte) 10);
        node4.detachChildren();
        node4.setCharno(19);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.instrumentationTemplate = "language version";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.strictMessageReplacement = false;
        compilerOptions0.locale = "language version";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Node tree inequality:\nTree1:\nNUMBER 52.0 0\n\n\nTree2:\nGT NUMBER 1.0 0\n\n\nSubtree1: NUMBER 52.0 0\n\n\nSubtree2: GT NUMBER 1.0 0\n", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing3 = compilerOptions0.getTweakProcessing();
        compilerOptions0.inlineGetters = false;
        boolean boolean6 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + tweakProcessing3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing3.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.moveFunctionDeclarations;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "language version");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 5, 0, diagnosticType7, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel11, "<No stack trace available>");
        diagnosticType7.level = checkLevel11;
        compilerOptions0.checkProvides = checkLevel11;
        boolean boolean16 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.debugFunctionSideEffectsPath = "-1";
        com.google.javascript.jscomp.CheckLevel checkLevel23 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.make("Unknown class name", checkLevel23, "EOF  0");
        compilerOptions0.checkUndefinedProperties = checkLevel23;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(2, "Named type with empty name component", 49, (int) (byte) 0);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("EOF ", "1b", (int) (byte) 1, "", 160);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        loggerErrorManager1.setTypedPercent((double) 'a');
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.moveFunctionDeclarations;
        compilerOptions5.removeUnusedLocalVars = false;
        compilerOptions5.recordFunctionInformation = true;
        java.lang.String str11 = compilerOptions5.nameReferenceReportPath;
        compilerOptions5.checkSymbols = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions5.checkRequires;
        com.google.javascript.jscomp.JSError jSError15 = null;
        loggerErrorManager1.println(checkLevel14, jSError15);
        loggerErrorManager1.setTypedPercent((double) 22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }
}

